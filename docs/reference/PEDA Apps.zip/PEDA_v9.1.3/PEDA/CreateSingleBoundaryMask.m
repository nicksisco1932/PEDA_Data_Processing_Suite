function outputMask = CreateSingleBoundaryMask(TxParameters, Radius)
outputMask = zeros(TxParameters.ImageResolution,TxParameters.ImageResolution,TxParameters.NumberSlices);

for sliceIdx = 1:12
    if size(Radius) == 1 % For UA and MTR mask
        [XMask,YMask] = pol2cart(TxParameters.ProstateBoundaryTheta*(pi/180),Radius);
    else % Prostate mask
        if TxParameters.isUAactive(sliceIdx)
            [XMask,YMask] = pol2cart(TxParameters.ProstateBoundaryTheta*(pi/180),Radius(:,sliceIdx));
        else
            [XMask,YMask] = pol2cart(TxParameters.ProstateBoundaryTheta*(pi/180),0); % 0 on non active slices
        end
    end
    outputMask(:,:,sliceIdx) = poly2mask(XMask+TxParameters.ux(end,sliceIdx),-YMask+TxParameters.uy(end,sliceIdx),TxParameters.ImageResolution,TxParameters.ImageResolution);
end

outputMask = logical(outputMask);
