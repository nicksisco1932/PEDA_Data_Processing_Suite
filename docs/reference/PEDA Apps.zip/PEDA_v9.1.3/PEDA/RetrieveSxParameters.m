function SxParameters = RetrieveSxParameters(dirName,segmentIdx,directory,varargin)
global PEDA_VERSION 
%==========================================================================
% Create folder structure
%==========================================================================
SxParameters.pathSessionFiles = dirName;
SxParameters.pathPEDA = fullfile(directory,filesep,['PEDA',PEDA_VERSION]);
SxParameters.pathData = fullfile(directory,filesep,['PEDA',PEDA_VERSION],filesep,['Segment ',num2str(segmentIdx)]);

if ~exist(SxParameters.pathData)
    mkdir(SxParameters.pathData)
end

if nargin < 4
    SxParameters.PatientID = char(regexp(SxParameters.pathData, '[0-9]+[0-9]+[0-9]+-+[0-9]+[0-9]+[0-9]', 'match'));
else
    SxParameters.PatientID = varargin{1};
end

%==========================================================================
% Load session files and find number of dynamics
%==========================================================================
%% First Loop through all of the info in InitializationData
InitializationData = ReadInitializationData(dirName);

% Parse Manufacturer Info
SxParameters.Manufacturer = strtrim(ParseInitializationData(InitializationData, 'MRI cartridge information - Name'));
% Parse software version
SxParameters.SoftwareVersion = strtrim(ParseInitializationData(InitializationData, 'Treatment controller version'));
SWVersion = cell2mat(textscan(strrep(SxParameters.SoftwareVersion,'.',' '),'%d'));

TreatmentControllerData =   readtable(fullfile(SxParameters.pathSessionFiles,'TreatmentControllerData.txt'), 'TreatAsEmpty',{'Pre-Treatment','NA','N/A'});
HardwareInfo =              readtable(fullfile(SxParameters.pathSessionFiles,'HardwareInfo.txt'),'TreatAsEmpty',{'Pre-Treatment','NA','N/A'});

fid = fopen(fullfile(SxParameters.pathSessionFiles,'TreatmentControllerInfo.txt')); 

if SWVersion(2) < 7 ||  SWVersion(2) == 7 && SWVersion(4) < 2617
    Header = textscan(fid,'%s',15,'delimiter','\t');
    TreatmentControllerInfo = textscan(fid,'%f %d %s %s %f %f %f %f %f %f %f %f %f %f %s','delimiter','\t','TreatAsEmpty', {'N/A','Pre-Treatment'});
else
    if SWVersion(2) < 10 && SWVersion(4) >= 2617 
        Header = textscan(fid,'%s',14,'delimiter','\t');
        TreatmentControllerInfo = textscan(fid,'%f %d %s %s %f %f %f %f %f %f %f %f %f %f','delimiter','\t','TreatAsEmpty', {'N/A','Pre-Treatment'});
    else
        if SWVersion(2) >= 10
            Header = textscan(fid,'%s',17,'delimiter','\t');
            TreatmentControllerInfo = textscan(fid,'%f %d %d %s %s %s %f %f %f %d %f %f %f %f %f %f %f','delimiter','\t','TreatAsEmpty', {'N/A','Pre-Treatment'});
        else
       % place holder for readtable 
        end
    end
end
        

HardwareInfo = CheckTableContinuity(HardwareInfo,'HardwareInfo');
TreatmentControllerData = CheckTableContinuity(TreatmentControllerData,'TreatmentControllerData');
TreatmentControllerInfo = CheckTreatmentControllerInfoContinuity(TreatmentControllerInfo);
[HardwareInfo,TreatmentControllerInfo,TreatmentControllerData] = TrimData(HardwareInfo,TreatmentControllerInfo,TreatmentControllerData, SxParameters.pathSessionFiles, SWVersion);

save(fullfile(SxParameters.pathData,'TreatmentControllerData.mat'),'TreatmentControllerData')
save(fullfile(SxParameters.pathData,'HardwareInfo.mat'),'HardwareInfo');
save(fullfile(SxParameters.pathData,'TreatmentControllerInfo.mat'),'TreatmentControllerInfo','Header')

%% Determine which UA elements are active
% SxParameters.SliceThickness =                           str2double(ParseInitializationData(InitializationData, 'Slice Thickness'));
SxParameters.SliceThickness =                           5; % hard-coded for now until TDC-4721 is fixed
SxParameters.ImageResolution =                          str2double(ParseInitializationData(InitializationData, 'Image Resolution'));
SxParameters.FOV =                                      str2double(ParseInitializationData(InitializationData, 'Frequency Encode Field-of-View'));
imageSize =                                             sscanf(ParseInitializationData(InitializationData, 'Number of Rows and Columns of Data'),'%d x %d');
SxParameters.NumberOfRows =                             imageSize(1);
SxParameters.NumberOfCols =                             imageSize(2);
SxParameters.NumberSlices =                             str2double(ParseInitializationData(InitializationData, 'Number of Slices'));
SxParameters.Tc =                                       str2double(ParseInitializationData(InitializationData, 'Control temperature'));
SxParameters.Tb =                                       str2double(ParseInitializationData(InitializationData, 'Patient temperature'));
SxParameters.InitialRotationDirection =                 strtrim(ParseInitializationData(InitializationData, 'Rotary rotation direction'));
SxParameters.MRCenterFrequency =                        strtrim(ParseInitializationData(InitializationData, 'MR Center Frequency'));
SxParameters.PixelSize =                                SxParameters.FOV/SxParameters.ImageResolution;
SxParameters.ThermalDoseThreshold = 43;
SxParameters.ThermalDoseCEM = 240;
SxParameters.MinimumTreatmentRadiusMM =                 str2double(ParseInitializationData(InitializationData, 'Minimum treatment radius'))-2;%%Fix for TS-301 - script subtracts 2 because the Minimum treatment radius in TDC refers to Prostate boundary but for PEDA, it refers to the Control Boundary
SxParameters.MinimumTreatmentRadius =                   SxParameters.MinimumTreatmentRadiusMM/SxParameters.PixelSize;
SxParameters.MaximumTreatmentRadiusMM = 28;
SxParameters.MaximumTreatmentRadius =                   SxParameters.MaximumTreatmentRadiusMM/SxParameters.PixelSize;
SxParameters.UARadiusMM = 4;
SxParameters.UARadius =                                 SxParameters.UARadiusMM/SxParameters.PixelSize;
SxParameters.StabilityThreshold = 10;
SxParameters.TUVThreshold = 2; 

%% Retrieve PS Position Version (2.6 and higher) and TemperatureApprochingBoiling (2.6.3 and higher)
if SWVersion(2) > 5
    SxParameters.PSposition = strtrim(ParseInitializationData(InitializationData, 'PS position'));
end

try
    SxParameters.ApproachingBoilingThreshold = TreatmentControllerData.TemperatureApproachingBoilingLevelThreshold;
catch
    %fprintf('Couldn''t find ApproachingBoilingThreshold variable in logs. Defaulting to 86�')
    try
        SxParameters.ApproachingBoilingThreshold = repmat(86,1,TreatmentControllerData.MriDynamicNumber(end));
    catch
        SxParameters.ApproachingBoilingThreshold = repmat(86,1,TreatmentControllerData.ImageNumber(end));
    end
end

%% Third Loop through all of the info in Treatment Controller Data
SxParameters.ImageTime = TreatmentControllerData.ElapsedTime_sec;
if iscell(SxParameters.ImageTime)
    SxParameters.ImageTime = double(string(SxParameters.ImageTime));
end
SxParameters.ImageTime(isnan(SxParameters.ImageTime)) = 0;
SxParameters.NumRefImages = 5;
SxParameters.ImageNumber = TreatmentControllerData{:,2} + 1;
SxParameters.ThermAngle = TreatmentControllerData.ControlAngle_deg;
SxParameters.UnwoundThermAngle = UnwindAngle(SxParameters.ThermAngle);

%% Retrieve Prostate and Control Boundary
index_boundary = find(not(cellfun('isempty', strfind(InitializationData, 'Radius_mm')))); %includes both Prostate and Control Boundaries
index_boundaryChange = find(not(cellfun('isempty', regexp(InitializationData, 'CurrentDynamicNumber:.[0-9]+$'))));
numberOfSubSegments = length(index_boundary)/2;
index_boundary = reshape(index_boundary,2,numberOfSubSegments)';

if numberOfSubSegments > 1 && SWVersion(2) > 6
    index_boundaryChange = reshape(index_boundaryChange,2,numberOfSubSegments)'; 
    SxParameters.SubSegmentImageNumber = 1;
else
    SxParameters.SubSegmentImageNumber = [1 SxParameters.ImageNumber(end)];
    numberOfSubSegments = 1;
end

for boundaryIdx = 1:numberOfSubSegments
    L1 = [1:10*360*3] + index_boundary(boundaryIdx,1);
    L2 = [1:10*360*3] + index_boundary(boundaryIdx,2);
    if isempty(index_boundaryChange)
        temp = InitializationData{index_boundary(boundaryIdx,1)};
    else
        temp = InitializationData{index_boundaryChange(boundaryIdx,1)};
    end
    
    Index = L1(1):3:L1(end);
    Index2 = L2(1):3:L2(end);
    
    for angleIdx = 1:length(L1)/3
        ProstateBoundary_temp(angleIdx,:) = [str2double(InitializationData{Index(angleIdx)}) str2double(InitializationData{Index(angleIdx)+1}) str2double(InitializationData{Index(angleIdx)+2})];
        ControlBoundary_temp(angleIdx,:) = [str2double(InitializationData{Index(angleIdx)}) str2double(InitializationData{Index2(angleIdx)+1}) str2double(InitializationData{Index2(angleIdx)+2})];
    end
    SxParameters.ProstateBoundaryTheta(:,:) = ProstateBoundary_temp(1:360,2);
    SxParameters.ProstateBoundaryMM(:,:,boundaryIdx) = [zeros(360,1),reshape(ProstateBoundary_temp(:,3),[360 10]),zeros(360,1)];
    SxParameters.ProstateBoundary(:,:,boundaryIdx) = SxParameters.ProstateBoundaryMM(:,:,boundaryIdx)/SxParameters.PixelSize;
    SxParameters.ControlBoundaryTheta(:,:) = ControlBoundary_temp(1:360,2);
    SxParameters.ControlBoundaryMM(:,:,boundaryIdx) = [zeros(360,1),reshape(ControlBoundary_temp(:,3),[360 10]),zeros(360,1)];
    SxParameters.ControlBoundary(:,:,boundaryIdx) = SxParameters.ControlBoundaryMM(:,:,boundaryIdx)/SxParameters.PixelSize;
    if numberOfSubSegments > 1
        SxParameters.SubSegmentImageNumber(boundaryIdx) = str2double(temp(strfind(temp,':')+1:end)) + 1; %TDC is zero-based
    end
end

if numberOfSubSegments > 1
    % Remove any redundancies due to cancelling during DeliveryInitialization
    [SxParameters.SubSegmentImageNumber, uniqueIdx, ~] = unique(SxParameters.SubSegmentImageNumber,'legacy');
    SxParameters.ProstateBoundaryMM = SxParameters.ProstateBoundaryMM(:,:,uniqueIdx);
    SxParameters.ProstateBoundary   = SxParameters.ProstateBoundary(:,:,uniqueIdx);
    SxParameters.ControlBoundaryMM  = SxParameters.ControlBoundaryMM(:,:,uniqueIdx);
    SxParameters.ControlBoundary    = SxParameters.ControlBoundary(:,:,uniqueIdx);
    
    SxParameters.SubSegmentImageNumber(end+1) = SxParameters.ImageNumber(end);
    if isnan(SxParameters.SubSegmentImageNumber(1))
        SxParameters.SubSegmentImageNumber(1) = 1;
    end
    SxParameters.SubSegmentImageNumber(isnan(SxParameters.SubSegmentImageNumber)) = [];
    [SxParameters.TreatedSector, SxParameters.Combined.TreatedSector] = GetTreatedSectorSubsegment(SxParameters.ThermAngle,SxParameters.SubSegmentImageNumber,SxParameters.ImageNumber);
else
    SxParameters.TreatedSector = GetTreatedSector(SxParameters.ThermAngle);
    SxParameters.Combined = []; % have to declare this field for uniformity when combining SxParameters
end

%% Fourth Retrieve UA center
if sum(strcmp('UACenterInPixelsX_E1',TreatmentControllerData.Properties.VariableNames))
    SxParameters.ux = [TreatmentControllerData.UACenterInPixelsX_Apex TreatmentControllerData.UACenterInPixelsX_E1 TreatmentControllerData.UACenterInPixelsX_E2 TreatmentControllerData.UACenterInPixelsX_E3 TreatmentControllerData.UACenterInPixelsX_E4 TreatmentControllerData.UACenterInPixelsX_E5 TreatmentControllerData.UACenterInPixelsX_E6 TreatmentControllerData.UACenterInPixelsX_E7 TreatmentControllerData.UACenterInPixelsX_E8 TreatmentControllerData.UACenterInPixelsX_E9 TreatmentControllerData.UACenterInPixelsX_E10 TreatmentControllerData.UACenterInPixelsX_Base]+0.5;
    SxParameters.uy = [TreatmentControllerData.UACenterInPixelsY_Apex TreatmentControllerData.UACenterInPixelsY_E1 TreatmentControllerData.UACenterInPixelsY_E2 TreatmentControllerData.UACenterInPixelsY_E3 TreatmentControllerData.UACenterInPixelsY_E4 TreatmentControllerData.UACenterInPixelsY_E5 TreatmentControllerData.UACenterInPixelsY_E6 TreatmentControllerData.UACenterInPixelsY_E7 TreatmentControllerData.UACenterInPixelsY_E8 TreatmentControllerData.UACenterInPixelsY_E9 TreatmentControllerData.UACenterInPixelsY_E10 TreatmentControllerData.UACenterInPixelsY_Base]+0.5; 
else
    % backward compatible with PEDA
    index_ua = find(not(cellfun('isempty', strfind(InitializationData, 'Urethra Center'))));
    temp = InitializationData{index_ua};
    temp2 = strfind(temp,'X');
    UAcoordinates = sscanf(temp(temp2:end),'X: %g, Y: %g');
    SxParameters.ux = repmat(UAcoordinates(1) + 0.5,size(SxParameters.ImageNumber,1),12);
    SxParameters.uy = repmat(UAcoordinates(2) + 0.5,size(SxParameters.ImageNumber,1),12);
end

% only save for the UA coordinates at start of treatment (SxParameters structure would be too large if saved for every dyn)
for sliceIdx = 1:size(SxParameters.ProstateBoundary,2)
    for subSegmentIdx = 1:size(SxParameters.ProstateBoundary,3)
        [X_ProstateBoundary,Y_ProstateBoundary] = toCartesian(SxParameters.ProstateBoundary(:,sliceIdx,subSegmentIdx));
        [X_ControlBoundary, Y_ControlBoundary] =  toCartesian(SxParameters.ControlBoundary(:,sliceIdx,subSegmentIdx));
        if numberOfSubSegments > 1
            subSegmentImageNumber = find(SxParameters.ImageNumber == SxParameters.SubSegmentImageNumber(subSegmentIdx+1)); % UA center defined at ImageShifted center at time of treatment when Boundary was Modified
        else
            subSegmentImageNumber = length(SxParameters.ImageNumber); %end of segment
        end
        X_ProstateBoundary =  X_ProstateBoundary + SxParameters.ux(subSegmentImageNumber,sliceIdx);
        Y_ProstateBoundary = -Y_ProstateBoundary + SxParameters.uy(subSegmentImageNumber,sliceIdx);
        X_ControlBoundary =   X_ControlBoundary  + SxParameters.ux(subSegmentImageNumber,sliceIdx);
        Y_ControlBoundary =  -Y_ControlBoundary  + SxParameters.uy(subSegmentImageNumber,sliceIdx);
        SxParameters.ProstateBoundaryXY(:,:,sliceIdx,subSegmentIdx) = [X_ProstateBoundary,Y_ProstateBoundary];
        SxParameters.ControlBoundaryXY(:,:,sliceIdx,subSegmentIdx) =  [X_ControlBoundary,Y_ControlBoundary];
    end
end

% create combined subsegment boundaries if boundary was modified
if numberOfSubSegments > 1
    [SxParameters.Combined.ProstateBoundary, SxParameters.Combined.ControlBoundary, SxParameters.Combined.ProstateBoundaryXY, SxParameters.Combined.ControlBoundaryXY] = CombineBoundaries(SxParameters);
    SxParameters.Combined.ProstateBoundaryMM = SxParameters.Combined.ProstateBoundary.*SxParameters.PixelSize;
    SxParameters.Combined.ControlBoundaryMM = SxParameters.Combined.ControlBoundary.*SxParameters.PixelSize;
end

%% Retrieve UA calibration data
% TS-206
UAcalibration = ReadUAcalibration(dirName);

SxParameters.UA.Schema =        	str2num(ParseInitializationData(UAcalibration, 'Schema'));
SxParameters.UA.SerialNumber =    	strtrim(ParseInitializationData(UAcalibration, 'Serial Number'));
SxParameters.UA.ProductionDate =	strtrim(ParseInitializationData(UAcalibration, 'Production Date'));
SxParameters.UA.LowFrequency =  	str2num(ParseInitializationData(UAcalibration, 'Common Low Frequency'));
SxParameters.UA.HighFrequency = 	str2num(ParseInitializationData(UAcalibration, 'Common High Frequency'));
SxParameters.UA.BeamAlign =         str2num(ParseInitializationData(UAcalibration, 'Beam Align Degrees'));

if SxParameters.UA.Schema == 1
    offset_low = find(not(cellfun('isempty', strfind(UAcalibration,'Efficiency - Low Frequencies:'))));
    offset_high = find(not(cellfun('isempty', strfind(UAcalibration,'Efficiency - High Frequencies:'))));
    
    if SWVersion(1) == 2 && SWVersion(2) < 9
        SxParameters.UA.LowFrequencyEfficiency =    cellfun(@str2num, {UAcalibration{(1:10) + offset_low + 12}});
        SxParameters.UA.HighFrequencyEfficiency =   cellfun(@str2num, {UAcalibration{(1:10) + offset_high + 12}});
    elseif SWVersion(1) == 2 && SWVersion(2) == 9 && SWVersion(3) >= 0 && SWVersion(4) >= 4847
        SxParameters.UA.LowFrequencyEfficiency =    cellfun(@str2num, {UAcalibration{(1:10) + offset_low}});
        SxParameters.UA.HighFrequencyEfficiency =   cellfun(@str2num, {UAcalibration{(1:10) + offset_high}});
    else
        SxParameters.UA.LowFrequencyEfficiency =    [];
        SxParameters.UA.HighFrequencyEfficiency =   [];
    end
else
    SxParameters.UA.LowFrequencyEfficiency =    [];
    SxParameters.UA.HighFrequencyEfficiency =   [];
%     warning('UA efficiencies not saved')
end

%% Retrieve Hardware Logs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% find each entry with a unique ImageNumber
HardwareInfo = HardwareInfo(~isnan(HardwareInfo.ElapsedTime_sec),:);
[~,HardwareInfoIdx,~] = unique(HardwareInfo{:,2},'legacy'); %legacy argument finds last instance of unique elements (which is equivalent to TreatmentControlllerData)
HardwareInfoIdx = HardwareInfoIdx(HardwareInfo{:,2}(HardwareInfoIdx)>23);

SxParameters.IsElementEnabled = false(length(HardwareInfoIdx), 10);
SxParameters.IsElementEnabled(:,1) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E1(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,2) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E2(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,3) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E3(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,4) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E4(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,5) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E5(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,6) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E6(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,7) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E7(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,8) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E8(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,9) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E9(HardwareInfoIdx));
SxParameters.IsElementEnabled(:,10) = cellfun(@(x) strcmpi('True', x), HardwareInfo.IsActive_E10(HardwareInfoIdx));

SxParameters.IsPaused = repmat(cellfun(@(x) strcmpi('Paused', x), TreatmentControllerData.TreatmentState),1,10);
try
    SxParameters.IsElementEnabled = SxParameters.IsElementEnabled & ~SxParameters.IsPaused;
catch
    warning('SxParameters.IsElementEnabled is not corrected to reflect when user Paused TDC')
end
SxParameters.IsPaused = padarray(SxParameters.IsPaused, [0 1], 0); % zeropad M0 and M11 columns
SxParameters.IsElementEnabled = padarray(SxParameters.IsElementEnabled, [0 1], 0); % zeropad M0 and M11 columns
SxParameters.isUAactive = any(SxParameters.IsElementEnabled);

HardwareInfo = HardwareInfo(~isnan(HardwareInfo.ElapsedTime_sec),:);
elementFrequencies  = [ HardwareInfo.Frequency_E1 HardwareInfo.Frequency_E2 HardwareInfo.Frequency_E3 HardwareInfo.Frequency_E4...
                        HardwareInfo.Frequency_E5 HardwareInfo.Frequency_E6 HardwareInfo.Frequency_E7 HardwareInfo.Frequency_E8...
                        HardwareInfo.Frequency_E9 HardwareInfo.Frequency_E10];
elementPowers       = [ HardwareInfo.PowerNetWa_E1 HardwareInfo.PowerNetWa_E2 HardwareInfo.PowerNetWa_E3 HardwareInfo.PowerNetWa_E4...
                        HardwareInfo.PowerNetWa_E5 HardwareInfo.PowerNetWa_E6 HardwareInfo.PowerNetWa_E7 HardwareInfo.PowerNetWa_E8...
                        HardwareInfo.PowerNetWa_E9 HardwareInfo.PowerNetWa_E10];

SxParameters.elementFrequencies = padarray(elementFrequencies(HardwareInfoIdx,:), [0 1], 0);
SxParameters.elementPowers = padarray(elementPowers(HardwareInfoIdx,:), [0 1], 0);
PSPositionDeg_Desired = HardwareInfo.PSPositionDeg_Desired(HardwareInfoIdx);
SxParameters.RotationDirection = cell(length(HardwareInfoIdx),1);
SxParameters.RotationDirection(PSPositionDeg_Desired > 1) = {'Counterclockwise'};
SxParameters.RotationDirection(PSPositionDeg_Desired < 1) = {'Clockwise'};

%% Identify Thermal Boosted Element (2.10 and higher)
if SWVersion(1) >= 2 && SWVersion(2) >= 10
    
    % Initialize variables that are a function of dynamic
    NumImages = length(SxParameters.ImageNumber);
    NumElements = SxParameters.NumberSlices - 2;
    ControllerStateString = TreatmentControllerInfo{1,5}; %element state ['Disabled', 'Enabled', 'Boosted']
    ControllerState = zeros(size(ControllerStateString));
    ControllerState(cellfun(@(x) strcmpi(x,'Disabled'), ControllerStateString)) = 0;
    ControllerState(cellfun(@(x) strcmpi(x,'Enabled'), ControllerStateString)) = 1;
    ControllerState(cellfun(@(x) strcmpi(x,'Boosted'), ControllerStateString)) = 2;
    ControllerState = reshape(ControllerState,NumElements,NumImages);
    ControllerState = padarray(ControllerState', [0 1], 0); % zeropad M0 and M11 columns
   
    % Initialize variables that are a function of angle
    SxParameters.ThermalBoostInfo.TreatmentState = zeros(360, 12);
    SxParameters.ThermalBoostInfo.ControlBoundaryMM = ones(360, 12)*SxParameters.MinimumTreatmentRadiusMM;
    
    % Cell elements defined from 0:359, as with Sxparameters.ThermAngle
    AnglesTreatedPerDyn = cell(NumImages,12);

    % Number of dyns to use in smoothing function.  This is set to 1 (i.e. no smoothing) for now
    WindowLength = 1;
    
    % Find all angles that were treated by each UA element on each dynamic, and save their corresponding treatment state (Disabled/Enabled/Boosted)
    for sliceIdx = 1:12
        if SxParameters.isUAactive(sliceIdx)
            IsPowerOn = movmean( strcmpi(TreatmentControllerData.TreatmentState,'Delivery') & SxParameters.IsElementEnabled(:,sliceIdx) , WindowLength) > 0;
            for dynIdx = 3:length(SxParameters.ImageTime) %would normally start at 2 since this is a loop over time differences, but the first dyn is skipped since the UA rotates at 120 dpm on the first dyn 
                if IsPowerOn(dynIdx)
                    % Find the angles spanned in this dynamic (unwrap if crossing 359)
                    StartAndEndAngles = [round(SxParameters.ThermAngle(dynIdx-1))  round(SxParameters.ThermAngle(dynIdx)) ];
                    % Assumes UA is rotating in the CW direction
                    AnglesTreatedPerDyn{dynIdx-1,sliceIdx} = min(StartAndEndAngles):1:max(StartAndEndAngles);
                    % If there are more than 180 degrees spanned CW, assume rotation is in the CCW direction
                    if numel(AnglesTreatedPerDyn{dynIdx-1,sliceIdx}) > 180
                        AnglesTreatedPerDyn{dynIdx-1,sliceIdx} = [ 0:1:min(StartAndEndAngles) max(StartAndEndAngles):1:359 ];            
                    end
                end
            end
        end
    end
    
    % Loop through each angle and find all instances (dynamics) in which it was treated.  Rank the instances first based on largest target radius, and then on treatment state.  Assign the target radius and treatment state with the highest rank.
    for sliceIdx = 1:12
        if SxParameters.isUAactive(sliceIdx)
            for angleIdx = 1:360
                currentControlBoundaryMM = [];
                if angleIdx==360
                    rowsWithTreatedAngle = find(cellfun(@(x) ismember(0,x), AnglesTreatedPerDyn(:,sliceIdx)));
                else
                    rowsWithTreatedAngle = find(cellfun(@(x) ismember(angleIdx-1,x), AnglesTreatedPerDyn(:,sliceIdx)));
                end
                if ~isempty(rowsWithTreatedAngle)
                    currentStates = ControllerState(rowsWithTreatedAngle,sliceIdx);
                    currentSubSegments = getSubSegment(SxParameters.ImageNumber(rowsWithTreatedAngle), SxParameters.SubSegmentImageNumber);
                    for rowIdx = 1:length(rowsWithTreatedAngle)
                        currentControlBoundaryMM(rowIdx) = SxParameters.ControlBoundaryMM(angleIdx,sliceIdx,currentSubSegments(rowIdx));
                    end
                    % Remove any instances of the element being disabled.
                    enabledIdx = currentStates > 0;
                    currentControlBoundaryMM = currentControlBoundaryMM(enabledIdx);
                    currentStates = currentStates(enabledIdx);
                    if isempty(currentStates)
                        % If it was always disabled, then assign TreatmentState to 0 and ControlBoundaryMM to MTR
                        SxParameters.ThermalBoostInfo.TreatmentState(angleIdx,sliceIdx) = 0;
                        SxParameters.ThermalBoostInfo.ControlBoundaryMM(angleIdx,sliceIdx) = SxParameters.MinimumTreatmentRadiusMM;
                    else
                        % Apply ranking of Max radius, then treatment controller state
                        [~, rankIdx] = sortrows([currentControlBoundaryMM; currentStates']', [1 2], 'descend');
                        SxParameters.ThermalBoostInfo.TreatmentState(angleIdx,sliceIdx) = currentStates(rankIdx(1));
                        SxParameters.ThermalBoostInfo.ControlBoundaryMM(angleIdx,sliceIdx) = currentControlBoundaryMM(rankIdx(1));
                    end
                end
            end
        end
    end
    
    % Determine amount of time spent with Thermal Boost enabled and its angular extent.  The extent of these metrics is recorded as long as one of the active elements have Thermal Boost enabled.
    dynamicIdxWithThermalBoost = any(ControllerState==2,2);
    timeElapsedPerDynamic_sec = [0; diff(SxParameters.ImageTime)];
    SxParameters.ThermalBoostInfo.ElapsedTime_sec = sum(timeElapsedPerDynamic_sec(dynamicIdxWithThermalBoost));
end  

%% Save Tx Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if exist(fullfile(SxParameters.pathPEDA,'SxParameters.mat')) && segmentIdx > 1
    currentSxParameters = SxParameters;
    load(fullfile(SxParameters.pathPEDA,'SxParameters.mat'))
    SxParameters(segmentIdx) = currentSxParameters;
end
save(fullfile(SxParameters(segmentIdx).pathPEDA,'SxParameters.mat'),'SxParameters')

% Return only the current SxParameters and not the whole structure
SxParameters = SxParameters(segmentIdx);

end

function result = ParseInitializationData(file_contents, search_string)
index = find(not(cellfun('isempty', strfind(file_contents, search_string))));
temp = file_contents{index};
result = temp(strfind(temp,':')+1:end);
end

function InitializationData = ReadInitializationData(dirName)
fclose('all');
fid = fopen(fullfile(dirName,'InitializationData.txt'));
temp = textscan(fid,'%s','delimiter','\t');
InitializationData = temp{1,1};
end

function UAcalibration = ReadUAcalibration(dirName)
fclose('all');
fid = fopen(fullfile(dirName,'HardwareUACalibrationData0.txt'));
temp = textscan(fid,'%s','delimiter','\t');
UAcalibration = temp{1,1};
end

function FixedTable = CheckTableContinuity(Table, TableName)
% It is possible (but unlikely) for HardwareInfo to have missing dyns if 
% TDC is busy or the network has high traffic.  This function will find the
% discontinuities and instead of inserting a dummy row, it will simply
% replace the field ImageNumber on the row before the discontinuity with
% the missing dyn.  It will only try to correct in cases when 1 dyn was
% skipped
[~,Idx,~] = unique(Table{:,2},'legacy');
ImageNumber = Table{:,2}(Idx);
MissingImageNumbers = setdiff(24:ImageNumber(end),ImageNumber);

if isempty(MissingImageNumbers)
    FixedTable = Table; %No changes
    return
end

MissingDynGap = diff(setdiff(MissingImageNumbers(1)-1:MissingImageNumbers(end)+1,MissingImageNumbers));

if any(MissingDynGap(MissingDynGap>2))
    error(['There was an instance in ',TableName,' with 2 or more consecutive dynamics missing.  Aborting PEDA.'])
end

if sum(ismember(Table.Properties.VariableNames, 'ImageNumber')) ~= 1
    Table.Properties.VariableNames{'TdcDynamicNumber'} = 'ImageNumber';
end

for missingIdx = 1:length(MissingDynGap)
    MissingIdx = find(Table.ImageNumber == MissingImageNumbers(missingIdx)+1);
    duplicateLine = Table(MissingIdx-1,:);
    duplicateLine.ImageNumber = MissingImageNumbers(missingIdx);
    FixedTable = [Table(1:MissingIdx,:);
                        duplicateLine;
                        Table(MissingIdx+1:end,:)];
    warning(['ImageNumber ' num2str(MissingImageNumbers(missingIdx)) ' was missing in ', TableName])
end

% Check for continuity again
[~,HardwareInfoIdx,~] = unique(FixedTable.ImageNumber,'legacy');
ImageNumber = FixedTable.ImageNumber(HardwareInfoIdx);
MissingImageNumbers = setdiff(ImageNumber(1):ImageNumber(end),ImageNumber);

if ~isempty(MissingImageNumbers)
    error(['Attempted to fix ', TableName,' with missing dynamics but failed.  Aborting PEDA.'])
end

end

function TreatmentControllerInfo = CheckTreatmentControllerInfoContinuity(TreatmentControllerInfo)
% Similar to CheckHardwareInfoContinuity except for TreatmentControllerInfo 

NumElements = 10;
ImageNumber = TreatmentControllerInfo{:,2};
MissingImageNumbers = setdiff(ImageNumber(1):ImageNumber(end),ImageNumber);

if isempty(MissingImageNumbers)
    return
elseif length(MissingImageNumbers) > 1
    error(['There was more than one instance in TreatmentControllerInfo with dynamics missing.  Aborting PEDA.'])
end

MissingDynGap = diff(setdiff(MissingImageNumbers(1)-1:MissingImageNumbers(end)+1,MissingImageNumbers));

if any(MissingDynGap(MissingDynGap>2))
    error(['There was an instance in TreatmentControllerInfo with 2 or more consecutive dynamics missing.  Aborting PEDA.'])
end

for missingIdx = 1:length(MissingDynGap)
    MissingIdxForward = find(ImageNumber == MissingImageNumbers(missingIdx)+1);
    MissingIdxBackward = find(ImageNumber == MissingImageNumbers(missingIdx)-1);

    if length(MissingIdxForward) == 2*NumElements % Has two instances of MissingImageNumber + 1, simply fix ImageNumber field by replacement
        TreatmentControllerInfo{MissingIdxForward(1):MissingIdxForward(NumElements),2};
    elseif length(MissingIdxBackward) == 2*NumElements % Has two instances of MissingImageNumber - 1, simply fix ImageNumber field by replacement
        TreatmentControllerInfo{MissingIdxForward(NumElements)+1:MissingIdxForward(end),2};
    elseif length(MissingIdxForward) == NumElements && length(MissingIdxBackward) == NumElements % Completely missing data, have to insert data into structure
        TreatmentControllerInfoNew = cell(1,length(TreatmentControllerInfo));
        for TreatmentControllerInfoIdx = 1:length(TreatmentControllerInfo)
            TreatmentControllerInfoIdxEnd = length(TreatmentControllerInfo{:,1});
            if ~iscell(TreatmentControllerInfo{1,TreatmentControllerInfoIdx})
                TreatmentControllerInfoNew{:,TreatmentControllerInfoIdx} = cat(1,TreatmentControllerInfo{1,TreatmentControllerInfoIdx}(1:MissingIdxBackward(end)),...
                                                                             TreatmentControllerInfo{1,TreatmentControllerInfoIdx}([1:NumElements]+MissingIdxBackward(end)),...
                                                                             TreatmentControllerInfo{1,TreatmentControllerInfoIdx}(MissingIdxForward(1):TreatmentControllerInfoIdxEnd));
            else
                TreatmentControllerInfoNew{:,TreatmentControllerInfoIdx} = {TreatmentControllerInfo{1,TreatmentControllerInfoIdx}{1:MissingIdxBackward(end)},...
                                                                             TreatmentControllerInfo{1,TreatmentControllerInfoIdx}{[1:NumElements]+MissingIdxBackward(end)},...
                                                                             TreatmentControllerInfo{1,TreatmentControllerInfoIdx}{MissingIdxForward(1):TreatmentControllerInfoIdxEnd}};                
            end
        end
        TreatmentControllerInfo = TreatmentControllerInfoNew;
    else
        error(['Missing ImageNumber ' num2str(MissingImageNumbers) ' was not simply missing all element information, or written as the ImageNumber just prior to or after it.  Aborting PEDA.'])
    end

    warning(['ImageNumber ' num2str(MissingImageNumbers(missingIdx)) ' was missing in TreatmentControllerInfo'])
end

end

function [HardwareInfo,TreatmentControllerInfo,TreatmentControllerData] = TrimData(HardwareInfo,TreatmentControllerInfo,TreatmentControllerData, pathToSessionFiles, SWVersion)
% We want to find the minimum number of dynamics that can be found. 
% There are 4 different "locations": HardwareInfo, TreatmentControllerInfo, TreatmentControllerData, and the Thermometry Folder

HWInfoNbOfDyns = HardwareInfo{:,2}(HardwareInfo{:,2} > 23); % Has to be hard-coded because ImageNumber has not been loaded yet. DardwareInfo.ImageNumber is zero-based here
HWInfoNbOfDyns = HWInfoNbOfDyns(end);
TreatmentControllerDataNbOfDyns = TreatmentControllerData{:,2}(end);
TreatmentControllerInfoNbOfDyns = TreatmentControllerInfo{:,2}(end);

thermometryFiles = dir(fullfile(pathToSessionFiles,'Thermometry\*Curr*'));
parsedLastFile = textscan(thermometryFiles(end).name,'i%4d-s%2d-%s');

NbOfDynsBeforePostTreatment = min([HWInfoNbOfDyns,TreatmentControllerDataNbOfDyns,TreatmentControllerInfoNbOfDyns,parsedLastFile{1}]);

% Prior to TDC 2.9, [TCD, TCI, HWI] started at ImageNumber 24.  After,
% [TCD, TCI] start at ImageNumber 5 while HWI starts at ImageNumber 24.
% HWI also ends once RF stops (i.e during cool-down) while [TCD. TCI]
% continue logging
if SWVersion(1) == 2 && SWVersion(2) < 9
    TreatmentControllerInfoLastDynIdx = find(TreatmentControllerInfo{:,2} == NbOfDynsBeforePostTreatment,1,'last');
else
    TreatmentControllerData.ElapsedTime_sec = double(string(TreatmentControllerData.ElapsedTime_sec));
    TreatmentControllerData = TreatmentControllerData(~isnan(TreatmentControllerData.ElapsedTime_sec),:);
    
    TreatmentControllerInfo = cellfun(@(mycell) mycell(~isnan(TreatmentControllerInfo{1,1})),TreatmentControllerInfo,'UniformOutput',false);
    TreatmentControllerInfoLastDynIdx = find(TreatmentControllerInfo{:,2} == NbOfDynsBeforePostTreatment,1,'last');
end
TreatmentControllerData = TreatmentControllerData(1:NbOfDynsBeforePostTreatment-23,:);
TreatmentControllerInfo = cellfun(@(mycell) mycell(1:TreatmentControllerInfoLastDynIdx),TreatmentControllerInfo,'UniformOutput',false);
HardwareInfoLastDynIdx = find(HardwareInfo{:,2} == NbOfDynsBeforePostTreatment,1,'last');
HardwareInfo = HardwareInfo(1:HardwareInfoLastDynIdx,:);

end

function subSegment = getSubSegment(dynIdx,SxSubSegmentImageNumber)
% For a given number of dynamics, returns which subsegement they belong to
subSegment = zeros(length(dynIdx),1);
for idx = 1:length(dynIdx)
    subSegment(idx) = find(dynIdx(idx)-SxSubSegmentImageNumber < 0,1) - 1;
end
end

