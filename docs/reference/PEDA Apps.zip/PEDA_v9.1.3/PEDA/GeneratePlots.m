function GeneratePlots(TMapTDose, Mask, TxParameters, isothermRadius)
%==========================================================================
% Purpose:  plots masked TMax or TDose, with target boundary, prostate
% boundary and isotherm radii
%
% Inputs:
%      - TMapTDose = matrix to be displayed.
%      - TxParameters
%      - isothermRadius
%==========================================================================

%==========================================================================
% ----- Variable initialization -----
%==========================================================================
% For backward compatibility
if iscell(TMapTDose)
    for i = 1:TxParameters.NumberSlices
        TMapTDoseMatrix(:,:,i) = TMapTDose{i};
    end
    clear TMapTDose;
    TMapTDose = TMapTDoseMatrix;
end

% Retrieve UA center and isotherms
[X_UA,Y_UA] = toCartesian(TxParameters.UARadius);
UACenterX = TxParameters.ux(end,:);
UACenterY = TxParameters.uy(end,:);

if ~isempty(TxParameters.Combined)
    [XControl, YControl] = toCartesian(TxParameters.Combined.ControlBoundary);
    [XProstate, YProstate] = toCartesian(TxParameters.Combined.ProstateBoundary);   
    if length(TxParameters.Combined.TreatedSector) == 360
        X_isotherm = zeros(length(TxParameters.Combined.TreatedSector)+1,TxParameters.NumberSlices);
        Y_isotherm = zeros(length(TxParameters.Combined.TreatedSector)+1,TxParameters.NumberSlices);
    else
        X_isotherm = zeros(length(TxParameters.Combined.TreatedSector),TxParameters.NumberSlices);
        Y_isotherm = zeros(length(TxParameters.Combined.TreatedSector),TxParameters.NumberSlices);
    end
    for sliceIdx = 1:length(TxParameters.isUAactive)
        if TxParameters.isUAactive(sliceIdx) == 1
            [X_isotherm(:,sliceIdx),Y_isotherm(:,sliceIdx)] = toCartesian(isothermRadius(:,sliceIdx),TxParameters.Combined.TreatedSector);
        end
    end
else
    [XControl, YControl] = toCartesian(TxParameters.ControlBoundary);
    [XProstate, YProstate] = toCartesian(TxParameters.ProstateBoundary);
    if length(TxParameters.TreatedSector) == 360
        X_isotherm = zeros(length(TxParameters.TreatedSector)+1,TxParameters.NumberSlices);
        Y_isotherm = zeros(length(TxParameters.TreatedSector)+1,TxParameters.NumberSlices);
    else
        X_isotherm = zeros(length(TxParameters.TreatedSector),TxParameters.NumberSlices);
        Y_isotherm = zeros(length(TxParameters.TreatedSector),TxParameters.NumberSlices);
    end
    for sliceIdx = 1:length(TxParameters.isUAactive)
        if TxParameters.isUAactive(sliceIdx) == 1
            [X_isotherm(:,sliceIdx),Y_isotherm(:,sliceIdx)] = toCartesian(isothermRadius(:,sliceIdx),TxParameters.TreatedSector);
        end
    end
end
if isfield(TxParameters,'ThermalBoostInfo')
    [XBoost,YBoost] = toCartesian((TxParameters.ThermalBoostInfo.TreatmentState==2).*TxParameters.ThermalBoostInfo.ControlBoundaryMM./TxParameters.PixelSize);
    XBoost(XBoost==0) = NaN;
    YBoost(YBoost==0) = NaN;
end

% Set the appropriate coloraxis and colormap
if strcmpi(inputname(1),'TDose') %#ok<STRIFCND> Remove warning about using contains which is 2017 only
    currentColormap = CreateColormap('TDose');
    currentCaxis = [0 1024];
    colorscaleLimits = currentCaxis;
    TickLabels = {0 500 1000};
    XTick = [0 500 1000];
    if isfield(TxParameters,'ThermalBoostInfo')
        LegendLabels = {'UA Overlay', 'Control Boundary', 'Thermal Boost Sectors', 'Prostate Boundary', [num2str(TxParameters.ThermalDoseCEM) ' CEM' num2str(TxParameters.ThermalDoseThreshold) ' isodose']};
    else
        LegendLabels = {'UA Overlay', 'Control Boundary', 'Prostate Boundary', [num2str(TxParameters.ThermalDoseCEM) ' CEM' num2str(TxParameters.ThermalDoseThreshold) ' isodose']};
    end
elseif strcmpi(inputname(1),'TMax') %#ok<STRIFCND> Remove warning about using contains which is 2017 only
    currentColormap = CreateColormap('TMap',min(TxParameters.ApproachingBoilingThreshold(:)));
    currentCaxis = [20 101];
    colorscaleLimits = currentCaxis;
    TickLabels = {20 55 min(TxParameters.ApproachingBoilingThreshold(:))};
    XTick = [20 55 min(TxParameters.ApproachingBoilingThreshold(:))];
    if isfield(TxParameters,'ThermalBoostInfo')
        LegendLabels = {'UA Overlay', 'Control Boundary', 'Thermal Boost Sectors', 'Prostate Boundary', 'Control Isotherm'};
    else
        LegendLabels = {'UA Overlay', 'Control Boundary', 'Prostate Boundary', 'Control Isotherm'};
    end
elseif strcmpi(inputname(1),'TMax_withIsotherm55') %#ok<STRIFCND> Remove warning about using contains which is 2017 only
    currentColormap = CreateColormap('TMap',min(TxParameters.ApproachingBoilingThreshold(:)));
    currentCaxis = [20 101];
    colorscaleLimits = currentCaxis;
    TickLabels = {20 55 min(TxParameters.ApproachingBoilingThreshold(:))};
    XTick = [20 55 min(TxParameters.ApproachingBoilingThreshold(:))];
    if isfield(TxParameters,'ThermalBoostInfo')
        LegendLabels = {'UA Overlay', 'Control Boundary', 'Thermal Boost Sectors', 'Prostate Boundary', 'Isotherm 55�C'};
    else
        LegendLabels = {'UA Overlay', 'Control Boundary', 'Prostate Boundary', 'Isotherm 55�C'};
    end
elseif strcmpi(inputname(1),'TDoseLog') %#ok<STRIFCND> Remove warning about using contains which is 2017 only
    currentColormap = CreateColormap('TDoseLog');
    currentCaxis = [0 26.1];
    colorscaleLimits = currentCaxis;
    TickLabels = {0 4 7 15};
    XTick = [0 4 7 15];
    if isfield(TxParameters,'ThermalBoostInfo')
        LegendLabels = {'UA Overlay', 'Control Boundary', 'Thermal Boost Sectors', 'Prostate Boundary', [num2str(TxParameters.ThermalDoseCEM) ' CEM' num2str(TxParameters.ThermalDoseThreshold) ' isodose']};
    else
        LegendLabels = {'UA Overlay', 'Control Boundary', 'Prostate Boundary', [num2str(TxParameters.ThermalDoseCEM) ' CEM' num2str(TxParameters.ThermalDoseThreshold) ' isodose']};
    end
end

% If we plot Masked version, we need to modify the colormap to show masked pixels as grey
% This only works for TMax for now
if size(Mask,4) == 1
    currentMask = Mask;
else
    currentMask = Mask(:,:,:,end-1);
end
TMapTDoseMasked = TMapTDose.*currentMask; % Apply masking
TMapTDoseMasked(currentMask == 0) = -100; % Only to display masked pixels as grey.

% Modify the colormap (Tdose and TMax colormap changes are different to accomodate different original colormap sizes)
if logical(strfind(inputname(1),'Dose'))
    currentCaxisMasked = [-100 1024]; % Masked values will be assigned the value -100
    currentColormapMasked = [0.4 0.4 0.4;repmat(currentColormap(1,:),24,1);currentColormap]; %Increase the colormap to work with more values
    
elseif logical(strfind(inputname(1),'TMax'))
    currentCaxisMasked = [-99 101]; % Masked values will be assigned the value -99
    currentColormapMasked = [0.4 0.4 0.4;repmat(currentColormap(1,:),118,1);currentColormap]; %Increase the colormap to go down to -99
end

% Subplot parameters
offset = 0.02; % Horizontal offset
spacing = 0.01; % Horizontal spacing
plotWidth = (1/TxParameters.NumberSlices*(1-2*offset-(TxParameters.NumberSlices-1)*spacing));
plotHeight = 1/4.5*(1-2*offset-spacing); % Without colorbar, it should be 1/2*(1-2*offset-spacing). Needs more room with the colorbar
verticalOffset = 2.1*plotHeight;

%==========================================================================
% ----- Plot data -----
%==========================================================================
figure('Position',get(0, 'Screensize'));

for row = 1:4
    % Row 1: zoomed out, unmasked
    % Row 2: zoomed out, masked
    % Row 3: zoomed in, unmasked, isotherms
    % Row 4: zoomed in, masked, isotherms
    
    for sliceIdx = 1:TxParameters.NumberSlices
        % Initialize subplots
        hSubplot = subplot('Position',[offset+(plotWidth+spacing)*(sliceIdx-1) 1-((verticalOffset-plotHeight)+(plotHeight+spacing)*(row-1)) plotWidth plotHeight]);
        
        % Set appropriate parameters
        switch row
            case 1
                currentMatrix = TMapTDose(:,:,sliceIdx);
                zoomlevel = 1.5;
                rowName = 'UNMASKED';
                colorMap = currentColormap;
                cAxis = currentCaxis;
            case 2
                currentMatrix = TMapTDoseMasked(:,:,sliceIdx);
                zoomlevel = 1.5;
                rowName = 'MASKED';
                colorMap = currentColormapMasked;
                cAxis = currentCaxisMasked;
            case 3
                currentMatrix = TMapTDose(:,:,sliceIdx);
                zoomlevel = 3.5;
                rowName = 'UNMASKED';
                colorMap = currentColormap;
                cAxis = currentCaxis;
            case 4
                currentMatrix = TMapTDoseMasked(:,:,sliceIdx);
                zoomlevel = 3.5;
                rowName = 'MASKED';
                colorMap = currentColormapMasked;
                cAxis = currentCaxisMasked;
        end
        
        % Display matrix
        imshow(currentMatrix, cAxis); hold on
        
        % Set titles
        if sliceIdx == 1
            title(sprintf('M%d (APEX)',sliceIdx-1))
        elseif sliceIdx == TxParameters.NumberSlices
            title(sprintf('M%d (BASE)',sliceIdx-1))
        else
            title(['E' num2str(sliceIdx-1)])
        end
        
        % Set zoom level
        zoomcenter(UACenterX(sliceIdx),UACenterY(sliceIdx),zoomlevel);
        
        % Set row name
        if sliceIdx == 1
            ylabel(gca,rowName,'FontWeight','Bold','Units','Normalized','Position',[hSubplot.Position(1)-0.05 0.5]);
        end
        
        % Set colorscale and colorbar 
        colormap(gca,colorMap);
        if row == 4 
            if sliceIdx == TxParameters.NumberSlices
                colorbar('Southoutside','TickLabels',TickLabels,'XTick',XTick,'Limits',colorscaleLimits,'Position', [hSubplot.Position(1:3) 0.015]);
            end
        end
        
        % Overlay additional plots
        hUA = plot(X_UA + UACenterX(sliceIdx),-Y_UA + UACenterY(sliceIdx),'k','linewidth',0.1);
        
        if (sliceIdx > 1 && sliceIdx < TxParameters.NumberSlices)
            hControl = plot(XControl(:,sliceIdx) + UACenterX(sliceIdx),-YControl(:,sliceIdx) + UACenterY(sliceIdx),'k','linewidth',0.2);
            if isfield(TxParameters,'ThermalBoostInfo')
                hBoost = plot(XBoost(:,sliceIdx) + UACenterX(sliceIdx), -YBoost(:,sliceIdx) + UACenterY(sliceIdx), 'color', 'm', 'linewidth', 0.5);
%             hBoost = plot(XBoost(:,sliceIdx) + UACenterX(sliceIdx), -YBoost(:,sliceIdx) + UACenterY(sliceIdx), 'color', [0.9100 0.4100 0.1700], 'linewidth', 1);
            end
            hProstate = plot(XProstate(:,sliceIdx) + UACenterX(sliceIdx),-YProstate(:,sliceIdx) + UACenterY(sliceIdx),'k','linewidth',0.5);
            if row == 3 || row == 4
                plot(X_isotherm(:,sliceIdx) + UACenterX(sliceIdx),-Y_isotherm(:,sliceIdx) + UACenterY(sliceIdx),'r','linewidth',0.1);
            end
            
            if sliceIdx == 2 && row == 4
                % TS-196
                hLegend = columnlegend(4, LegendLabels);
                set(hLegend, 'FontSize', 6, 'Location','Southoutside','Position', [0.25 hSubplot.Position(2)-0.05 0.45 0.015]);
            end
        elseif sliceIdx == 1 
            % TS-150
            if row == 3 || row == 4
                plotUAAngleDirection(gca, TxParameters.ThermAngle(1), TxParameters.RotationDirection(1), TxParameters.ux(end,1), TxParameters.uy(end,1), TxParameters.PixelSize)
            end
        end
    end
end

%==========================================================================
% ----- Save figures -----
%==========================================================================
print('-r100',gcf, fullfile(TxParameters.pathData,strjoin([TxParameters.PatientID "_" inputname(1) ".png"], '')), '-dpng');
orient landscape;
print(gcf, fullfile(TxParameters.pathData,strjoin([TxParameters.PatientID "_" inputname(1) ".pdf"], '')), '-dpdf', '-bestfit' );
orient portrait;

close all
