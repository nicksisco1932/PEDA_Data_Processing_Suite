function PlotTmax(Parameters,segmentIdx)
%==========================================================================
% Purpose:  plots masked TMax or TDose, with target boundary, prostate
% boundary and isotherm radii
%
% Inputs:
%      - input_directory = filepath where logfiles are stored
%      - filename_prefix = prefix of logfiles (i.e.2012.03.27-2025_TEST)
%      - TEMP_DOSE = variable to indicate whether to plot MaxTemp of Dose
%==========================================================================

% Always generate these plots
load(fullfile(Parameters.pathData,'TMaxMasked.mat'));
load(fullfile(Parameters.pathData,'TDoseMasked.mat'));
load(fullfile(Parameters.pathData,'TMax.mat'));
load(fullfile(Parameters.pathData,'TDose.mat'));
load(fullfile(Parameters.pathData,'isotherms.mat'));
if nargin > 1 % This is a treatment segment
    load(fullfile(Parameters.pathData,'Masks','Mask.mat'));
else % This is the entire treatment
    load(fullfile(Parameters.pathData,'Mask.mat'));
end

GeneratePlots(TMax, Mask, Parameters, isothermRadius_combined./Parameters.PixelSize);
GeneratePlots(TDose, Mask, Parameters, isothermRadiusTDose./Parameters.PixelSize);
TMax_withIsotherm55 = TMax; % GeneratePlots uses the name of the input variable.  This only changes the legend labeling
GeneratePlots(TMax_withIsotherm55, Mask, Parameters, isothermRadius55./Parameters.PixelSize);

if ~isempty(Parameters.Combined)
    GenerateSegmentPlot(Parameters,segmentIdx)
end

if nargin < 2 %If this is a multiple segment treatment, generate an additional plot with each row showing a segment
    GenerateSegmentPlot(Parameters)
end
end