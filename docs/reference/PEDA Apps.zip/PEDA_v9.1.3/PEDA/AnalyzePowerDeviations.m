function [HL_PowerDeviatedPercent, HL_PowerDesiredWa, HL_PowerNetWa, meanHL_PowerDeviatedPercent, stdevHL_PowerDeviatedPercent, NumberOfSamplesPerElement, PercentPowerWithinSpec] = AnalyzePowerDeviations(HardwareInfo,LOWERBOUND_PERCENT_POWER_DEVIATION,UPPERBOUND_PERCENT_POWER_DEVIATION)

NumberOfElements = 10;
maxHL_PowerDeviatedPercent_99 = zeros(1,NumberOfElements);
meanHL_PowerDeviatedPercent = zeros(1,NumberOfElements);
stdevHL_PowerDeviatedPercent = zeros(1,NumberOfElements);
NumberOfSamplesPerElement = zeros(1,NumberOfElements);
PercentPowerWithinSpec = zeros(1,NumberOfElements);

HL_PowerDesiredWa   = [HardwareInfo.PowerDesiredWa_E1 HardwareInfo.PowerDesiredWa_E2 HardwareInfo.PowerDesiredWa_E3 HardwareInfo.PowerDesiredWa_E4 HardwareInfo.PowerDesiredWa_E5 HardwareInfo.PowerDesiredWa_E6 HardwareInfo.PowerDesiredWa_E7 HardwareInfo.PowerDesiredWa_E8 HardwareInfo.PowerDesiredWa_E9 HardwareInfo.PowerDesiredWa_E10];
HL_PowerNetWa       = [HardwareInfo.PowerNetWa_E1 HardwareInfo.PowerNetWa_E2 HardwareInfo.PowerNetWa_E3 HardwareInfo.PowerNetWa_E4 HardwareInfo.PowerNetWa_E5 HardwareInfo.PowerNetWa_E6 HardwareInfo.PowerNetWa_E7 HardwareInfo.PowerNetWa_E8 HardwareInfo.PowerNetWa_E9 HardwareInfo.PowerNetWa_E10];

% Calculate Power Deviations
HL_PowerDeviatedPercent  = (HL_PowerNetWa - HL_PowerDesiredWa)./HL_PowerDesiredWa.*100;
% If division by 0, replace all NaNs
HL_PowerDeviatedPercent(isnan(HL_PowerDeviatedPercent)) = 0;

for elemIdx = 1:NumberOfElements
    currHL_PowerDeviatedPercent = HL_PowerDeviatedPercent(:,elemIdx);
    % Only consider instances when there was desired power
    NonzeroPowerIdx = HL_PowerDesiredWa(:,elemIdx) ~= 0 & HL_PowerNetWa(:,elemIdx) ~= 0; %%Fix for TS-300
    currHL_PowerDeviatedPercent = currHL_PowerDeviatedPercent(NonzeroPowerIdx);
    % Since the Lower (-30%) and Upper (+50%) bounds are different, center the power
    % deviations about 0 to find the indices of the samples that are
    % furthest from the bounds
    [~,sortIndices] = sort(abs(currHL_PowerDeviatedPercent - ((UPPERBOUND_PERCENT_POWER_DEVIATION - LOWERBOUND_PERCENT_POWER_DEVIATION)./2 + LOWERBOUND_PERCENT_POWER_DEVIATION)));
    if isempty(sortIndices)
        maxHL_PowerDeviatedPercent_99(elemIdx) = NaN;
        meanHL_PowerDeviatedPercent(elemIdx) = NaN;
        stdevHL_PowerDeviatedPercent(elemIdx) = NaN;
        NumberOfSamplesPerElement(elemIdx) = 0;
    else
        meanHL_PowerDeviatedPercent(elemIdx) = mean(currHL_PowerDeviatedPercent);
        stdevHL_PowerDeviatedPercent(elemIdx) = std(currHL_PowerDeviatedPercent);
        PercentPowerWithinSpec(elemIdx) = sum(currHL_PowerDeviatedPercent <= UPPERBOUND_PERCENT_POWER_DEVIATION & currHL_PowerDeviatedPercent >= LOWERBOUND_PERCENT_POWER_DEVIATION)./numel(sortIndices)*100;
        NumberOfSamplesPerElement(elemIdx) = numel(sortIndices);
    end
end