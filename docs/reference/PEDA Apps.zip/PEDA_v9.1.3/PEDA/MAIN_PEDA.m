function MAIN_PEDA(directory, varargin)
%==========================================================================
% Purpose:  Main script for Post Expriment Data Analysis (PEDA)
%           Divided into two sections:
%               1) Log file analysis - for analyzing PS, FC, RF, and SW logfiles generated from TDC
%               2) Isotherm analysis - for analyzing isotherm targeting
%               accuracy, volumetric error, and DSC statistics
%==========================================================================

%==========================================================================
%----- Variable initialization -----
%==========================================================================
global PEDA_VERSION 
PEDA_VERSION = 'v9.1.3';
% Add AdditionalFunctions to path
addpath(fullfile(fileparts(mfilename('fullpath')),'AdditionalFunctions'))

if nargin > 1
    patientID = varargin{1};
end

% Determine number of segments
[NumberSegments,dirName] = DetermineNumberSegments(directory);

fprintf('\n --> PEDA script version %s started!\n',PEDA_VERSION);

%==========================================================================
%----- Segment analysis -----
%==========================================================================
for segmentIdx = 1:NumberSegments
    disp('============================================');
    fprintf('ANALYZING SEGMENT %d/%d \n',segmentIdx,NumberSegments);
    
    fprintf('\t STEP 1: Retrieve segment parameters \n');
    if exist('patientID')
        SxParameters = RetrieveSxParameters(dirName{segmentIdx},segmentIdx,directory,patientID);
    else
        SxParameters = RetrieveSxParameters(dirName{segmentIdx},segmentIdx,directory);
    end
    SxParameters = SplitTreatment(SxParameters,-1); % Allow the user to stop the treatment at a specific angle
    
    fprintf('\t STEP 2: Create TMax and TDose: ');
    [TMap, Magnitude, MaxTemperatureTime, Mask, TUV, TUVMag] = CreateTMaxTDose(SxParameters); %creates maximum TMap, masked maximum TMap, TDose, masked TDose
    
    fprintf('\t STEP 3: Create movies \n');
    GenerateMovies(SxParameters, TMap, Magnitude, MaxTemperatureTime, TUV, TUVMag);

    fprintf('\t STEP 4: Analyze hardware logs \n');
    AnalyzeHardwareLogs(SxParameters);
    
    fprintf('\t STEP 5: Perform distance and beam angle masking \n');
    AdditionalImageMasking(SxParameters, TMap);
    
    fprintf('\t STEP 6: Create isotherms \n');
    CreateIsotherms(SxParameters); %computes isotherm radii, targetting error, volumetric and DSC statistics, and saves as "isotherms.mat"
    
    fprintf('\t STEP 7: Output treatment controller statistics \n');
    TreatmentControllerSummary(SxParameters,segmentIdx); % calculates and plots treatment controller statistics
    
    fprintf('\t STEP 8: Output segment statistics \n');
    OutputStatistics(SxParameters,segmentIdx); %saves 1-D targetting error, volumetric error, and DSC statistics as "IsothermSummary.txt"
    
    fprintf('\t STEP 9: Plot data for current segment \n');
    PlotTmax(SxParameters,segmentIdx); %plots with target boundary, prostate boundary and 55�C isotherm radii
end

%==========================================================================
%----- Treatment analysis -----
%==========================================================================
if NumberSegments > 1
    disp('============================================');
    fprintf('ANALYZING COMPLETE TREATMENT \n');
    
    fprintf('\t STEP 1: Combine all treatment segments \n');
    TxParameters = CombineTreatmentSegments(SxParameters.pathPEDA);
    
    fprintf('\t STEP 2: Create isotherms \n');
    CreateIsotherms(TxParameters); %computes isotherm radii, targetting error, volumetric and DSC statistics, and saves as "isotherms.mat"
    
    fprintf('\t STEP 3: Output treatment controller statistics \n');
%     TreatmentControllerSummary(TxParameters); % calculates and plots treatment controller statistics
    
    fprintf('\t STEP 4: Output treatment statistics \n');
    OutputStatistics(TxParameters); %saves 1-D targetting error, volumetric error, and DSC statistics as "IsothermSummary.txt"
    
    fprintf('\t STEP 5: Plot data \n');
    PlotTmax(TxParameters); %plots with target boundary, prostate boundary and 55�C isotherm radii
else
    OutputStatistics(SxParameters); %saves 1-D targetting error, volumetric error, and DSC statistics as "IsothermSummary.txt"
end


disp('============================================');
close all
fclose ('all');
return;