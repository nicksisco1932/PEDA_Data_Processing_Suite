function TreatedSector = GetTreatedSector(Angle)
%===============================================
% Return treated sector
%===============================================
% 0� is East. 180� is West
% CCW is decreasing angle. CW is increasing angle.

% Remove phase jumps
UnwoundAngle = UnwindAngle(Angle);

angularExtent = abs(max(UnwoundAngle)-min(UnwoundAngle));

if angularExtent >= 355 % Full revolution
    TreatedSector = 0:359;
else
    TreatedSector = mod(round(min(UnwoundAngle)):round(max(UnwoundAngle)),360); %Return value between 0 and 359 (might have a phase jump. That's fine)
end