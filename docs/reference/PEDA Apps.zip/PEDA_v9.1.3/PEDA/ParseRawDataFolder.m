%% ParseRawDataFolder.m ===========================================
% Purpose: To parse the TDC 2.10 Raw file containing the raw.dat files from
% the TUV and Thermometry acquisitions during the entire session. Contents
% are identified to a segment-specific TUV/Thermometry folder and copied.
% Original Raw files are maintained for traceability.
% 
% Inputs:
% =========
% - dirName - session level directory name
%
% Example function call:
% ======================
% dirName = 'C:\Users\SShekhar\Desktop\PEDA 2.10 - Updates for Raw file\_2020-09-05--13-13-27 620573390';
% ParseRawDataFolder(dirName);
%
% Outputs:
% =========
% - Raw folder contents parsed and copied into Segment-specific TUV/Therm
% 
% Additional Toolboxes Required:
% ==============================
% - None
% 
% ===========================
% Written by: Sid Shekhar
% Last edited by: Sid Shekhar
% Last edited on: 06-APR-2021
% =========================================================================

function ParseRawDataFolder(dirName)
global PEDA_VERSION
% 1. Identify all subfolders in Raw directory
    rawData = dir(fullfile(dirName, '\Raw'));
    rawFolderCount = sum([rawData(~ismember({rawData.name},{'.','..'})).isdir]);

% 2. Identify file counts/folder timestamp in each subfolder (ie. # of raw.dat files)
    for iRaw = 1:rawFolderCount
        rawSubData = dir(fullfile(dirName, '\Raw', rawData(iRaw + 2).name));
        rawContents(iRaw).fileCount = length(rawSubData)-2;
        rawContents(iRaw).dateTime = convertCharsToStrings(rawData(iRaw + 2).name);
        
        if length(rawSubData)>= 312 
            rawContents(iRaw).dataType=  'Thermometry'; % Thermometry Data
        elseif length(rawSubData)>= 300 && length(rawSubData) <= 312
            rawContents(iRaw).dataType =  'TUV';
        end
    end

% 3. Identify all sub-segments
    sessionData = dir(dirName);
    segmentFolderCount = sum([sessionData(~ismember({sessionData.name},{'.','..','local.db','Raw',strcat('PEDA', PEDA_VERSION)})).isdir]);
    for iSegment = 1:segmentFolderCount
        segmentContents(iSegment).dateTime = convertCharsToStrings(sessionData(iSegment + 2).name);
    end
    
% 4. Single Segment Treatment - Move Raw files into TUV/Therm Folders
    if segmentFolderCount == 1
       tuvIdx = find(strcmp({rawContents.dataType}, 'TUV')==1, 1, 'last');
       sourceTUV = fullfile(dirName, 'Raw', rawContents(tuvIdx).dateTime);
       sourceTherm = fullfile(dirName, 'Raw', rawContents(end).dateTime);
       destTUV = fullfile(sessionData(3).folder, sessionData(3).name, 'TUV');
       destTherm = fullfile(sessionData(3).folder,  sessionData(3).name, 'Thermometry');
       copyfile(sourceTUV, destTUV, 'f')
       copyfile(sourceTherm, destTherm, 'f')
       
% 5. Multi-Segment Treatment - Move Raw files into TUV/Therm Folders
    else
        for iRaw = 1:rawFolderCount
            for iSegment = 2:segmentFolderCount
                if rawContents(iRaw).dateTime < segmentContents(iSegment).dateTime
                    source = fullfile(dirName, 'Raw', rawContents(iRaw).dateTime);
                    dest = fullfile(dirName, segmentContents(iSegment-1).dateTime, rawContents(iRaw).dataType);
                    copyfile(source, dest, 'f');
                elseif iSegment == segmentFolderCount
                    source = fullfile(dirName, 'Raw', rawContents(iRaw).dateTime);
                    dest = fullfile(dirName, segmentContents(iSegment).dateTime, rawContents(iRaw).dataType);
                    copyfile(source, dest, 'f');
                end
            end
        end
    end
end



