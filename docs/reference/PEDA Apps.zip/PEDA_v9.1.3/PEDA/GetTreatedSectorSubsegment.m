function [TreatedSector, CombinedTreatedSector] = GetTreatedSectorSubsegment(Angle,SubSegmentImageNumber,ImageNumber)
%===============================================
% Return treated sector
%===============================================
% Shell function to allocate TreatedSectors into cells if part of
% subsegments, and also an output of the TreatedSector for the combined 
% segment

TreatedSector = cell(1,length(SubSegmentImageNumber)-1);
[offsetDynIdx,~] = find(ImageNumber == SubSegmentImageNumber);

for boundaryIdx = 1:length(SubSegmentImageNumber)-1
    if boundaryIdx == 1
        ThermAngle = Angle(1:offsetDynIdx(boundaryIdx));
    else
        ThermAngle = Angle(offsetDynIdx(boundaryIdx-1)+1:offsetDynIdx(boundaryIdx));
    end

    TreatedSector{boundaryIdx} = GetTreatedSector(ThermAngle);

end
% TS-207
CombinedTreatedSector = GetTreatedSector([TreatedSector{:}]);
