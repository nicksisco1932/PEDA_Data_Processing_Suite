function [VV_SCRIPT_VERSION] = VVScriptVersion()
    % This script stores the current version of the MATLAB V&V
    % scripts as they are on Agile. 
    % All scripts get their version number from this script
    VV_SCRIPT_VERSION = 'v3.9';
end

