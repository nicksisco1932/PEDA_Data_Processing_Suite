function [cImage, Err_Code, fftImage] = fload_rc(File_Name, Num_Coils, Nx, Ny, Offset, Img_Orient, Coil_Type)
%==========================================================================
% function [cImage, Err_Code, fftImage] = k_fload(File_Name, Num_Coils, Nx, Ny, Offset, Img_Orient, Coil_Type)
%
% Purpose:
% ========
%     Loads *.raw file and reformats into an MR images.
%     *.raw files come from the real-time GE format on the 1.5T
%
% Input(s):
% =========
%     File_Name:     File name to read in
%     Num_Coils:     Number of coils.
%     Nx:            Number of frequency-encode points
%     Ny:            Number of phase-encode points
%     Offset:        Offset in bytes to skip
%     Img_Orient:    Image orientation (e.g. 'axial', 'coronal', 'sagittal').
%     Coil_Type:     = 'head1ch'
%                    = 'pelvic4ch'
%                    = 'cardiac8ch'
%                    = 'body1ch'
% Output(s):
% ==========
%     cImage:     Complex image of size Nx x Nx
%     Err_Code:   Returns -1 if error occurred.
%     fftImage:   Fourier spectrum of image.
%
%==========================================================================
% Author:   Rajiv Chopra
% Created:  June, 2004.
% Last Modified:
%           May 10, 2005 - by Kee Tang.
%           Feb 24, 2006 - by KT - modified to check for coil_type instead
%                 of number of coils.
%==========================================================================

cImage = [];
fftImage = [];
Err_Code = 0;

%====================================================================
% Loading raw files.
%====================================================================
% little endian on GE Excite platform
fid = fopen(File_Name, 'r', 'l');

try
    % Locate beginning of file.
    fseek(fid, Offset, -1);
catch
    fclose('all');
    err_msg = strcat(['Could not open file (', File_Name,') ==> Check if filename is valid...']);
    errordlg(err_msg);
    Err_Code = -1;
    return;
end

% Read image and resize to make int a complex data set (a+i*b)
rawdata = fread(fid, [2*Nx, Ny], 'short');
kspace = rawdata(1:2:2*Nx, :) + sqrt(-1).*rawdata(2:2:2*Nx, :);

% Must correct for alternating values (GE SPGR sequence specific)
% by changing the sign of every second value.
%***needs to be checked to see whether negating the 1,3,5, etc. has an
%impact on the final result
kspace(:,2:2:Ny) = -kspace(:,2:2:Ny);

% If size of kspace is 128x64 then zero-pad to make image square.
if Ny < Nx
    zpad = zeros(Nx, Nx);
    zpad(:, Ny/2+1:(Nx-Ny/2)) = kspace;
    kspace = zpad;
end

% Do fourier transforms. ***needs to be checked to make sure it's
% consistent - the following three lines are Kee's code
imgShifted1 = fftshift(kspace);
imgShifted2 = ifft2(imgShifted1);
imgShifted3 = fftshift(imgShifted2);
%imgShifted3 = ifftshift(ifft2(kspace));


if ~isempty(strfind(Img_Orient,'coronal'))
    % For coronal slices, must flip vertically.
    imgRotated = flipud(imgShifted3);
else % For axial slices...
    if ~isempty(strfind(Coil_Type,'head1ch'))
        imgRotated = imgShifted3;
    else % Pelvic coils & Body coil
        % Rotate image 90 degrees clockwise (since Matlab has
        % reversed axes).
        imgRotated = rot90(imgShifted3,-1);
    end
end

cImage = imgRotated;
fftImage = kspace;

fclose('all');

return;

