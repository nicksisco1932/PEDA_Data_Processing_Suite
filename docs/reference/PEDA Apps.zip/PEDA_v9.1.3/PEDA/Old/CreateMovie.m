function CreateMovie(TxParameters, TMap, Anatomy, MaxTemperatureTime, TUV, TUVMag, Mask)
%======================================
% function CreateMovie;
%
% Purpose:
% ========
% Generates movie files from thermometry / magnitude data
%
% Input(s):
% =========
% - TxParameters
%
% Output(s):
% ==========
% - Movies
%
%==========================================================================

%==========================================================================
% Variable initialization
%==========================================================================
TDCColoraxis = [20 101]; %We want to map from 20 to 100 but somehow Matlab colormap works with intervals. So we need to get to 101
cmapTUV = CreateColormap('TUV');
NumberOfSlices = 12;
MaximumRadiusMM = 30;
MaximumRadius = MaximumRadiusMM./TxParameters.PixelSize;
MovieType = {'TUV','TUVMag','Maximum Temperature','Magnitude','Current Temperature','Maximum Temperature Overlay','Current Temperature Overlay'};
% ======== change nargin structure in future instead to make this an input
recenterImages = 1; %1 to shift image and keep boundaries static, 0 to shift boundaries and keep image static

if nargin > 6
    videoType = 'Masked';
    MovieType([1:2 4 6:7]) = [] ; %Do not output masked Magnitude or TUV
    coloraxis = [-99 101]; %Masked values will be assigned the value -99
    outputMaskedData = 1;
else
    coloraxis = TDCColoraxis;
    outputMaskedData = 0;
    videoType = '';
    %for scaling the indexed Magnitude colormaps
    minMagnitude = min(Anatomy(:));
    maxMagnitude = max(Anatomy(:));
    MagnitudeColoraxis = [minMagnitude 0.8*maxMagnitude];
end

%

%==========================================================================
% Retrieve Prostate, Control, MTR boundaries
%==========================================================================
[X_UA_CTRL,Y_UA_CTRL]       =  pol2cart(TxParameters.ThermAngle*(pi/180),20); %UA Control Angle
[X_MTR,Y_MTR]               =  toCartesian(TxParameters.MinimumTreatmentRadius);
[MaxRadiusX,MaxRadiusY]     =  toCartesian(MaximumRadius);
[UARadiusX,UARadiusY]       =  toCartesian(TxParameters.UARadius);
[XControl,YControl]         =  toCartesian(TxParameters.ControlBoundary);
[XProstate,YProstate]       =  toCartesian(TxParameters.ProstateBoundary);

%==========================================================================
% Retrieve each element state and frequency
%==========================================================================
load(fullfile(TxParameters.pathData,'HardwareInfo.mat'));
HardwareInfo = HardwareInfo(~isnan(HardwareInfo.ElapsedTime_sec),:);
[~,uniqueIdx] = unique(HardwareInfo.ImageNumber,'legacy');

elementFrequencies  = [ HardwareInfo.Frequency_E1 HardwareInfo.Frequency_E2 HardwareInfo.Frequency_E3 HardwareInfo.Frequency_E4...
                        HardwareInfo.Frequency_E5 HardwareInfo.Frequency_E6 HardwareInfo.Frequency_E7 HardwareInfo.Frequency_E8...
                        HardwareInfo.Frequency_E9 HardwareInfo.Frequency_E10];
elementPowers       = [ HardwareInfo.PowerNetWa_E1 HardwareInfo.PowerNetWa_E2 HardwareInfo.PowerNetWa_E3 HardwareInfo.PowerNetWa_E4...
                        HardwareInfo.PowerNetWa_E5 HardwareInfo.PowerNetWa_E6 HardwareInfo.PowerNetWa_E7 HardwareInfo.PowerNetWa_E8...
                        HardwareInfo.PowerNetWa_E9 HardwareInfo.PowerNetWa_E10];

elementFrequencies = elementFrequencies(uniqueIdx,:);
elementPowers = elementPowers(uniqueIdx,:);
normalizedElementPowers = elementPowers./max(elementPowers(:));

%==========================================================================
% Generate movies
%==========================================================================
for MovieTypeIndex = MovieType
    currentMovieType = MovieTypeIndex{1};
    movieName = [TxParameters.PatientID,'_',currentMovieType,videoType,'.mp4'];
    
    if exist(fullfile(TxParameters.pathData,movieName)) ~= 2
        
        %==========================================================================
        % Create objects
        %==========================================================================
        mov = VideoWriter(fullfile(TxParameters.pathData,movieName),'MPEG-4'); mov.FrameRate = 5;
        open(mov);
        hFig = figure('Position',[100 65 1700 950],'resize', 'off', 'Color',[0 0 0]);
        set(gca,'NextPlot','replacechildren');
        
        for dynIdx = 1:TxParameters.ImageNumber(end)
            for sliceIdx = 1:NumberOfSlices
                %==========================================================================
                % Variable and matrix initialization
                %==========================================================================
                elementIdx = sliceIdx - 1;
                offsetDynIdx = dynIdx-(TxParameters.ImageNumber(1)-1);
                InTreatment = dynIdx >= TxParameters.ImageNumber(1);
                
                if InTreatment && offsetDynIdx >= 2
                    % Starting from 2.6.3, temperature approching boiling threshold may be changed during treatment.
                    if ~isequal(TxParameters.ApproachingBoilingThreshold(offsetDynIdx),TxParameters.ApproachingBoilingThreshold(offsetDynIdx-1)) ||...
                            strcmp(currentMovieType,'Current Temperature') || strcmp(currentMovieType,'Maximum Temperature') ||...
                            strcmp(currentMovieType,'Current Temperature Overlay') || strcmp(currentMovieType,'Maximum Temperature Overlay')
                        TickLabels = {20 55 TxParameters.ApproachingBoilingThreshold(offsetDynIdx) 100};
                        XTick = [20 55 TxParameters.ApproachingBoilingThreshold(offsetDynIdx) 100];
                        cmap3 = CreateColormap('TMap',TxParameters.ApproachingBoilingThreshold(offsetDynIdx));
                        if outputMaskedData
                            cmap3 = [0.4 0.4 0.4;repmat(cmap3(1,:),118,1);cmap3]; %-99 is grey
                        end
                    end
                else
                    if dynIdx == 1
                        TickLabels = {20 55 TxParameters.ApproachingBoilingThreshold(1) 100};
                        XTick = [20 55 TxParameters.ApproachingBoilingThreshold(1) 100];
                        cmap3 = CreateColormap('TMap',TxParameters.ApproachingBoilingThreshold(1));
                        if outputMaskedData
                            cmap3 = [0.4 0.4 0.4;repmat(cmap3(1,:),118,1);cmap3]; %-99 is grey
                        end
                    end
                end
                
                switch currentMovieType
                    case 'Current Temperature'
                        currentMatrix = TMap(:,:,sliceIdx,dynIdx);
                    case 'Maximum Temperature'
                        currentMatrix = MaxTemperatureTime(:,:,sliceIdx,dynIdx);
                    case 'Magnitude'
                        currentMatrix = Anatomy(:,:,sliceIdx,dynIdx);
                    case 'TUV'
                        currentMatrix = TUV(:,:,sliceIdx,dynIdx);
                    case 'TUVMag'
                        currentMatrix = TUVMag(:,:,sliceIdx,dynIdx);
                    case 'Current Temperature Overlay'
                        if dynIdx < TxParameters.NumRefImages
                            Mask43TMap = zeros(128,128);
                        else
                            Mask43TMap = TMap(:,:,sliceIdx,dynIdx) >=43 | TMap(:,:,sliceIdx,dynIdx) < 20;
                        end
                        TMapMasked43 = squeeze(TMap(:,:,sliceIdx,dynIdx)).*Mask43TMap;
                        TMapMasked43(1,1) = TDCColoraxis(1); TMapMasked43(1,2) = TDCColoraxis(2); %ensure entire range of TMap colours are being used by forcing corner pixels (which get cropped anyway) to limits of colormap
                        
                        %currentMatrix is the indexed Magnitude (needs to be plotted first under the TMap overlay
                        currentMatrix = label2rgb(round(normalizemat(ceilfloor(Anatomy(:,:,sliceIdx,dynIdx),MagnitudeColoraxis(1),MagnitudeColoraxis(2)),1,255)),gray(256));
                        indexedTMapMasked43 = label2rgb(round(normalizemat(ceilfloor(TMapMasked43,TDCColoraxis(1),TDCColoraxis(2)),TDCColoraxis(1) - TDCColoraxis(1) + 1, TDCColoraxis(2) - TDCColoraxis(1))),cmap3);
                        currentMatrix = uint8(currentMatrix);
                        indexedTMapMasked43 = uint8(indexedTMapMasked43);
                        
                    case 'Maximum Temperature Overlay'
                        if dynIdx < TxParameters.NumRefImages
                            Mask43TMap = zeros(128,128);
                        else
                            Mask43TMap = MaxTemperatureTime(:,:,sliceIdx,dynIdx) >=43 | MaxTemperatureTime(:,:,sliceIdx,dynIdx) < 20;
                        end
                        
                        TMapMasked43 = squeeze(MaxTemperatureTime(:,:,sliceIdx,dynIdx)).*Mask43TMap;
                        TMapMasked43(1,1) = TDCColoraxis(1); TMapMasked43(1,2) = TDCColoraxis(2); %ensure entire range of TMap colours are being used by forcing corner pixels (which get cropped anyway) to limits of colormap
                        
                        %currentMatrix is the indexed Magnitude (needs to be plotted first under the TMap overlay
                        currentMatrix = label2rgb(round(normalizemat(ceilfloor(Anatomy(:,:,sliceIdx,dynIdx),MagnitudeColoraxis(1),MagnitudeColoraxis(2)),1,255)),gray(256));
                        indexedTMapMasked43 = label2rgb(round(normalizemat(ceilfloor(TMapMasked43,TDCColoraxis(1),TDCColoraxis(2)),TDCColoraxis(1) - TDCColoraxis(1) + 1, TDCColoraxis(2) - TDCColoraxis(1))),cmap3);
                        currentMatrix = uint8(currentMatrix);
                        indexedTMapMasked43 = uint8(indexedTMapMasked43);
                end
                
                if outputMaskedData
                    currentMask = double(Mask(:,:,sliceIdx,dynIdx));
                    currentMatrix = currentMatrix.*currentMask; %Apply masking
                    currentMatrix(currentMask == 0) = -99; %Only to display masked pixels as grey.
                end
                
                 % Required for the timer
                if InTreatment
                    TreatmentTimeMin = TxParameters.ImageTime(offsetDynIdx)/60;
                else
                    TreatmentTimeMin = 0;
                end
                Minute = floor(TreatmentTimeMin);
                Second = floor((TreatmentTimeMin-Minute)*60);
                
                
                %==========================================================================
                % If first frame, create imshow objects, plots, and timer
                %==========================================================================
                if dynIdx == 1
                    ax(sliceIdx) = subaxis(2,6,sliceIdx,'Spacing',0.005,'MT',0.05,'MR',0.18,'ML',0.005,'MB',0.005,'PT',0.05);
                    imshowHandle(sliceIdx) = imshow(currentMatrix,[]);
                    axis equal, zoomcenter(TxParameters.ux(1),TxParameters.uy(1),3.5), hold on
                    
                    
                    %Add overlay 
                    if strcmp(currentMovieType,'Current Temperature Overlay') || strcmp(currentMovieType,'Maximum Temperature Overlay')
                        hold on
                        imshowHandleOverlay(sliceIdx) = imshow(indexedTMapMasked43,[],'Parent',ax(sliceIdx));
                        set(imshowHandleOverlay(sliceIdx),'AlphaData',Mask43TMap)
                    end

                    %Add plots
                    if ~(sliceIdx == 1 || sliceIdx == NumberOfSlices)
                        hProstatePlot(sliceIdx-1) = plot(XProstate(:,elementIdx) + TxParameters.ux(1),-YProstate(:,elementIdx) + TxParameters.uy(1),'k','linewidth',0.5);
                        hControlPlot(sliceIdx-1) = plot(XControl(:,elementIdx) + TxParameters.ux(1),-YControl(:,elementIdx) + TxParameters.uy(1),'k','linewidth',0.2);
                    end
                    
                    hMTRPlot(sliceIdx) = plot(X_MTR + TxParameters.ux(1),-Y_MTR + TxParameters.uy(1),'k','linewidth',0.1);
                    hMaxRadPlot(sliceIdx) = plot(MaxRadiusX + TxParameters.ux(1),-MaxRadiusY + TxParameters.uy(1),'g--','linewidth',0.2);
                    text(MaxRadiusX(90) + TxParameters.ux(1),-(MaxRadiusY(90) + 2) + TxParameters.uy(1),[num2str(MaximumRadiusMM) ' mm'],'Color','g','HorizontalAlignment','Center','FontWeight','bold');
                    hAnglePlot(sliceIdx) = plot([TxParameters.ux(1) (X_UA_CTRL(1) + TxParameters.ux(1))],[TxParameters.uy(1) (-Y_UA_CTRL(1) + TxParameters.uy(1))],'k','linewidth',1.5,'Parent',ax(sliceIdx));
                    
                    %Add subplot titles
                    if sliceIdx == 1
                        title(sprintf('M%d (APEX)',elementIdx),'color','white','fontsize',18);
                    elseif sliceIdx == NumberOfSlices
                        title(sprintf('M%d (BASE)',elementIdx),'color','white','fontsize',18);
                    else
                        hTitle(elementIdx) = title(sprintf('E%d',elementIdx),'color','white','fontsize',18);
                        
                        if ~(strcmp(currentMovieType,'TUV') || strcmp(currentMovieType,'TUVMag')) && any(normalizedElementPowers(:,elementIdx)) %Add power indicators only if there was power
                            hTitle(elementIdx).Position(1) = hTitle(elementIdx).Position(1) - 5; %Off-center title
                            
                            titlePosition(1) = hTitle(elementIdx).Position(1) + 5;
                            titlePosition(2) = hTitle(elementIdx).Position(2) - 1.35;
                            
                            maxWidth = 11;
                            maxHeight = 2;
                            XpatchPosition = [titlePosition(1) titlePosition(1)              titlePosition(1)+maxWidth       titlePosition(1)+maxWidth];
                            YpatchPosition = [titlePosition(2) titlePosition(2)-maxHeight    titlePosition(2)-maxHeight      titlePosition(2)];
                            
                            hPatchEdge(sliceIdx) = patch(ax(sliceIdx),XpatchPosition,YpatchPosition,'white','FaceColor','none','EdgeColor','white','Clipping','off');
                            hPatch(sliceIdx) = patch(ax(sliceIdx),XpatchPosition,YpatchPosition,'black','FaceColor','none','EdgeColor','none','Clipping','off');
                        end
                    end
                    
                    %Add colorbar
                    if strcmp(currentMovieType,'Current Temperature') || strcmp(currentMovieType,'Maximum Temperature')
                        colormap(gca,cmap3);
                        caxis(coloraxis);
                        if sliceIdx == NumberOfSlices
                            TextBoxString2 = '[\circC]';
                            annotation('textbox',[0.95 0.37 0.7 0.15],'string',TextBoxString2,'color','white','fontsize',22,'edgecolor','none')
                            hColorbar = colorbar;
                            set(hColorbar,'Position',[0.85 0.05 .0581 0.8150],'fontsize',18,'linewidth',2,'color',[1 1 1],'TickLabels',TickLabels,'XTick',XTick,'Limits',TDCColoraxis);
                        end
                    elseif strcmp(currentMovieType,'Current Temperature Overlay') || strcmp(currentMovieType,'Maximum Temperature Overlay')
                        if sliceIdx == NumberOfSlices
                            TextBoxString2 = '[\circC]';
                            annotation('textbox',[0.95 0.37 0.7 0.15],'string',TextBoxString2,'color','white','fontsize',22,'edgecolor','none')
                            axhidden = subplot('Position',[-0.1 -0.1 0.01 0.01]);
                            imagesc([20 101]); colormap(cmap3)
                            hColorbar = colorbar;
                            set(hColorbar,'Position',[0.85 0.05 .0581 0.8150],'fontsize',18,'linewidth',2,'color',[1 1 1],'TickLabels',TickLabels,'XTick',XTick,'Limits',TDCColoraxis);
                        end
                    elseif strcmp(currentMovieType,'TUV') || strcmp(currentMovieType,'TUVMag')
                        hAnglePlot(sliceIdx).Visible = 'off';
                        if strcmp(currentMovieType,'TUV')
                            colormap(gca,cmapTUV);
                            caxis([0 6]);
                            if sliceIdx == NumberOfSlices
                                TextBoxString2 = '[\circC]';
                                annotation('textbox',[0.95 0.37 0.7 0.15],'string',TextBoxString2,'color','white','fontsize',22,'edgecolor','none')
                                colorbar('Position',[0.85 0.05 .0581 0.8150],'fontsize',18,'linewidth',2,'color',[1 1 1],'Ticks',[0 2 4],'TickLabels',{'0' '2' '4'})
                            end
                        end
                        plot(X_MTR + TxParameters.ux(1),-Y_MTR + TxParameters.uy(1),'k','linewidth',0.1)
                        plot(UARadiusX + TxParameters.ux(1),-UARadiusY + TxParameters.uy(1),'r','linewidth',0.2)
                    end
                    
                    %Create timer
                    if sliceIdx == 1
                        if InTreatment
                            TextBoxString = sprintf('Treatment Time: %d:%02d\nDynamic #%d', Minute, Second, dynIdx);
                        else
                            TextBoxString = sprintf('Initialization\nDynamic #%d', dynIdx);
                        end
                        if  (strcmp(currentMovieType,'TUV')) || (strcmp(currentMovieType,'TUVMag'))
                            TextBoxString = sprintf('TUV\nDynamic #%d', dynIdx);
                        end
                        annotation('textbox',[0.2 0.84 0.75 0.15],'string',TextBoxString,'color','white','fontsize',20,'edgecolor','none','Tag','elapsedTime','Horizontalalignment','Right')
                        hTextBox = findall(gcf,'Tag','elapsedTime');
                    end
                else
                    %==========================================================================
                    % Else, update the data
                    %==========================================================================       
                    set(imshowHandle(sliceIdx),'CData',currentMatrix,'Parent',ax(sliceIdx))
                    
%                     %Add overlay 
%                     if dynIdx == TxParameters.NumRefImages+1 && strcmp(currentMovieType,'Current Temperature Overlay') || strcmp(currentMovieType,'Maximum Temperature Overlay')
%                         hold on
%                         imshowHandleOverlay(sliceIdx) = imshow(indexedTMapMasked43,[],'Parent',ax(sliceIdx));
%                         set(imshowHandleOverlay(sliceIdx),'AlphaData',Mask43TMap)
%                     end
                    
                    if dynIdx > TxParameters.NumRefImages+1 && (strcmp(currentMovieType,'Current Temperature Overlay') || strcmp(currentMovieType,'Maximum Temperature Overlay'))
                        set(imshowHandleOverlay(sliceIdx),'CData',indexedTMapMasked43,'Parent',ax(sliceIdx),'AlphaData',Mask43TMap)
                        set(hColorbar,'TickLabels',TickLabels,'XTick',XTick);
                        colormap(axhidden,cmap3);
                        caxis(axhidden,coloraxis);
                    end
                    if InTreatment && offsetDynIdx > 1 && (strcmp(currentMovieType,'Current Temperature') || strcmp(currentMovieType,'Maximum Temperature')) && ...
                            ~isequal(TxParameters.ApproachingBoilingThreshold(offsetDynIdx),TxParameters.ApproachingBoilingThreshold(offsetDynIdx-1))
                        set(hColorbar,'TickLabels',TickLabels,'XTick',XTick);
                        colormap(ax(sliceIdx),cmap3);
                        caxis(ax(sliceIdx),coloraxis);
                    end
                    
                    if InTreatment && offsetDynIdx > 1
                        if ~(sliceIdx == 1 || sliceIdx == NumberOfSlices)
                            set(hProstatePlot(elementIdx),'XData',XProstate(:,elementIdx)      + TxParameters.ux(offsetDynIdx,sliceIdx));
                            set(hProstatePlot(elementIdx),'YData',-YProstate(:,elementIdx)     + TxParameters.uy(offsetDynIdx,sliceIdx));
                            set(hControlPlot(elementIdx), 'XData',XControl(:,elementIdx)       + TxParameters.ux(offsetDynIdx,sliceIdx));
                            set(hControlPlot(elementIdx), 'YData',-YControl(:,elementIdx)      + TxParameters.uy(offsetDynIdx,sliceIdx));
                        end
                        
                        set(hMTRPlot(sliceIdx),'XData',X_MTR                                + TxParameters.ux(offsetDynIdx,sliceIdx));
                        set(hMTRPlot(sliceIdx),'YData',-Y_MTR                               + TxParameters.uy(offsetDynIdx,sliceIdx));
                        set(hMaxRadPlot(sliceIdx),'XData',MaxRadiusX                        + TxParameters.ux(offsetDynIdx,sliceIdx));
                        set(hMaxRadPlot(sliceIdx),'YData',-MaxRadiusY                       + TxParameters.uy(offsetDynIdx,sliceIdx));
                        set(hAnglePlot(sliceIdx),'XData',[TxParameters.ux(offsetDynIdx,sliceIdx) (X_UA_CTRL(offsetDynIdx) + TxParameters.ux(offsetDynIdx,sliceIdx))]);
                        set(hAnglePlot(sliceIdx),'YData',[TxParameters.uy(offsetDynIdx,sliceIdx) (-Y_UA_CTRL(offsetDynIdx) + TxParameters.uy(offsetDynIdx,sliceIdx))]);
                    else
                        if ~(sliceIdx == 1 || sliceIdx == NumberOfSlices)
                            set(hProstatePlot(elementIdx),'XData',XProstate(:,elementIdx)      + TxParameters.ux(1,sliceIdx));
                            set(hProstatePlot(elementIdx),'YData',-YProstate(:,elementIdx)     + TxParameters.uy(1,sliceIdx));
                            set(hControlPlot(elementIdx), 'XData',XControl(:,elementIdx)       + TxParameters.ux(1,sliceIdx));
                            set(hControlPlot(elementIdx), 'YData',-YControl(:,elementIdx)      + TxParameters.uy(1,sliceIdx));
                        end
                        
                        set(hMTRPlot(sliceIdx),'XData',X_MTR                                + TxParameters.ux(1,sliceIdx));
                        set(hMTRPlot(sliceIdx),'YData',-Y_MTR                               + TxParameters.uy(1,sliceIdx));
                        set(hMaxRadPlot(sliceIdx),'XData',MaxRadiusX                        + TxParameters.ux(1,sliceIdx));
                        set(hMaxRadPlot(sliceIdx),'YData',-MaxRadiusY                       + TxParameters.uy(1,sliceIdx));
                        set(hAnglePlot(sliceIdx),'XData',[TxParameters.ux(1,sliceIdx) (X_UA_CTRL(1) + TxParameters.ux(1,sliceIdx))]);
                        set(hAnglePlot(sliceIdx),'YData',[TxParameters.uy(1,sliceIdx) (-Y_UA_CTRL(1) + TxParameters.uy(1,sliceIdx))]);
                    end
                    % Update text box
                    if InTreatment
                        set(hTextBox,'String',sprintf('Treatment Time: %d:%02d\nDynamic #%d', Minute, Second, dynIdx));
                    else
                        set(hTextBox,'String',sprintf('Initialization\nDynamic #%d', dynIdx));
                    end
                    if  (strcmp(currentMovieType,'TUV')) || (strcmp(currentMovieType,'TUVMag'))
                        set(hTextBox,'String',sprintf('TUV\nDynamic #%d', dynIdx));
                    end
                    
                    
                    % shift the frame/titles so shifted overlays look static
                    if recenterImages && InTreatment && offsetDynIdx > 1
                        if TxParameters.ux(dynIdx-TxParameters.ImageNumber(1)+1,sliceIdx) ~= TxParameters.ux(dynIdx-TxParameters.ImageNumber(1),sliceIdx) || TxParameters.uy(dynIdx-TxParameters.ImageNumber(1)+1,sliceIdx) ~= TxParameters.uy(dynIdx-TxParameters.ImageNumber(1),sliceIdx)
                            XLimNew = get(ax(sliceIdx),'XLim') + TxParameters.ux(offsetDynIdx,sliceIdx) - TxParameters.ux(dynIdx-TxParameters.ImageNumber(1),sliceIdx);
                            YLimNew = get(ax(sliceIdx),'YLim') + TxParameters.uy(offsetDynIdx,sliceIdx) - TxParameters.uy(dynIdx-TxParameters.ImageNumber(1),sliceIdx);
                            set(ax(sliceIdx),'XLim', XLimNew);
                            set(ax(sliceIdx),'YLim', YLimNew);
                            set(ax(sliceIdx),'DataAspectRatio', [1 1 1]);
                            if ~(sliceIdx == 1 || sliceIdx == NumberOfSlices)
                                XPositionNew = hTitle(elementIdx).Position(1) + TxParameters.ux(offsetDynIdx,sliceIdx) - TxParameters.ux(dynIdx-TxParameters.ImageNumber(1),sliceIdx);
                                YPositionNew = hTitle(elementIdx).Position(2) + TxParameters.uy(offsetDynIdx,sliceIdx) - TxParameters.uy(dynIdx-TxParameters.ImageNumber(1),sliceIdx);
                                hTitle(elementIdx).Position(1) = XPositionNew;
                                hTitle(elementIdx).Position(2) = YPositionNew;
                                if ~(strcmp(currentMovieType,'TUV') || strcmp(currentMovieType,'TUVMag')) && any(normalizedElementPowers(:,elementIdx)) %Add power indicators only if there was power
                                    titlePosition(1) = hTitle(elementIdx).Position(1) + 5;
                                    titlePosition(2) = hTitle(elementIdx).Position(2) - 1.35;
                                    XpatchPosition = [titlePosition(1) titlePosition(1)              titlePosition(1)+maxWidth       titlePosition(1)+maxWidth];
                                    YpatchPosition = [titlePosition(2) titlePosition(2)-maxHeight    titlePosition(2)-maxHeight      titlePosition(2)];
                                    hPatchEdge(sliceIdx).delete;
                                    hPatch(sliceIdx).delete;
                                    hPatchEdge(sliceIdx) = patch(ax(sliceIdx),XpatchPosition,YpatchPosition,'white','FaceColor','none','EdgeColor','white','Clipping','off');
                                    hPatch(sliceIdx) = patch(ax(sliceIdx),XpatchPosition,YpatchPosition,'black','FaceColor','none','EdgeColor','none','Clipping','off');
                                end
                            end
                        end
                    end
                    
                    % Update title color and power indicators (Green = LF; Red = HF)
                    if ~(strcmp(currentMovieType,'TUV') || strcmp(currentMovieType,'TUVMag')) &&...
                            ~(sliceIdx == 1 || sliceIdx == NumberOfSlices) && any(normalizedElementPowers(:,elementIdx)) &&...
                            InTreatment
                        updatedXpatchPosition = [  hPatchEdge(sliceIdx).XData(1) hPatchEdge(sliceIdx).XData(2) ...
                            hPatchEdge(sliceIdx).XData(1)+(normalizedElementPowers(offsetDynIdx,elementIdx).*maxWidth)...
                            hPatchEdge(sliceIdx).XData(1)+(normalizedElementPowers(offsetDynIdx,elementIdx).*maxWidth)];
                        
                        switch elementFrequencies(offsetDynIdx,elementIdx)
                            case TxParameters.LowFrequency
                                hPatch(sliceIdx).XData = updatedXpatchPosition;
                                hPatch(sliceIdx).FaceColor = 'green'; %[0 0.75 0];
                                
                            case TxParameters.HighFrequency
                                hPatch(sliceIdx).XData = updatedXpatchPosition;
                                hPatch(sliceIdx).FaceColor = 'red';
                                
                            otherwise
                                hPatch(sliceIdx).FaceColor = 'none';
                        end
                        if ~TxParameters.IsElementEnabled(offsetDynIdx,elementIdx)
                            hPatchEdge(sliceIdx).FaceColor = [0.6 0.6 0.6]; % Light gray
                            hTitle(elementIdx).Color = [0.6 0.6 0.6]; % Light gray
                        else
                            hPatchEdge(sliceIdx).FaceColor = 'black';
                            hTitle(elementIdx).Color = [1 1 1]; % white
                        end
                    end
                end
            end %end slice loop
            
            %Write video object
            writeVideo(mov,getframe(hFig));
            
            %Finish the loop earlier if TUV
            if (strcmp(currentMovieType,'TUV') && (dynIdx) == size(TUV,4)) || ...
                    (strcmp(currentMovieType,'TUVMag') && (dynIdx) == size(TUVMag,4))
                close(mov)
                close(gcf)
                break
            end
        end
        %==========================================================================
        % Close objects
        %==========================================================================
        close(mov)
        close(gcf)
    end
end