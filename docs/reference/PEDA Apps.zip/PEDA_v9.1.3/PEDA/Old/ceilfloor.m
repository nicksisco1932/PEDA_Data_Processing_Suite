% All values less than low become low.  All values above high become high.

function M = ceilfloor(N, low, high)

M = N;
M(N<low) = low;
M(N>high)= high;