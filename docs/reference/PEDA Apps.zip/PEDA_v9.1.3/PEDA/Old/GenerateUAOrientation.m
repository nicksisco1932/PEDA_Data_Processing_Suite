function GenerateUAOrientation(dicomPath,saveFolder)

[~,folderName] = fileparts(dicomPath);

if nargin == 1
    saveFolder = fileparts(dicomPath);
end

dicomList = dir(dicomPath);
dicomList = dicomList(~[dicomList(:).isdir]);

if isempty(dicomList)
    warning('on')
    fprintf('******************************************\n');
    warning('\nCould not find DICOMs files in %s to generate UA orientation',dicomPath);
    fprintf('******************************************\n');
    warning('off')
    return
end

%You need to find the first instance of the scan
instanceNumber = -1;
dcmIdx = 1;
while instanceNumber ~= 1 && dcmIdx <= length(dicomList)
    % Needs to be in a try catch statment since it may happen that a file does not have an instanceNumber (Philips scanners)
    try
        imageInfo = dicominfo(fullfile(dicomPath,dicomList(dcmIdx).name));
        instanceNumber = imageInfo.InstanceNumber;
    catch
    end
    dcmIdx = dcmIdx + 1;
end

%Get the required information
Pos = imageInfo.ImagePositionPatient;
Orient = imageInfo.ImageOrientationPatient;
FOV = [imageInfo.PixelSpacing(1)*imageInfo.Rows;imageInfo.PixelSpacing(1)*imageInfo.Columns];
% UACenter = [FOV/2 FOV/2];
UACenter = [128 128];

Header = {'ScanPositionX' 'ScanPositionY' 'ScanPositionZ' ...
    'BasisX.X' 'BasisX.Y' 'BasisX.Z' 'BasisY.X' 'BasisY.Y' 'BasisY.Z'...
    'UALocationX_MM' 'UALocationY_MM'};

Data = {Pos(1), Pos(2) Pos(3) Orient(1) Orient(2) Orient(3) Orient(4) Orient(5) Orient(6) UACenter(1) UACenter(2)};

%Write the file
fid = fopen(fullfile(saveFolder,sprintf('%s_UAOrientation.csv',folderName)),'w');
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',Header{1,1:end});
fprintf(fid,'%6f,%6f,%6f,%6f,%6f,%6f,%6f,%6f,%f,%f,%f',Data{1,1:end});
fclose(fid);

end
