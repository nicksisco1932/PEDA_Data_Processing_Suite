function Result = IsothermInterpolate(T, xx, yy)
%==========================================================================
% function Result = k_interpolate(T, xx, yy)
%
% Purpose:
% ========
%     Interpolates temperature points on an image.
%
% Input(s):
% =========
%     T:       2D Matrix where the interpolation is performed
%     xx, yy:  x and y coordinates where for which we want the interpolated
%              value
%
% Output(s):
% ==========
%
%
%==========================================================================
% Author: Rajiv Chopra
% Created: ??
% Last Modified: 
%        by KT - 22Feb08 - Modified to accept vectors of points.
%
%==========================================================================

   Result = [];
   
   for i = 1:length(xx)

      xt = xx(i);
      yt = yy(i);
      
      x1 = floor(xt);
      x2 = ceil(xt);
      y1 = floor(yt);
      y2 = ceil(yt);

      
      T_yt_x1 = T(y2,x1) + (T(y1,x1) - T(y2,x1)).*(y2-yt);
      T_yt_x2 = T(y2,x2) + (T(y1,x2) - T(y2,x2)).*(y2-yt);

      interp = T_yt_x1 + (T_yt_x2 - T_yt_x1).*(xt-x1);
      Result = [Result; interp];
   
   end
   
   

return;

