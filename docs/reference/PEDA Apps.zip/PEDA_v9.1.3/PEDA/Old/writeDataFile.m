function writeDataFile( filename, headerLabels, data )
%==========================================================================
% Purpose:  writes formatted data into PEDA files 
% 
% Inputs: 
%      - filename = full filepath of PEDA files
%      - headerLabels = titles for each column
%      - data = data to writes in PEDA files
%==========================================================================
    %----- open file -----
    fout = fopen( filename, 'w' );
    if( fout < 0 )
       error( ['Could not open file (', filename,') for writing.'] ); 
    end

    %----- write labels -----
    for n=1:size( headerLabels,1 )
        fprintf( fout, '%s\t', headerLabels(n,:) );
    end
    fprintf( fout, '\n' );

    %----- write data -----
    for r = 1 : size( data,1 )
        for c = 1 : size( data,2 )
            fprintf( fout, '%f\t', data(r,c) );
        end
        fprintf( fout, '\n' );
    end

    %----- close file -----
    fclose( fout );

end