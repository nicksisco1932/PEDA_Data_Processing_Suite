function [cmap1, cmap2, cmap3, cmap4] = k_createColorMaps(Tc)
%==========================================================================
% Purpose:  creates three colormaps
%
% Inputs:
%      - Tc = Target Temperature
%
% Outputs:
%      - cmap1 -
%      - cmap2 = TDC colormap (no green transition)
%      - cmap3 = TDC colormap with transition area shown as green pixels
%      - cmap4 = Thermal Dose colormap
%==========================================================================
%-----------------------------------------------------------------------
% Create CMap1_BlueRed:
%-----------------------------------------------------------------------
cmap1 = zeros(70,3);
for i = 20:89
    j = i - 19;
    if (i < 37 && i >= 20)
        cmap1(j,1) = 0;
        cmap1(j,2) = 0;
        cmap1(j,3) = 1;
    elseif (i < 55 && i >= 37)
        cmap1(j,1) = (i-37)/(55-37);
        cmap1(j,2) = (i-37)/(55-37);
        cmap1(j,3) = 1;
    elseif (i < 80 && i >= 55)
        cmap1(j,1) = 1;
        cmap1(j,2) = 1-(i-55)/(80-55);
        cmap1(j,3) = 1-(i-55)/(80-55);
    else
        cmap1(j,1) = 1;
        cmap1(j,2) = 0;
        cmap1(j,3) = 0;
    end
end


%-----------------------------------------------------------------------
% Create cmap2: TDC colormap (no green transition)
%-----------------------------------------------------------------------
cmap2 = zeros(70,3);
for i = 20:89
    j = i - 19;
    if (i < 55 && i >= 20)
        cmap2(j,1) = 0;
        cmap2(j,2) = (i-20)/(55-20);
        cmap2(j,3) = 1;
    elseif (i < 85 && i >= 55)
        cmap2(j,1) = 1;
        cmap2(j,2) = 1-(i-55)/(85-55);
        cmap2(j,3) = 0;
    else
        cmap2(j,1) = 0.5;
        cmap2(j,2) = 0.25;
        cmap2(j,3) = 0.5;
    end
end


%-----------------------------------------------------------------------
% Create cmap3: TDC colormap (with transition area shown as green pixels)
%-----------------------------------------------------------------------
cmap3 = zeros(70,3);
j = 0;
for i = (Tc-35):(Tc+34)
    j = j+1;
    if (i < (Tc-3) && i >= (Tc-35))
        cmap3(j,1) = 0;
        cmap3(j,2) = (i-(Tc-35))/((Tc-3)-(Tc-35));
        cmap3(j,3) = 1;
    elseif (i < Tc && i >= (Tc-3)) %Using light green.  Dark green -> (0.125, 0.5, 0.5); Light green -> (0, 0.75, 0);
        cmap3(j,1) = 0;
        cmap3(j,2) = 0.65;
        cmap3(j,3) = 0;
    elseif (i < (Tc+30) && i >= Tc)
        cmap3(j,1) = 1;
        cmap3(j,2) = 1-(i-Tc)/((Tc+30)-Tc);
        cmap3(j,3) = 0;
    else
        cmap3(j,1) = 0.5;
        cmap3(j,2) = 0.25;
        cmap3(j,3) = 0.5;
    end
end

%-----------------------------------------------------------------------
% Create cmap4: Thermal Dose colormap
%-----------------------------------------------------------------------
for i = 0:255 % 1020/4
    j = i + 1;
    if (i < 60) %240/4
        cmap4(j,1) = 0;
        cmap4(j,2) = 0.5;
        cmap4(j,3) = 1;
    elseif (i >= 60 && i < 250) %240/4 and 1000/4
        cmap4(j,1) = 0;
        cmap4(j,2) = 0.85;
        cmap4(j,3) = 0;
    elseif( i>=250) %1000/4
        cmap4(j,1) = 1;
        cmap4(j,2) = 1;
        cmap4(j,3) = 0;
    end
end

% %%%%%%%%%--------Customize Colormap--------------------------------%%%%%%%% 
% 
% %%% zone 1 - when T < Tc %%%
% colorStart_zone1 = [0 0 0.5];
% colorEnd_zone1 = [0 1 1];
% 
% %%% zone 2 - when T > Tc %%%
% colorStart_zone2 = [1 1 0];
% colorEnd_zone2 = [1 0 0];
% 
% %%% zone 3 - when T > Tmax - 5 %%%
% colorStart_zone3 = [0.5 0 1];
% colorEnd_zone3 = [0.5 0 1];
% 
% if Tc == 40 %% Gel
%         for i = 1:3
%             cmap_zone1(1:70,i) = linspace(colorStart_zone1(i),colorEnd_zone1(i),70);
%             cmap_zone2(1:60,i) = linspace(colorStart_zone2(i),colorEnd_zone2(i),60);
%             cmap_zone3(1:10,i) = linspace(colorStart_zone3(i),colorEnd_zone3(i),10);
%         end
% elseif Tc == 55 %% Canine or Human prostate
%         for i = 1:3
%             cmap_zone1(1:70,i) = linspace(colorStart_zone1(i),colorEnd_zone1(i),70);
%             cmap_zone2(1:60,i) = linspace(colorStart_zone2(i),colorEnd_zone2(i),60);
%             cmap_zone3(1:10,i) = linspace(colorStart_zone3(i),colorEnd_zone3(i),10);
%         end
% end
% 
% cmap = vertcat(cmap_zone1,cmap_zone2,cmap_zone3);


return;
