function [radius, theta, MaxProstateRadius,RealProstateRadius] = CalculateIsotherms(tmap, cx, cy, dx, min_rad, max_rad, start_angle, step_angle, Tc, SelectionOption, target, AdditionalRadius_mm, outfile)
% syntax :  [radius, theta] = im_isotherm_calculationPbound(tmap, cx, cy, dx, min_rad, max_rad, start_angle, step_angle, Tc, SelectionOption, target )
% example : [radius, theta] = im_isotherm_calculation(TMax{2}, ucentre(1), ucentre(2), 200/128, 8, ProstateBnd, 0, 1, 55, 2, TargetBnd);
%
% Inputs :  tmap: Temperature matrix, typically 128x128
%           cx  : centre x (columns), scalar value
%           cy  : centre y (rows), scalar value
%           dx  : spatial increment per pixel (mm/px)
%           min_rad : minimum treatment radius (mm)
%           max_rad : maximum radial extent of lesion [angles, radius]
%           start_angle: starting angle
%           step_angle: angle increment in degrees
%           Tc : Target Temperature (isotherm value)
%           SelectionOption: 1,2, or 3; method for selecting isotherm radius
%           target: target radius
%           AdditionalRadius_mm; distance beyond prostate boundary to look
%           for 55 deg isotherm (mm)
%
% Outputs : radius : Matix corresponding to the measured isotherm in polar coordinates
%           theta : angle values in radians to use with radius
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% --- Initialize Variables --- %%
radius_CW = zeros(length([start_angle:step_angle:359 0:step_angle:(start_angle-step_angle)]),1); %Initialize isotherm radius
radius_CCW = zeros(length([start_angle:step_angle:359 0:step_angle:(start_angle-step_angle)]),1); %Initialize isotherm radius
min_rad = min_rad/dx; % Convert to pixels
RealProstateRadius = max_rad(:,2);
max_rad(:,2) = max_rad(:,2) + AdditionalRadius_mm; %extra search radius to account for overheating 
max_rad(:,2) = max_rad(:,2)/dx; % Convert to pixels
target = target/dx; % Convert to pixels
ua_rad = 3.25/dx; % Convert to pixels
dr = 0.1; %pixel step size for isotherm search radius


%% Rotate Clockwise
%Find Isotherm Radius at each angle
index = 361;
Angles = [-1:-step_angle:-360 0:step_angle:(start_angle-step_angle)]/(180/pi);

for m = 360:-1:1
    theta = Angles(M);
    index = index-1;
    rfind=[];
    
    % Search for point where Temperatures change from >= 55 to <= 55
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %convert from polar to cartesian
    rad = ua_rad:dr:max_rad(m,2); 
    [xx yy] = cart2pol(ones(360,1)*theta,rad); 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %account for Matlab inversion and UA center
    xx = xx + cx;
    yy = -yy + cy;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Calculate interpolated temperatures
    t_interp = IsothermInterpolate(tmap,x,y);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Find transition point
    t_interp1 = t_interp(1:end-1) - Tc;
    t_interp2 = t_interp(2:end) - Tc;
    t_interp_multiplication = t_interp1.*t_interp2;
    FindZeroCrossings = find (t_interp_multiplication <= 0);
    rfind = rad(FindZeroCrossings);

     
    %Check if temperature at radius maximum is < Tc and no other isotherm
    %was found. If so, isotherm radius = zero. Otherwise, the radius is
    %maximum heat. Lastly, there were other radii found but temperature is
    %temperature at prostate boundary is < Tc, use normal selecetion
    %options
    
    if (length(rfind) == 0) && t_interp(end) < Tc
        rfind = 0;
        radius_CW(m) = rfind;
    
    elseif (length(rfind) == 0) && t_interp(end) >= Tc
        rfind = rad(end);
        radius_CW(m) = rfind;
    
    elseif (length(rfind) == 1) && t_interp(end) < Tc
        radius_CW(m) = rfind;
        
    else
        rfind = [rfind rad(end)];
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %Use nearest neighbour algorithm to determine if multiple isotherms
        %exst
        if(index < 360)
            [val,ind]=min(abs(rfind-radius_CW(m+1)));
            radius_CW(m) = rfind(ind);
            
        else
            radius_CW(m) = max(rfind);
        end
    end
    
end


%% Rotate Counter Clockwise
%Find Isotherm Radius at each angle
Angles = [start_angle:step_angle:359 0:step_angle:(start_angle-step_angle)];

for m = 1:360
    theta = Angles(M);
    index = index-1;
    rfind=[];
    
    % Search for point where Temperatures change from >= 55 to <= 55
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %convert from polar to cartesian
    rad = ua_rad:dr:max_rad(m,2); 
    [xx yy] = cart2pol(ones(360,1)*theta,rad); 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %account for Matlab inversion and UA center
    xx = xx + cx;
    yy = -yy + cy;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Calculate interpolated temperatures
    t_interp = IsothermInterpolate(tmap,x,y);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Find transition point
    t_interp1 = t_interp(1:end-1) - Tc;
    t_interp2 = t_interp(2:end) - Tc;
    t_interp_multiplication = t_interp1.*t_interp2;
    FindZeroCrossings = find (t_interp_multiplication <= 0);
    rfind = rad(FindZeroCrossings);

     
    %Check if temperature at radius maximum is < Tc and no other isotherm
    %was found. If so, isotherm radius = zero. Otherwise, the radius is
    %maximum heat. Lastly, there were other radii found but temperature is
    %temperature at prostate boundary is < Tc, use normal selecetion
    %options
    
    if (length(rfind) == 0) && t_interp(end) < Tc
        rfind = 0;
        radius_CCW(m) = rfind;
    
    elseif (length(rfind) == 0) && t_interp(end) >= Tc
        rfind = rad(end);
        radius_CCW(m) = rfind;
    
    elseif (length(rfind) == 1) && t_interp(end) < Tc
        radius_CCW(m) = rfind;
        
    else
        rfind = [rfind rad(end)];
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %Use nearest neighbour algorithm to determine if multiple isotherms
        %exst
        if(index < 360)
            [val,ind]=min(abs(rfind-radius_CCW(m+1)));
            radius_CCW(m) = rfind(ind);
            
        else
            radius_CCW(m) = max(rfind);
        end
    end
    
end





%% Determine whcih radius to use based on closest to target
[Min_CW, Indice_CW] = min(abs(radius_CW - target));
[Min_CCW, Indice_CCW] = min(abs(radius_CCW - target));

Closer_to_target_CCW = find (Min_CCW < Min_CW);

radius = radius_CW;
radius (Indice_CCW) = radius_CCW (Closer_to_target_CCW);


%% im_isotherm_calculationPbound outputs
radius = radius*dx;
theta = [start_angle:step_angle:359 0:step_angle:(start_angle-step_angle)];
MaxProstateRadius = max_rad(:,2)*dx;
return;

