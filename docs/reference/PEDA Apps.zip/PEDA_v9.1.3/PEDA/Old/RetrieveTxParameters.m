function [TxParameters, HardwareInfo] = RetrieveTxParameters(dirName,Tx,directory)

%% Find the correct directory to retrieve the Tx Parameters
TxParameters.pathSegment = dirName;
TxParameters.pathPEDA = [directory,filesep,'PEDA'];
TxParameters.pathPEDASegment = [directory,filesep,'PEDA',filesep,'Segment ',num2str(Tx)];
TxParameters.pathMain = directory;


%% First Loop through all of the info in InitializationData
fclose('all');
fid = fopen([dirName,'InitializationData.txt']);

fseek(fid, 0, 'eof'); %go to end of file
fileSize = ftell(fid); %determine number bytes
frewind(fid); %go back to beginning of file
data = fread(fid, fileSize, 'uint8');
numLines = sum(data == 10); %count number of line-feeds

frewind(fid); %go back to beginning of file
if numLines > 7260
    lineind = find(data == 10);
    laststart = lineind(numLines-7260); %if there are more than one set of InitializationData, set cursor to end of file minus the amount for one set of InitializationData
    fseek(fid,laststart,'bof'); 
end
temp = textscan(fid,'%s','delimiter','\t');
InitializationData = temp{1,1};


%% Determine which UA elements are active
offset_active = find(not(cellfun('isempty', strfind(InitializationData,'Is enabled?'))));

for element = 1:10
    temp = InitializationData{offset_active + element};
    
    if strcmp(temp,'True') == 1
        TxParameters.isUAactive(element) = 1;
    else
        TxParameters.isUAactive(element) = 0;
    end
    
end

%% Determine Slice Thickness
TxParameters.SliceThickness = str2double(ParseInitializationData(InitializationData, 'Slice Thickness'));

%% Retrieve Image Resolution
TxParameters.ImageResolution = str2double(ParseInitializationData(InitializationData, 'Image Resolution'));

%% Retrieve FOV
TxParameters.FOV = str2double(ParseInitializationData(InitializationData, 'Frequency Encode Field-of-View'));

%% Retrieve NumberSlices
TxParameters.NumberSlices = str2double(ParseInitializationData(InitializationData, 'Number of Slices'));

%% Retrieve Control Temperature
TxParameters.Tc = str2double(ParseInitializationData(InitializationData, 'Control temperature'));

%% Retrieve Patient Base Temperature
TxParameters.Tb = str2double(ParseInitializationData(InitializationData, 'Patient temperature'));

%% Retrieve TDC Version
TxParameters.SoftwareVersion = strtrim(ParseInitializationData(InitializationData, 'Treatment controller version'));

%% Retrieve Rotation Direction
TxParameters.InitialRotationDirection = strtrim(ParseInitializationData(InitializationData, 'Rotary rotation direction'));

%% Retrieve UA Center
index_ua = find(not(cellfun('isempty', strfind(InitializationData, 'Urethra Center'))));
temp = InitializationData{index_ua};
temp2 = strfind(temp,':');
TxParameters.ux = str2double(temp(temp2(1)+2:temp2(1)+8))       + 0.5;
TxParameters.uy = str2double(temp(temp2(2)+2:temp2(2)+8))       + 0.5;

%% Retrive Pixel Size (in-plane)
TxParameters.PixelSize = TxParameters.FOV/TxParameters.ImageResolution;

%% Retrieve Thermal Dose Threshold and Thermal Dose CEM
TxParameters.ThermalDoseThreshold = 43;
TxParameters.ThermalDoseCEM = 240;

%% Retrieve Minimum Treatment Radius
TxParameters.MinimumTreatmentRadiusMM = 8;
TxParameters.MinimumTreatmentRadius = TxParameters.MinimumTreatmentRadiusMM/TxParameters.PixelSize;

%% Retrieve UA Diameter
TxParameters.UARadiusMM = 4;
TxParameters.UARadius = TxParameters.UARadiusMM/TxParameters.PixelSize;

%% Retrieve Prostate Boundary
index_boundary = find(not(cellfun('isempty', strfind(InitializationData, 'Radius_mm'))));
L = index_boundary(1) + 1:10*360*3 + index_boundary(1);
Index = L(1):3:L(end);

for i = 1:length(L)/3
    ProstateBoundary_temp(i,:) = [str2double(InitializationData{Index(i)}) str2double(InitializationData{Index(i)+1}) str2double(InitializationData{Index(i)+2})];
end

TxParameters.ProstateBoundaryTheta = ProstateBoundary_temp(1:360,2);
TxParameters.ProstateBoundaryMM = reshape(ProstateBoundary_temp(:,3),[360 10]);
TxParameters.ProstateBoundary = TxParameters.ProstateBoundaryMM/TxParameters.PixelSize;

for i = 1:size(TxParameters.ProstateBoundary,2)
    [X_ProstateBoundary,Y_ProstateBoundary] = pol2cart(TxParameters.ProstateBoundaryTheta*pi/180,TxParameters.ProstateBoundary(:,i));
    X_ProstateBoundary = X_ProstateBoundary + TxParameters.ux;
    Y_ProstateBoundary = -Y_ProstateBoundary + TxParameters.uy;
    TxParameters.ProstateBoundaryXY(:,:,i) = [X_ProstateBoundary,Y_ProstateBoundary];
end

%% Retrieve Control Boundary
L = index_boundary(2) + 1:10*360*3 + index_boundary(2);
Index = L(1):3:L(end);

for i = 1:length(L)/3
    ControlBoundary_temp(i,:) = [str2double(InitializationData{Index(i)}) str2double(InitializationData{Index(i)+1}) str2double(InitializationData{Index(i)+2})];
end

TxParameters.ControlBoundaryTheta = ControlBoundary_temp(1:360,2);
TxParameters.ControlBoundaryMM = reshape(ControlBoundary_temp(:,3),[360 10]);
TxParameters.ControlBoundary = TxParameters.ControlBoundaryMM/TxParameters.PixelSize;

for i = 1:size(TxParameters.ControlBoundary,2)
    [X_ControlBoundary,Y_ControlBoundary] = pol2cart(TxParameters.ControlBoundaryTheta*pi/180,TxParameters.ControlBoundary(:,i));
    X_ControlBoundary = X_ControlBoundary + TxParameters.ux;
    Y_ControlBoundary = -Y_ControlBoundary + TxParameters.uy;
    TxParameters.ControlBoundaryXY(:,:,i) = [X_ControlBoundary,Y_ControlBoundary];
end
%% Create Segment Directory
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~exist(fullfile(TxParameters.pathPEDA,['Segment ' num2str(Tx)]))
    mkdir(TxParameters.pathPEDA,['Segment ' num2str(Tx)])
end

%% Second Loop through all of the info in Treatment Controller Info
fclose('all');
fid = fopen([TxParameters.pathSegment,'TreatmentControllerInfo.txt']); 
Header = textscan(fid,'%s',15,'delimiter','\t');
TreatmentControllerInfo = textscan(fid,'%f %d %s %s %f %f %f %f %f %f %f %f %f %f %s','delimiter','\t','TreatAsEmpty', {'Pre-Treatment','N/A'});

save([TxParameters.pathPEDASegment,filesep,'TreatmentControllerInfo.mat'],'TreatmentControllerInfo','Header')

%% Third Loop through all of the info in Treatment Controller Data
TreatmentControllerData = readtable([TxParameters.pathSegment,'TreatmentControllerData.txt'], 'TreatAsEmpty',{'Pre-Treatment','NA','N/A'});

%Sometimes, the first cell of TreatmentControllerData is a string for the
%second segment (Pre-treatment). We replace it by 0
TxParameters.ImageTime = TreatmentControllerData.ElapsedTime_sec;
TxParameters.ImageTime(isnan(TxParameters.ImageTime)) = 0;

TxParameters.ImageNumber = TreatmentControllerData.ImageNumber;
TxParameters.ThermAngle = TreatmentControllerData.ControlAngle_deg;
TxParameters.UnwoundThermAngle = UnwindAngle(TxParameters.ThermAngle);
TxParameters.RotationDirection = TreatmentControllerData.RotationDirection;

TxParameters.IsElementActive = [TreatmentControllerData.Frequency_E1 TreatmentControllerData.Frequency_E2 TreatmentControllerData.Frequency_E3 TreatmentControllerData.Frequency_E4 ...
                                TreatmentControllerData.Frequency_E5 TreatmentControllerData.Frequency_E6 TreatmentControllerData.Frequency_E7 TreatmentControllerData.Frequency_E8 ...
                                TreatmentControllerData.Frequency_E9 TreatmentControllerData.Frequency_E10];
TxParameters.IsAnyElementActive = any(TxParameters.IsElementActive,2);

save([TxParameters.pathPEDASegment,filesep,'TreatmentControllerData.mat'],'TreatmentControllerData')

%% Fourth Create Prostate Mask
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ProstateMask] = CreateProstateMask(TxParameters);
TxParameters.ProstateMask = ProstateMask;


%% Fifth Create UA Mask
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[UAMask] = CreateUAMask(4/TxParameters.PixelSize,TxParameters);
TxParameters.UAMask = UAMask;


%% Retrieve UA Efficiency Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fclose('all');
fid = fopen([dirName,'HardwareUACalibrationData0.txt']);
temp = textscan(fid,'%s','delimiter','\t');
HardwareUACalibrationData = temp{1,1};

%Retrieve Low Frequency Information
temp = HardwareUACalibrationData{7};
TxParameters.LowFrequency = str2num(temp(strfind(temp,':')+1:end));

%Retrieve High Frequency Information
temp = HardwareUACalibrationData{8};
TxParameters.HighFrequency = str2num(temp(strfind(temp,':')+1:end));

%Retrieve UA Calibration Angle
temp = HardwareUACalibrationData{9};
TxParameters.UACalibrationAngle = str2num(temp(strfind(temp,':')+1:end));

%% Retrieve Hardware Logs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
HardwareInfo = readtable(fullfile(TxParameters.pathSegment,'HardwareInfo.txt'),'TreatAsEmpty',{'Pre-Treatment','NA','N/A'});
save(fullfile(TxParameters.pathPEDASegment,'HardwareInfo.mat'),'HardwareInfo');

%% Save Tx Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
save([TxParameters.pathPEDASegment,filesep,'TxParameters.mat'],'TxParameters')

end

function result = ParseInitializationData(file_contents, search_string)

index = find(not(cellfun('isempty', strfind(file_contents, search_string))));
temp = file_contents{index};
result = temp(strfind(temp,':')+1:end);

end


