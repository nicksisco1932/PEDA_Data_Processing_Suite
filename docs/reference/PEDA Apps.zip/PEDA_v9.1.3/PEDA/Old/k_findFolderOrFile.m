function [New_Path, Err_Code] = k_findFolderOrFile(Base_Path, Search_String, Type)
%==========================================================================
% function [New_Path, Err_Code] = k_findFolder(Base_Path, Search_String)
%
% Purpose:
% ========
%     Searches for a specified folder that includes the search string.
%
% Input(s):
% =========
%     Base_Path = base path where folder should be searched.
%     Search_String = string to search for in folders.
%     Type = 'file' or 'folder'
%
% Output(s):
% ==========
%     New_Path = path of new folder.
%
%==========================================================================
% Author: Kee Tang
% Created: Aug. 17, 2006
% Last Modified: 
%
%==========================================================================

   Err_Code = 0;
   New_Path = '';
   
   cur_dir = dir(Base_Path);
   
   % Search for folder in base path.
   booFound = 0;
   for i = 1:length(cur_dir)   
		%cur_dir(i).name
      if strfind(cur_dir(i).name, Search_String)
         booFound = 1;
         strPath = cur_dir(i).name;
         break;
      end
   end
   
   if booFound == 0
      Err_Code = -1;
      return;
   end
   
   switch lower(Type)
      case 'folder'
         New_Path = strcat(Base_Path, strPath, '\');
      case 'file'
         New_Path = strcat(Base_Path, strPath);
   end
   
return;