function outputSegmentStatistics(TxParameters,segmentIdx)
%==========================================================================
% Inputs:
%      - TxParameters
% Outputs:
%      - PEDA_Output_Si.txt
%==========================================================================
global PEDA_VERSION

%==========================================================================
% ----- Variable initialization -----
%==========================================================================
load(fullfile(TxParameters.pathPEDASegment,filesep,'isotherms'));

% Open file to write summary of results
fileFID = fopen(fullfile(TxParameters.pathPEDASegment,sprintf('PEDA_Output_S%d.txt',segmentIdx)),'w');

if ~fileFID
    error( 'Error creating file to write PEDA summary' );
end

%==========================================================================
% ----- Write statistics to the file -----
%==========================================================================

c = clock();
fprintf( fileFID, 'Profound Medical Inc.\n' );
fprintf( fileFID, 'Executed on Matlab %s, %s \n',version,datetime);
fprintf( fileFID, 'PEDA Version %s \n',PEDA_VERSION);
fprintf( fileFID, 'Used TMaxMasked.mat and TDoseMasked.mat \n' );
fprintf( fileFID, 'Script Run on %s at %02d:%02d\n', date(), c(4),c(5) );
fprintf( fileFID, '\n' );

%==========================================================================
%----- write general  information -----
     
TotalThermAngle = [];TotalTreatmentTime = [];
possibleDirections = {'Clockwise';'Counterclockwise'};

fprintf( fileFID, '*************  Segment Statistics  ********************************\n');

SegmentDuration = TxParameters.ImageTime(end);
SegmentUnwoundAngle = TxParameters.UnwoundThermAngle;
TotalThermAngle = [TotalThermAngle;TxParameters.ThermAngle];
TotalTreatmentTime = [TotalTreatmentTime;TxParameters.ImageTime];


% The intent below is to calculate angular coverage for both CW and CCW
InitialRotationDirection = TxParameters.InitialRotationDirection;
OppositeRotationDirection = possibleDirections{~strcmp(InitialRotationDirection,possibleDirections)};
changesInDirection = strcmp(TxParameters.RotationDirection,TxParameters.InitialRotationDirection);
angularCoverageGoingInitialDirection = sum(abs(diff(SegmentUnwoundAngle(changesInDirection))));
angularCoverageGoingOppositeInitialDirection = sum(abs(diff(SegmentUnwoundAngle(~changesInDirection))));
if isempty(angularCoverageGoingOppositeInitialDirection)
    angularCoverageGoingOppositeInitialDirection = '0';
end
angularCoverage = sum(abs(diff(TxParameters.UnwoundThermAngle)));

fprintf( fileFID, 'Segment time [minutes]: %.1f\n',SegmentDuration/60);
fprintf( fileFID, 'Angular extent [�]: %.1f\n',abs(max(TxParameters.UnwoundThermAngle)-min(TxParameters.UnwoundThermAngle)));
fprintf( fileFID, 'Angular coverage [�]: %.1f ',angularCoverage);
fprintf( fileFID, '(%s: %.1f� - %s: %.1f�)\n',InitialRotationDirection,angularCoverageGoingInitialDirection,OppositeRotationDirection,angularCoverageGoingOppositeInitialDirection);
fprintf( fileFID, 'Patient temperature [�C]: %.3f\n',TxParameters.Tb);
fprintf( fileFID, '\n');

%==========================================================================
%----- write volumetric error and DSC statistics -----
fprintf( fileFID, '*************  Volumetric Error Statistics  ********************************\tTEMPERATURE\tTHERMAL DOSE\n');
fprintf( fileFID, 'Total Prostate Volume of Active Elements [cm^3]\t%.1f\t%.1f\n', accuracy_result_0mm.prostate_volume, accuracy_result_0mm_tdose.prostate_volume );
fprintf( fileFID, 'Total Target Volume [cm^3]\t%.1f\t%.1f\n', accuracy_result_0mm.target_volume, accuracy_result_0mm_tdose.target_volume );
fprintf( fileFID, 'Percent Overshoot Volume [%%]\t%.1f\t%.1f\n', accuracy_result_0mm.OSpercent, accuracy_result_0mm_tdose.OSpercent );
fprintf( fileFID, 'Percent Undershoot Volume [%%]\t%.1f\t%.1f\n', accuracy_result_0mm.USpercent, accuracy_result_0mm_tdose.USpercent );
fprintf( fileFID, 'Absolute Volumetric Error [cm^3]\t%.1f\t%.1f\n', accuracy_result_0mm.Volumetric_Error, accuracy_result_0mm_tdose.Volumetric_Error );
fprintf( fileFID, 'Percent Overshoot Volume - 1mm margin [%%]\t%.1f\t%.1f\n', accuracy_result_1mm.OSpercent, accuracy_result_1mm_tdose.OSpercent );
fprintf( fileFID, 'Percent Undershoot Volume - 1mm margin [%%]\t%.1f\t%.1f\n', accuracy_result_1mm.USpercent, accuracy_result_1mm_tdose.USpercent );
fprintf( fileFID, 'Absolute Volumetric Error Volume - 1mm margin [cm^3]\t%.1f\t%.1f\n', accuracy_result_1mm.Volumetric_Error, accuracy_result_1mm_tdose.Volumetric_Error );
fprintf( fileFID, '\n' );
fprintf( fileFID, '**************  DSC Statistics *******************************************\tTEMPERATURE\tTHERMAL DOSE\n');
fprintf( fileFID, 'DSC Volume \t%.2f\t%.2f\n', accuracy_result_0mm.DSCvol, accuracy_result_0mm_tdose.DSCvol );

for elemNo = 1:length(TxParameters.isUAactive)
        if( TxParameters.isUAactive(elemNo) == 1 )
            fprintf( fileFID, 'DSC Area Element %i \t%.2f\t%.2f\n',elemNo, accuracy_result_0mm.DSCarea(elemNo), accuracy_result_0mm_tdose.DSCarea(elemNo) );
        end
end

%==========================================================================
%----- write control boundary statistics -----
fprintf( fileFID, '\n' );
fprintf( fileFID, '***********  Control Boundary Info *************\n');
fprintf( fileFID, '\tMean\tStd.Dev.\tMinimum\tMaximum\n' );

for elemNo = 1:length(TxParameters.isUAactive)
    if( TxParameters.isUAactive(elemNo) == 1 ) 
        data = TxParameters.ControlBoundaryMM(:,elemNo);
        fprintf( fileFID, 'Element %i -- [mm]\t%.1f\t%.1f\t%.1f\t%.1f\n', elemNo, mean(data),std(data),min(data),max(data) );
    end
end

fprintf( fileFID, '\n' );

%==========================================================================
%----- write signed error statistics -----
fprintf( fileFID, '\n' );
fprintf( fileFID, '***********  1D Targeting Statistics *************\tTEMPERATURE\t\t\t\t\tTHERMAL DOSE\n');
fprintf( fileFID, '\tMean\tStd.Dev.\tMinimum\tMaximum\t\tMean\tStd.Dev.\tMinimum\tMaximum\n' );

for elemNo = 1:length(TxParameters.isUAactive)
        if( TxParameters.isUAactive(elemNo) == 1 )
            data = accuracy_result_0mm.error1D_eachSlice(elemNo).data;
            data2= accuracy_result_0mm_tdose.error1D_eachSlice(elemNo).data;
            fprintf( fileFID, 'Element %i -- Signed Targeting Error [mm]\t%.1f\t%.1f\t%.1f\t%.1f\t\t%.1f\t%.1f\t%.1f\t%.1f\n', elemNo, mean(data),std(data),min(data),max(data), mean(data2),std(data2),min(data2),max(data2) );
        end
end
data = accuracy_result_0mm.error1D_allSlices;
data2= accuracy_result_0mm_tdose.error1D_allSlices;
fprintf( fileFID, '1D - Total Targeting Error [mm]\t%.1f\t%.1f\t%.1f\t%.1f\t\t%.1f\t%.1f\t%.1f\t%.1f\n', mean(data),std(data),min(data),max(data), mean(data2),std(data2),min(data2),max(data2) );


%==========================================================================
%----- write radial extent of treatment statistics -----
fprintf( fileFID, '\n' );
fprintf( fileFID, '***********  Max Treatment Radius *************\n');
fprintf( fileFID, 'Max radius\tControl\tTreatment\n' );

max_r = max(isothermRadius);

for elemNo = 1:length(TxParameters.isUAactive)
    if( TxParameters.isUAactive(elemNo) == 1 )
        ctrl_r = max(TxParameters.ControlBoundaryMM(:,elemNo));
        fprintf( fileFID, 'Element %i -- [mm]\t%.1f\t%.1f\n', elemNo, ctrl_r, max_r(elemNo) );
    end
end
ctrl_r = max(max(TxParameters.ControlBoundaryMM));
fprintf( fileFID, 'All Elements -- [mm]\t%.1f\t%.1f\n', ctrl_r, max(max_r) );

fprintf( fileFID, '\n' );


fclose( fileFID );


%==========================================================================
%----- Generate csv file for UA overlay in TDC -----
for SegmentIdx = 1:size(TxParameters,2)
    anatomy2DFolder = fullfile(TxParameters.pathSegment,'Anatomy2D');
    dicom2DFolder = dir(anatomy2DFolder);
    if ~isempty(dicom2DFolder) 
    GenerateUAOrientation(fullfile(anatomy2DFolder,dicom2DFolder(end).name),TxParameters.pathPEDASegment);
    end
end
return;

