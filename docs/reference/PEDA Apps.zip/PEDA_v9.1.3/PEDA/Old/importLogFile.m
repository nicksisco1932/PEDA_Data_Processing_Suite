function [data] = importLogFile( filename, nHeaderRows, nCols )
%==========================================================================
% Purpose:  imports raw data into vectors
% 
% Inputs: 
%      - filename = full filepath of raw logfiles
%      - nHeaderRows = number of rows to skip
%      - nCols = number of columns to import
% Outputs:
%      - imported data
%==========================================================================
    disp('[importLogFile] importing file...');
    disp(filename);

    data = zeros(1,nCols);
    nRows = 0;

    %----- open file -----
    fin = fopen( filename, 'r' );
    if( fin < 0 )
       error( ['Could not open file (', filename,') for reading.'] ); 
    end

    %----- skip header rows ----
    for i=1:nHeaderRows
        fgetl(fin);
    end

    %----- import remainder of data into vector -----
    while(1)

        %----- get next line from file to parse -----
        buffer = fgetl(fin);          %  get next line as a string
        
        %----- check if end-of-file received -----
        if( buffer == -1 )
           break;
        end
        
        %----- increment row counter -----
        nRows = nRows + 1;

        %----- parse current line read from file -----
        for j=1:nCols
            
            %----- get next value, delimited by standard tokens -----
            [next,buffer] = strtok(buffer);
            
            %----- ensure value is a proper number -----
            if( isempty(str2num( next )) )
                data = data(1:length(data)-1,:);
                %error(['Error parsing file! "',next,'" is not a number! (at ',num2str(nRows),',',num2str(nCols),')']);
                fclose(fin);
                return;
            end
            
            %----- store value -----
            data( nRows,j ) = str2num( next );
        end
    end

    %----- close file -----
    fclose( fin );

end