function result = error_volume_Xmm(lesion, bound, prostate, X, minrad, zres,isUAactive)
%==========================================================================
% Purpose:  Calculate volumetric error and DSC statistics
%
% Inputs:
%      - lesion = isotherm radius (360xM)
%      - bound = target radius (360xN)
%      - prostate = prostate boundary
%      - X = tolerance around the garget boundary within which volume error
%      is not summed.
%      - minrad = minimum radius, such that regions where the target
%      boundary is less than minimum radius are not included in the
%      calculation
%      - input_directory = filepath where logfiles are stored
% Outputs:
%      - OSpercent = percent overshoot
%      - USpercent = percent Undershoot
%      - Volumetric_Error = volumetric targeting error in cc
%      - prostate_volume = volume of the prostate in cc
%      - target_volume = volume of the target in cc
%      - DSCvol = Dice Similarity Coefficient using volume
%      - DSCarea = Dice Similarity Coefficient using area
%      - 1D error statistics = Mean, std, min and max of the 1D shortest
%      distance error
%==========================================================================

if (size(lesion,2) ~= size(bound,2))
    fprintf(1,'\n\nERROR: lesion and bound must be same size\n\n');
    return;
end



dtheta = 1*pi/180; %factor that converts degrees to radians

%%Defining variables and assigning a value of zero
boundv = 0; % Target boundary volume, in mm^3
lesionv = 0; % Isotherm lesion volume, in mm^3
prostatev = 0; % Prostate boundary volume, in mm^3
ov = 0; % Overtreatment volume, in mm^3
uv = 0; % Undertreatment volume, in mm^2
error_allSlices = []; %1D error, all slices combined

theta = [0:359]*(pi/180); %converting degree increments to radians


for z = 1:size(lesion,2) %for each slice
    error_eachSlice(z).data = []; %1D error, for each slice, and initially assign a value of zero
    %bound_index = z - 0 + 1; %make sure the target boundary slice number (which is Nslices x 360) matches the isotherm slice number (which is NElements x 360)
    [lesion_x, lesion_y] = pol2cart(theta',lesion(:,z)); %Convert isotherm radius to Cartesian coordinates
    [target_x, target_y] = pol2cart(theta',bound(:,z)); %convert target radius to Cartesian coordinates
    areaoverlap(z) = 0; %assign overlap area initial value of 0
    areabound(z) = 0; %assign target area initial value of 0
    arealesion(z) = 0; %assign isotherm area initial value of 0
    
    if (isUAactive(z) == 1) %calculate error for active elements only, and disregard elements that aren't active
        for j = 1:size(lesion,1) %evaluate statistics at every angle
            prostatev = prostatev + zres*prostate(j,z)*prostate(j,z)*dtheta/2; %prostate boundary volume where Volume_Cumulative = sum (z * r (theta)^2 * pi/360)
            if (bound(j,z) >= minrad)
                %Volumetric Accuracy
                boundv = boundv + zres*bound(j,z)*bound(j,z)*dtheta/2; %target boundary volume
                lesionv = lesionv + zres*lesion(j,z)*lesion(j,z)*dtheta/2; %isotherm lesion volume
                areabound(z) = areabound(z) + bound(j,z)*bound(j,z)*dtheta/2;  %target boundary area where Area_Cumulative = sum (r (theta)^2 * pi/360)
                arealesion(z) = arealesion(z) + lesion(j,z)*lesion(j,z)*dtheta/2; %lesion boundary area
                areaoverlap(z) = areaoverlap(z) + min(bound(j,z),lesion(j,z))*min(bound(j,z),lesion(j,z))*dtheta/2; %where Area_Overlap_Cumulative = sum (min (r_isotherm (theta), r_target(theta) ^2 * pi/360) 
                
                delta_T = lesion(j,z)-bound(j,z); %evaluating the incremental isotherm  radius to determine overshoot or undershoot
                if (delta_T > X) %if the isotherm radius is greater than 1 mm of target boundary, it's overshoot error
                    ov = ov + zres*(lesion(j,z)*lesion(j,z) - (bound(j,z)+X)*(bound(j,z)+X))*dtheta/2; % in mm^3    -                
                %the overshoot volume is calculated by taking the
                %difference of the isotherm boundary to the target boundary
                %but adding an extra mm to the target boundary before
                %subtraction
                   
                    
                elseif (delta_T < -1*X) %if the isotherm radius is less than 1 mm of target boundary, it's undershoot error
                    uv = uv + zres*((bound(j,z)-X)*(bound(j,z)-X) - lesion(j,z)*lesion(j,z))*dtheta/2; % in mm^3
                   %the undershoot volume is calculated by taking the
                %difference of the target boundary to the isotherm boundary
                %but subtracting an extra mm to the target boundary before taking the difference 
                     
                end
                
                %1D Accuracy
                if delta_T < 0 %Undertreatment, mindist(target_point to lesion_polynomial)
                    error = -1*distancePointPolyline([target_x(j), target_y(j)],[lesion_x, lesion_y]);
                    error_eachSlice(z).data = [error_eachSlice(z).data, error];
                    error_allSlices = [error_allSlices, error];
                else %Overtreatment, mindist(siotherm_point to bound_polynomial)
                    error = distancePointPolyline([lesion_x(j), lesion_y(j)],[target_x, target_y]);
                    error_eachSlice(z).data = [error_eachSlice(z).data, error];
                    error_allSlices = [error_allSlices, error];
                end
            end
        end
    end
    DSCarea(z) = 2*areaoverlap(z)/(areabound(z)+arealesion(z));
end

result.OSpercent = (ov/boundv)*100;
result.USpercent = (uv/boundv)*100;
result.Volumetric_Error = (ov + uv)/1000; %in cm^3
result.target_volume = boundv/1000; %in cm^3
result.prostate_volume = prostatev/1000; %in cm^3
result.DSCvol = 2*sum(areaoverlap)/(sum(arealesion)+sum(areabound));
result.DSCarea = DSCarea;
result.error1D_allSlices = error_allSlices;
result.error1D_eachSlice = error_eachSlice;

return;