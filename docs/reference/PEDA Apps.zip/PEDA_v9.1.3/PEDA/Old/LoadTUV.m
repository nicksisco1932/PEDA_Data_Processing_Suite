function TUV = LoadTUV(SxParameters,matchingExp)

TemperatureUncertaintyFiles = dir(fullfile(SxParameters.pathSegment,'TUV',matchingExp));
numberOfDynamics = length(TemperatureUncertaintyFiles)/12;

for fileIdx = 1:length(TemperatureUncertaintyFiles)
    pathToCurrentFile = fullfile(SxParameters.pathSegment,'TUV',TemperatureUncertaintyFiles(fileIdx).name);
    fid = fopen(pathToCurrentFile);
    fileInfo = textscan(TemperatureUncertaintyFiles(fileIdx).name,['i%4d-s%2d-%s']);
    currentDynamic = fileInfo{1} + 1; % File name is zero-based
    currentSlice = fileInfo{2} + 1; % File name is zero-based
    TUV(:,:,currentSlice,currentDynamic) = fread(fid,[128 128],'float')';
    fclose(fid);
end

% Shift TUV matrix so it starts at index 1
TUV = TUV(:,:,:,(size(TUV,4)-numberOfDynamics+1):end);
