function [radius_CW, radius_CCW, radius, MaxProstateRadius] = im_isotherm_calculationPbound(tmap, ux, uy, dx, ProstateRadius, start_angle, step_angle, Tc, SelectionOption, target, AdditionalRadiusMM, UARadius, outfile)
%==========================================================================
% Inputs :  tmap: Temperature matrix, typically 128x128
%           ux  : centre x (columns), scalar value
%           uy  : centre y (rows), scalar value
%           dx  : spatial increment per pixel (mm/px)
%           max_rad : maximum radial extent of lesion [angles, radius]
%           start_angle: starting angle
%           step_angle: angle increment in degrees
%           Tc : Target Temperature (isotherm value)
%           SelectionOption: 1,2, or 3; method for selecting isotherm radius
%           target: target radius
%           AdditionalRadius_mm; distance beyond prostate boundary to look for Tc isotherm (mm)
%
% Outputs : radius : Matix corresponding to the measured isotherm in polar coordinates
%           theta : angle values in radians to use with radius
%           MaxProstateRadius: The prostate radius in mm + the additional search radius

%==========================================================================
% --- Initialize Variables --- %%
radius = zeros(length(ProstateRadius),1); %Initialize empty isotherm radius
max_rad = ProstateRadius + AdditionalRadiusMM/dx; %extra search radius to account for overheating
dr=0.1; 


%==========================================================================
% --- Find isotherm radius at each angle but rotating CW --- 
index = 361;
for th2 = -1:-step_angle:-360
    index = index-1;
    rfind=[];
    
    %---In 0.1pix spacial increments, search for a point < Tc where the next point is > Tc
    
    for rad = UARadius:dr:max_rad(index)

        [xt1,yt1] = pol2cart(th2*(pi/180),rad);
        [xt2,yt2] = pol2cart(th2*(pi/180),rad+dr);
        
        t_interp1 = m_get_interpolated_temp(tmap,xt1+ux,-yt1+uy);
        t_interp2 = m_get_interpolated_temp(tmap,xt2+ux,-yt2+uy);
        
        if ((t_interp1 >= Tc) && (t_interp2 <= Tc))
            rfind=[rfind rad];
        end
    end
    
    %Now we have found all radii between UA centre and prostate boundary
    %that have a transition pt from > Tc to < Tc
    %However, there are a pts actually on the prostate boundary that are
    %still warmer than Tc and we need to account for this
    
    %Check if temperature at radius maximum is < Tc and no other isotherm
    %was found. If so, isotherm radius = zero. Otherwise, the radius is
    %maximum heat. Lastly, there were other radii found but temperature is
    %temperature at prostate boundary is < Tc, use normal selecetion
    %options
    
    rad_maximum = max_rad(index);
    xt1 = ux + rad_maximum*cos(th2*(pi/180));
    yt1 = uy - rad_maximum*sin(th2*(pi/180));
    t_interp1 = k_interpolate(tmap,xt1,yt1);
    
    if (length(rfind) == 0)
        
        if t_interp1 < Tc
            rfind = 0;
        else
            rfind = rad_maximum;
        end
        
        
    elseif (length(rfind) ~= 0)
        
        if t_interp1 < Tc
            rfind = rfind;
        else
            rfind = sort([rfind rad_maximum],'ascend');
        end
    end
    
    %==========================================================================
    %---if multiple isotherm radii are found, find isotherm radius according to "SelectionOption"
    if(SelectionOption==1)
        rad=rfind(1);
    elseif(SelectionOption==2)
        rad=rfind(length(rfind));
    elseif(SelectionOption==3)
        if(index < 360)
            [val,ind1]=min(abs(rfind-radius(index+1)));
            rad=rfind(ind1);
        else
            rad=rfind(length(rfind));
        end
    end
    
    %If rad==0, isotherm was either not reached or max_rad was too small.
    %If rad!=0, interpolate the radius value to find isotherm radius
    if( rad == 0 )
        radius(index) = 0;
    else %linear interpolation between rad and rad+dr to find isotherm radius (i.e. radius where T=Tc)
        radius(index) = rad;
    end
end

radius_CW = radius;

%reinitialize to zero
radius = zeros(length(ProstateRadius),1); %Initialize empty isotherm radius


%==========================================================================
% --- Find isotherm radius at each angle but rotating CCW --- 
index = 0;
for th = start_angle:step_angle:359
    index = index+1;
    rfind=[];
    
    
    for rad = UARadius:dr:max_rad(index)

        [xt1,yt1] = pol2cart(th*(pi/180),rad);
        [xt2,yt2] = pol2cart(th*(pi/180),rad+dr);
        
        t_interp1 = m_get_interpolated_temp(tmap,xt1+ux,-yt1+uy);
        t_interp2 = m_get_interpolated_temp(tmap,xt2+ux,-yt2+uy);
        
        if ((t_interp1 >= Tc) && (t_interp2 <= Tc))
            rfind=[rfind rad];
        end
    end
    
%     if Tc > 55
%     else
%         fprintf(outfile,'%i\t',th);
%         if isempty(rfind) == 1
%             fprintf(outfile,'NaN');
%         else
%             for m = 1:length(rfind)
%                 fprintf(outfile,'%0.3g\t',rfind(m)*dx);
%             end
%         end
%         fprintf(outfile,'\n');
%     end
    
    rad_maximum = max_rad(index);
    xt1 = ux + rad_maximum*cos(th*(pi/180));
    yt1 = uy - rad_maximum*sin(th*(pi/180));
    t_interp1 = k_interpolate(tmap,xt1,yt1);
    
    if (length(rfind) == 0)
        
        if t_interp1 < Tc
            rfind = 0;
        else
            rfind = rad_maximum;
        end
        
        
    elseif (length(rfind) ~= 0)
        
        if t_interp1 < Tc
            rfind = rfind;
        else
            rfind = sort([rfind rad_maximum],'ascend');
        end
    end
    
    %==========================================================================
    %---if multiple isotherm radii is found, find isotherm radius according to "SelectionOption"
    if(SelectionOption==1)
        rad=rfind(1);
    elseif(SelectionOption==2)
        rad=rfind(length(rfind));
    elseif(SelectionOption==3)
        if(index>1 && ~isnan(radius(index-1)))
            [val,ind1]=min(abs(rfind-radius(index-1)));
            rad=rfind(ind1);
        else
            rad=rfind(length(rfind));
        end
    end
    
    
    %If rad==0, isotherm was either not reached or max_rad was too small.
    %If rad!=0, interpolate the radius value to find isotherm radius
    if( rad == 0 )
        radius(index) = 0;
    else %linear interpolation between rad and rad+dr to find isotherm radius (i.e. radius where T=Tc)
        radius(index) = rad;
    end
end


radius_CCW = radius;

%==========================================================================
% --- Determine which radius to use based on closest to target
radius = zeros(length(ProstateRadius),1); %Initialize empty isotherm radius

for i = 1:360
    [ClosestRadii Indice] = min(abs([radius_CW(i) radius_CCW(i)] - target(i)));
    
    if Indice == 1
        radius(i) = radius_CW(i);
    elseif Indice == 2
        radius(i) = radius_CCW(i);
        
    end
end


%==========================================================================
% Pass outputs
radius = radius*dx;
MaxProstateRadius = max_rad(:)*dx; %convert back to pixels

return;

