function [NumberSegments,SegmentsPath] = DetermineNumberSegments(dirName)
% Use dir function as recursive to locate TreatmentControllerInfo.txt
paths = dir(fullfile(dirName,'**','TreatmentControllerInfo.txt'));

SegmentsPath = {paths.folder};

if isempty(SegmentsPath)
    error('PEDA did not find valid segment folder(s) containing file TreatmentControllerInfo.txt. Abording\n. Verify input path');
end

NumberSegments = length(SegmentsPath);