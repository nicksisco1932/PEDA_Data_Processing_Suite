%% TreatmentControllerSummary.m ===========================================
% Using technical logs, recalculate controller algorithm decisions.  Plots
% technical log rotational velocity over the Matlab pipeline showing its
% equivalence to the minimum velocity of all elements.
% 
% Inputs:  
%       - SxParameters for file locations (use only single treatment segment SxParameters)
%       - segmentIdx for naming files
% 
% Outputs:
%       - w: [dpm] MxN matrix with calculated rotational velocities; M elements, N dyns
%       - p: [Wa] MxN matrix with calculated power 
%       - f: [MHz] MxN matrix with calculated frequency
%       - w_max: [dpm] MxN matrix of maximum rotational velocity
%       - TreatmentControllerSummary.png
%           - row 1: control angle
%           - row 2: imagesc with rows as UA elements, columns as dyn, and colorscale as desired power (low frequency in red, high frequency in blue)
%           - row 3: imagesc with rows as UA elements, columns as dyn, and colorscale as control temperature; turns green at 57 degC and yellow/red when above
%           - row 4: imagesc with rows as UA elements, columns as dyn, and colorscale as rotational velocity; overlaid with green dots indicating element with lowest velocity, red dots when control boundary is within MTR, and blue dots when element is either in disabled or Paused state
%       - TreatmentControllerElementSummary.png
%           - row 1: amount of redundancy of minimum velocity to decide UA rotational velocity
%           - row 2: histogram showing how often each UA element is responsible for deciding the UA rotational velocity (not mutually exclusive)
%       - TreatmentControllerAngularSummary.png
%           - Mx2 plots: each plot represents an active element showing as a function of treatment angle:
%               - Control boundary
%               - 55 degC isotherm
%               - energy delivered at each angular segment
%               - starting position and direction of treatment
% 
% By: Ben Leung
% Date: 16-JAN-2017
%%=========================================================================
function TreatmentControllerSummary(SxParameters, segmentIdx)

%% Initialization, load technical logs saved by PEDA
load(fullfile(SxParameters.pathData,'TreatmentControllerInfo.mat'));
load(fullfile(SxParameters.pathData,'TreatmentControllerData.mat'));
load(fullfile(SxParameters.pathData,'HardwareInfo.mat'));
load(fullfile(SxParameters.pathData,'Isotherms.mat'));

% Check if SxParameters has Approaching Boiling Threshold (new in TDC 2.6.3)
if ~exist(fullfile(SxParameters.pathData,'Treatment Controller'))
    mkdir(fullfile(SxParameters.pathData,'Treatment Controller'));
end
pathTreatmentController = fullfile(SxParameters.pathData,'Treatment Controller');

MTR = 8; %[mm] minimum treatment radius (control boundary)
NumImages = length(SxParameters.ImageNumber);
NumElements = SxParameters.NumberSlices - 2;
% NumImages = round(length(TreatmentControllerInfo{1,2})./NumElements);
ActiveSlices = find(SxParameters.isUAactive);
NumActiveElements = sum(SxParameters.isUAactive);

diffImageTime = diff(SxParameters.ImageTime)';
meanImageTime = mean(diffImageTime); %to estimate treatment time
diffImageTime = cat(2,meanImageTime,diffImageTime);

ImageNumber = reshape(TreatmentControllerInfo{1,2},NumElements,NumImages); %image number
ImageNumber = ImageNumber(1,:); %only need first row for plotting

SWVersion = cell2mat(textscan(strrep(SxParameters.SoftwareVersion,'.',' '),'%d'));

if SWVersion(1) == 2 && SWVersion(2) < 10
    element_location = reshape(TreatmentControllerInfo{1,4},NumElements,NumImages); %outer or center
    theta = reshape(TreatmentControllerInfo{1,5},NumElements,NumImages); %[deg] control angle
    theta = theta(ActiveSlices(1)-1,:); %only need first row for plotting
    r = reshape(TreatmentControllerInfo{1,6},NumElements,NumImages); %[mm] control radius
    Tr = reshape(TreatmentControllerInfo{1,7},NumElements,NumImages); %[degC] control temperature
    TMaxSector = reshape(TreatmentControllerInfo{1,11},NumElements,NumImages); %[degC] max temperature in +/-15 deg sector
    Predicted_Temperature_Max = reshape(TreatmentControllerInfo{1,14},NumElements,NumImages); %[degC] predictive max temperature in +/- 15 deg sector
else
    if SWVersion(2) >= 10
        element_location = reshape(TreatmentControllerInfo{1,6},NumElements,NumImages); %outer or center
        theta = reshape(TreatmentControllerInfo{1,7},NumElements,NumImages); %[deg] control angle
        theta = theta(ActiveSlices(1)-1,:); %only need first row for plotting
        r = reshape(TreatmentControllerInfo{1,8},NumElements,NumImages); %[mm] control radius
        Tr = reshape(TreatmentControllerInfo{1,9},NumElements,NumImages); %[degC] control temperature
        TMaxSector = reshape(TreatmentControllerInfo{1,14},NumElements,NumImages); %[degC] max temperature in +/-15 deg sector
        Predicted_Temperature_Max = reshape(TreatmentControllerInfo{1,17},NumElements,NumImages); %[degC] predictive max temperature in +/- 15 deg sector
    else
    end
end
% use later for finding bugs
nancount.r = length(r(isnan(r)))-(NumElements-NumActiveElements)*NumImages;             r(isnan(r)) = 0;
nancount.Tr = length(Tr(isnan(Tr)))-(NumElements-NumActiveElements)*NumImages;          Tr(isnan(Tr)) = 0;
nancount.TMaxSector = length(TMaxSector(isnan(TMaxSector)))-(NumElements-NumActiveElements)*NumImages;    TMaxSector(isnan(TMaxSector)) = 0;
nancount.Predicted_Temperature_Max = length(Predicted_Temperature_Max(isnan(Predicted_Temperature_Max)))-(NumElements-NumActiveElements)*NumImages; Predicted_Temperature_Max(isnan(Predicted_Temperature_Max)) = 0;

% convert to Slice indexing
r =                         padarray(r, [1 0], 0);
Tr =                        padarray(Tr, [1 0], 0);
TMaxSector =                padarray(TMaxSector, [1 0], 0);
Predicted_Temperature_Max = padarray(Predicted_Temperature_Max, [1 0], 0);
element_location =          [element_location(1,:); element_location; element_location(end,:)];

% if there are multiple subsegments, use the combined boundary
if ~isempty(SxParameters.Combined)
    TreatedSectorOriginal = SxParameters.Combined.TreatedSector;
    ControlBoundaryMM = SxParameters.Combined.ControlBoundaryMM;
else
    TreatedSectorOriginal = SxParameters.TreatedSector;
    ControlBoundaryMM = SxParameters.ControlBoundaryMM;
end

% determine unique ImageNumber indices in HardwareInfo.mat
[~,HIind,~] = unique(HardwareInfo{:,2},'legacy'); %legacy argument finds last instance of unique elements (which is equivalent to TreatmentControlllerData)
HIind = HIind(find(HardwareInfo{:,2}(HIind)>23));
if ~isequal(HardwareInfo{:,2}(HIind),ImageNumber')
    error(sprintf('HardwareInfo.mat (%i) and TreatmentControllerData.mat (%i) ImageNumber fields are not equivalent', length(HardwareInfo.ImageNumber(HIind)),length(ImageNumber')))
    return
end
yTicksVelocity = [4 20 50 120];

IsNotActive = logical(zeros(NumElements,NumImages));
IsNotActive(1,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E1(HIind));
IsNotActive(2,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E2(HIind));
IsNotActive(3,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E3(HIind));
IsNotActive(4,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E4(HIind));
IsNotActive(5,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E5(HIind));
IsNotActive(6,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E6(HIind));
IsNotActive(7,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E7(HIind));
IsNotActive(8,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E8(HIind));
IsNotActive(9,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E9(HIind));
IsNotActive(10,:) = cellfun(@(x) strcmp(x,'False'),HardwareInfo.IsActive_E10(HIind));
IsNotActive = padarray(IsNotActive, [1 0], 1);

[sliceIsNotActive,imIsNotActive]=find(IsNotActive); %find indices where UA element is disabled by user
[sliceMTR,imMTR] = find(r<MTR); %find indices where UA is within MTR (at each element)
[sliceIs90degC,imIs90degC] = find(TMaxSector>min(SxParameters.ApproachingBoilingThreshold(:)));
[sliceIs57degC,imIs57degC] = find(Tr>=57 | Predicted_Temperature_Max>=57);
f_low = SxParameters.UA.LowFrequency;
f_high = SxParameters.UA.HighFrequency;
first_TMap = zeros(SxParameters.NumberSlices,NumImages);

w = zeros(SxParameters.NumberSlices,NumImages);
p = zeros(SxParameters.NumberSlices,NumImages);
f = zeros(SxParameters.NumberSlices,NumImages);
w_max = zeros(SxParameters.NumberSlices,NumImages);

%% For TDC verson < 2.6.3
if ~any(strcmp('TemperatureApproachingBoilingLevelThreshold',fieldnames(TreatmentControllerData)))
    TreatmentControllerData.TemperatureApproachingBoilingLevelThreshold = repmat(90,NumImages,1);
end

for dynIdx = 1:SxParameters.ImageNumber(end) % loop through dyns
    offsetDynIdx = dynIdx-(SxParameters.ImageNumber(1)-1);
    InTreatment = dynIdx >= SxParameters.ImageNumber(1);
    if InTreatment
        for sliceIdx = 1:SxParameters.NumberSlices %loop through slices
            if SxParameters.isUAactive(sliceIdx) == 1
                [w(sliceIdx,offsetDynIdx),p(sliceIdx,offsetDynIdx),f(sliceIdx,offsetDynIdx),w_max(sliceIdx,offsetDynIdx)] = Control_Algorithm(r(sliceIdx,offsetDynIdx),TMaxSector(sliceIdx,offsetDynIdx),f_low,f_high,Tr(sliceIdx,offsetDynIdx),element_location(sliceIdx,offsetDynIdx),first_TMap(sliceIdx,offsetDynIdx),Predicted_Temperature_Max(sliceIdx,offsetDynIdx),TreatmentControllerData.TemperatureApproachingBoilingLevelThreshold(offsetDynIdx));
                if IsNotActive(sliceIdx,offsetDynIdx)
                    w(sliceIdx,offsetDynIdx) = w_max(find(SxParameters.isUAactive,1),1); %this is not exactly equivalent to controller but guarantees that disabled elements don't influence the rotational velocity decision
                end
            end
        end
    
        % If TDC is paused, power on all elements is set to 0 and rotational velocity is also set to zero.  Here it is set to w_max to not interfere with rotational velocity calculation
        if strcmp(TreatmentControllerData.TreatmentState(offsetDynIdx), 'Paused')
            w(:,offsetDynIdx) = w_max(find(SxParameters.isUAactive,1),1);
        end
    end
end
IsPaused = cellfun(@(x) strcmp(x,'Paused'), TreatmentControllerData.TreatmentState)';
[sliceIsPaused,imIsPaused]=find(repmat(IsPaused,SxParameters.NumberSlices,1));

%% generate matrix indicating power desired
% add 4 Wa to high frequency values, so colorbar is
% 0 (black): off
% 0-4 (red gradient): low frequency Wa
% 4-6 (blue gradient): high frequency Wa

frequency = f;
power = p;
power(frequency==f_high) = power(frequency==f_high) + 4; % separate low and high frequency for plotting
power = power.*repmat(~IsPaused,SxParameters.NumberSlices,1);

%% Calculate energy using HardwareInfo instead of TreatmentController (higher temporal resolution)
HI_powerDesiredWa = zeros(size(HardwareInfo,1),NumElements);
HI_powerDesiredWa(:,1) = HardwareInfo.PowerDesiredWa_E1;
HI_powerDesiredWa(:,2) = HardwareInfo.PowerDesiredWa_E2;
HI_powerDesiredWa(:,3) = HardwareInfo.PowerDesiredWa_E3;
HI_powerDesiredWa(:,4) = HardwareInfo.PowerDesiredWa_E4;
HI_powerDesiredWa(:,5) = HardwareInfo.PowerDesiredWa_E5;
HI_powerDesiredWa(:,6) = HardwareInfo.PowerDesiredWa_E6;
HI_powerDesiredWa(:,7) = HardwareInfo.PowerDesiredWa_E7;
HI_powerDesiredWa(:,8) = HardwareInfo.PowerDesiredWa_E8;
HI_powerDesiredWa(:,9) = HardwareInfo.PowerDesiredWa_E9;
HI_powerDesiredWa(:,10) = HardwareInfo.PowerDesiredWa_E10;
HI_powerDesiredWa = padarray(HI_powerDesiredWa, [0 1], 0);

HI_powerNetWa = zeros(size(HardwareInfo,1),NumElements);
HI_powerNetWa(:,1) = HardwareInfo.PowerNetWa_E1;
HI_powerNetWa(:,2) = HardwareInfo.PowerNetWa_E2;
HI_powerNetWa(:,3) = HardwareInfo.PowerNetWa_E3;
HI_powerNetWa(:,4) = HardwareInfo.PowerNetWa_E4;
HI_powerNetWa(:,5) = HardwareInfo.PowerNetWa_E5;
HI_powerNetWa(:,6) = HardwareInfo.PowerNetWa_E6;
HI_powerNetWa(:,7) = HardwareInfo.PowerNetWa_E7;
HI_powerNetWa(:,8) = HardwareInfo.PowerNetWa_E8;
HI_powerNetWa(:,9) = HardwareInfo.PowerNetWa_E9;
HI_powerNetWa(:,10) = HardwareInfo.PowerNetWa_E10;
HI_powerNetWa = padarray(HI_powerNetWa, [0 1], 0);

HI_f_low_mask = logical(zeros(size(HardwareInfo,1),NumElements));
HI_f_low_mask(:,1) = HardwareInfo.Frequency_E1 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,2) = HardwareInfo.Frequency_E2 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,3) = HardwareInfo.Frequency_E3 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,4) = HardwareInfo.Frequency_E4 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,5) = HardwareInfo.Frequency_E5 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,6) = HardwareInfo.Frequency_E6 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,7) = HardwareInfo.Frequency_E7 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,8) = HardwareInfo.Frequency_E8 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,9) = HardwareInfo.Frequency_E9 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask(:,10) = HardwareInfo.Frequency_E10 == repmat(SxParameters.UA.LowFrequency,size(HardwareInfo,1),1);
HI_f_low_mask = padarray(HI_f_low_mask, [0 1], 0);

HI_f_high_mask = logical(zeros(size(HardwareInfo,1),NumElements));
HI_f_high_mask(:,1) = HardwareInfo.Frequency_E1 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,2) = HardwareInfo.Frequency_E2 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,3) = HardwareInfo.Frequency_E3 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,4) = HardwareInfo.Frequency_E4 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,5) = HardwareInfo.Frequency_E5 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,6) = HardwareInfo.Frequency_E6 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,7) = HardwareInfo.Frequency_E7 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,8) = HardwareInfo.Frequency_E8 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,9) = HardwareInfo.Frequency_E9 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask(:,10) = HardwareInfo.Frequency_E10 == repmat(SxParameters.UA.HighFrequency,size(HardwareInfo,1),1);
HI_f_high_mask = padarray(HI_f_high_mask, [0 1], 0);

HI_theta = wrapTo360(HardwareInfo.PSPositionDeg_Actual);

diffElapsedTime_sec = repmat(cat(1,diff(HardwareInfo.ElapsedTime_sec), diff(HardwareInfo.ElapsedTime_sec(end-1:end))),1,SxParameters.NumberSlices);
diffElapsedTime_sec(isnan(diffElapsedTime_sec)) = 0;

HI_energylowDesired =   HI_powerDesiredWa.*diffElapsedTime_sec.*HI_f_low_mask./1e3;
HI_energyhighDesired =  HI_powerDesiredWa.*diffElapsedTime_sec.*HI_f_high_mask./1e3;
HI_energylowNet =       HI_powerNetWa.*diffElapsedTime_sec.*HI_f_low_mask./1e3;
HI_energyhighNet =      HI_powerNetWa.*diffElapsedTime_sec.*HI_f_high_mask./1e3;

HI_energylowDesiredAngle = zeros(SxParameters.NumberSlices,360);
HI_energylowNetAngle = zeros(SxParameters.NumberSlices,360);
HI_energyhighDesiredAngle = zeros(SxParameters.NumberSlices,360);
HI_energyhighNetAngle = zeros(SxParameters.NumberSlices,360);
HI_theta_mask = logical(zeros(size(HardwareInfo,1),360));

% bin the energies into angular increments of 1�
for angleIdx = 0:359
    HI_theta_mask(:,angleIdx+1) = round(HI_theta) == repmat(angleIdx,size(HardwareInfo,1),1);
    theta_mask_temp = repmat(HI_theta_mask(:,angleIdx+1),1,SxParameters.NumberSlices);
    HI_energylowDesiredAngle(:,angleIdx+1) = sum(HI_energylowDesired.*theta_mask_temp);
    HI_energyhighDesiredAngle(:,angleIdx+1) = sum(HI_energyhighDesired.*theta_mask_temp);
    HI_energylowNetAngle(:,angleIdx+1) = sum(HI_energylowNet.*theta_mask_temp);
    HI_energyhighNetAngle(:,angleIdx+1) = sum(HI_energyhighNet.*theta_mask_temp);
end



%% Determine velocity of next fastest element after the slowest element
[w_min, ~] = min(w(ActiveSlices,:));
[w_sort, sort_ind] = sort(w(ActiveSlices,:));
% [~, sort_ind2] = sort(sort_ind);
min_ind_cell = cell(1,NumImages); %use cells to determine redundancies
legendTitles = cell(1,NumActiveElements+1);

nextfastest = w_sort(2,:) - w_sort(1,:);
nextfastestunique = zeros(1,SxParameters.ImageNumber(end)); %if slowest element is multiple elements, find next fastest unique velocity
dw_sort = diff(w_sort);

for dynIdx = 1:NumImages
    if sum(dw_sort(:,dynIdx))~=0
        nextfastestunique(dynIdx) = dw_sort(find(dw_sort(:,dynIdx),1),dynIdx);
    end
    min_ind_cell{dynIdx} = find(w(:,dynIdx)==w_min(dynIdx))';
end

%% cmaps generation
cmap = CreateColormap('TMap',min(SxParameters.ApproachingBoilingThreshold(:)));
% Slightly modify the colormap to show green as 54, 55, 56 (at control) instead of 52, 53, 54 (at prostate)
FiftyFiveDegrees = find(ismember(cmap,[1 1 0],'rows'));
cmap(FiftyFiveDegrees:(FiftyFiveDegrees+1),:) = [cmap(FiftyFiveDegrees-1,:); cmap(FiftyFiveDegrees-1,:)];
cmap((FiftyFiveDegrees-3):(FiftyFiveDegrees-2),:) = [cmap(FiftyFiveDegrees-4,:); cmap(FiftyFiveDegrees-4,:)];

%cmap for power
cmappower = zeros(61,3);
cmappower(2:length(0.1:0.1:4)+1,1) = ones(1,length(0.1:0.1:4));
cmappower(length(0.1:0.1:4)+1:-1:2,2) = normalizemat(0.1:0.1:4);
cmappower(length(0.1:0.1:4)+1:-1:2,3) = normalizemat(0.1:0.1:4);
cmappower(end:-1:length(0.1:0.1:4)+2,1) = normalizemat(0.1:0.1:2);
cmappower(end:-1:length(0.1:0.1:4)+2,2) = normalizemat(0.1:0.1:2);
cmappower(end:-1:length(0.1:0.1:4)+2,3) = ones(1,length(0.1:0.1:2));

%% Plotting
% =================== TREATMENT CONTROLLER SUMMARY ========================
figure('units','normalized','position',[0 0 1 1])
ax1 = axes('units','normalized','position',[0.1 0.75 0.8 0.2]);
yyaxis right
plot(ImageNumber,theta,'-k','LineWidth',2)
set(gca,'YTick', [30 90 150 210 270 330], 'YTickLabel', [30 90 150 210 270 330],'xLim',[24 ImageNumber(1,end)],'yLim',[-10 370],'YColor','k')
ylabel('Control Angle (�)')
yyaxis left
set(gca,'YTick', [30 90 150 210 270 330], 'YTickLabel', deg2clock([30 90 150 210 270 330]),'xLim',[24 ImageNumber(1,end)],'yLim',[-10 370],'YColor','k')
ylabel('Control Angle (clock hours)')
grid on

counter = 0;
for sliceIdx = ActiveSlices
    counter = counter + 1;
    elementIdx = sliceIdx - 1;
    if dynIdx == ActiveSlices(1)
        legendTitles{counter} = ['APEX, E' int2str(elementIdx)];
    elseif dynIdx == ActiveSlices(end)
        legendTitles{counter} = ['BASE, E' int2str(elementIdx)];
    else
        legendTitles{counter} = ['E' int2str(elementIdx)];
    end
end

ax2 = axes('units','normalized','position',[0.1 0.52 0.8 0.2]);
imagesc(ImageNumber,ActiveSlices,power(ActiveSlices,:))
ylabel('Power Summary', 'FontSize', 14)
set(gca,'YDir','normal','YTick',ActiveSlices,'YTickLabel',legendTitles,'TickLength',[0 0])
colormap(ax2,cmappower)
caxis(ax2,[0 6])
cb = colorbar;
set(cb,'YTick', [0:6],'YTickLabel', {'Off'; '1'; '2'; '3'; '4'; '1'; '2'}, 'Position',[0.92 0.52 .02 0.2])
ylabel(cb, {'Desired Power (W_a)'; ['Red: ' num2str(f_low) ' MHz        Blue: ' num2str(f_high) ' MHz']} )

ax3 = axes('units','normalized','position',[0.1 0.29 0.8 0.2]);
imagesc(ImageNumber,ActiveSlices,Tr(ActiveSlices,:))
ylabel('Temperature Summary', 'FontSize', 14)
set(gca,'YDir','normal','YTick',ActiveSlices,'YTickLabel',legendTitles,'TickLength',[0 0])
colormap(ax3,cmap)
caxis(ax3,[20 101])
cb = colorbar;
set(cb,'YTick', [20:10:50 57 70:10:80 min(SxParameters.ApproachingBoilingThreshold(:)) 100],'YTickLabel', [20:10:50 57 70:10:80 min(SxParameters.ApproachingBoilingThreshold(:)) 100], 'Position',[0.92 0.29 .02 0.2])
ylabel(cb, 'Control Temperature (�C)')

ax4 = axes('units','normalized','position',[0.1 0.06 0.8 0.2]);
imagesc(ImageNumber,ActiveSlices,log10(w(ActiveSlices,:)))
ylabel('Velocity Summary', 'FontSize', 14)
set(gca,'YDir','normal','YTick',ActiveSlices,'YTickLabel',legendTitles,'TickLength',[0 0])
colormap(ax4,gray)
cb = colorbar;
set(cb,'YTick', log10(yTicksVelocity),'YTickLabel', yTicksVelocity, 'Position',[0.92 0.06 .02 0.2])
ylabel(cb, {'Rotational velocty (dpm)'; 'Cyan: Slowest Element(s)'; 'Red: Within MTR'; ['Green: >57^\circC   Purple: >' num2str(min(SxParameters.ApproachingBoilingThreshold(:))) '^\circC']; 'Blue: IsNotActive OR IsPaused'})
hold on
for dynIdx = 1:NumImages
    plot(repmat(ImageNumber(dynIdx),1,length(min_ind_cell{dynIdx})), min_ind_cell{dynIdx}, '.c')
end
plot(ImageNumber(imIs57degC),sliceIs57degC,'.', 'MarkerEdgeColor', [0 0.5 0]);
plot(ImageNumber(imIs90degC),sliceIs90degC,'.', 'MarkerEdgeColor', [0.35 0.25 0.35]);
plot(ImageNumber(imMTR),sliceMTR,'.r');%,'MarkerEdgeColor', [218 165 32]./255)
plot(ImageNumber(imIsNotActive),sliceIsNotActive,'.', 'MarkerEdgeColor', [0 0 1]);
plot(ImageNumber(imIsPaused),sliceIsPaused,'.', 'MarkerEdgeColor', [0 0 1]);

xlabel('ImageNumber')
linkaxes([ax1 ax2 ax3 ax4], 'x');

print(gcf, fullfile(pathTreatmentController,strjoin([SxParameters.PatientID "_TreatmentControllerSummary_Segment" num2str(segmentIdx) ".png"], '')), '-dpng');
close(gcf)

% ====================== ELEMENT SUMMARY ==================================
figure('units','normalized','position',[0.2 0.1 0.6 0.8])
ActiveElements = ActiveSlices - 1;
for offsetDynIdx = find(IsPaused)
    min_ind_cell{offsetDynIdx} = [];
end
ax1 = subplot(221);
h = hist(cell2mat(min_ind_cell), ActiveSlices);
bar(ActiveElements, h./NumImages*100, 'EdgeColor', 'none')
axis([ActiveElements(1)-0.5 ActiveElements(end)+0.5 0 1.1*max(h./NumImages*100)])
xlabel('Element Number')
ylabel({'Percentage of Segment', 'being the slowest element'})

meanRadius = zeros(1,SxParameters.NumberSlices);
stdRadius = zeros(1,SxParameters.NumberSlices);
boundv = zeros(1,SxParameters.NumberSlices);

zres = 4;
for sliceIdx = ActiveSlices
    tempr = r(sliceIdx,:); %as a function of dyns
    tempR = ControlBoundaryMM(:,sliceIdx); %as a function of angle
    tempw = w(sliceIdx,:);
    tempp = power(sliceIdx,:);
    meanRadius(sliceIdx) = mean(tempr(tempr>MTR));
    stdRadius(sliceIdx) = std(tempr(tempr>MTR));
    boundv(sliceIdx) = sum((tempR(tempR>MTR).^2).*(pi/180)./2.*zres); %control volume
end

ax2 = subplot(223);
hBar = bar(ActiveElements, meanRadius(ActiveSlices), 'FaceColor', [218 165 32]./255 , 'EdgeColor', 'none');
hold on
hError = errorbar(ActiveElements, meanRadius(ActiveSlices), stdRadius(ActiveSlices), '.k');
hPlot = plot(ActiveElements, max(r(ActiveSlices,:),[],2), '*k');
plot([0 11], [30 30], '--k')
legend([hBar, hError, hPlot],{'Mean (excludes points within MTR)', 'Standard Deviation', 'Maximum'})
axis([ActiveElements(1)-0.5 ActiveElements(end)+0.5 0 42])
ylabel('Control Radius (mm)')
xlabel('Element Number')

ax3 = subplot(222);
bar(ActiveElements, mean(w(ActiveSlices,:),2), 'FaceColor', [1 1 1]*0.75 , 'EdgeColor', 'none')
axis([ActiveElements(1)-0.5 ActiveElements(end)+0.5 0 1.1*max(w(:))])
ylabel({'Mean requested ', 'rotation speed (dpm)'})
xlabel('Element Number')

ax4 = subplot(224);
hBar = bar(ActiveElements,cat(2,sum(HI_energylowNetAngle(ActiveSlices,:),2), sum(HI_energyhighNetAngle(ActiveSlices,:),2)), 'stacked', 'EdgeColor', 'none');
set(ax4, 'xLim', [ActiveElements(1)-0.5 ActiveElements(end)+0.5]);
set(hBar,{'FaceColor'},{'r';'b'});
legend([num2str(f_low,2) ' MHz'], [num2str(f_high,2) ' MHz'])
xlabel('Element Number');
ylabel('Net Energy delivered (kJ_a)')

print(gcf, fullfile(pathTreatmentController,strjoin([SxParameters.PatientID "_TreatmentControllerElementSummary_Segment" num2str(segmentIdx) ".png"], '')), '-dpng');
close(gcf)

% ======================= ANGULAR SUMMARY =================================
figure('units','normalized','position',[0 0 1 1])
counter = 0;
TreatedSectorind = find(abs(diff(TreatedSectorOriginal))>1);
for sliceIdx = ActiveSlices
    counter = counter+1;
    elementIdx = sliceIdx-1;
    subplot(round(NumActiveElements/2),2,counter)
    yyaxis left
    hcontrol = plot(0:359, ControlBoundaryMM(:,sliceIdx), '-k', 'LineWidth', 2);
    hold on
    
    TreatedSector = NaN(1,length(TreatedSectorOriginal) + length(TreatedSectorind)); %preallocate NaNs
    isotherm = NaN(1,length(TreatedSectorOriginal) + length(TreatedSectorind));
    idx = setdiff(1:length(TreatedSectorOriginal) + length(TreatedSectorind), TreatedSectorind+1);
    TreatedSector(idx) = TreatedSectorOriginal;
    isotherm(idx) = isothermRadius(:,sliceIdx);
    hisotherm = plot(TreatedSector, isotherm, '-', 'Color', [0 0.749 0]);
    htreatable = plot([0 361 361 30], [8 8 30 30], '--k');
    
    text(7,35-NumActiveElements/2,['E' num2str(elementIdx)],'FontSize',14)
    if round(theta(1))==0; theta(1) = 360; end;
    if strcmp(HardwareInfo.UARotationDirection(1),'Counterclockwise')
        hstart = plot(theta(1), ControlBoundaryMM(round(theta(1)),sliceIdx), '>r', 'MarkerFaceColor', [1 0 0], 'MarkerSize',7);
        direction = 'CCW';
    else
        hstart = plot(theta(1), ControlBoundaryMM(round(theta(1)),sliceIdx), '<r', 'MarkerFaceColor', [1 0 0], 'MarkerSize',7);
        direction = 'CW';
    end
    
    set(gca,'XTick', [0:30:360], 'XTickLabel', deg2clock([0:30:360]),'XTickLabelRotation', 45, 'xLim',[0 360],'yLim',[0 35],'YColor','k')
    if sliceIdx == ActiveSlices(end) || sliceIdx == ActiveSlices(end-1); xlabel('Treatment Angle (clock hours)'); end;
    ylabel({'Distance from '; 'UA center (mm)'})
    
    yyaxis right
    hBar = bar(0:359, cat(2,(HI_energylowNetAngle(sliceIdx,:)'), (HI_energyhighNetAngle(sliceIdx,:)')), 'stacked', 'EdgeColor', 'none', 'BarWidth', 1, 'FaceAlpha', 0.5);
    set(hBar,{'FaceColor'},{'r';'b'});
    HI_energylowDesiredAngle(HI_energylowDesiredAngle==0) = -0.001;
    HI_energyhighDesiredAngle(HI_energyhighDesiredAngle==0) = -0.001;
    stairs([0:359]-0.5, HI_energylowDesiredAngle(sliceIdx,:)', '-r')
    stairs([0:359]-0.5, HI_energyhighDesiredAngle(sliceIdx,:)', '-b')
    if max(max(HI_energylowDesiredAngle)) > 0; set(gca,'yLim',[0 1.2*max(max(HI_energylowDesiredAngle))],'YColor','k'); end;
    if NumActiveElements > 6; set(gca,'FontSize',8); end;
    ylabel({'Net Energy delivered (bar)'; 'Energy desired (line)' ; '(kJ_a)'})
    if sliceIdx == ActiveSlices(end)
        legend([hcontrol hisotherm htreatable hstart],{'Control boundary', '57�C isotherm', 'Treatable range', ['Treatment Start (' direction ')']}, 'Position', [0.827 0.94 0.05 0.05]);
    end
end

print(gcf, fullfile(pathTreatmentController,strjoin([SxParameters.PatientID "_TreatmentControllerAngularSummary_Segment" num2str(segmentIdx) ".png"], '')), '-dpng');
close(gcf)

save(fullfile(pathTreatmentController,'EnergyDesiredkJ_LowFrequency.mat'),'HI_energylowDesiredAngle');
save(fullfile(pathTreatmentController,'EnergyNetkJ_LowFrequency.mat'),'HI_energylowNetAngle');
save(fullfile(pathTreatmentController,'EnergyDesiredkJ_HighFrequency.mat'),'HI_energyhighDesiredAngle');
save(fullfile(pathTreatmentController,'EnergyNetkJ_HighFrequency.mat'),'HI_energyhighNetAngle');


%% old

% figure(100)
% hold on
% plot(boundv./1e3, sum(energylow + energyhigh, 2)./1e3, 'xg')
% 
% figure(4)
% hold on
% plot(mean(w(1:NumActiveElements,:),2), sum(energylow + energyhigh,2)/1e3,'xg')


% for pp = 1:3
%     figure('units','normalized','position',[0 0 1 1])
%     ax1 = axes('units','normalized','position',[0.1 0.69 0.8 0.28]);
%     if pp == 1 || pp == 2
%         hold off
%         for ii = 1:NumActiveElements
%             semilogy(ImageNumber,w(ii,:))
%             hold on
%             leg{ii} = ['E' int2str(ii)];
%         end
%         leg{end} = sprintf('%s\n%s', 'Minimum', 'velocity');
%         plot(TreatmentControllerData.ImageNumber, TreatmentControllerData.RotationVelocity, ':k', 'LineWidth', 2) %uses the technical log (which is shown to be equivalent by overlaying the Matlab pipeline)
%         % plot(ImageNumber, w_min, ':k', 'LineWidth', 2) % Matlab pipeline minimum rotation velocity
%         set(gca,'YScale','log')
%         ylabel('Rotational Velocities (dpm)')
%         lh = legend(leg);%,'Location','northeastoutside');
%         set(lh,'Position',[0.92 0.71 .04 0.25])
%         axis([24 ImageNumber(1,end) -6 w_max(1,end)+10])
%         set(gca,'YTick',yTicks,'YTickLabel',yTicks)
%     elseif pp == 3
%         yyaxis left
%         plot(ImageNumber,theta,'-r','LineWidth',2)
%         set(gca,'YTick', [30 90 150 210 270 330], 'YTickLabel', [30 90 150 210 270 330],'xLim',[24 ImageNumber(1,end)],'yLim',[-10 370],'YColor','k')
%         ylabel('Control Angle (�)')
%         yyaxis right
%         set(gca,'YTick', [30 90 150 210 270 330], 'YTickLabel', {deg2clock(30); deg2clock(90); deg2clock(150); deg2clock(210); deg2clock(270); deg2clock(330)},'xLim',[24 ImageNumber(1,end)],'yLim',[-10 370],'YColor','k')
%         ylabel('Control Angle (clock hours)')
% %         axis([24 ImageNumber(1,end) -10 370])
%         grid on
%     end
%     
%     ax2 = axes('units','normalized','position',[0.1 0.37 0.8 0.28]);
%     if pp == 1
%         plot(ImageNumber, nextfastest,'-b')
%         hold on
%         plot(ImageNumber, nextfastestunique,'--r')
%         set(gca,'YScale','lin')
%         axis([24 ImageNumber(1,end) -6 w_max(1,end)+10])
%         ylabel({'Difference in', 'Rotational Velocities (dpm)'})
%         lh = legend(sprintf('%s\n%s', 'Next fastest', 'rotational velocity' ), sprintf('%s\n%s', 'Next fastest unique', 'rotational velocity' ));%,'Location','northeastoutside')
%         set(lh,'Position',[0.92 0.57 .06 0.08])
%     elseif pp == 2
%         errorbarpatch(ax2,ImageNumber,mean(w(1:NumActiveElements,:)), std(w(1:NumActiveElements,:),0));
%         hold on
%         plot(TreatmentControllerData.ImageNumber, TreatmentControllerData.RotationVelocity, ':k', 'LineWidth', 2)
%         lh = legend(sprintf('%s\n%s', 'Mean', 'velocity'), sprintf('%s\n%s', 'Standard', 'deviation'), sprintf('%s\n%s', 'Minimum', 'velocity'));
%         set(lh,'Position',[0.92 0.55 .06 0.1])
%         ylabel('Rotational Velocities (dpm)')
%         box on
%     elseif pp == 3
%         imagesc(ImageNumber,1:NumActiveElements,Tr(1:NumActiveElements,:))
%         set(gca,'YDir','normal','YTick',1:NumActiveElements,'YTickLabel',leg)
%         colormap(ax2,cmap)
%         caxis(ax2,[35 65])
%         cb = colorbar;
%         set(cb,'YTick', [35:5:50 57 60:5:65],'YTickLabel', [35:5:50 57 60:5:65], 'Position',[0.92 0.37 .02 0.28])
%         ylabel(cb, 'Control Temperature (�C)')
%     end
%     
%     ax3 = axes('units','normalized','position',[0.1 0.05 0.8 0.28]);
%     if pp == 1 || pp == 3
% %         imagesc(ImageNumber,1:NumActiveElements,log10(w(1:NumActiveElements,:)))
% %         set(gca,'YDir','normal','YTick',1:NumActiveElements,'YTickLabel',leg)
% %         colormap(ax3,gray)
% %         cb = colorbar;
% %         set(cb,'YTick', log10(yTicks),'YTickLabel', yTicks, 'Position',[0.92 0.05 .02 0.28])
% %         ylabel(cb, 'Rotational velocty (dpm)')
% %         hold on
% %         plot(ImageNumber,min_ind,'.g')
% %         xlabel('ImageNumber')
%         imagesc(ImageNumber,1:NumActiveElements,log10(w(1:NumActiveElements,:)))
%         ylabel('Velocity Summary', 'FontSize', 14)
%         set(gca,'YDir','normal','YTick',1:NumActiveElements,'YTickLabel',leg,'TickLength',[0 0])
%         colormap(ax3,gray)
%         cb = colorbar;
%         set(cb,'YTick', log10(yTicks),'YTickLabel', yTicks, 'Position',[0.92 0.06 .02 0.2])
%         ylabel(cb, {'Rotational velocty (dpm)'; 'Green: Slowest Element(s)'; 'Red: Within MTR'; 'Blue: IsNotActive OR IsPaused'})
%         hold on
% %         plot(ImageNumber,min_ind,'.g')
%         for ii = 1:NumImages
%            plot(repmat(ImageNumber(ii),1,length(min_ind_cell{ii})), min_ind_cell{ii}, '.g')
%         end
%         plot(ImageNumber(imMTR),elemMTR,'.r');%,'MarkerEdgeColor', [218 165 32]./255)
%         plot(ImageNumber(imIsNotActive),elemIsNotActive,'.', 'MarkerEdgeColor', [0 0 1]);
%         plot(ImageNumber(imIsPaused),elemIsPaused,'.', 'MarkerEdgeColor', [0 0 1]);
% 
%         xlabel('ImageNumber')
%     else
%         plot(ImageNumber, mean(w(1:NumActiveElements,:)) - min(w(1:NumActiveElements,:)), '-b')
%         xlabel('ImageNumber')
%         ylabel({'Difference of mean and', 'minimum velocity (dpm)'})
%         linkaxes([ax2 ax3], 'xy')
%     end
%     linkaxes([ax1 ax2 ax3], 'x');
%     print(gcf, fullfile(fileparts(fileparts(pathPEDAsegment)),['TreatmentController' int2str(pp) '.png']), '-dpng');
% %     if pp == 1
% %         print(gcf, fullfile(fileparts(fileparts(pathPEDAsegment)),'TreatmentController1.png'), '-dpng');
% %     else
% %         print(gcf, fullfile(fileparts(fileparts(pathPEDAsegment)),'TreatmentController2.png'), '-dpng');
% %     end
% end