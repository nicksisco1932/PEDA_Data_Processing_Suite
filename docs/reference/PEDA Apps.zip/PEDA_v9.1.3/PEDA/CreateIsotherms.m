function CreateIsotherms(TxParameters)
%==========================================================================
% Purpose:  Calculate isotherm radius, volumetric error and DSC statistics
% and store results into "isotherms.mat"
%
% Inputs:
%      - TxParameters/SxParameters
% Outputs:
%      - None
%==========================================================================

%==========================================================================
% ----- Variable initialization -----
%==========================================================================

% Import matrices
load(fullfile(TxParameters.pathData,'TMaxMasked.mat'));
load(fullfile(TxParameters.pathData,'TDoseMasked.mat'));

% Variables initilzation
num_elems           = length(TxParameters.isUAactive);
if ~isempty(TxParameters.Combined)
    treatedSector   = TxParameters.Combined.TreatedSector;
    TxParameters.ProstateBoundary = TxParameters.Combined.ProstateBoundary;
    TxParameters.ControlBoundary = TxParameters.Combined.ControlBoundary;
else
    treatedSector   = TxParameters.TreatedSector;
end
num_angles          = length(treatedSector);
dx                  = TxParameters.PixelSize;
Tc                  = TxParameters.Tc;
Tc63                = 63;
Tc65                = 65;
Tc55                = 55;
TDoseCEM            = TxParameters.ThermalDoseCEM;
MinTR               = TxParameters.MinimumTreatmentRadiusMM;
MaxTR               = TxParameters.MaximumTreatmentRadiusMM; % in mm
SliceThickness      = TxParameters.SliceThickness; % in mm
isothermRadius      = zeros(num_angles,num_elems);
isothermRadius63    = zeros(num_angles,num_elems);
isothermRadius65    = zeros(num_angles,num_elems);
isothermRadius_combined = zeros(num_angles, num_elems);
isothermRadius55    = zeros(num_angles,num_elems);
isothermRadiusTDose = zeros(num_angles,num_elems);
theta               = zeros(num_angles,num_elems);
MaxProstateRadius   = zeros(num_angles,num_elems);
ux                  = TxParameters.ux(end,:); % Initialize UA center.  Either it is single element (before TDC v2.6.3) or we use the initial UA center which is not slice dependent, so take first value
uy                  = TxParameters.uy(end,:);
UARadius            = TxParameters.UARadius;
AdditionalRadiusMM  = 7; %how many mm beyond prostate radius are we going to look for drawing our isotherm
SelectionOption     = 3;% Isotherm radius detection method if several radii along the same angle were found
                        % 1) Select minimal radius between min_rad and max_rad
                        % 2) Select maximal radius between min_rad and max_rad
                        % 3) Select radius closest to the radius of previously found point, select maximum radius is previous point is NaN

%==========================================================================
% ----- Calculate isotherms ----- 
%==========================================================================
for sliceIdx = 1 : length(TxParameters.isUAactive)
    if ( TxParameters.isUAactive(sliceIdx) == 1)
        % T = Tc (57�C) 
        [isothermRadius(:,sliceIdx),MaxProstateRadius(:,sliceIdx)] = CalculateIsotherm(TMaxMasked(:,:,sliceIdx),  ux(sliceIdx), uy(sliceIdx), TxParameters.PixelSize,...
            TxParameters.ProstateBoundary(treatedSector+1,sliceIdx), treatedSector, Tc, SelectionOption, ...
            TxParameters.ControlBoundary(treatedSector+1,sliceIdx), AdditionalRadiusMM, TxParameters.UARadius);

        % T = 63�C
        isothermRadius63(:,sliceIdx) = CalculateIsotherm(TMaxMasked(:,:,sliceIdx),  ux(sliceIdx), uy(sliceIdx), TxParameters.PixelSize,...
            TxParameters.ProstateBoundary(treatedSector+1,sliceIdx), treatedSector, Tc63, SelectionOption, ...
            TxParameters.ControlBoundary(treatedSector+1,sliceIdx), AdditionalRadiusMM, TxParameters.UARadius);

        % T = 65�C
        isothermRadius65(:,sliceIdx) = CalculateIsotherm(TMaxMasked(:,:,sliceIdx),  ux(sliceIdx), uy(sliceIdx), TxParameters.PixelSize,...
            TxParameters.ProstateBoundary(treatedSector+1,sliceIdx), treatedSector, Tc65, SelectionOption, ...
            TxParameters.ControlBoundary(treatedSector+1,sliceIdx), AdditionalRadiusMM, TxParameters.UARadius);

        % T = 55�C
        isothermRadius55(:,sliceIdx) = CalculateIsotherm(TMaxMasked(:,:,sliceIdx),  ux(sliceIdx), uy(sliceIdx), TxParameters.PixelSize,...
        TxParameters.ProstateBoundary(treatedSector+1,sliceIdx), treatedSector, Tc55, SelectionOption, ...
        TxParameters.ControlBoundary(treatedSector+1,sliceIdx), AdditionalRadiusMM, TxParameters.UARadius);

        % TDose
        isothermRadiusTDose(:,sliceIdx) = CalculateIsotherm(TDoseMasked(:,:,sliceIdx),  ux(sliceIdx), uy(sliceIdx), TxParameters.PixelSize,...
        TxParameters.ProstateBoundary(treatedSector+1,sliceIdx), treatedSector, TDoseCEM, SelectionOption, ...
        TxParameters.ControlBoundary(treatedSector+1,sliceIdx), AdditionalRadiusMM, TxParameters.UARadius);
    end
end

%==========================================================================
% ----- Combine isotherms ----- 
%==========================================================================
% this doesn't account for boost between segments
% basically, every time you combine boundaries, you have to account for
% boost state
for sliceIdx = 1 : length(TxParameters.isUAactive)
    if TxParameters.isUAactive(sliceIdx)
        for angleIdx = 1 : 360
            try
                if ismember(angleIdx, treatedSector+1)
                    if TxParameters.ThermalBoostInfo.TreatmentState(angleIdx,sliceIdx) < 2 % if Thermal Boost was not enabled
                        isothermRadius_combined(find(angleIdx == treatedSector+1), sliceIdx) = isothermRadius(find(angleIdx == treatedSector+1), sliceIdx);
                    else % if Thermal Boost was enabled
                        if TxParameters.ControlBoundary(angleIdx, sliceIdx) < 15./TxParameters.PixelSize
                           isothermRadius_combined(find(angleIdx == treatedSector+1), sliceIdx) = isothermRadius(find(angleIdx == treatedSector+1), sliceIdx);
                        elseif (TxParameters.ControlBoundary(angleIdx, sliceIdx) >= 15./TxParameters.PixelSize && TxParameters.ControlBoundary(angleIdx, sliceIdx) < 29./TxParameters.PixelSize)
                           isothermRadius_combined(find(angleIdx == treatedSector+1), sliceIdx) = isothermRadius63(find(angleIdx == treatedSector+1), sliceIdx);
                        elseif (TxParameters.ControlBoundary(angleIdx, sliceIdx) > 29./TxParameters.PixelSize)
                           isothermRadius_combined(find(angleIdx == treatedSector+1), sliceIdx) = isothermRadius65(find(angleIdx == treatedSector+1), sliceIdx);
                        end
                    end
                end
            catch
                if ismember(angleIdx, treatedSector+1)
                    isothermRadius_combined(find(angleIdx == treatedSector+1), sliceIdx) = isothermRadius(find(angleIdx == treatedSector+1), sliceIdx);
                end
            end
        end
    end
end

%==========================================================================
% ----- Calculate volumetric error and DSC -----
%==========================================================================
if ~isempty(TxParameters.Combined)

    accuracy_result_0mm =               CalculateErrors(isothermRadius_combined,         TxParameters.Combined.ControlBoundaryMM(treatedSector+1,:),      TxParameters.Combined.ProstateBoundaryMM, 0, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates Tc �C versus target, with 0 mm margin
    accuracy_result_1mm =               CalculateErrors(isothermRadius_combined,         TxParameters.Combined.ControlBoundaryMM(treatedSector+1,:),      TxParameters.Combined.ProstateBoundaryMM, 1, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates Tc �C versus target, with 1 mm margin
    accuracy_result_0mm_tdose =         CalculateErrors(isothermRadiusTDose,    TxParameters.Combined.ProstateBoundaryMM(treatedSector+1,:),     TxParameters.Combined.ProstateBoundaryMM, 0, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates 240 EM43 thermal dose versus prostate, with 0 mm margin
    accuracy_result_1mm_tdose =         CalculateErrors(isothermRadiusTDose,    TxParameters.Combined.ProstateBoundaryMM(treatedSector+1,:),     TxParameters.Combined.ProstateBoundaryMM, 1, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates 240 EM43 thermal dose versus prostate, with 1 mm margin
    accuracy_result_0mm_prostate =         CalculateErrors(isothermRadius55,    TxParameters.Combined.ProstateBoundaryMM(treatedSector+1,:),     TxParameters.Combined.ProstateBoundaryMM, 0, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates 55 degC versus prostate, with 0 mm margin
    accuracy_result_1mm_prostate =         CalculateErrors(isothermRadius55,    TxParameters.Combined.ProstateBoundaryMM(treatedSector+1,:),     TxParameters.Combined.ProstateBoundaryMM, 1, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates 55 degC versus prostate, with 1 mm margin

else

    accuracy_result_0mm =               CalculateErrors(isothermRadius_combined,         TxParameters.ControlBoundaryMM(treatedSector+1,:),      TxParameters.ProstateBoundaryMM, 0, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates Tc �C versus target, with 0 mm margin
    accuracy_result_1mm =               CalculateErrors(isothermRadius_combined,         TxParameters.ControlBoundaryMM(treatedSector+1,:),      TxParameters.ProstateBoundaryMM, 1, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates Tc �C versus target, with 1 mm margin
    accuracy_result_0mm_tdose =         CalculateErrors(isothermRadiusTDose,    TxParameters.ProstateBoundaryMM(treatedSector+1,:),        TxParameters.ProstateBoundaryMM, 0, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates 240 EM43 thermal dose versus prostate, with 0 mm margin
    accuracy_result_1mm_tdose =         CalculateErrors(isothermRadiusTDose,    TxParameters.ProstateBoundaryMM(treatedSector+1,:),        TxParameters.ProstateBoundaryMM, 1, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates 240 EM43 thermal dose versus prostate, with 1 mm margin
    accuracy_result_0mm_prostate =         CalculateErrors(isothermRadius55,    TxParameters.ProstateBoundaryMM(treatedSector+1,:),        TxParameters.ProstateBoundaryMM, 0, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates 55 degC versus prostate, with 0 mm margin
    accuracy_result_1mm_prostate =         CalculateErrors(isothermRadius55,    TxParameters.ProstateBoundaryMM(treatedSector+1,:),        TxParameters.ProstateBoundaryMM, 1, MinTR, MaxTR, SliceThickness, TxParameters.isUAactive, treatedSector); %Calculates 55 degCversus prostate, with 1 mm margin


end
   
%==========================================================================
% ----- Save isotherms -----
%==========================================================================
save(fullfile(TxParameters.pathData, 'Isotherms'),'isothermRadius','isothermRadius63','isothermRadius65','isothermRadius_combined', 'MaxProstateRadius','isothermRadius55','isothermRadiusTDose','accuracy_result_0mm','accuracy_result_1mm','accuracy_result_0mm_tdose','accuracy_result_1mm_tdose','accuracy_result_0mm_prostate','accuracy_result_1mm_prostate','SelectionOption');
return;
