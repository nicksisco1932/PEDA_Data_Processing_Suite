%% PostTreatmentOverlay.m =================================================
% This function rescales planning, treatment, and post-treatment images and
% displays them using overlays.  Colormaps are equivalent to TDC, with
% thermometry pixels only appearing if T >= 43�C.
% 
% Inputs:
%   - pathT1:   path to T1w post-treatment DICOMs
%   - argT1:    partial string to identify T1 DICOMs
%   - pathT2:   path to T2w planning DICOMs
%   - argT2:    partial string to identify T1 DICOMs
%   - pathPEDA: path to PEDA folder to load TMaxMasked, TxParameters
%   - options:  structure with fields:
%                   - PathT1Pre: string with path to Pre-contrast T1 DICOMs
%                   - ArgT1Pre:  string with wildcard argument for Pre-contrast T1 DICOMs
%                   - T1ManualCenter: set = 1 to enable override to select UA center manually on T1 images
%                   - ZoomFactor: overrides zoomfactor
%                   - T1Min, T1Max, T2Min, T2Max: relative min and max window values (between 0 and 1)
% 
% Outputs:
%   - figure with 4 rows:
%       - Row 4 (top):  T2w planning images overlaid with prostate boundary (goldenrod with red in cases if prostate is within MTR)
%       - Row 3:        T2w planning images overlaid with TMax (100% opacity), prostate boundary (black), and 240 CEM43 isodose (magenta)
%       - Row 2:        T2w planning images overlaid with TDose (100% opacity) and prostate boundary (black)
%       - Row 1 (bot):  T1w post-treatment images overlaid with 55 degC isotherm (green) and 240 CEM43 isodose (magenta)
%   - Steps:
%       - Index the images onto their respective colormaps
%       - Plot grayscale images
%       - Hold on
%       - Plot TDC colormap thermometry
%       - Apply mask on the 'AlphaData' property of thermometry image
% 
% By Ben Leung
% Date: 20-JUN-2018
% =========================================================================
function PostTreatmentOverlay(pathT1, argT1, pathT2, argT2, pathPEDA, options)
%% Initialization
warning('off','MATLAB:mpath:nameNonexistentOrNotADirectory');
addpath(fullfile(pwd, 'export_fig')); %add path to export_fig function
global blnaccept
blnaccept = 0;
global lr
if ~exist('options')
    options.ZoomFactor = 2.5;
    options.T1ManualCenter = 0;
    options.T1Min = 0;
    options.T1Max = 0.7;
    options.T2Min = 0;
    options.T2Max = 0.8;
    options.LineWidth = 2;
    options.Segment = 0; % 0 means all combined
end

PEDAindex = regexpi(pathPEDA,'PEDA');
PEDA_version = str2num(pathPEDA(PEDAindex+5:end));
if isempty(PEDA_version)
    PEDA_version = 10; % essentially _dev
end

% if exist(fullfile(pathPEDA,'SxParameters.mat'))
%     if exist(fullfile(pathPEDA,'TxParameters.mat'))
%         load(fullfile(pathPEDA,'TxParameters.mat'), 'TxParameters'); % segments combined
%     else
%         load(fullfile(pathPEDA,'SxParameters.mat'), 'SxParameters'); %the only parameters used from SxParameters is ApproachingBoilingThreshold, and ImageShifted ux and uy.  Otherwise, redefine everything in terms of TxParameters to keep uniformity with older PEDA versions
%         TxParameters = SxParameters; %this is a little redundant, but necessary to keep backward compatibility
%         TxParameters.ux = []; % null these fields for identification later
%         TxParameters.uy = [];
%         pathPEDA = fullfile(pathPEDA,'Segment 1'); %there is only 1 segment
%     end
% %     PEDA_version = 8;
% else
%     load(fullfile(pathPEDA,'Segment 1','TxParameters.mat'), 'TxParameters'); % may have to change for multi-segment treatments (only chooses Segment 1)
% %     PEDA_version = 7;
% end

if options.Segment % explicitly load this segment
    load(fullfile(pathPEDA,'SxParameters.mat'), 'SxParameters');
    TxParameters = SxParameters(options.Segment);
    SxParameters = SxParameters(options.Segment);
    pathPEDA = fullfile(pathPEDA,['Segment ' num2str(options.Segment)]);
else
    if exist(fullfile(pathPEDA,'TxParameters.mat'))
        load(fullfile(pathPEDA,'TxParameters.mat'), 'TxParameters'); % segments combined
    else
        load(fullfile(pathPEDA,'SxParameters.mat'), 'SxParameters'); %the only parameters used from SxParameters is ApproachingBoilingThreshold, and ImageShifted ux and uy.  Otherwise, redefine everything in terms of TxParameters to keep uniformity with older PEDA versions
        TxParameters = SxParameters; %this is a little redundant, but necessary to keep backward compatibility
        TxParameters.ux = []; % null these fields for identification later
        TxParameters.uy = [];
        pathPEDA = fullfile(pathPEDA,'Segment 1'); %there is only 1 segment
    end
end


% Load TMax, TDose, and Mask
load(fullfile(pathPEDA,'TMax.mat'));
load(fullfile(pathPEDA,'TDose.mat'));
if exist(fullfile(pathPEDA,'Masks')) == 7 %if the Masks folder exists, it is a single segment treatment.  Mask.mat is located here
    load(fullfile(pathPEDA,'Masks','Mask.mat'));
    Mask = Mask(:,:,:,end); % the loaded mask is a function of dynamic, so take the last dyn
else
    load(fullfile(pathPEDA,'Mask.mat'));
end
TMaxMasked = TMax.*Mask;
TDoseMasked = TDose.*Mask;

if iscell(TMax) %convert cells into matrix if older version of PEDA
    TMaxMaskedtemp = zeros(128,128,TxParameters.NumberSlices);
    TMaxtemp = zeros(128,128,TxParameters.NumberSlices);
    for ii = 1:TxParameters.NumberSlices
        TMaxMaskedtemp(:,:,ii) = TMaxMasked{ii};
        TMaxtemp(:,:,ii) = TMax{ii};
    end
    TMaxMasked = TMaxMaskedtemp;
    TMax = TMaxtemp;
    clear TMaxMaskedtemp; clear TMaxtemp   
end
TMaxCLim = [43 101];
TDoseCLim = [30 1024];
Mask43 = TMaxMasked>=TMaxCLim(1); % additional masking for all pixels 43�C and above
TMaxMasked = TMaxMasked.*Mask43; % overwrite old mask
Mask30CEM = (TDoseMasked>=30); % additional masking for all pixels 30CEM43 and above
TDoseMasked = TDoseMasked.*Mask30CEM; % overwrite old mask
% Load isotherms and colormap
load(fullfile(pathPEDA,'isotherms.mat'));
if PEDA_version < 8.3
   TxParameters.isUAactive = [0 TxParameters.isUAactive 0];
   TxParameters.ProstateBoundaryMM = cat(2,zeros(size(SxParameters.ProstateBoundaryMM,1),1),SxParameters.ProstateBoundaryMM,zeros(size(SxParameters.ProstateBoundaryMM,1),1));
   TxParameters.ControlBoundaryMM = cat(2,zeros(size(SxParameters.ControlBoundaryMM,1),1),SxParameters.ControlBoundaryMM,zeros(size(SxParameters.ControlBoundaryMM,1),1));
   isothermRadius55 = cat(2,zeros(size(isothermRadius55,1),1),isothermRadius55,zeros(size(isothermRadius55,1),1));
   isothermRadiusTDose = cat(2,zeros(size(isothermRadiusTDose,1),1),isothermRadiusTDose,zeros(size(isothermRadiusTDose,1),1));
end
if exist('SxParameters')
    if ~isfield(SxParameters,'ApproachingBoilingThreshold')
        SxParameters.ApproachingBoilingThreshold = 90;
    end
    cmap3 = CreateColormap('TMap', min(SxParameters.ApproachingBoilingThreshold));
else
    cmap3 = CreateColormap('TMap');
end
cmapTDose = CreateColormap('TDose');
cmap3 = cmap3(TMaxCLim(1)-20+1:TMaxCLim(2)-20,:);

if strfind(pathPEDA, 'Commercial')
    site_index = regexp(pathPEDA,'--', 'ONCE');
    patient_index = regexp(pathPEDA,'-+[0-9]+[0-9]+[0-9]', 'ONCE');
%     if isempty(site_index) || isempty(patient_index)
%         error('Invalid Commercial patient ID')
%         return
%     end
%     patientID = pathPEDA([site_index:patient_index]+3);
    patientID = '';
elseif strfind(pathPEDA, 'TACT')
    patient_index = regexp(pathPEDA, '[0-9]+[0-9]+[0-9]+-+[0-9]+[0-9]+[0-9]');
    if isempty(patient_index)
        error('Invalid TACT patient ID')
        return
    end
    patientID = pathPEDA(patient_index:patient_index+6);
else
    warning('Invalid patient directory')
    patientID = 'UnknownPatient';
end

% TxParameters.isUAactive = [1 1 1 1 0 0 0 0 0 0]; %in case it was not written properly in InitializationData.txt at time of running PEDA
if sum(TxParameters.isUAactive) < 3; error('Have not programmed for less than 2 active elements'); return; end;
isPlotSlice = bwmorph(TxParameters.isUAactive,'dilate',1); % slices to plot, dilate to show adjacent slices
FirstSlice = find(isPlotSlice,1);
LastSlice = find(isPlotSlice,1,'last');
NumberofSubplots = sum(isPlotSlice) + 0.4;
% For subplot creation
offset = 0.04; %0.01; %Horizontal offset
spacing = [0.015 0.015 0.015 0.017 0.005 0.005 0.002 0.002 0.002 0.002 0.002 0.002]; %0.015; %Horizontal spacing
plotWidth = (1/NumberofSubplots*(1-2*offset-(NumberofSubplots-1)*spacing(sum(isPlotSlice))));
plotHeight = 1/4*(1-2*offset-(4-1)*spacing(sum(isPlotSlice)));
verticalOffset = 0.3; %0.35
alphaFactor = 0.3;
MinTRmm = 8; %for control boundary
MaxTRmm = 28; %for control boundary
prostateRGB = [218 165 32]./255; %goldenrod, TDC equivalent
prostateRGBlarge = [240 128 128]./255; %light coral, TDC equivalent
scalebar_mm = 10; %length of scalebar in mm
scalebar_margin = 0.05; %fraction of frame edge to inset scalebar

cbTMaxLUT =[0      0       0       0;
            0      0       0       0;
            0      0       0       0;
            0      0       0       0;
            0.945  0.535   0.015   0.208;
            0.945  0.539   0.015   0.200;
            0.945  0.542   0.015   0.200;
            0.945  0.540   0.015   0.205;
            0.955  0.550   0.015   0.185;
            0.955  0.560   0.015   0.165;
            0.955  0.567   0.015   0.150;
            0.955  0.573   0.015   0.138]; %position vector for colorbar, for 5-10 columns

cbTDoseLUT = cbTMaxLUT;
cbTDoseLUT(:,2) = cbTDoseLUT(:,2) - 0.228;

FontSizeLUT =   [10 10 10 10 14 14 14 14 14 12 12 12];
%% Load images and determine scaling factors
if ~isempty(argT1)
    dirT1 = dir(fullfile(pathT1,['*' argT1 '*']));
else
    dirT1 = dir(fullfile(pathT1,['*.*']));
end
if ~isempty(argT2)
    dirT2 = dir(fullfile(pathT2,['*' argT2 '*']));
else
    dirT2 = dir(fullfile(pathT2,['*.*']));
end

%% Use DICOM headers for pixel size and image dimensions
% first clean up files that are not DICOMs (i.e. directories)
dirT1 = dirT1(~[dirT1(:).isdir]);
dirT2 = dirT2(~[dirT2(:).isdir]);
% DICOM slices assumed to be same file size; excludes files of size outside of 3 stdev of median (gets rid on PS or XX DICOMs)
if std([dirT1.bytes]) > 100 % 100 byte threshold 
    dirT1 = dirT1(find([dirT1.bytes] < median([dirT1.bytes]) + 3*std([dirT1.bytes]) & [dirT1.bytes] > median([dirT1.bytes]) - 3*std([dirT1.bytes])));
end
if std([dirT2.bytes]) > 100 % 100 byte threshold 
    dirT2 = dirT2(find([dirT2.bytes] < median([dirT2.bytes]) + 3*std([dirT2.bytes]) & [dirT2.bytes] > median([dirT2.bytes]) - 3*std([dirT2.bytes])));
end

if isfield(options,'PathT1Pre')
    T1mat = subtractT1(options.PathT1Pre, options.ArgT1Pre, pathT1, argT1);
    for ii = 1:length(dirT1)
        infoT1(ii) = dicominfo(fullfile(pathT1,dirT1(ii).name));
    end
else
    for ii = 1:length(dirT1)
        infoT1(ii) = dicominfo(fullfile(pathT1,dirT1(ii).name));
    end
end
lr = round(length(dirT1)/2);

for jj = 1:length(dirT2)
    infoT2(jj) = dicominfo(fullfile(pathT2,dirT2(jj).name));
end

if ~isequal(infoT1(1).FrameOfReferenceUID,infoT2.FrameOfReferenceUID)
    warning('Frame of Reference between T1 and T2 scans are not equal.  Images may not be lined up properly')
end

%can probably do this with SliceLocation as well since you're only comparing against itself
ImagePositionPatientT1 = [infoT1.ImagePositionPatient];
ImagePositionPatientT1 = ImagePositionPatientT1(3,:); % z position
[~,indT1all] = sort(ImagePositionPatientT1,'ascend');
ImagePositionPatientT2 = [infoT2.ImagePositionPatient];
ImagePositionPatientT2 = ImagePositionPatientT2(3,:); % z position
[~,indT2all] = sort(ImagePositionPatientT2,'ascend');

%load the matrices in ascending order
T1mat = zeros(infoT1(1).Rows,infoT1(1).Columns,length(dirT1));
T2mat = zeros(infoT2(1).Rows,infoT2(1).Columns,length(dirT2));
for ii = 1:length(dirT1)
    T1mat(:,:,ii) = dicomread(fullfile(pathT1, dirT1(indT1all(ii)).name));
end
for jj = 1:length(dirT2)
    T2mat(:,:,jj) = dicomread(fullfile(pathT2, dirT2(indT2all(jj)).name));
end

infoEPI.Rows = TxParameters.ImageResolution;
infoEPI.Columns = TxParameters.ImageResolution;
infoEPI.PixelSpacing(1) = TxParameters.PixelSize;
infoEPI.PixelSpacing(2) = TxParameters.PixelSize;

% Where is UA center defined on slice? (to be integrated with the GUI later)
if options.T1ManualCenter
    LoadOrGinput = questdlg('Define UA center by loading old coordinates or generating new ones?', 'Load or Define?', 'Load old coordinates', 'Generate new coordinates', 'Generate new coordinates');
    if strcmp(LoadOrGinput, 'Load old coordinates')
        if strfind(pathPEDA, 'Segment')
            [UAcenterFile,UAcenterPath] = uigetfile(fullfile(fileparts(fileparts(pathPEDA)),'Post Treatment Overlay','*UAcenters.mat'));
        else
            [UAcenterFile,UAcenterPath] = uigetfile(fullfile(fileparts(pathPEDA),'Post Treatment Overlay','*UAcenters.mat'));
        end
        
        if isequal(UAcenterFile,0)
           warning('User canceled selection.  Defining UA center in the center of T1 images');
           UAcenterT1 = [double(infoT1(1).Columns/2) double(infoT1(1).Rows/2)] + 0.5; % factor of 0.5 is for display purposes (shifts from center of pixel to bottom right-hand corner) 
        else
           load(fullfile(UAcenterPath,UAcenterFile));
        end
    else % generate new UA center with ginput
        while blnaccept == 0
            figure
            set(gcf,'units','normalized','outerposition',[0 0 1 1],'WindowKeyPressFcn', @arrowpress);
            imagesc(T1mat(:,:,lr)); colormap gray; axis equal
            title({['Slice ' num2str(lr)] ; 'Use arrow keys to change slice'; 'Press Enter to select slice that best represents UA center'},'fontsize',14)
            waitforbuttonpress
            %if user tries to toggle beyond specified slices, it will stay on current slice
            if blnaccept == 1
                break
            else     
                if lr < 1
                    lr = 1;
                elseif lr > length(dirT1)
                    lr = length(dirT1);
                end

            end
        end
    %     figure('units','normalized','outerposition',[0 0 1 1]); imagesc(T1mat(:,:, ))),colormap gray, axis equal,title(['Indicate Urethra Center, slice ' num2str(round(length(indT1)/2))],'fontsize',14),zoom(2); 
        title({['Slice ' num2str(lr)] ; 'Select UA center'; ''},'fontsize',14)
        UAcenterT1 = ginput(1) + 0.5;
        close(gcf)
    end
else
    UAcenterT1 = [double(infoT1(1).Columns/2) double(infoT1(1).Rows/2)] + 0.5; % factor of 0.5 is for display purposes (shifts from center of pixel to bottom right-hand corner)
end
UAcenterT2 = [double(infoT2(1).Columns/2) double(infoT2(1).Rows/2)] + 0.5; % factor of 0.5 is for display purposes (shifts from center of pixel to bottom right-hand corner)
% UAcenterEPI = [TxParameters.ux TxParameters.uy];
if exist('SxParameters')
    if size(SxParameters.ux,1) > 1 % if there is ImageShift
        UAcenterEPI = [SxParameters.ux(end,:); SxParameters.uy(end,:)] - 0.5;
    else % ImageShift was on current image (if at all), not reference image; repmat make this have the same dimension as above
        if isfield('TxParameters','ux')
            UAcenterEPI = [repmat(TxParameters.ux,1,TxParameters.NumberSlices); repmat(TxParameters.uy,1,TxParameters.NumberSlices)] - 0.5;
        else
            UAcenterEPI = [repmat(SxParameters.ux,1,SxParameters.NumberSlices); repmat(SxParameters.uy,1,SxParameters.NumberSlices)] - 0.5;
        end
    end
else
    UAcenterEPI = [repmat(TxParameters.ux,1,TxParameters.NumberSlices); repmat(TxParameters.uy,1,TxParameters.NumberSlices)] - 0.5;
end

% Determine nearest slice neighbours between T1 and T2 stacks
diffSlices = zeros(length(dirT1),TxParameters.NumberSlices);
for ii = 1:length(dirT1)
    for jj = 1:length(dirT2)
        zcT1 = infoT1(indT1all(ii)).ImagePositionPatient(3) ... 
               + UAcenterT1(1)*infoT1(indT1all(ii)).ImageOrientationPatient(3)*infoT1(indT1all(ii)).PixelSpacing(2) ... 
               + UAcenterT1(2)*infoT1(indT1all(ii)).ImageOrientationPatient(6)*infoT1(indT1all(ii)).PixelSpacing(1);
        
        zcT2 = infoT2(indT2all(jj)).ImagePositionPatient(3) ... 
               + UAcenterT2(1)*infoT2(indT2all(jj)).ImageOrientationPatient(3)*infoT2(indT2all(jj)).PixelSpacing(2) ...
               + UAcenterT2(2)*infoT2(indT2all(jj)).ImageOrientationPatient(6)*infoT2(indT2all(jj)).PixelSpacing(1);
        
        diffSlices(ii,jj) = zcT1 - zcT2;        
    end
end

[~,indT1] = min(abs(diffSlices)); %index of T1 dicoms closest to T2 dicoms.  The index of indT1 represents slice number of EPI sequence and its value is the index of T1 sequence
% indT1 = [1:12]+3; %manual override in case the above method did not work.  Adjust the offset as needed
% Index the images: convert each frame into RGB MxNx3 matrix with colours encoded into the 3 colour channels
indexedT1mat = zeros(infoT1(1).Rows,infoT1(1).Columns,3,TxParameters.NumberSlices);
indexedT2mat = zeros(infoT2(1).Rows,infoT2(1).Columns,3,TxParameters.NumberSlices);
indexedTMaxMasked = zeros(infoEPI(1).Rows,infoEPI(1).Columns,3,TxParameters.NumberSlices);
indexedTDoseMasked = zeros(infoEPI(1).Rows,infoEPI(1).Columns,3,TxParameters.NumberSlices);

minT1mat = min(T1mat(:));
maxT1mat = max(T1mat(:));
minT2mat = min(T2mat(:));
maxT2mat = max(T2mat(:));

for jj = 1:TxParameters.NumberSlices
    indexedT1mat(:,:,:,jj) = label2rgb(round(normalizemat(ceilfloor(T1mat(:,:,indT1(jj)),options.T1Min*(maxT1mat-minT1mat)+minT1mat,options.T1Max*maxT1mat),1,255)),gray(256)); %windowed to 70% dynamic range for higher brightness
    indexedT2mat(:,:,:,jj) = label2rgb(round(normalizemat(ceilfloor(T2mat(:,:,jj),options.T2Min*(maxT2mat-minT2mat)+minT2mat,options.T2Max*maxT2mat),1,255)),gray(256)); %windowed to 80% dynamic range for higher brightness
    minTMaxMasked = round(min(min(ceilfloor(TMaxMasked(:,:,jj),TMaxCLim(1),TMaxCLim(2)))));
    maxTMaxMasked = round(max(max(ceilfloor(TMaxMasked(:,:,jj),TMaxCLim(1),TMaxCLim(2)))));
    if maxTMaxMasked ~= minTMaxMasked % else, everything is masked out, then leave it as zeroes
        indexedTMaxMasked(:,:,:,jj) = label2rgb(round(normalizemat(ceilfloor(TMaxMasked(:,:,jj),TMaxCLim(1),TMaxCLim(2)),minTMaxMasked-TMaxCLim(1)+1,maxTMaxMasked-TMaxCLim(1))),cmap3(minTMaxMasked-TMaxCLim(1)+1:maxTMaxMasked-TMaxCLim(1),:));
    end
    minTDoseMasked = round(min(min(ceilfloor(TDoseMasked(:,:,jj),TDoseCLim(1),TDoseCLim(2)))));
    maxTDoseMasked = round(max(max(ceilfloor(TDoseMasked(:,:,jj),TDoseCLim(1),TDoseCLim(2)))));
    if maxTDoseMasked ~= minTDoseMasked % else, everything is masked out, then leave it as zeroes
        indexedTDoseMasked(:,:,:,jj) = label2rgb(round(normalizemat(ceilfloor(TDoseMasked(:,:,jj),1,1024),1,255)),cmapTDose(:,:));
    end
end
indexedT1mat = uint8(indexedT1mat);
indexedT2mat = uint8(indexedT2mat);
indexedTMaxMasked = uint8(indexedTMaxMasked);
indexedTDoseMasked = uint8(indexedTDoseMasked);

% Determine scaling and translation factors.  Latter is in units of pixels and calculated since the reference point is the top left corner
scaleFactorEPI_T1 = infoEPI(1).PixelSpacing(1)./infoT1(1).PixelSpacing(1);
scaleFactorEPI_T2 = infoEPI(1).PixelSpacing(1)./infoT2(1).PixelSpacing(1);
% Translation to align UA center of EPI and T2.  First calculate the amount of translation in mm (max 2 mm by TDC specs)
if exist('SxParameters')
    if size(SxParameters.ux,1) > 1 % if there is ImageShift
        % distortionOffset should not be confused with ImageShift.  It is
        % the difference between the final location of the UA center with
        % the center of EPI slice (e.g. the UA center could have be aligned
        % 2 mm below center of slice <distortion> but over course of
        % treatment, it gets ImageShifted up 2 mm and the UA center is at
        % center of slice <distortion + ImageShift> = distortionOffset)
        distortionOffsetMM = [(SxParameters.ux(end,:)-0.5-double(infoEPI(1).Rows/2))*infoEPI(1).PixelSpacing(1); (SxParameters.uy(end,:)-0.5-double(infoEPI(1).Rows/2))*infoEPI(1).PixelSpacing(1)];
    else % ImageShift was on current image (if at all), not reference image; repmat make this have the same dimension as above
        if isfield('TxParameters','ux')
            distortionOffsetMM = [(repmat(TxParameters.ux,1,TxParameters.NumberSlices)-0.5-double(infoEPI(1).Rows/2))*infoEPI(1).PixelSpacing(1); (repmat(TxParameters.uy,1,TxParameters.NumberSlices)-0.5-double(infoEPI(1).Columns/2))*infoEPI(1).PixelSpacing(2)];
        else
            distortionOffsetMM = [(repmat(SxParameters.ux,1,SxParameters.NumberSlices)-0.5-double(infoEPI(1).Rows/2))*infoEPI(1).PixelSpacing(1); (repmat(SxParameters.uy,1,SxParameters.NumberSlices)-0.5-double(infoEPI(1).Columns/2))*infoEPI(1).PixelSpacing(2)];
        end
    end
else
    distortionOffsetMM = [(repmat(TxParameters.ux,1,TxParameters.NumberSlices)-0.5-double(infoEPI(1).Rows/2))*infoEPI(1).PixelSpacing(1); (repmat(TxParameters.uy,1,TxParameters.NumberSlices)-0.5-double(infoEPI(1).Columns/2))*infoEPI(1).PixelSpacing(2)];
end
% for ii = 1:TxParameters.NumberSlices
%     if sqrt(((SxParameters.ux(1,ii)-0.5-double(infoEPI(1).Rows/2))*infoEPI(1).PixelSpacing(1))^2 + ((SxParameters.uy(1,ii)-0.5-double(infoEPI(1).Rows/2))*infoEPI(1).PixelSpacing(1))^2 ) > 2
%         warning(['Distortion correction on slice ' num2str(ii) ' is calculated to be > 2 mm (larger than TDC spec)'])
%     %     return;    
%     end
% end
% the distortion correction has a resolution equal to the T2 pixel size
distortionOffsetPixel_T2 = round(distortionOffsetMM./infoT2(1).PixelSpacing);

resizedIndexedTMaxMaskedEPI_T2 = imresize(indexedTMaxMasked,scaleFactorEPI_T2,'method','nearest');
resizedIndexedTDoseMaskedEPI_T2 = imresize(indexedTDoseMasked,scaleFactorEPI_T2,'method','nearest');
resizedMask43T2 = imresize(Mask43,scaleFactorEPI_T2,'method','nearest');
resizedMask30CEMT2 = imresize(Mask30CEM,scaleFactorEPI_T2,'method','nearest');

padpixels = round([(size(T2mat,1) - size(resizedIndexedTMaxMaskedEPI_T2,1))/2 (size(T2mat,2) - size(resizedIndexedTMaxMaskedEPI_T2,2))/2]);
% if FOV on EPI is smaller than T2, pad it with zeros.  Otherwise, crop it (by an amount equal to -padpixels on each side)
% keep the zeropads/crop centered about origin
if size(resizedIndexedTMaxMaskedEPI_T2,1) + max(abs(distortionOffsetPixel_T2(1,:))) < size(T2mat,1) || size(resizedIndexedTMaxMaskedEPI_T2,2) + max(abs(distortionOffsetPixel_T2(2,:))) < size(T2mat,2) %zeropad
    cropResizedIndexedTMaxMaskedEPI_T2 = padarray(resizedIndexedTMaxMaskedEPI_T2, padpixels, 0);
    cropResizedMask43T2 = padarray(resizedMask43T2, padpixels);
    cropResizedIndexedTDoseMaskedEPI_T2 = padarray(resizedIndexedTDoseMaskedEPI_T2, padpixels, 0);
    cropResizedMask30CEMT2 = padarray(resizedMask30CEMT2, padpixels);
else
    cropResizedIndexedTMaxMaskedEPI_T2 = resizedIndexedTMaxMaskedEPI_T2(-padpixels+1:end+padpixels, -padpixels+1:end+padpixels,:,:);
    cropResizedMask43T2 = (resizedMask43T2(-padpixels+1:end+padpixels, -padpixels+1:end+padpixels,:,:)); %opaque
    cropResizedIndexedTDoseMaskedEPI_T2 = resizedIndexedTDoseMaskedEPI_T2(-padpixels+1:end+padpixels, -padpixels+1:end+padpixels,:,:);
    cropResizedMask30CEMT2 = (resizedMask30CEMT2(-padpixels+1:end+padpixels, -padpixels+1:end+padpixels,:,:));
end

for sliceNo = 1:TxParameters.NumberSlices
    % circshift moves the center of the image (expected to be cropped anyway, so edges are not important)
    cropResizedIndexedTMaxMaskedEPI_T2(:,:,:,sliceNo)   = circshift(cropResizedIndexedTMaxMaskedEPI_T2(:,:,:,sliceNo) , -[distortionOffsetPixel_T2(2,sliceNo) distortionOffsetPixel_T2(1,sliceNo)]); %translate for distortion correction and ImageShift
    cropResizedMask43T2(:,:,sliceNo)                    = circshift(cropResizedMask43T2(:,:,sliceNo) , -[distortionOffsetPixel_T2(2,sliceNo) distortionOffsetPixel_T2(1,sliceNo)]); %translate for distortion correction and ImageShift
    cropResizedIndexedTDoseMaskedEPI_T2(:,:,:,sliceNo)   = circshift(cropResizedIndexedTDoseMaskedEPI_T2(:,:,:,sliceNo) , -[distortionOffsetPixel_T2(2,sliceNo) distortionOffsetPixel_T2(1,sliceNo)]); %translate for distortion correction and ImageShift
    cropResizedMask30CEMT2(:,:,sliceNo)                    = circshift(cropResizedMask30CEMT2(:,:,sliceNo) , -[distortionOffsetPixel_T2(2,sliceNo) distortionOffsetPixel_T2(1,sliceNo)]); %translate for distortion correction and ImageShift
end

% How much to zoom in referenced to T1 slices
zoomFactor = options.ZoomFactor;
zoomFactorT2_T1 = (double(infoT2(1).Rows*infoT2(1).PixelSpacing(1))./double(infoT1(1).Rows*infoT1(1).PixelSpacing(1))).*zoomFactor;
zoomFactorEPI_T1 = zoomFactor*scaleFactorEPI_T1*double(infoEPI(1).Rows)./double(infoT1(1).Rows);


%% Create the figure
if sum(isPlotSlice) < 8
    figure('units','normalized','Position',[0 0 (sum(isPlotSlice)+1)./10+0.05 1],'Resize','off'); %shrink the figure width so rows don't overlap
else
    figure('Position',get(0, 'Screensize'),'Resize','off'); %designed for 1920x1080 monitor, may need to tweak if aspect ratio is different
end
h = zeros(1,LastSlice); %handles for the overlay axes
p = zeros(1,LastSlice); pp = zeros(1,LastSlice); ppp = zeros(1,LastSlice); pppp = zeros(1,LastSlice); %handles for the subplots
ylabh = zeros(1,4); %handles for the ylabels
for sliceNo = find(isPlotSlice)
    elemNo = sliceNo - 1;
% ======================TREATMENT PLANNING=================================
    row = 4; %top row
    p(sliceNo) = subplot('Position',[offset+(plotWidth+spacing(sum(isPlotSlice)))*(sliceNo-FirstSlice) (verticalOffset-plotHeight)+(plotHeight+spacing(sum(isPlotSlice))*0)*(row-1) plotWidth plotHeight]);
    imshow(indexedT2mat(:,:,:,sliceNo),[])
    hold on
    zoomcenter(UAcenterT2(1), UAcenterT2(2), zoomFactorT2_T1); %center on the UA center (also happens to be center of image)
    
    if ismember(sliceNo, find(TxParameters.isUAactive))
        if PEDA_version >= 8.3
            if ~isempty(TxParameters.Combined)
                [X_Prostate_MM, Y_Prostate_MM] = pol2cart(TxParameters.ProstateBoundaryTheta*(pi/180),TxParameters.Combined.ProstateBoundaryMM(:,sliceNo));
                MinTRind = find(TxParameters.Combined.ControlBoundaryMM(:,sliceNo) < MinTRmm); %calculate MTR - defined on control boundary, not prostate boundary
                MaxTRind = find(TxParameters.Combined.ControlBoundaryMM(:,sliceNo) > MaxTRmm); %calculate MTR - defined on control boundary, not prostate boundary
            else
                [X_Prostate_MM, Y_Prostate_MM] = pol2cart(TxParameters.ProstateBoundaryTheta*(pi/180),TxParameters.ProstateBoundaryMM(:,sliceNo));
                MinTRind = find(TxParameters.ControlBoundaryMM(:,sliceNo) < MinTRmm); %calculate MTR - defined on control boundary, not prostate boundary
                MaxTRind = find(TxParameters.ControlBoundaryMM(:,sliceNo) > MaxTRmm); %calculate MTR - defined on control boundary, not prostate boundary
            end
        else
            [X_Prostate_MM, Y_Prostate_MM] = pol2cart(TxParameters.ProstateBoundaryTheta*(pi/180),TxParameters.ProstateBoundaryMM(:,sliceNo));
            MinTRind = find(TxParameters.ControlBoundaryMM(:,sliceNo) < MinTRmm); %calculate MTR - defined on control boundary, not prostate boundary
            MaxTRind = find(TxParameters.ControlBoundaryMM(:,sliceNo) > MaxTRmm); %calculate MTR - defined on control boundary, not prostate boundary
        end
        X_Prostate_MM(361) = X_Prostate_MM(1);    Y_Prostate_MM(361) = Y_Prostate_MM(1);
        plot(X_Prostate_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(1), -Y_Prostate_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(2),'Color',prostateRGB,'LineWidth',options.LineWidth) %prostate translated to center of image (i.e. no distortion)
        
        MinTR_X_MM = X_Prostate_MM(MinTRind);
        MinTR_Y_MM = Y_Prostate_MM(MinTRind);
        MaxTR_X_MM = X_Prostate_MM(MaxTRind);
        MaxTR_Y_MM = Y_Prostate_MM(MaxTRind);
        % find discontinuities and insert a row of NaNs to break up unnecessary connecting lines
        dMinTRind = diff(MinTRind);
        if ~isempty(MinTRind) 
            if sum(dMinTRind)+1 > length(MinTRind)
                MinTR_X_MM(find(dMinTRind>1)) = NaN;
                MinTR_Y_MM(find(dMinTRind>1)) = NaN;
            end
            plot(MinTR_X_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(1), -MinTR_Y_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(2),'Color',[1 0 0],'LineWidth',options.LineWidth) %prostate translated to center of image (i.e. no distortion)
        end
        dMaxTRind = diff(MaxTRind);
        if ~isempty(MaxTRind) 
            if sum(dMaxTRind)+1 > length(MaxTRind)
                MaxTR_X_MM(find(dMaxTRind>1)) = NaN;
                MaxTR_Y_MM(find(dMaxTRind>1)) = NaN;
            end
            plot(MaxTR_X_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(1), -MaxTR_Y_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(2),'Color',prostateRGBlarge,'LineWidth',options.LineWidth) %prostate translated to center of image (i.e. no distortion)
        end
    end
    
    if sliceNo == FirstSlice
        title('APEX')
        ylabel('Treatment Planning')
        ylabh(row) = get(gca,'YLabel');
        set(ylabh(row),'units','normalized','Position',[-0.05 0.5],'FontSize',FontSizeLUT(sum(isPlotSlice)))
    elseif sliceNo == LastSlice
        title('BASE')
%         Add scalebar
        scalebar_pxT2 = scalebar_mm./infoT2(1).PixelSpacing(1);
        zoomHeightT2 = infoT2(1).Rows./zoomFactorT2_T1;
        zoomWidthT2 = infoT2(1).Columns./zoomFactorT2_T1;
        botEdgeT2 = infoT2(1).Rows - ((infoT2(1).Rows - (infoT2(1).Rows./zoomFactorT2_T1))/2);
        rightEdgeT2 = infoT2(1).Columns - ((infoT2(1).Columns - (infoT2(1).Columns./zoomFactorT2_T1))/2);
        scalebarRightT2 = rightEdgeT2 - zoomWidthT2*scalebar_margin;
        scalebarLeftT2 = scalebarRightT2 - scalebar_pxT2; 
        scalebarBotT2 = botEdgeT2 - zoomHeightT2*scalebar_margin;
        scalebarTopT2 = scalebarBotT2 - scalebar_pxT2/10; %10:1 aspect ratio
        patch([scalebarLeftT2 scalebarRightT2 scalebarRightT2 scalebarLeftT2],[scalebarTopT2 scalebarTopT2 scalebarBotT2 scalebarBotT2],[1 1 1],'EdgeColor','w')
        text(double(scalebarLeftT2-zoomWidthT2*scalebar_margin/3),double(scalebarBotT2-zoomHeightT2*scalebar_margin*1.1),[num2str(scalebar_mm/10) ' cm'], 'Color', [1 1 1], 'HorizontalAlignment', 'left','FontSize',8)
    elseif ismember(sliceNo, find(TxParameters.isUAactive))
        title(['E' num2str(elemNo)])
    else
        title(['E' num2str(elemNo)], 'Color', [1 1 1]*0.7)
    end
    
% =================ANATOMY WITH TREATMENT OVERLAY==========================
    row = 3;
    pp(sliceNo) = subplot('Position',[offset+(plotWidth+spacing(sum(isPlotSlice)))*(sliceNo-FirstSlice) (verticalOffset-plotHeight)+(plotHeight+spacing(sum(isPlotSlice))*0)*(row-1) plotWidth plotHeight]);
    imshow(indexedT2mat(:,:,:,sliceNo),[])
    hold on
    h(sliceNo) = imshow(cropResizedIndexedTMaxMaskedEPI_T2(:,:,:,sliceNo),[]);
    set(h(sliceNo),'AlphaData',cropResizedMask43T2(:,:,sliceNo));
    zoomcenter(UAcenterT2(1), UAcenterT2(2), zoomFactorT2_T1);
    
    
    if ismember(sliceNo, find(TxParameters.isUAactive))
        if PEDA_version >= 8.3
            if ~isempty(TxParameters.Combined)
                [X_isotherm55,Y_isotherm55] = pol2cart(TxParameters.Combined.TreatedSector*(pi/180),isothermRadius55(:,sliceNo)'); %[mm]
                [X_isodoseCEM240,Y_isodoseCEM240] = pol2cart(TxParameters.Combined.TreatedSector*(pi/180),isothermRadiusTDose(:,sliceNo)'); %[mm]
            else
                [X_isotherm55,Y_isotherm55] = pol2cart(TxParameters.TreatedSector*(pi/180),isothermRadius55(:,sliceNo)'); %[mm]
                [X_isodoseCEM240,Y_isodoseCEM240] = pol2cart(TxParameters.TreatedSector*(pi/180),isothermRadiusTDose(:,sliceNo)'); %[mm]
            end
        else
            [X_isotherm55,Y_isotherm55] = pol2cart(TxParameters.ControlBoundaryTheta'*(pi/180),isothermRadius55(:,sliceNo)'); %[mm]
            [X_isodoseCEM240,Y_isodoseCEM240] = pol2cart(TxParameters.ControlBoundaryTheta'*(pi/180),isothermRadiusTDose(:,sliceNo)'); %[mm]
        end
        X_isotherm55(361) = X_isotherm55(1);    Y_isotherm55(361) = Y_isotherm55(1);
        X_isodoseCEM240(361) = X_isodoseCEM240(1);    Y_isodoseCEM240(361) = Y_isodoseCEM240(1);
        
        plot((X_isodoseCEM240)./infoT2(1).PixelSpacing(1) + UAcenterT2(1),(-Y_isodoseCEM240)./infoT2(1).PixelSpacing(1) + UAcenterT2(2),'Color',[1 0 1],'LineWidth',options.LineWidth)   
        plot(X_Prostate_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(1), -Y_Prostate_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(2),'Color',[0 0 0],'LineWidth',options.LineWidth)
    end
    if sliceNo == FirstSlice
        ylabel({'Anatomy with', 'Treatment Overlay'})
        ylabh(row) = get(gca,'YLabel');
        set(ylabh(row),'units','normalized','Position',[-0.05 0.5],'FontSize',FontSizeLUT(sum(isPlotSlice)))
    elseif sliceNo == LastSlice
        % scalebar
        patch([scalebarLeftT2 scalebarRightT2 scalebarRightT2 scalebarLeftT2],[scalebarTopT2 scalebarTopT2 scalebarBotT2 scalebarBotT2],[1 1 1],'EdgeColor','w')
        text(double(scalebarLeftT2-zoomWidthT2*scalebar_margin/3),double(scalebarBotT2-zoomHeightT2*scalebar_margin*1.1),[num2str(scalebar_mm/10) ' cm'], 'Color', [1 1 1], 'HorizontalAlignment', 'left','FontSize',8)
        % colorbar
        TMaxAxis = subplot('Position',[0 0 0 0]);
        colormap(TMaxAxis,cmap3);
        caxis(TMaxAxis,TMaxCLim);
        cbTMax = colorbar;
        if exist('SxParameters')
            TickLabelsTMax = {num2str(TMaxCLim(1)) 55 num2str(min(SxParameters.ApproachingBoilingThreshold)) num2str(TMaxCLim(2)-1)};
            XTickTMax = [TMaxCLim(1) 55 min(SxParameters.ApproachingBoilingThreshold) TMaxCLim(2)-1];
        else
            TickLabelsTMax = {num2str(TMaxCLim(1)) 55 90 num2str(TMaxCLim(2)-1)};
            XTickTMax = [TMaxCLim(1) 55 90 TMaxCLim(2)-1];
        end
        set(cbTMax,'Position',cbTMaxLUT(sum(isPlotSlice),:),'TickLabels',TickLabelsTMax,'XTick',XTickTMax,'Limits',TMaxCLim,'FontSize',FontSizeLUT(sum(isPlotSlice)),'YAxisLocation','left');
        ylabcb = ylabel(cbTMax,'Max Temperature (�C)');
        set(ylabcb,'units','normalized','Position',[2.2 0.49]) 
    end
        
% =================ANATOMY WITH THERMAL DOSE OVERLAY==========================
    row = 2;
    ppp(sliceNo) = subplot('Position',[offset+(plotWidth+spacing(sum(isPlotSlice)))*(sliceNo-FirstSlice) (verticalOffset-plotHeight)+(plotHeight+spacing(sum(isPlotSlice))*0)*(row-1) plotWidth plotHeight]);
    imshow(indexedT2mat(:,:,:,sliceNo),[])
    hold on
    h(sliceNo) = imshow(cropResizedIndexedTDoseMaskedEPI_T2(:,:,:,sliceNo),[]);
    set(h(sliceNo),'AlphaData',cropResizedMask30CEMT2(:,:,sliceNo));
    zoomcenter(UAcenterT2(1), UAcenterT2(2), zoomFactorT2_T1);
    if ismember(sliceNo, find(TxParameters.isUAactive))
        end
    if ismember(sliceNo, find(TxParameters.isUAactive))
        plot(X_Prostate_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(1), -Y_Prostate_MM./infoT2(1).PixelSpacing(1) + UAcenterT2(2),'Color',[0 0 0],'LineWidth',options.LineWidth)
    end
    if sliceNo == FirstSlice
        ylabel({'Anatomy with', 'CEM43 Overlay'})
        ylabh(row) = get(gca,'YLabel');
        set(ylabh(row),'units','normalized','Position',[-0.05 0.5],'FontSize',FontSizeLUT(sum(isPlotSlice)))
    elseif sliceNo == LastSlice
        % scalebar
        patch([scalebarLeftT2 scalebarRightT2 scalebarRightT2 scalebarLeftT2],[scalebarTopT2 scalebarTopT2 scalebarBotT2 scalebarBotT2],[1 1 1],'EdgeColor','w')
        text(double(scalebarLeftT2-zoomWidthT2*scalebar_margin/3),double(scalebarBotT2-zoomHeightT2*scalebar_margin*1.1),[num2str(scalebar_mm/10) ' cm'], 'Color', [1 1 1], 'HorizontalAlignment', 'left','FontSize',8)
        % colorbar
        TDoseAxis = subplot('Position',[0 0 0 0]);
        colormap(TDoseAxis,cmapTDose(8:255,:))
        caxis(TDoseAxis,TDoseCLim);
        cbTDose = colorbar;
        TickLabelsTDose = {num2str(TDoseCLim(1)) 240 1000};
        XTickTDose = [TDoseCLim(1) 240 1000];
        set(cbTDose,'Position',cbTDoseLUT(sum(isPlotSlice),:),'TickLabels',TickLabelsTDose,'XTick',XTickTDose,'Limits',TDoseCLim,'FontSize',FontSizeLUT(sum(isPlotSlice)),'YAxisLocation','left');
        ylabcb = ylabel(cbTDose,'Thermal Dose (CEM43)');
        set(ylabcb,'units','normalized','Position',[2.2 0.49])
    end    

% ========================POST TREATMENT CE-MRI============================
    row = 1;
    pppp(sliceNo) = subplot('Position',[offset+(plotWidth+spacing(sum(isPlotSlice)))*(sliceNo-FirstSlice) (verticalOffset-plotHeight)+(plotHeight+spacing(sum(isPlotSlice))*0)*(row-1) plotWidth plotHeight]);
    imshow(indexedT1mat(:,:,:,sliceNo),[])
    hold on
    zoomcenter(UAcenterT1(1),UAcenterT1(2), zoomFactor);
    if ismember(sliceNo, find(TxParameters.isUAactive))
  
%     Uncomment next two lines to plot prostate (and MTR) boundaries
%     plot(X_Prostate_MM./infoT1(1).PixelSpacing(1) + UAcenterT1(1), -Y_Prostate_MM./infoT1(1).PixelSpacing(1) + UAcenterT1(2),'Color',prostateRGB,'LineWidth',options.LineWidth) %prostate translated to center of image (i.e. no distortion)
%     plot(MTR_X_MM./infoT1(1).PixelSpacing(1) + UAcenterT1(1), -MTR_Y_MM./infoT1(1).PixelSpacing(1) + UAcenterT1(2),'Color',[1 0 0],'LineWidth',options.LineWidth) %prostate translated to center of image (i.e. no distortion)
%     plot((X_isotherm55)./infoT1(1).PixelSpacing(1) + UAcenterT1(1),(-Y_isotherm55)./infoT1(1).PixelSpacing(1) + UAcenterT1(2),'Color',[0 0.749 0],'LineWidth',options.LineWidth)
%     plot((X_isodoseCEM240)./infoT1(1).PixelSpacing(1) + UAcenterT1(1),(-Y_isodoseCEM240)./infoT1(1).PixelSpacing(1) + UAcenterT1(2),'Color',[1 0 1],'LineWidth',options.LineWidth)
    end
    if sliceNo == FirstSlice
        ylabel({'Post Treatment','CE-MRI'})
        ylabh(row) = get(gca,'YLabel');
        set(ylabh(row),'units','normalized','Position',[-0.05 0.5],'FontSize',FontSizeLUT(sum(isPlotSlice)))
        
    elseif sliceNo == LastSlice
        scalebar_px = scalebar_mm./infoT1(1).PixelSpacing(1);
        zoomWidth = infoT1(1).Columns./zoomFactor;
        zoomHeight = infoT1(1).Rows./zoomFactor;
        botEdge = infoT1(1).Rows - ((infoT1(1).Rows - (infoT1(1).Rows./zoomFactor))/2);
        topEdge = infoT1(1).Rows - ((infoT1(1).Rows + (infoT1(1).Rows./zoomFactor))/2);
        rightEdge = infoT1(1).Columns - ((infoT1(1).Columns - (infoT1(1).Columns./zoomFactor))/2);
        scalebarRight = rightEdge - zoomWidth*scalebar_margin;
        scalebarLeft = scalebarRight - scalebar_px; 
        scalebarBot = botEdge - zoomHeight*scalebar_margin;
        scalebarTop = scalebarBot - scalebar_px/10; %10:1 aspect ratio
        patch([scalebarLeft scalebarRight scalebarRight scalebarLeft],[scalebarTop scalebarTop scalebarBot scalebarBot],[1 1 1],'EdgeColor','w')
        text(double(scalebarLeft-zoomWidth*scalebar_margin/3),double(scalebarBot-zoomHeight*scalebar_margin*1.1),[num2str(scalebar_mm/10) ' cm'], 'Color', [1 1 1], 'HorizontalAlignment', 'left','FontSize',8)
%         text(double(scalebarRight),double(topEdge+2.5*zoomHeight*scalebar_margin*1.1),{'55�C isotherm'}, 'Color', [0 0.75 0], 'HorizontalAlignment', 'right','FontSize',10,'FontWeight','bold')
        text(double(scalebarRight),double(topEdge+zoomHeight*scalebar_margin*1.1),{'240 CEM43 isodose'}, 'Color', [1 0 1], 'HorizontalAlignment', 'right','FontSize',10,'FontWeight','bold')
    end
end

linkaxes([p pp], 'xy');
linkaxes(ppp, 'xy');
linkaxes(pppp, 'xy');

%% export as a .pdf
tic
if strfind(pathPEDA, 'Segment')
    pathPEDA = fileparts(pathPEDA); %go back one folder
end
if ~exist(fullfile(fileparts(pathPEDA),'Post Treatment Overlay'))
    mkdir(fullfile(fileparts(pathPEDA),'Post Treatment Overlay'))
end
strT1subtracted = '';
strSegment = '';
if isfield(options,'PathT1Pre')
    strT1subtracted = '_T1subtracted';
end
if options.Segment
    strSegment = ['_Segment' num2str(options.Segment)];
end

print(gcf, fullfile(fileparts(pathPEDA),'Post Treatment Overlay',[patientID '_PostTreatmentOverlay' strT1subtracted strSegment '.png']), '-dpng')
save(fullfile(fileparts(pathPEDA),'Post Treatment Overlay',[patientID '_options' strSegment '.mat']), 'pathT1', 'argT1', 'pathT2', 'argT2', 'pathPEDA','options')
export_fig(gcf, fullfile(fileparts(pathPEDA),'Post Treatment Overlay', [patientID '_PostTreatmentOverlay' strT1subtracted strSegment '.pdf']))

%     print(gcf, fullfile(fileparts(pathPEDA),'Post Treatment Overlay',[patientID '_PostTreatmentOverlayT1Subtracted.png']), '-dpng')
%     save(fullfile(fileparts(pathPEDA),'Post Treatment Overlay',[patientID '_options.mat']), 'pathT1', 'argT1', 'pathT2', 'argT2', 'pathPEDA','options')
%     export_fig(gcf, fullfile(fileparts(pathPEDA),'Post Treatment Overlay', [patientID '_PostTreatmentOverlayT1Subtracted.pdf']))
% else
%     print(gcf, fullfile(fileparts(pathPEDA),'Post Treatment Overlay',[patientID '_PostTreatmentOverlay.png']), '-dpng')
%     save(fullfile(fileparts(pathPEDA),'Post Treatment Overlay',[patientID '_options.mat']), 'pathT1', 'argT1', 'pathT2', 'argT2', 'pathPEDA','options')
%     export_fig(gcf, fullfile(fileparts(pathPEDA),'Post Treatment Overlay', [patientID '_PostTreatmentOverlay.pdf']))
% end

if options.T1ManualCenter
    UAcenterT1Manual = 1;
    save(fullfile(fileparts(pathPEDA),'Post Treatment Overlay',[patientID '_UAcenters.mat']), 'UAcenterT1', 'UAcenterT2', 'UAcenterEPI', 'UAcenterT1Manual')
else
    save(fullfile(fileparts(pathPEDA),'Post Treatment Overlay',[patientID '_UAcenters.mat']), 'UAcenterT1', 'UAcenterT2', 'UAcenterEPI')
end
toc
close(gcf)
warning('on','MATLAB:mpath:nameNonexistentOrNotADirectory');
end

function arrowpress(~,evnt)
    global blnaccept
    global lr
    if blnaccept == 1 %don't allow it to increment unless it is expecting it
       return
    end
    if strcmp(evnt.Key, 'rightarrow')
        lr = lr + 1;
    elseif strcmp(evnt.Key, 'leftarrow')
        lr = lr -1;
    elseif strcmp(evnt.Key, 'return')
        blnaccept = 1;
    end
end

%% Old

% old locations of single colorbar on right
% cbLUT = [0      0       0       0;
%          0      0       0       0;
%          0      0       0       0;
%          0      0       0       0;
%          0.93   0.083   0.02    0.887;
%          0.93   0.087   0.02    0.88;
%          0.93   0.085   0.02    0.887;
%          0.945  0.081   0.02    0.894;
%          0.945  0.092   0.02    0.872;
%          0.945  0.102   0.02    0.853;
%          0.945  0.11    0.02    0.837;
%          0.945  0.116   0.02    0.825;]; %position vector for colorbar, for 5-10 columns

% % ==========================TREATMENT SUMMARY==============================
%     row = 2;
%     ppp(sliceNo) = subplot('Position',[offset+(plotWidth+spacing(sum(isPlotSlice)))*(sliceNo-FirstSlice) (verticalOffset-plotHeight)+(plotHeight+spacing(sum(isPlotSlice))*0)*(row-1) plotWidth plotHeight]);
%     imshow(TMax(:,:,sliceNo),[],'colormap',cmap3)
%     hold on
% %     colormap(cmap3)
%     caxis(TMaxCLim)
%     zoomcenter(UAcenterEPI(1),UAcenterEPI(2),zoomFactorEPI_T1);
%     
%     if ismember(sliceNo, find([0 TxParameters.isUAactive 0]))
%         TxParameters.ProstateBoundaryXY(361,:,elemNo) = TxParameters.ProstateBoundaryXY(1,:,elemNo);
%         plot(TxParameters.ProstateBoundaryXY(:,1,elemNo), TxParameters.ProstateBoundaryXY(:,2,elemNo),'Color',[0 0 0],'LineWidth',1)
%     end
%     if sliceNo == FirstSlice
%         ylabel('Treatment Summary')
%         ylabh(row) = get(gca,'YLabel');
%         set(ylabh(row),'units','normalized','Position',[-0.05 0.5],'FontSize',FontSizeLUT(sum(isPlotSlice)))
%     elseif sliceNo == LastSlice
%         cbTMax = colorbar;
%         if exist('SxParameters')
%             TickLabels = {20 55 num2str(min(SxParameters.ApproachingBoilingThreshold)) 100};
%             XTick = [20 55 min(SxParameters.ApproachingBoilingThreshold) 100];
%         else
%             TickLabels = {20 55 90 100};
%             XTick = [20 55 90 100];
%         end
%         
%         set(cbTMax,'Position',cbLUT(sum(isPlotSlice),:),'TickLabels',TickLabels,'XTick',XTick,'Limits',TMaxCLim,'FontSize',14,'YAxisLocation','right');
%         ylabcb = ylabel(cbTMax,'Maximum temperature reached (�C)');
%         set(ylabcb,'units','normalized','Position',[1.9 0.5])
%         
%         scalebar_pxEPI = scalebar_mm./infoEPI(1).PixelSpacing(1);
%         zoomWidthEPI = infoEPI(1).Rows./zoomFactorEPI_T1;
%         zoomHeightEPI = infoEPI(1).Columns./zoomFactorEPI_T1;
%         rightEdgeEPI = double(infoEPI(1).Rows - ((infoEPI(1).Rows - (infoEPI(1).Rows./zoomFactorEPI_T1))/2));
%         botEdgeEPI = double(infoEPI(1).Columns - ((infoEPI(1).Columns - (infoEPI(1).Columns./zoomFactorEPI_T1))/2));
%         scalebarRightEPI = rightEdgeEPI - double(zoomWidthEPI*scalebar_margin);
%         scalebarLeftEPI = scalebarRightEPI - scalebar_pxEPI; 
%         scalebarBotEPI = botEdgeEPI - double(zoomHeightEPI*scalebar_margin);
%         scalebarTopEPI = scalebarBotEPI - scalebar_pxEPI/10; %10:1 aspect ratio
%         patch([scalebarLeftEPI scalebarRightEPI scalebarRightEPI scalebarLeftEPI],[scalebarTopEPI scalebarTopEPI scalebarBotEPI scalebarBotEPI],[0 0 0],'EdgeColor','k')
%         text(double(scalebarLeftEPI-zoomWidthEPI*scalebar_margin/3),double(scalebarBotEPI-zoomHeightEPI*scalebar_margin*1.5),[num2str(scalebar_mm/10) ' cm'], 'Color', [0 0 0], 'HorizontalAlignment', 'left','FontSize',8)
%     end
%  ==========================================================================================


% % Determine nearest slice neighbours between T1 and T2 stacks
% diffSlices = zeros(length(dirT1),TxParameters.NumberSlices);
% for ii = 1:length(dirT1)
%     for jj = 1:length(dirT2)
%         %diffSlices(ii,jj) = infoT1(ii).SliceLocation - infoT2(indT2(jj)).SliceLocation;
%         %diffSlices(ii,jj) = infoT1(ii).ImagePositionPatient(3) - infoT2(indT2(jj)).ImagePositionPatient(3);                
% %         zcT1 = infoT1(ii).ImagePositionPatient(3) ... 
% %                + (double(infoT1(ii).Rows)/2)*infoT1(ii).ImageOrientationPatient(3)*infoT1(ii).PixelSpacing(2) ... 
% %                + (double(infoT1(ii).Columns)/2)*infoT1(ii).ImageOrientationPatient(6)*infoT1(ii).PixelSpacing(1);
% %         
% %         zcT2 = infoT2(jj).ImagePositionPatient(3) ... 
% %                + (double(infoT2(jj).Rows)/2)*infoT2(jj).ImageOrientationPatient(3)*infoT2(jj).PixelSpacing(2) ...
% %                + (double(infoT2(jj).Columns)/2)*infoT2(jj).ImageOrientationPatient(6)*infoT2(jj).PixelSpacing(1);
%          
%         zcT1 = infoT1(ii).ImagePositionPatient(3) ... 
%                + UAcenterT1(1)*infoT1(ii).ImageOrientationPatient(3)*infoT1(ii).PixelSpacing(2) ... 
%                + UAcenterT1(2)*infoT1(ii).ImageOrientationPatient(6)*infoT1(ii).PixelSpacing(1);
%         
%         zcT2 = infoT2(jj).ImagePositionPatient(3) ... 
%                + UAcenterT2(1)*infoT2(jj).ImageOrientationPatient(3)*infoT2(jj).PixelSpacing(2) ...
%                + UAcenterT2(2)*infoT2(jj).ImageOrientationPatient(6)*infoT2(jj).PixelSpacing(1);
%         
%         diffSlices(ii,jj) = zcT1 - zcT2;        
%     end
% end

% ================================================================================================

%     if( TxParameters.isUAactive(elemNo) == 1 )
%         row = 2;
%         ppp(elemNo) = subplot('Position',[offset+(plotWidth+spacing)*(elemNo-1) (verticalOffset-plotHeight)+(plotHeight+spacing*0)*(row-1) plotWidth plotHeight]);
%         imshow(indexedT1mat(:,:,:,indT1(elemNo+1)))
%         hold on
%         hh(elemNo) = imshow(cropResizedIndexedTMaxMaskedEPI_T1(:,:,:,elemNo+1));
%         set(hh(elemNo),'AlphaData',cropResizedMask43T1(:,:,elemNo+1));
% %         if elemNo == 1
% %             title(sprintf('E%d (APEX)',elemNo))
% %         elseif elemNo == EndRange
% %             title(sprintf('E%d (BASE)',elemNo))
% %         else
% %             title(['E' num2str(elemNo)])
% %         end
% 
%     end
%     zoomcenter((TxParameters.ux)*scaleFactorEPI_T1 - translationFactorEPI_T1,(TxParameters.ux)*scaleFactorEPI_T1 - translationFactorEPI_T1,zoomFactor);
% %     [X_isotherm,Y_isotherm] = pol2cart(TxParameters.ControlBoundaryTheta*(pi/180),radius(:,elemNo));
% %     X_isotherm(361) = X_isotherm(1);    Y_isotherm(361) = Y_isotherm(1);
% %     plot((X_isotherm + TxParameters.ux)*scaleFactorEPI_T1 - translationFactorEPI_T1,(-Y_isotherm + TxParameters.uy)*scaleFactorEPI_T1 - translationFactorEPI_T1,'Color',isothermRGB,'LineWidth',0.1)

%create dummy figure to get colorbar
% subplot('Position', [1.1 1.1 0.01 0.01])
% imagesc([20 101]);
% colormap(cmap3);
% cb = colorbar;
% TickLabels = {20 55 90 100};
% XTick = [20 55 90 100];
% set(cb, 'Position',[0.94 0.082 .02 0.85],'TickLabels',TickLabels,'XTick',XTick,'Limits',[20 101],'FontSize',14,'YAxisLocation','right');
% % set(cb, 'Position',[0.925 0.4 .02 0.2],'TickLabels',TickLabels,'XTick',XTick,'Limits',[20 101],'FontSize',14,'YAxisLocation','right');

% orient landscape; 
% set(gcf,'Color',[1 1 1],'InvertHardCopy','off');
% print(gcf, fullfile(fileparts(pathPEDA),[patientID '_PostTreatmentOverlay.pdf']), '-fillpage','-r300', '-dpdf')