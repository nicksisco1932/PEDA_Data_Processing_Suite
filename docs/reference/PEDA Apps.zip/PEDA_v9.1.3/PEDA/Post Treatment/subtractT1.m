%% subtractT1.m ===========================================================
% Input the directories for pre and post contrast enhanced images to output
% the subtracted image matrix.
%  - pathT1pre: folder path to pre contrast images
%  - argT1pre: wildcard string to identify DICOMs
%  - pathT1post: folder path to post contrast images
%  - argT1post: wildcard string to identify DICOMs
% =========================================================================
function T1diff = subtractT1(pathT1pre, argT1pre, pathT1post, argT1post)

if ~isempty(argT1pre)
    dirT1pre = dir(fullfile(pathT1pre,['*' argT1pre '*']));
else
    dirT1pre = dir(fullfile(pathT1pre,['*.*']));
end
if ~isempty(argT1post)
    dirT1post = dir(fullfile(pathT1post,['*' argT1post '*']));
else
    dirT1post = dir(fullfile(pathT1post,['*.*']));
end

infoT1pre = dicominfo(fullfile(pathT1pre,dirT1pre(1).name));
infoT1post = dicominfo(fullfile(pathT1post,dirT1post(1).name));

if infoT1pre.Rows ~= infoT1post.Rows || infoT1pre.Columns ~= infoT1post.Columns || length(dirT1pre) ~= length(dirT1post)
    error('Pre and post contrast images do not have the same dimension')
    return
end

T1pre = zeros(infoT1pre.Rows, infoT1pre.Columns, length(dirT1pre));
T1post = zeros(infoT1post.Rows, infoT1post.Columns, length(dirT1post));

for ii = 1:length(dirT1pre)
    T1pre(:,:,ii) = dicomread(fullfile(pathT1pre, dirT1pre(ii).name));
end
for ii = 1:length(dirT1post)
    T1post(:,:,ii) = dicomread(fullfile(pathT1post, dirT1post(ii).name));
end

T1diff = T1post - T1pre;
