%% PostTreatmentOverlayGUI.m ==============================================
% Small GUI to Initialize parameters for PostTreatmentOverlay function.
% Select options and click Continue button to execute PostTreatmentOverlay.
% If PostTreatmentOverlay has been performed in the past, you can input the
% XXX-XXX_options.mat structure into this function to populate the fields
% with the settings used to generate that image (except for manual UA
% center location for now).
% 
% Can Preview DICOMs (including TUV Magnitude) in separate viewer that 
% allows user to adjust window level before generate PostTreatmentOverlay
% output.  Measurement tool has been added to the viewer as well.
% 
% Inputs (optional):
%     - options structure generated from past PostTreatmentOverlay 
% 
% By Ben Leung
% Date: 27-SEP-2018
% =========================================================================
function PostTreatmentOverlayGUI(varargin)
% find all patients with DICOMs and populate drop down list
patientroot = '\\PMIFS03\ClinicalData$\Clinical Trial Pivotal (TACT)';
patientdir = dir(patientroot);
patientdir = patientdir([patientdir(:).isdir]);
patientdir = patientdir(3:end); %get rid of . and ..
patientindex = zeros(1,length(patientdir));
for ii = 1:length(patientdir)
    if exist(fullfile(patientdir(ii).folder,patientdir(ii).name,'DICOMs'))
        patientindex(ii) = 1;
    end
end
patientdir = patientdir(find(patientindex));

if nargin == 1
    presets = validateOptions(varargin{1}, patientroot);
    disp('Loaded presets')
else
    presets = validateOptions(0, patientroot);
end
    
hFig = figure('Position',[500 500 1100 300]);
handles.PanelOptions = uipanel('title','Options','units','normalized','position',[0.03 .05 .7 .5]);
handles.CheckT1Subtract = uicontrol('parent', handles.PanelOptions,'Style','Checkbox','Units','normalized','Position',    [0.02 .85 .5 .1],'String','T1 subtract?','Callback', @chkT1Subtract);
handles.CheckT1ManualCenter = uicontrol('parent', handles.PanelOptions,'Style','Checkbox','Units','normalized','Position',[0.02 .7 .5 .1],'String','Select UA center?');

handles.TextZoomFactor = uicontrol('parent', handles.PanelOptions, 'Style','Text','Units','normalized','Position', [.02 .48 .11 .15],'String','Zoom Factor','HorizontalAlignment','Left');
handles.EditZoomFactor = uicontrol('parent', handles.PanelOptions, 'Style','Edit','Units','normalized','Position', [.11 .5 .05 .15],'String',num2str(presets.ZoomFactor),'HorizontalAlignment','Left');
handles.TextLineWidth = uicontrol('parent', handles.PanelOptions, 'Style','Text','Units','normalized','Position', [.02 .33 .11 .15],'String','Line Width','HorizontalAlignment','Left');
handles.EditLineWidth = uicontrol('parent', handles.PanelOptions, 'Style','Edit','Units','normalized','Position', [.11 .35 .05 .15],'String',num2str(presets.LineWidth),'HorizontalAlignment','Left');
handles.TextSegments = uicontrol('parent', handles.PanelOptions, 'Style','Text','Units','normalized','Position', [0.23 .86 .5 .1],'String','Segment','HorizontalAlignment','Left');
handles.listSegments = uicontrol('parent', handles.PanelOptions, 'Style','popupmenu','units','normalized','position',[0.23 .73 .05 .1],'String',{'0','1'});



handles.TextInstructions = uicontrol('parent', handles.PanelOptions, 'Style','Text','Units','normalized','Position', [.02 0 .22 .35],'String','Set the DICOM paths before Preview.  T1 Preview requires a defined T2 path for aligning boundaries.','HorizontalAlignment','Left','FontSize',7);

handles.PanelWindow = uipanel('parent', handles.PanelOptions,'title','Windowing','units','normalized','position',[.3 .05 .7 0.95]);
handles.PanelWindowT1 = uipanel('parent', handles.PanelWindow,'title','AX T1 Post Treatment','units','normalized','position',[0 .55 1 .45]);
handles.PanelWindowT2 = uipanel('parent', handles.PanelWindow,'title','AX T2 Planning','units','normalized','position',[0 0.05 1 .45]);

handles.TextT1Min = uicontrol('parent', handles.PanelWindowT1, 'Style','Text','Units','normalized','Position', [.02 .5 .055 .5],'String','Min','HorizontalAlignment','Right');
handles.TextT1Max = uicontrol('parent', handles.PanelWindowT1, 'Style','Text','Units','normalized','Position', [.02 0 .055 .5],'String','Max','HorizontalAlignment','Right');
handles.TextT2Min = uicontrol('parent', handles.PanelWindowT2, 'Style','Text','Units','normalized','Position', [.02 .5 .055 .5],'String','Min','HorizontalAlignment','Right');
handles.TextT2Max = uicontrol('parent', handles.PanelWindowT2, 'Style','Text','Units','normalized','Position', [.02 0 .055 .5],'String','Max','HorizontalAlignment','Right');
if presets.T1Min < 0
    handles.SliderT1Min = uicontrol('parent', handles.PanelWindowT1,'Style','slider','Units','normalized', 'Position',[0.1 .5 .7 .5],'Min',0,'Max',1,'Value',0,'SliderStep',[.05 .2],'Callback',@XSliderCallbackT1Min);
else
    handles.SliderT1Min = uicontrol('parent', handles.PanelWindowT1,'Style','slider','Units','normalized', 'Position',[0.1 .5 .7 .5],'Min',0,'Max',1,'Value',presets.T1Min,'SliderStep',[.05 .2],'Callback',@XSliderCallbackT1Min);
end
if presets.T1Max > 1
    handles.SliderT1Max = uicontrol('parent', handles.PanelWindowT1,'Style','slider','Units','normalized', 'Position',[0.1 0 .7 .5],'Min',0,'Max',1,'Value',1,'SliderStep',[.05 .2],'Callback',@XSliderCallbackT1Max);
else
    handles.SliderT1Max = uicontrol('parent', handles.PanelWindowT1,'Style','slider','Units','normalized', 'Position',[0.1 0 .7 .5],'Min',0,'Max',1,'Value',presets.T1Max,'SliderStep',[.05 .2],'Callback',@XSliderCallbackT1Max);
end
handles.EditT1Min = uicontrol('parent', handles.PanelWindowT1, 'Style','Edit','Units','normalized','Position', [.82 .5 .07 .5],'String',num2str(presets.T1Min),'HorizontalAlignment','Right', 'Callback',@EditT1Min);
handles.EditT1Max = uicontrol('parent', handles.PanelWindowT1, 'Style','Edit','Units','normalized','Position', [.82 0 .07 .5],'String',num2str(presets.T1Max),'HorizontalAlignment','Right', 'Callback',@EditT1Max);
handles.PreviewT1 = uicontrol('parent', handles.PanelWindowT1, 'Style','pushbutton','Units','normalized','Position', [.9 0 .1 1],'String','Preview','HorizontalAlignment','Center', 'Callback',@PreviewT1);

if presets.T2Min < 0
    handles.SliderT2Min = uicontrol('parent', handles.PanelWindowT2,'Style','slider','Units','normalized', 'Position',[0.1 .5 .7 .5],'Min',0,'Max',1,'Value',0,'SliderStep',[.05 .2],'Callback',@XSliderCallbackT2Min);
else
    handles.SliderT2Min = uicontrol('parent', handles.PanelWindowT2,'Style','slider','Units','normalized', 'Position',[0.1 .5 .7 .5],'Min',0,'Max',1,'Value',presets.T2Min,'SliderStep',[.05 .2],'Callback',@XSliderCallbackT2Min);
end
if presets.T2Max > 1
    handles.SliderT2Max = uicontrol('parent', handles.PanelWindowT2,'Style','slider','Units','normalized', 'Position',[0.1 0 .7 .5],'Min',0,'Max',1,'Value',1,'SliderStep',[.05 .2],'Callback',@XSliderCallbackT2Max);
else
    handles.SliderT2Max = uicontrol('parent', handles.PanelWindowT2,'Style','slider','Units','normalized', 'Position',[0.1 0 .7 .5],'Min',0,'Max',1,'Value',presets.T2Max,'SliderStep',[.05 .2],'Callback',@XSliderCallbackT2Max);
end
handles.EditT2Min = uicontrol('parent', handles.PanelWindowT2, 'Style','Edit','Units','normalized','Position', [.82 .5 .07 .5],'String',num2str(presets.T2Min),'HorizontalAlignment','Right', 'Callback',@EditT2Min);
handles.EditT2Max = uicontrol('parent', handles.PanelWindowT2, 'Style','Edit','Units','normalized','Position', [.82 0 .07 .5],'String',num2str(presets.T2Max),'HorizontalAlignment','Right', 'Callback',@EditT2Max);
handles.PreviewT2 = uicontrol('parent', handles.PanelWindowT2, 'Style','pushbutton','Units','normalized','Position', [.9 0 .1 1],'String','Preview','HorizontalAlignment','Center', 'Callback',@PreviewT2);

handles.listPatients = uicontrol('Style','popupmenu','units','normalized','position',[0.75 .93 .2 .05],'String',{patientdir.name},'Callback', @SelectPatient);

handles.PanelPaths = uipanel('title','File paths','units','normalized','position',[0.03 .55 .7 .45]);

handles.TextPathT1Pre = uicontrol('parent', handles.PanelPaths,'Style','Text','Units','normalized','Position',[0 .6 .15 .15],'String','T1 Pre contrast','HorizontalAlignment','Right','Visible','off');
handles.TextPathT1 = uicontrol('parent', handles.PanelPaths,'Style','Text','Units','normalized','Position',   [0 .4 .15 .15],'String','T1 Post contrast','HorizontalAlignment','Right');
handles.TextPathT2 = uicontrol('parent', handles.PanelPaths,'Style','Text','Units','normalized','Position',   [0 .2 .15 .15],'String','T2','HorizontalAlignment','Right');
handles.TextPathPEDA = uicontrol('parent', handles.PanelPaths,'Style','Text','Units','normalized','Position', [0 0 .15 .15],'String','PEDA','HorizontalAlignment','Right');

handles.EditPathT1Pre = uicontrol('parent', handles.PanelPaths,'Style','Edit','Units','normalized','Position',[.15 .6 .7 .15],'String',presets.PathT1Pre,'HorizontalAlignment','Left','Visible','off');
handles.EditPathT1 = uicontrol('parent', handles.PanelPaths,'Style','Edit','Units','normalized','Position',   [.15 .4 .7 .15],'String',presets.PathT1,'HorizontalAlignment','Left');
handles.EditPathT2 = uicontrol('parent', handles.PanelPaths,'Style','Edit','Units','normalized','Position',   [.15 .2 .7 .15],'String',presets.PathT2,'HorizontalAlignment','Left');
handles.EditPathPEDA = uicontrol('parent', handles.PanelPaths,'Style','Edit','Units','normalized','Position', [.15 0 .7 .15],'String', presets.PathPEDA,'HorizontalAlignment','Left');

handles.btnT1Pre = uicontrol('parent', handles.PanelPaths,'Style','pushbutton','Units','normalized','Position', [.86 .6 .02 .15],'String','...','Visible','off', 'Callback', @setPathT1Pre);
handles.btnT1Post = uicontrol('parent', handles.PanelPaths,'Style','pushbutton','Units','normalized','Position',[.86 .4 .02 .15],'String','...', 'Callback', @setPathT1Post);
handles.btnT2 = uicontrol('parent', handles.PanelPaths,'Style','pushbutton','Units','normalized','Position',    [.86 .2 .02 .15],'String','...','Callback',@setPathT2);
handles.btnPEDA = uicontrol('parent', handles.PanelPaths,'Style','pushbutton','Units','normalized','Position',  [.86 0 .02 .15],'String','...','Callback',@setPathPEDA);

handles.TextArg = uicontrol('parent', handles.PanelPaths,'Style','Text','Units','normalized','Position',                [0.89 .8 .1 .15],'String','Wildcard','HorizontalAlignment','Center');
handles.EditArgT1Pre = uicontrol('parent', handles.PanelPaths,'Style','Edit','Units','normalized','Position',           [0.89 .6 .1 .15],'String',presets.ArgT1Pre,'HorizontalAlignment','Center','Visible','off');
handles.EditArgT1 = uicontrol('parent', handles.PanelPaths,'Style','Edit','Units','normalized','Position',              [0.89 .4 .1 .15],'String',presets.ArgT1,'HorizontalAlignment','Center');
handles.EditArgT2 = uicontrol('parent', handles.PanelPaths,'Style','Edit','Units','normalized','Position',              [0.89 .2 .1 .15],'String',presets.ArgT2,'HorizontalAlignment','Center');
handles.btnPEDAPreview = uicontrol('parent', handles.PanelPaths,'Style','pushbutton','Units','normalized','Position',   [0.89  0 .1 .15],'String','Preview TUV','Callback',@PreviewTUV);


handles.btnContinue = uicontrol('Style','pushbutton','Units','normalized','Position',[.85 .05 .1 .1],'String','Continue','Callback',@clkContinue);

if ~strcmp(presets.PathT1Pre,patientroot)
    handles.CheckT1Subtract.Value = 1;
    handles.TextPathT1Pre.Visible = 'on';
    handles.EditPathT1Pre.Visible = 'on';
    handles.EditArgT1Pre.Visible = 'on';
    handles.btnT1Pre.Visible = 'on';
end
if presets.T1ManualCenter; handles.CheckT1ManualCenter.Value = 1; end
    

guidata(hFig,handles);

%% Callbacks
    
    %enable/disable T1 subtraction function and edit fields
    function chkT1Subtract(hFig,eventData)
        handles = guidata(hFig); 
        if handles.CheckT1Subtract.Value
            set(handles.EditPathT1Pre,'Visible','on')
            set(handles.TextPathT1Pre,'Visible','on')
            set(handles.EditArgT1Pre,'Visible','on')
            set(handles.btnT1Pre,'Visible','on')
        else
            set(handles.EditPathT1Pre,'Visible','off')
            set(handles.TextPathT1Pre,'Visible','off')
            set(handles.EditArgT1Pre,'Visible','off')
            set(handles.btnT1Pre,'Visible','off')
        end
        guidata(hFig,handles);
    end
    
    % if a new patient is selected, populate text fields with DICOM paths
    function SelectPatient(hFig,eventData)
       handles = guidata(hFig);
       patientID = handles.listPatients.String(handles.listPatients.Value);
       ind = regexp(patientID{1}, '[0-9]+[0-9]+[0-9]+-+[0-9]+[0-9]+[0-9]');
       patientID = patientID{1}(ind:ind+6);
       if isempty(strfind(handles.EditPathT1Pre.String,patientID)); handles.EditPathT1Pre.String = fullfile(patientdir(handles.listPatients.Value).folder,patientdir(handles.listPatients.Value).name,'DICOMs'); end;
       if isempty(strfind(handles.EditPathT1.String,patientID)); handles.EditPathT1.String = fullfile(patientdir(handles.listPatients.Value).folder,patientdir(handles.listPatients.Value).name,'DICOMs'); end;
       if isempty(strfind(handles.EditPathT2.String,patientID)); handles.EditPathT2.String = fullfile(patientdir(handles.listPatients.Value).folder,patientdir(handles.listPatients.Value).name,'DICOMs'); end;
       if isempty(strfind(handles.EditPathPEDA.String,patientID))
           pathSessions = fullfile(fileparts(fullfile(patientdir(handles.listPatients.Value).folder,patientdir(handles.listPatients.Value).name,'DICOMs')),'Sessions');
           dirSessions = dir(pathSessions);
           indPEDA = 0;
           for jj = 1:length(dirSessions)
                if strfind(dirSessions(jj).name,'PEDA')
                    indPEDA = jj;
                end
           end
           if indPEDA ~=0
               verPEDA = dirSessions(indPEDA).name;
               handles.EditPathPEDA.String = fullfile(fileparts(fullfile(patientdir(handles.listPatients.Value).folder,patientdir(handles.listPatients.Value).name,'DICOMs')),'Sessions',verPEDA);
           else
               handles.EditPathPEDA.String = fullfile(fileparts(fullfile(patientdir(handles.listPatients.Value).folder,patientdir(handles.listPatients.Value).name,'DICOMs')),'Sessions');
           end
       end
       if strcmp(patientID(1:3),'002')
           handles.EditArgT1Pre.String = '_W';
           handles.EditArgT1.String = '_W';
       end
       handles.SxParameters = getSxParameters(hFig);
       guidata(hFig,handles);
    end
    
%% change folders with dialogue
    function setPathT1Pre(hFig,eventData)
        handles = guidata(hFig);
        newpath = uigetdir(handles.EditPathT1Pre.String, 'Select PRE contrast T1 directory');
        if newpath
            handles.EditPathT1Pre.String = newpath;
        end
        guidata(hFig,handles);
    end

    function setPathT1Post(hFig,eventData)
        handles = guidata(hFig);
        newpath = uigetdir(handles.EditPathT1.String, 'Select POST contrast T1 directory');
        if newpath
            handles.EditPathT1.String = newpath;
        end
        guidata(hFig,handles);
    end

    function setPathT2(hFig,eventData)
        handles = guidata(hFig);
        newpath = uigetdir(handles.EditPathT2.String, 'Select AX T2 directory');
        if newpath
            handles.EditPathT2.String = newpath;
        end
        guidata(hFig,handles);
    end

    function setPathPEDA(hFig,eventData)
        handles = guidata(hFig);
        newpath = uigetdir(handles.EditPathPEDA.String, 'Select PEDA directory');
        if newpath
            handles.EditPathPEDA.String = newpath;
        end
        handles.SxParameters = getSxParameters(hFig);
        handles.TUVmag = getTUVMag(hFig);
        set(handles.listSegments,'String', {0:length(handles.SxParameters)});
        guidata(hFig,handles);
    end

%% sliders
    function XSliderCallbackT1Min(hFig,eventData)
        handles = guidata(hFig);
        handles.EditT1Min.String = num2str(handles.SliderT1Min.Value,2);
        guidata(hFig,handles);
    end

    function XSliderCallbackT1Max(hFig,eventData)
        handles = guidata(hFig);
        handles.EditT1Max.String = num2str(handles.SliderT1Max.Value,2);
        guidata(hFig,handles);
    end

    function XSliderCallbackT2Min(hFig,eventData)
        handles = guidata(hFig);
        handles.EditT2Min.String = num2str(handles.SliderT2Min.Value,2);
        guidata(hFig,handles);
    end

    function XSliderCallbackT2Max(hFig,eventData)
        handles = guidata(hFig);
        handles.EditT2Max.String = num2str(handles.SliderT2Max.Value,2);
        guidata(hFig,handles);
    end

    function EditT1Min(hFig,eventData)
        handles = guidata(hFig);
        handles.SliderT1Min.Value = str2num(handles.EditT1Min.String);
        guidata(hFig,handles);
    end

    function EditT1Max(hFig,eventData)
        handles = guidata(hFig);
        handles.SliderT1Max.Value = str2num(handles.EditT1Max.String);
        guidata(hFig,handles);
    end

    function EditT2Min(hFig,eventData)
        handles = guidata(hFig);
        handles.SliderT2Min.Value = str2num(handles.EditT2Min.String);
        guidata(hFig,handles);
    end
    
    function EditT2Max(hFig,eventData)
        handles = guidata(hFig);
        handles.SliderT2Max.Value = str2num(handles.EditT2Max.String);
        guidata(hFig,handles);
    end

%% Preview images to set window levels
function PreviewT1(hFigT1,eventData)
handles = guidata(hFig);
patient_index = regexp(handles.EditPathT1.String, '2017');
handlesT1.SxParameters = getSxParameters(hFig);

dirT1 = dir(fullfile(handles.EditPathT1.String,['*' handles.EditArgT1.String '*']));
dirT1 = dirT1(~[dirT1(:).isdir]); %get rid of '.' and '..'

dirT2 = dir(fullfile(handles.EditPathT2.String,['*' handles.EditArgT2.String '*']));
dirT2 = dirT2(~[dirT2(:).isdir]); %get rid of '.' and '..'
if std([dirT2.bytes]) > 100 % 100 byte threshold 
    dirT2 = dirT2(find([dirT2.bytes] < median([dirT2.bytes]) + 3*std([dirT2.bytes]) & [dirT2.bytes] > median([dirT2.bytes]) - 3*std([dirT2.bytes])));
end

% if length(dirT2) > 12
%     dirT2(find([dirT2.bytes] ~= median([dirT2.bytes]))) = []; %get rid of PS files
% end

for jjj = 1:length(dirT2)
    infoT2(jjj) = dicominfo(fullfile(dirT2(jjj).folder,dirT2(jjj).name));
end

ImagePositionPatientT2 = [infoT2.ImagePositionPatient];
ImagePositionPatientT2 = ImagePositionPatientT2(3,:);
[~,indT2] = sort(ImagePositionPatientT2,'ascend');

for kk = 1:length(dirT1)
    infoT1(kk) = dicominfo(fullfile(handles.EditPathT1.String,dirT1(kk).name));
end
if handles.CheckT1Subtract.Value == 1
    T1mat = subtractT1(handles.EditPathT1Pre.String, handles.EditArgT1Pre.String, handles.EditPathT1.String, handles.EditArgT1.String); 
else
%     T1mat = zeros(infoT1.Rows, infoT1.Columns, length(dirT1));
    for kk = 1:length(dirT1)
        
        T1mat(:,:,kk) = dicomread(fullfile(handles.EditPathT1.String, dirT1(kk).name));
    end
end

[infoT1, T1mat] = sortBySliceLocation(infoT1, T1mat);

diffSlices = zeros(length(dirT1),length(dirT2));
for iii = 1:length(dirT1)
    for jjj = 1:length(dirT2)       
        zcT1 = infoT1(iii).ImagePositionPatient(3) ... 
               + (double(infoT1(iii).Rows)/2)*infoT1(iii).ImageOrientationPatient(3)*infoT1(iii).PixelSpacing(2) ... 
               + (double(infoT1(iii).Columns)/2)*infoT1(iii).ImageOrientationPatient(6)*infoT1(iii).PixelSpacing(1);
        
        zcT2 = infoT2(jjj).ImagePositionPatient(3) ... 
               + (double(infoT2(jjj).Rows)/2)*infoT2(jjj).ImageOrientationPatient(3)*infoT2(jjj).PixelSpacing(2) ...
               + (double(infoT2(jjj).Columns)/2)*infoT2(jjj).ImageOrientationPatient(6)*infoT2(jjj).PixelSpacing(1);
        
        diffSlices(iii,jjj) = zcT1 - zcT2;
    end
end
[~,indT1] = min(abs(diffSlices));
diffindT1 = abs(diff(indT1));
indT1 = indT1(2:end-1);

handlesT1.UAcenterT1 = [double(infoT1(1).Columns)/2 double(infoT1(1).Rows)/2];

handlesT1.ProstateBoundaryT1XY = zeros(361,2,length(dirT1));
for kk = 1:length(dirT1)
    if ismember(kk,setdiff(1:length(dirT1),indT1))
        [x,y] = pol2cart(deg2rad([0:359]), 7./infoT1(1).PixelSpacing(1));
        x = x'; y = y';
    else
        [x,y] = pol2cart(deg2rad([0:359])',handles.SxParameters(1).ProstateBoundaryMM(:,find(indT1==kk))./infoT1(1).PixelSpacing(1));
    end
    x(361) = x(1);  y(361) = y(1);
    handlesT1.ProstateBoundaryT1XY(:,1,kk) = x' + handlesT1.UAcenterT1(1);
    handlesT1.ProstateBoundaryT1XY(:,2,kk) = -y' + handlesT1.UAcenterT1(2);
end
elem = 0;
for kk = indT1
    elem = elem + 1;
    if diffindT1(elem) > 1
        for kkk = kk - ceil(diffindT1(elem)/2):kk + ceil(diffindT1(elem)/2)
            fprintf('elem: %i\tkkk: %i\tkk: %i\n',elem,kkk,kk);
            handlesT1.ProstateBoundaryT1XY(:,1,kkk) = handlesT1.ProstateBoundaryT1XY(:,1,kk);
            handlesT1.ProstateBoundaryT1XY(:,2,kkk) = handlesT1.ProstateBoundaryT1XY(:,2,kk);
        end
    end
end

hFigT1 = figure('Position',[500 300 600 600]);
set(hFigT1,'WindowButtonDownFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigT1));
set(hFigT1,'WindowScrollWheelFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigT1));
set(hFigT1,'WindowKeyPressFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigT1));

handlesT1.absMin = double(min(T1mat(:)));
handlesT1.absMax = double(max(T1mat(:)));
handlesT1.CLimMin = (handlesT1.absMax - handlesT1.absMin).*(str2num(handles.EditT1Min.String)) + handlesT1.absMin;
handlesT1.CLimMax = (handlesT1.absMax - handlesT1.absMin).*(str2num(handles.EditT1Max.String)) + handlesT1.absMin;
handlesT1.CLimMinNorm = str2num(handles.EditT1Min.String);
handlesT1.CLimMaxNorm = str2num(handles.EditT1Max.String);
handlesT1.prostateRGB = [218 165 32]./255;
handlesT1.slice = 1;
handlesT1.Type = 'T1';
handlesT1.PixelSpacing = infoT1(1).PixelSpacing;
handlesT1.LineCoordinates = [double(infoT1(1).Rows)/2 double(infoT1(1).Rows)*0.65; double(infoT1(1).Columns)/2 double(infoT1(1).Columns)/2];
handlesT1.ShowDistLine = 0;
handlesT1.LineLength = (double(infoT1(1).Rows)*0.65 - double(infoT1(1).Rows)/2)*handlesT1.PixelSpacing(1);

handlesT1.axes1 = axes('units','normalized','Position',[.05 .15 .9 .8],'NextPlot','replacechildren');
handlesT1.imshow1 = imshow(T1mat(:,:,handlesT1.slice),[], 'colormap', gray);
hold on
handlesT1.ProstateBoundary = plot(handlesT1.ProstateBoundaryT1XY(:,1,handlesT1.slice),handlesT1.ProstateBoundaryT1XY(:,2,handlesT1.slice), '-', 'Color', handlesT1.prostateRGB, 'LineWidth', 1.5);

caxis([handlesT1.CLimMin handlesT1.CLimMax]); axis equal;
handlesT1.btnResetUACenterT1 = uicontrol('Style','pushbutton','Units','normalized','Position',  [.6  0.10 0.17 .05],'String','Reset UA center','Callback', @(hObject, eventdata)clkResetUACenterT1(hObject, eventdata, hFigT1));
handlesT1.btnChangeUACenterT1 = uicontrol('Style','pushbutton','Units','normalized','Position', [.6  0.05  0.17 .05],'String','Change UA center','Callback', @(hObject, eventdata)clkChangeUACenterT1(hObject, eventdata, hFigT1));
handlesT1.chkBoundary = uicontrol('Style','checkbox','Units','normalized','Position',           [.77 0.115 0.17 .05/2],'String','Boundary','Value',1,'Callback', @(hObject, eventdata)chkBoundary(hObject, eventdata, hFigT1));
handlesT1.btnAccept = uicontrol('Style','pushbutton','Units','normalized','Position',           [.77 0.05  0.13 .05],'String','Accept','Callback', @(hObject, eventdata)clkAcceptT1(hObject, eventdata, hFigT1));

handlesT1.TextTitle = uicontrol('Style','Text','Units','normalized','Position',       [.05 0.95  0.9 0.04],'String',handles.EditPathT1.String(patient_index:end),'HorizontalAlignment', 'Center', 'FontSize', 11);
handlesT1.TextMinLabel = uicontrol('Style','Text','Units','normalized','Position',    [.1  0.11  0.11 0.03],'String','Min','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextMaxLabel = uicontrol('Style','Text','Units','normalized','Position',    [.23 0.11  0.11 0.03],'String','Max','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextSliceLabel = uicontrol('Style','Text','Units','normalized','Position',  [.36 0.11  0.11 0.03],'String','Slice','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextMeasureLabel = uicontrol('Style','Text','Units','normalized','Position',[.49 0.11  0.11 0.03],'String',' ','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextMin = uicontrol('Style','Text','Units','normalized','Position',         [.1  0.08  0.11 0.03],'String',num2str(handlesT1.CLimMin),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextMax = uicontrol('Style','Text','Units','normalized','Position',         [.23 0.08  0.11 0.03],'String',num2str(handlesT1.CLimMax),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextSlice = uicontrol('Style','Text','Units','normalized','Position',       [.36  0.08 0.11 0.03],'String',num2str(handlesT1.slice),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextMeasure = uicontrol('Style','Text','Units','normalized','Position',     [.49  0.08 0.11 0.03],'String',' ','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextMinNorm = uicontrol('Style','Text','Units','normalized','Position',     [.1  0.05  0.11 0.03],'String',num2str(handlesT1.CLimMinNorm),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextMaxNorm = uicontrol('Style','Text','Units','normalized','Position',     [.23 0.05  0.11 0.03],'String',num2str(handlesT1.CLimMaxNorm),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT1.TextInstructions = uicontrol('Style','Text','Units','normalized','Position',[.05 0     0.9 0.03],'String','Window: Right mouse           Slices: Mouse wheel           Zoom: Press w/s           Measure: Press m','HorizontalAlignment', 'center', 'FontSize', 8);

guidata(hFigT1,handlesT1);
setappdata(hFigT1,'Tmat',T1mat);

function chkBoundary(hObject, eventdata, hFigT1)
    myhandles = guidata(hFigT1);
    if myhandles.chkBoundary.Value == 0
        myhandles.ProstateBoundary.Visible = 'off';
    else
        myhandles.ProstateBoundary.Visible = 'on';
    end
end

function clkChangeUACenterT1(hObject, eventdata, hFigT1)
    myhandles = guidata(hFigT1);
    oldUAcenter = myhandles.UAcenterT1;
    myhandles.UAcenterT1 = ginput(1);
    myhandles.ProstateBoundaryT1XY(:,1,:) = myhandles.ProstateBoundaryT1XY(:,1,:) + myhandles.UAcenterT1(1) - oldUAcenter(1);
    myhandles.ProstateBoundaryT1XY(:,2,:) = myhandles.ProstateBoundaryT1XY(:,2,:) + myhandles.UAcenterT1(2) - oldUAcenter(2);
    if myhandles.chkBoundary.Value == 1
        delete(myhandles.ProstateBoundary)
    end
    myhandles.ProstateBoundary = plot(myhandles.ProstateBoundaryT1XY(:,1,myhandles.slice),myhandles.ProstateBoundaryT1XY(:,2,myhandles.slice), '-', 'Color', myhandles.prostateRGB, 'LineWidth', 1.5);
    if myhandles.chkBoundary.Value == 0
        myhandles.ProstateBoundary.Visible = 'off';
    end
    guidata(hFigT1,myhandles)
end

function clkResetUACenterT1(hObject, eventdata, hFigT1)
    myhandles = guidata(hFigT1);
    T1Mat = getappdata(hFigT1,'Tmat');
    oldUAcenter = myhandles.UAcenterT1;
    
    myhandles.UAcenterT1(1) = size(T1Mat,2)./2;
    myhandles.UAcenterT1(2) = size(T1Mat,1)./2;
    
    myhandles.ProstateBoundaryT1XY(:,1,:) = myhandles.ProstateBoundaryT1XY(:,1,:) + myhandles.UAcenterT1(1) - oldUAcenter(1);
    myhandles.ProstateBoundaryT1XY(:,2,:) = myhandles.ProstateBoundaryT1XY(:,2,:) + myhandles.UAcenterT1(2) - oldUAcenter(2);
    if myhandles.chkBoundary.Value == 1
        delete(myhandles.ProstateBoundary)
    end
    myhandles.ProstateBoundary = plot(myhandles.ProstateBoundaryT1XY(:,1,myhandles.slice),myhandles.ProstateBoundaryT1XY(:,2,myhandles.slice), '-', 'Color', myhandles.prostateRGB, 'LineWidth', 1.5);
    if myhandles.chkBoundary.Value == 0
        myhandles.ProstateBoundary.Visible = 'off';
    end
    guidata(hFigT1,myhandles)
end

function clkAcceptT1(hObject, eventdata, hFigT1)
    T1Mat = getappdata(hFigT1,'Tmat');
    myhandles = guidata(hFigT1);

    guidata(hFig,handles);
    myhandles.CLimMin = str2double(myhandles.TextMin.String);
    myhandles.CLimMax = str2double(myhandles.TextMax.String);
    myhandles.CLimMinNorm = str2double(myhandles.TextMinNorm.String);
    myhandles.CLimMaxNorm = str2double(myhandles.TextMaxNorm.String);
    
    minT1Mat = double(min(T1Mat(:)));
    maxT1Mat = double(max(T1Mat(:)));
    handles.EditT1Min.String = num2str((myhandles.CLimMin - minT1Mat)./(maxT1Mat-minT1Mat));
    handles.EditT1Max.String = num2str((myhandles.CLimMax - minT1Mat)./(maxT1Mat-minT1Mat));
    
    if myhandles.CLimMinNorm < 0
        handles.SliderT1Min.Value = 0;
    else
        handles.SliderT1Min.Value = myhandles.CLimMinNorm;
    end
    
    if myhandles.CLimMaxNorm > 1
        handles.SliderT1Max.Value = 1;
    else
        handles.SliderT1Max.Value = myhandles.CLimMaxNorm;
    end

    close(hFigT1)
end

end

%%
function PreviewT2(hFigT2,eventData)
handles = guidata(hFig);
patient_index = regexp(handles.EditPathT2.String, '2017');
handlesT2.SxParameters = getSxParameters(hFig);

dirT2 = dir(fullfile(handles.EditPathT2.String,['*' handles.EditArgT2.String '*']));
dirT2 = dirT2(~[dirT2(:).isdir]); %get rid of '.' and '..'

if std([dirT2.bytes]) > 100 % 100 byte threshold 
    dirT2 = dirT2(find([dirT2.bytes] < median([dirT2.bytes]) + 3*std([dirT2.bytes]) & [dirT2.bytes] > median([dirT2.bytes]) - 3*std([dirT2.bytes])));
end

% if length(dirT2) > 12
%     dirT2(find([dirT2.bytes] ~= median([dirT2.bytes]))) = []; %get rid of PS files
% end

for jj = 1:length(dirT2)
    infoT2(jj) = dicominfo(fullfile(dirT2(jj).folder,dirT2(jj).name));
end

ImagePositionPatientT2 = [infoT2.ImagePositionPatient];
ImagePositionPatientT2 = ImagePositionPatientT2(3,:);
[~,indT2] = sort(ImagePositionPatientT2,'ascend');

T2mat = zeros(infoT2(1).Rows, infoT2(1).Columns, length(dirT2));
for kk = 1:length(dirT2)
    T2mat(:,:,kk) = dicomread(fullfile(handles.EditPathT2.String, dirT2(indT2(kk)).name));
end

handlesT2.ProstateBoundaryT2XY = zeros(361,2,12);
for kk = 1:12
    if kk == 1 || kk == 12
        [x,y] = pol2cart(deg2rad([0:359]), 7./infoT2(1).PixelSpacing(1));
        x = x'; y = y';
    else
        [x,y] = pol2cart(deg2rad([0:359])',handles.SxParameters(1).ProstateBoundaryMM(:,kk-1)./infoT2(1).PixelSpacing(1));
    end
    x(361) = x(1);  y(361) = y(1);
    handlesT2.ProstateBoundaryT2XY(:,1,kk) = x' + double(infoT2(1).Rows)/2;
    handlesT2.ProstateBoundaryT2XY(:,2,kk) = -y' + double(infoT2(1).Columns)/2;
end

hFigT2 = figure('Position',[500 300 600 600]);
set(hFigT2,'WindowButtonDownFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigT2));
set(hFigT2,'WindowScrollWheelFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigT2));
set(hFigT2,'WindowKeyPressFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigT2));

handlesT2.absMin = min(T2mat(:));
handlesT2.absMax = max(T2mat(:));
handlesT2.CLimMin = (handlesT2.absMax - handlesT2.absMin).*(str2num(handles.EditT2Min.String)) + handlesT2.absMin;
handlesT2.CLimMax = (handlesT2.absMax - handlesT2.absMin).*(str2num(handles.EditT2Max.String)) + handlesT2.absMin;
handlesT2.CLimMinNorm = str2num(handles.EditT2Min.String);
handlesT2.CLimMaxNorm = str2num(handles.EditT2Max.String);
handlesT2.prostateRGB = [218 165 32]./255;
handlesT2.Type = 'T2';
handlesT2.PixelSpacing = infoT2(1).PixelSpacing;
handlesT2.LineCoordinates = [double(infoT2(1).Rows)/2 double(infoT2(1).Rows)*0.65; double(infoT2(1).Columns)/2 double(infoT2(1).Columns)/2];
handlesT2.ShowDistLine = 0;
handlesT2.LineLength = (double(infoT2(1).Rows)*0.65 - double(infoT2(1).Rows)/2)*handlesT2.PixelSpacing(1);

handlesT2.slice = 1;

handlesT2.axes1 = axes('units','normalized','Position',[.05 .15 .9 .8],'NextPlot','replacechildren');
handlesT2.imshow1 = imshow(T2mat(:,:,handlesT2.slice),[], 'colormap', gray);
hold on
handlesT2.ProstateBoundary = plot(handlesT2.ProstateBoundaryT2XY(:,1,handlesT2.slice),handlesT2.ProstateBoundaryT2XY(:,2,handlesT2.slice), '-', 'Color', handlesT2.prostateRGB, 'LineWidth', 1.5);

caxis([handlesT2.CLimMin handlesT2.CLimMax]); axis equal;
handlesT2.btnAccept = uicontrol('Style','pushbutton','Units','normalized','Position', [.77 0.08 0.13 .05],'String','Accept','Callback', @(hObject, eventdata)clkAcceptT2(hObject, eventdata, hFigT2));
handlesT2.chkBoundary = uicontrol('Style','checkbox','Units','normalized','Position', [.63 0.08 0.13 .05],'String','Boundary','Value',1,'Callback', @(hObject, eventdata)chkBoundary(hObject, eventdata, hFigT2));

handlesT2.TextTitle = uicontrol('Style','Text','Units','normalized','Position',       [.05 0.95  0.9 0.04],'String',handles.EditPathT2.String(patient_index:end),'HorizontalAlignment', 'Center', 'FontSize', 11);
handlesT2.TextMinLabel = uicontrol('Style','Text','Units','normalized','Position',    [.1  0.11  0.11 0.03],'String','Min','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextMaxLabel = uicontrol('Style','Text','Units','normalized','Position',    [.23 0.11  0.11 0.03],'String','Max','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextSliceLabel = uicontrol('Style','Text','Units','normalized','Position',  [.36 0.11  0.11 0.03],'String','Slice','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextMeasureLabel = uicontrol('Style','Text','Units','normalized','Position',[.49 0.11  0.11 0.03],'String',' ','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextMin = uicontrol('Style','Text','Units','normalized','Position',         [.1  0.08  0.11 0.03],'String',num2str(handlesT2.CLimMin),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextMax = uicontrol('Style','Text','Units','normalized','Position',         [.23 0.08  0.11 0.03],'String',num2str(handlesT2.CLimMax),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextSlice = uicontrol('Style','Text','Units','normalized','Position',       [.36  0.08 0.11 0.03],'String',num2str(handlesT2.slice),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextMeasure = uicontrol('Style','Text','Units','normalized','Position',     [.49  0.08 0.11 0.03],'String',' ','HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextMinNorm = uicontrol('Style','Text','Units','normalized','Position',     [.1  0.05  0.11 0.03],'String',num2str(handlesT2.CLimMinNorm),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextMaxNorm = uicontrol('Style','Text','Units','normalized','Position',     [.23 0.05  0.11 0.03],'String',num2str(handlesT2.CLimMaxNorm),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesT2.TextInstructions = uicontrol('Style','Text','Units','normalized','Position',[.05 0     0.9 0.03],'String','Window: Right mouse           Slices: Mouse wheel           Zoom: Press w/s           Measure: Press m','HorizontalAlignment', 'center', 'FontSize', 8);


guidata(hFigT2,handlesT2);
setappdata(hFigT2,'Tmat',T2mat);

function chkBoundary(hObject, eventdata, hFigT2)
    myhandles = guidata(hFigT2);
    if myhandles.chkBoundary.Value == 0
        myhandles.ProstateBoundary.Visible = 'off';
    else
        myhandles.ProstateBoundary.Visible = 'on';
    end
    
end

function clkAcceptT2(hObject, eventdata, hFigT2)
    T2Mat = getappdata(hFigT2,'Tmat');
    myhandles = guidata(hFigT2);

    guidata(hFig,handles);
    myhandles.CLimMin = str2double(myhandles.TextMin.String);
    myhandles.CLimMax = str2double(myhandles.TextMax.String);
    myhandles.CLimMinNorm = str2double(myhandles.TextMinNorm.String);
    myhandles.CLimMaxNorm = str2double(myhandles.TextMaxNorm.String);
%     if myhandles.CLimMin < min(T1Mat(:)); myhandles.CLimMin = min(T1Mat(:)); end
    
    minT2Mat = double(min(T2Mat(:)));
    maxT2Mat = double(max(T2Mat(:)));
    handles.EditT2Min.String = num2str((myhandles.CLimMin - minT2Mat)./(maxT2Mat-minT2Mat));
    handles.EditT2Max.String = num2str((myhandles.CLimMax - minT2Mat)./(maxT2Mat-minT2Mat));
    
    if myhandles.CLimMinNorm < 0
        handles.SliderT2Min.Value = 0;
    else
        handles.SliderT2Min.Value = myhandles.CLimMinNorm;
    end
    
    if myhandles.CLimMaxNorm > 1
        handles.SliderT2Max.Value = 1;
    else
        handles.SliderT2Max.Value = myhandles.CLimMaxNorm;
    end

    close(hFigT2)
end

end


function PreviewTUV(hFigTUV,eventData)
handles = guidata(hFig);
patient_index = regexp(handles.EditPathT1.String, '2017');

handlesTUV.SxParameters = getSxParameters(hFig);
handlesTUV.TUVmag = getTUVMag(hFig);

TUVmat = handlesTUV.TUVmag;

hFigTUV = figure('Position',[500 300 600 600]);
set(hFigTUV,'WindowButtonDownFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigTUV));
set(hFigTUV,'WindowScrollWheelFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigTUV));
set(hFigTUV,'WindowKeyPressFcn',@(hObject, eventdata)XCallback(hObject, eventdata, hFigTUV));

handlesTUV.absMin = min(TUVmat(:));
handlesTUV.absMax = max(TUVmat(:));
handlesTUV.CLimMin = handlesTUV.absMin;
handlesTUV.CLimMax = handlesTUV.absMax;
handlesTUV.CLimMinNorm = 0;
handlesTUV.CLimMaxNorm = 1;
handlesTUV.prostateRGB = [218 165 32]./255;
handlesTUV.Type = 'TUV';
handlesTUV.PixelSpacing = [2 2];
handlesTUV.LineCoordinates = [64 64; 64 128*.65];
handlesTUV.ShowDistLine = 0;
handlesTUV.LineLength = 128*.65;

handlesTUV.slice = 1;

handlesTUV.ProstateBoundaryXY = zeros(361,2,12);
for kk = 1:12
    if kk == 1 || kk == 12
        [x,y] = pol2cart(deg2rad([0:359]), 7./2);
        x = x'; y = y';
    else
        [x,y] = pol2cart(deg2rad([0:359])',handlesTUV.SxParameters(1).ProstateBoundary(:,kk-1));
    end
    x(361) = x(1);  y(361) = y(1);
    handlesTUV.ProstateBoundaryXY(:,1,kk) = x' + handlesTUV.SxParameters(1).ux(1);
    handlesTUV.ProstateBoundaryXY(:,2,kk) = -y' + handlesTUV.SxParameters(1).uy(1);
end


handlesTUV.axes1 = axes('units','normalized','Position',[.05 .15 .9 .8],'NextPlot','replacechildren');
handlesTUV.imshow1 = imshow(TUVmat(:,:,handlesTUV.slice),[], 'colormap', gray);
hold on
handlesTUV.ProstateBoundary = plot(handlesTUV.ProstateBoundaryXY(:,1,handlesTUV.slice), handlesTUV.ProstateBoundaryXY(:,2,handlesTUV.slice), '-', 'Color', handlesTUV.prostateRGB, 'LineWidth', 1.5);

caxis([handlesTUV.CLimMin handlesTUV.CLimMax]); axis equal;
handlesTUV.btnAccept = uicontrol('Style','pushbutton','Units','normalized','Position', [.77 0.08 0.13 .05],'String','Close','Callback', @(hObject, eventdata)clkClose(hObject, eventdata, hFigTUV));
handlesTUV.TextTitle = uicontrol('Style','Text','Units','normalized','Position',       [.05 0.95  0.9 0.04],'String',handles.EditPathT1.String(patient_index:end),'HorizontalAlignment', 'Center', 'FontSize', 11);
handlesTUV.TextMinLabel = uicontrol('Style','Text','Units','normalized','Position',    [.1  0.11  0.2 0.03],'String','Min','HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextMaxLabel = uicontrol('Style','Text','Units','normalized','Position',    [.23 0.11  0.2 0.03],'String','Max','HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextSliceLabel = uicontrol('Style','Text','Units','normalized','Position',  [.36  0.11  0.2 0.03],'String','Slice','HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextMeasureLabel = uicontrol('Style','Text','Units','normalized','Position', [.49 0.11  0.11 0.03],'String',' ','HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextMin = uicontrol('Style','Text','Units','normalized','Position',         [.1  0.08  0.2 0.03],'String',num2str(handlesTUV.CLimMin),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextMax = uicontrol('Style','Text','Units','normalized','Position',         [.23 0.08  0.2 0.03],'String',num2str(handlesTUV.CLimMax),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextSlice = uicontrol('Style','Text','Units','normalized','Position',       [.36  0.08  0.2 0.03],'String',num2str(handlesTUV.slice),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextMeasure = uicontrol('Style','Text','Units','normalized','Position',      [.49  0.08 0.11 0.03],'String',' ','HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextMinNorm = uicontrol('Style','Text','Units','normalized','Position',     [.1  0.05  0.2 0.03],'String',num2str(handlesTUV.CLimMinNorm),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextMaxNorm = uicontrol('Style','Text','Units','normalized','Position',     [.23 0.05  0.2 0.03],'String',num2str(handlesTUV.CLimMaxNorm),'HorizontalAlignment', 'left', 'FontSize', 10);
handlesTUV.TextInstructions = uicontrol('Style','Text','Units','normalized','Position',[.05 0     0.9 0.03],'String','Window: Right mouse           Slices: Mouse wheel           Zoom: Press w/s           Measure: Press m','HorizontalAlignment', 'center', 'FontSize', 8);

handlesTUV.chkBoundary = uicontrol('Style','checkbox','Units','normalized','Position', [.63 0.08 0.13 .05],'String','Boundary','Value',1,'Callback', @(hObject, eventdata)chkBoundary(hObject, eventdata, hFigTUV));

guidata(hFigTUV,handlesTUV);
setappdata(hFigTUV,'Tmat',TUVmat);

function chkBoundary(hObject, eventdata, hFigTUV)
    myhandles = guidata(hFigTUV);
    if myhandles.chkBoundary.Value == 0
        myhandles.ProstateBoundary.Visible = 'off';
    else
        myhandles.ProstateBoundary.Visible = 'on';
    end

end

function clkClose(hObject, eventdata, hFigTUV)
   close(hFigTUV)
end

end

%%
function hImage = XCallback(hObject,Event,handle)
myhandles = guidata(handle);
switch Event.EventName
    case 'WindowMousePress'
        if strcmp(get(hObject,'SelectionType'),'alt') %if right mouse click
            adjustWindowLevels(myhandles, hObject)
        end
    case 'WindowScrollWheel'
        ScrollSlice(hObject, Event, myhandles)
    case 'WindowKeyPress'
        arrowPress(hObject, Event, myhandles) 
end

end

function adjustWindowLevels(myhandles, hObject)
% get the values and store them in the figure's appdata
props.WindowButtonMotionFcn = get(hObject,'WindowButtonMotionFcn');
props.WindowButtonUpFcn = get(hObject,'WindowButtonUpFcn');
setappdata(hObject,'TestGuiCallbacks',props);

% Store initial cursor position
myhandles.InitialCursorPosition = hObject.CurrentPoint;
myhandles.InitialCLim = myhandles.axes1.CLim;

% set the new values for the WindowButtonMotionFcn and
% WindowButtonUpFcn
set(hObject,'WindowButtonMotionFcn',{@(hObject, eventdata)adjustContrastMouseMotion(hObject, eventdata, myhandles)})
set(hObject,'WindowButtonUpFcn',{@wbu})
    function wbu(h,evd)
        % get the properties and restore them
        props = getappdata(h,'TestGuiCallbacks');
        set(h,props);
    end

    function adjustContrastMouseMotion(h,evd, myhandles)
        mouseDelta = (myhandles.InitialCursorPosition - h.CurrentPoint)/2; %Reduced to smooth things
        
        %Adjust level (linear shift)
        updatedCLim = myhandles.InitialCLim - mouseDelta(1);
        
        %Adjust window (slope)
        updatedCLim(1) = updatedCLim(1) + mouseDelta(2);
        updatedCLim(2) = updatedCLim(2) - mouseDelta(2);
        
        % Update CLim
        caxis(myhandles.axes1,round(updatedCLim));
        updatedCLimNorm(1) = (updatedCLim(1) - myhandles.absMin)./(myhandles.absMax - myhandles.absMin);
        updatedCLimNorm(2) = (updatedCLim(2) - myhandles.absMin)./(myhandles.absMax - myhandles.absMin);
        
        set(myhandles.TextMin,'String',num2str(updatedCLim(1)));
        set(myhandles.TextMax,'String',num2str(updatedCLim(2)));
        set(myhandles.TextMinNorm,'String',num2str(updatedCLimNorm(1)));
        set(myhandles.TextMaxNorm,'String',num2str(updatedCLimNorm(2)));
    end
end

function ScrollSlice(hObject, eventdata, myhandles)
    myhandles.slice = str2num(myhandles.TextSlice.String);
    T1Mat = getappdata(hObject,'Tmat');
    if eventdata.VerticalScrollCount > 0
        if myhandles.slice < size(T1Mat,3)
            myhandles.slice = myhandles.slice + 1;
        else
            myhandles.slice = size(T1Mat,3);
        end
    elseif eventdata.VerticalScrollCount < 0
        if myhandles.slice > 1
            myhandles.slice = myhandles.slice - 1;
        else
            myhandles.slice = 1;
        end
    end
    set(myhandles.imshow1, 'CData', T1Mat(:,:,myhandles.slice));
    
    if myhandles.chkBoundary.Value == 1
        delete(myhandles.ProstateBoundary)
    end
    if strcmp(myhandles.Type,'T2')
        myhandles.ProstateBoundary = plot(myhandles.ProstateBoundaryT2XY(:,1,myhandles.slice),myhandles.ProstateBoundaryT2XY(:,2,myhandles.slice), '-', 'Color', myhandles.prostateRGB, 'LineWidth', 1.5);
    elseif strcmp(myhandles.Type,'TUV')
        myhandles.ProstateBoundary = plot(myhandles.ProstateBoundaryXY(:,1,myhandles.slice),myhandles.ProstateBoundaryXY(:,2,myhandles.slice), '-', 'Color', myhandles.prostateRGB, 'LineWidth', 1.5);
    elseif strcmp(myhandles.Type,'T1')
        myhandles.ProstateBoundary = plot(myhandles.ProstateBoundaryT1XY(:,1,myhandles.slice),myhandles.ProstateBoundaryT1XY(:,2,myhandles.slice), '-', 'Color', myhandles.prostateRGB, 'LineWidth', 1.5);
    end
    if myhandles.chkBoundary.Value == 0
        myhandles.ProstateBoundary.Visible = 'off';
    end

    myhandles.TextSlice.String = num2str(myhandles.slice);
    
    guidata(hObject, myhandles);
end

function arrowPress(hObject, eventdata, myhandles)
    zoomfactorperstep = 1.33;
    if strcmp(eventdata.Key, 'uparrow') || strcmp(eventdata.Key, 'w')
        zoom(zoomfactorperstep)
    elseif strcmp(eventdata.Key, 'downarrow') || strcmp(eventdata.Key, 's')
        zoom(1/zoomfactorperstep)
    elseif strcmp(eventdata.Key, 'm')
        
        if myhandles.ShowDistLine == 0
            myhandles.TextMeasureLabel.String = 'Length';
            myhandles.TextMeasure.String = [num2str(myhandles.LineLength,3) ' mm'];
            myhandles.ShowDistLine = 1;
        
            myhandles.Line1 = imdistline(myhandles.axes1,myhandles.LineCoordinates(:,1),myhandles.LineCoordinates(:,2));
%         Coordinates1 = wait(Line1);
            myhandles.api = iptgetapi(myhandles.Line1);
            myhandles.api.setLabelVisible(0);
%             api.addNewPositionCallback(fcn);
            anonCB = @(pos) LineNewPos_Callback(hObject, myhandles, pos);
            myhandles.api.addNewPositionCallback(anonCB);
            
% %             fcn = makeConstrainToRectFcn('imline', get(myhandles.axes1,'XLim'),get(myhandles.axes1,'YLim'));
% %             api.setDragConstraintFcn(fcn);
% %             
% %             % Convert XData and YData to meters using conversion factor.
% %             XDataMM = get(myhandles.imshow1,'XData'); 
% %             YDataMM = get(myhandles.imshow1,'YData');
% % 
% %             % Set XData and YData of image to reflect desired units.    
% %             set(myhandles.imshow1,'XData',[myhandles.PixelSpacing(1) XDataMM(2)],'YData',[myhandles.PixelSpacing(2) YDataMM(2)]);    
% %             set(myhandles.axes1,'XLim',[myhandles.PixelSpacing(1) XDataMM(2)],'YLim',[myhandles.PixelSpacing(2) YDataMM(2)]);
% %             
% %             api.setLabelTextFormatter('%2.1f mm');
%             Coordinates1 = api.getPosition;
%             LineLength = sqrt( ((Coordinates1(1,2) - Coordinates1(2,2))*myhandles.PixelSpacing(1)).^2 + ((Coordinates1(1,1) - Coordinates1(2,1))*myhandles.PixelSpacing(2)).^2);
            
        else
            myhandles.TextMeasureLabel.String = ' ';
            myhandles.TextMeasure.String = ' ';
            myhandles.ShowDistLine = 0;
%             api = iptgetapi(myhandles.Line1);
            myhandles.api.delete();
        end
%         id = addNewPositionCallback(Line1,@(pos) set(myhandles.TextMeasure,'String', ['test']));
% 
%         % After observing the callback behavior, remove the callback.
%         % using the removeNewPositionCallback API function.     
%         removeNewPositionCallback(Line1,id);
        
        %calculate length of line
%         LineLength = sqrt( ((Coordinates1(1,2) - Coordinates1(2,2))*myhandles.PixelSpacing(1)).^2 + ((Coordinates1(1,1) - Coordinates1(2,1))*myhandles.PixelSpacing(2)).^2);
%         set(myhandles.TextMeasure,'String', [num2str(LineLength,3) ' mm']);
%         myhandles.LineCoordinates = Coordinates1;
%         delete(Line1)
        guidata(hObject,myhandles);
    end
    
end

function LineNewPos_Callback(hObject, myhandles, pos)
    LineLengthMM = sqrt( ((pos(1,2) - pos(2,2))*myhandles.PixelSpacing(1)).^2 + ((pos(1,1) - pos(2,1))*myhandles.PixelSpacing(2)).^2);
    set(myhandles.TextMeasure,'String',[num2str(LineLengthMM,3) ' mm'])
    myhandles.LineCoordinates = pos;
    myhandles.LineLengthMM = LineLengthMM;
    guidata(hObject, myhandles)
end

%% Call the PostTreatmentOverlay function with the appropriate input arguments
    function clkContinue(hFig,eventData)
        pathT1Pre = handles.EditPathT1Pre.String;
        pathT1 = handles.EditPathT1.String;
        pathT2 = handles.EditPathT2.String;
        pathPEDA = handles.EditPathPEDA.String;
        
        argT1Pre = handles.EditArgT1Pre.String;
        argT1 = handles.EditArgT1.String;
        argT2 = handles.EditArgT2.String;
        
        options.T1ManualCenter = handles.CheckT1ManualCenter.Value;
        options.ZoomFactor = str2num(handles.EditZoomFactor.String);
        options.LineWidth = str2num(handles.EditLineWidth.String);
        options.T1Min = str2num(handles.EditT1Min.String);
        options.T1Max = str2num(handles.EditT1Max.String);
        options.T2Min = str2num(handles.EditT2Min.String);
        options.T2Max = str2num(handles.EditT2Max.String);
        options.PathT1 = pathT1;
        options.PathT2 = pathT2;
        options.PathPEDA = pathPEDA;
        options.ArgT1 = argT1;
        options.ArgT2 = argT2;
        options.Segment = str2num(cell2mat(handles.listSegments.String(handles.listSegments.Value)));
%         options.EPIMin = 0;
%         options.EPIMax = 4095*.8;
        options.manualIsUAactive = [0 0 0 0 1 1 1 1 0 0 0 0];
        
        if handles.CheckT1Subtract.Value
            options.PathT1Pre = pathT1Pre;
            options.ArgT1Pre = argT1Pre;
        end
        
        if handles.SliderT1Min.Value > handles.SliderT1Max.Value || handles.SliderT2Min.Value > handles.SliderT2Max.Value
            warning('Make sure Max window values are less than Min window values')
        else
%             close(gcf)
            disp('Processing...')
            PostTreatmentOverlay(pathT1,argT1,pathT2,argT2,pathPEDA,options);
        end
    end
end

function [sortedInfo, sortedMatrix] = sortBySliceLocation(dinfo, matrix)
    sliceLocation = [dinfo.SliceLocation];
    [~,sortedIdx] = sort(sliceLocation);
    sortedIdx = fliplr(sortedIdx);
    sortedMatrix = matrix(:,:,sortedIdx);
    sortedInfo = dinfo(sortedIdx);
end

function Sx = getSxParameters(hFig)
    handles = guidata(hFig);
    load(fullfile(handles.EditPathPEDA.String,'SxParameters.mat'));
    Sx = SxParameters;
end

function T1mat = getTUVMag(hFig)
    handles = guidata(hFig);
    load(fullfile(handles.EditPathPEDA.String,'Segment 1','TUVMag.mat'));
    T1mat = TUVMag(:,:,:,end); %last dyn of TUV
end

function output = validateOptions(options, patientroot)
    if ~isstruct(options)
        options = [];
        options.Dummy = [];
    end
    output = options;

    if ~isfield(options,'PathPreT1Pre');    output.PathT1Pre = patientroot; end
    if ~isfield(options,'PathT1');          output.PathT1 = patientroot; end
    if ~isfield(options,'PathT2');          output.PathT2 = patientroot; end
    if ~isfield(options,'PathPEDA');        output.PathPEDA = patientroot; end
    if ~isfield(options,'ArgT1Pre');        output.ArgT1Pre = 'T1'; end
    if ~isfield(options,'ArgT1');           output.ArgT1 = 'T1'; end
    if ~isfield(options,'ArgT2');           output.ArgT2 = 'T2'; end
    if ~isfield(options,'ZoomFactor');      output.ZoomFactor = 2.5; end
    if ~isfield(options,'T1ManualCenter');  output.T1ManualCenter = 0; end
    if ~isfield(options,'T1Min');           output.T1Min = 0; end
    if ~isfield(options,'T1Max');           output.T1Max = 0.7; end
    if ~isfield(options,'T2Min');           output.T2Min = 0; end
    if ~isfield(options,'T2Max');           output.T2Max = 0.8; end
    if ~isfield(options,'EPIMin');          output.EPIMin = 0; end
    if ~isfield(options,'EPIMax');          output.EPIMax = 4095*.8; end
    if ~isfield(options,'LineWidth');       output.LineWidth = 2; end
    if ~isfield(options,'Segment');         output.Segment = 0; end

    
    if isfield(output,'Dummy'); rmfield(output,'Dummy'); end
end
    