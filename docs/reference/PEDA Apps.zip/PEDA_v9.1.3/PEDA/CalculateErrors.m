function errorStatistics = CalculateErrors(isothermRadius, targetBoundary, prostateBoundary, tol, MinTR, MaxTR, SliceThickness,isUAactive, treatedSector)
%==========================================================================
% Purpose:  Calculate volumetric error and DSC statistics
%
% Inputs:
%      - isothermRadius [mm]
%      - targetBoundary  [mm]
%      - prostateBoundary [mm]
%      - tol = tolerance around the target boundary within which volume error
%      is not summed. [mm]
%      - MinTR (Regions where the target boundary is less than MinTR are not
%      included in the calculation) [mm]
%      - MaxTR (Regions where the target boundary is more than MaxTR are not
%      included in a separate calculation) [mm]
%      - SliceThickness - Thickness of slices for volume calculation [mm]
%      - isUAactive - 12 element logical that determines which slices have
%      boundaries
%      - treatedSector - vector that stores the indexed treatment angle for
%      isothermRadius and targetBoundary

% Outputs:
%      - OSpercent = percent overshoot
%      - USpercent = percent Undershoot
%      - Volumetric_Error = volumetric targeting error in cc
%      - prostate_volume = volume of the prostate in cc
%      - target_volume = volume of the target in cc
%      - DSCvol = Dice Similarity Coefficient using volume
%      - DSCarea = Dice Similarity Coefficient using area
%      - 1D error statistics = Mean, std, min and max of the 1D shortest
%      distance error
%==========================================================================

if (size(isothermRadius,2) ~= size(targetBoundary,2))
    fprintf(1,'\n\nERROR: lesion and bound must be same size\n\n');
    return;
end

%==========================================================================
% --- Initialize Variables --- 
%==========================================================================
error_allSlices = []; %1D error, all slices combined
error_eachSlice(size(isothermRadius,2)).data = []; %1D error, for each slice, and initially assign a value of zero
StepAngleRad = deg2rad(abs(treatedSector(1) - treatedSector(2))); %Size of a sector in radians

MinTRMask = targetBoundary >= MinTR; %2D Matrix of size (numAngles x numSlices)
MaxTRMask = targetBoundary > MaxTR; %2D Matrix of size (numAngles x numSlices)

isothermRadiusMinTR = isothermRadius.*MinTRMask;
targetBoundaryMinTR = targetBoundary.*MinTRMask;
targetBoundaryMaxTR = targetBoundaryMinTR;
targetBoundaryMaxTR(MaxTRMask) = MaxTR;

distanceIsothermTarget = isothermRadiusMinTR-targetBoundaryMinTR;

%==========================================================================
% --- Compute general statistics --- 
%==========================================================================
%%%%%%%%%%%%%%%%%%%%%%%%%%
% Surfaces
%%%%%%%%%%%%%%%%%%%%%%%%%%
% Formula to compute area of a sector given by radius^2*(thetaRAD/2)
totalProstateArea   = sum(prostateBoundary(:,logical(isUAactive)).^2*StepAngleRad/2);
isothermArea        = sum(isothermRadiusMinTR.^2*StepAngleRad/2);
targetArea          = sum(targetBoundaryMinTR.^2*StepAngleRad/2);
targetAreaMaxTR     = sum(targetBoundaryMaxTR.^2*StepAngleRad/2);
treatedTargetArea   = sum(prostateBoundary.^2*StepAngleRad/2);

%Overtreated sectors are the small surfaces between the isotherm and the targetboundary + tolerance
overTreatedSectors =  (isothermRadiusMinTR.^2 - (targetBoundaryMinTR+tol).^2)*StepAngleRad/2;
%Undertreated sectors are the small surfaces between the targetboundary + tolerance and the isotherm
underTreatmentSectors = ((targetBoundaryMinTR-tol).^2 - isothermRadiusMinTR.^2)*StepAngleRad/2;
underTreatmentSectorsExcludingMaxTR = underTreatmentSectors.*~MaxTRMask;

%Overlap area is used for DSC
isothermTargetOverlapArea = sum(min(isothermRadiusMinTR,targetBoundaryMinTR).^2*StepAngleRad/2);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Volumes in mm3
%%%%%%%%%%%%%%%%%%%%%%%%%%
prostateVolume =  SliceThickness*sum(totalProstateArea);
isothermVolume =  SliceThickness*sum(isothermArea);
targetVolume =   SliceThickness*sum(targetArea);
targetVolumeMaxTR = SliceThickness*sum(targetAreaMaxTR);

% Overtreatment volume is the sum of each overtreated sectors where distanceIsothermTarget greater than tol  
overTreatmentPerSlice = sum(overTreatedSectors.*(distanceIsothermTarget > tol)); % in mm^3
overTreatmentVolume = SliceThickness*overTreatmentPerSlice;

% Undertreatment volume is the sum of each undertreated sectors where distanceIsothermTarget lower than tol    
underTreatmentPerSlice = sum(underTreatmentSectors.*(distanceIsothermTarget < -tol)); % in mm^3
underTreatmentVolume = SliceThickness*underTreatmentPerSlice;

underTreatmentPerSliceExcludingMaxTR = sum(underTreatmentSectorsExcludingMaxTR.*(distanceIsothermTarget < -tol)); % in mm^3
underTreatmentVolumeExcludingMaxTR = SliceThickness*underTreatmentPerSliceExcludingMaxTR;

%==========================================================================
% --- Loop over all slices --- 
%==========================================================================
for sliceIdx = 1:size(isothermRadius,2) %for each slice
    if (isUAactive(sliceIdx) == 1) %calculate error for active elements only, and disregard elements that aren't active
        for j = 1:size(isothermRadius,1) %evaluate statistics at every angle
            if (targetBoundary(j,sliceIdx) >= MinTR)
                delta_T = isothermRadius(j,sliceIdx)-targetBoundary(j,sliceIdx);
                
                %%%%%%%%%%%%%%%%%%
                %   1D Accuracy  %
                %%%%%%%%%%%%%%%%%%
                [isothermRadiusX, isothermRadiusY] = pol2cart(deg2rad(treatedSector'),isothermRadius(:,sliceIdx)); %Convert isotherm radius to Cartesian coordinates
                [targetBoundaryX, targetBoundaryY] = pol2cart(deg2rad(treatedSector'),targetBoundary(:,sliceIdx)); %convert target radius to Cartesian coordinates
                if delta_T < 0 %Undertreatment, mindist(target_point to lesion_polynomial)
                    error = -1*distancePointPolyline([targetBoundaryX(j), targetBoundaryY(j)],[isothermRadiusX, isothermRadiusY]);
                    error_eachSlice(sliceIdx).data = [error_eachSlice(sliceIdx).data, error];
                    error_allSlices = [error_allSlices, error];
                else %Overtreatment, mindist(siotherm_point to bound_polynomial)
                    error = distancePointPolyline([isothermRadiusX(j), isothermRadiusY(j)],[targetBoundaryX, targetBoundaryY]);
                    error_eachSlice(sliceIdx).data = [error_eachSlice(sliceIdx).data, error];
                    error_allSlices = [error_allSlices, error];
                end
            end
        end
    end
end

errorStatistics.OSVolumePercent = sum(overTreatmentVolume./sum(targetVolume))*100;
errorStatistics.overTreatmentPerSlicePercent = overTreatmentPerSlice./targetArea*100;
errorStatistics.USVolumePercent = sum(underTreatmentVolume./sum(targetVolume))*100;
errorStatistics.underTreatmentPerSlicePercent = underTreatmentPerSlice./targetArea*100;
errorStatistics.USVolumeExcludingMaxTRPercent = sum(underTreatmentVolumeExcludingMaxTR./sum(targetVolumeMaxTR))*100;
errorStatistics.underTreatmentPerSliceExcludingMaxTRPercent = underTreatmentPerSliceExcludingMaxTR./targetAreaMaxTR*100;
errorStatistics.Volumetric_Error = (sum(overTreatmentVolume) + sum(underTreatmentVolume))/1000; %in cm^3
errorStatistics.target_volume = targetVolume/1000; %in cm^3
errorStatistics.target_volumeMaxTR = targetVolumeMaxTR/1000; %in cm^3
errorStatistics.prostate_volume = prostateVolume/1000; %in cm^3
errorStatistics.DSCvol = 2*sum(isothermTargetOverlapArea)/(sum(isothermArea)+sum(targetArea));
errorStatistics.DSCarea = 2*isothermTargetOverlapArea./(targetArea+isothermArea);
errorStatistics.error1D_allSlices = error_allSlices;
errorStatistics.error1D_eachSlice = error_eachSlice;

return;