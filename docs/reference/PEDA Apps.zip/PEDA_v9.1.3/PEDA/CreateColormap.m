function cmap = CreateColormap(type, approchingBoilingTemperatureThreshold)
if strcmpi(type,'TUV')
    %% See TDC code in \TDC\Console\Infrastructure\Thermometry\TUVImageGenerator.cs
    %============================
    % Variable initialization
    %============================
    % Since we need to have a color gradient, we need to oversample the colormap
    cmapSize = 600;
    
    MinimumTemperatureUncertainty = 1;
    Threshold3 = cmapSize;
    Threshold2 = 2/3*cmapSize  + 1;
    Threshold1 = 1/3*cmapSize  + 1 ;
    
    cmap = zeros(3,cmapSize);
    red = zeros(1,cmapSize);
    green = zeros(1,cmapSize);
    blue = zeros(1,cmapSize);
    
    %============================
    % Build colormap
    %============================
    red(MinimumTemperatureUncertainty:Threshold1-1) = 0;
    blue(MinimumTemperatureUncertainty:Threshold1-1) = 255;
    green(MinimumTemperatureUncertainty:Threshold1-1) = linspace(0,255,(Threshold1-MinimumTemperatureUncertainty));
    
    red(Threshold1:Threshold2-1) = 255;
    green(Threshold1:Threshold2-1) = linspace(255,0,(Threshold2-Threshold1));
    blue(Threshold1:Threshold2-1) = 0;
    
    red(Threshold2:Threshold3) = 128;
    green(Threshold2:Threshold3) = 64;
    blue(Threshold2:Threshold3) = 128;
    
    cmap = [red; green; blue]'./255;
elseif strcmpi(type,'TMap')
    if nargin == 1
        approchingBoilingTemperatureThreshold = 90; %Assuming 90�C as default value
    end
    %% See TDC code in \TDC\Console\Infrastructure\Thermometry\TemperatureMapColourPalette.cs
    %============================
    % Variable initialization
    %============================
    ColdTemperatureThreshold = 20;
    MinTargetTemperature = 52;
    MaxTargetTemperature = 55;
    boilingTemperature = 100;
    
    % Matrices
    cmap = zeros(3,100);
    red = zeros(1,100);
    green = zeros(1,100);
    blue = zeros(1,100);
    
    %============================
    % Build colormap
    %============================
    red(1:MaxTargetTemperature-1) = hex2dec('00'); %0x00
    red(MaxTargetTemperature:approchingBoilingTemperatureThreshold-1) = hex2dec('FF'); %0XFF
    red(approchingBoilingTemperatureThreshold:boilingTemperature-1) = hex2dec('7F'); %0x7F
    red(boilingTemperature) = hex2dec('59'); %0X59
    
    green(1:ColdTemperatureThreshold-1) = 0;
    green(ColdTemperatureThreshold:MinTargetTemperature-1) = 255.*linspace(0,(MinTargetTemperature-1-ColdTemperatureThreshold)/(MinTargetTemperature - ColdTemperatureThreshold),(MinTargetTemperature - ColdTemperatureThreshold));
    green(MinTargetTemperature:MaxTargetTemperature-1) = hex2dec('BF'); %0xBF
    green(MaxTargetTemperature:approchingBoilingTemperatureThreshold-1) = 255.*linspace((approchingBoilingTemperatureThreshold-MaxTargetTemperature)/(approchingBoilingTemperatureThreshold - MaxTargetTemperature),0,(approchingBoilingTemperatureThreshold-MaxTargetTemperature));
    green(approchingBoilingTemperatureThreshold:boilingTemperature) = hex2dec('3F'); %0x3F
    
    blue(1:MinTargetTemperature-1) = hex2dec('FF'); %0xFF
    blue(MinTargetTemperature:approchingBoilingTemperatureThreshold-1) = hex2dec('00'); %0X00
    blue(approchingBoilingTemperatureThreshold:boilingTemperature-1) = hex2dec('7F'); %0x7F
    blue(boilingTemperature) = hex2dec('59'); %0x59
    
    cmap = [red; green; blue]';
    cmap = cmap(ColdTemperatureThreshold:end,:)/255;

elseif strcmpi(type,'TDose')
    %============================
    % Variable initialization
    %============================
    % Since we need to have a color gradient, we need to oversample the colormap
    cmapSize = 1020/4;
    
    Threshold1 = 240/4;
    Threshold2 = 1000/4;
        
    cmap = zeros(3,cmapSize);
    red = zeros(1,cmapSize);
    green = zeros(1,cmapSize);
    blue = zeros(1,cmapSize);
    
    %============================
    % Build colormap
    %============================
    red(1:Threshold1) = 0;
    green(1:Threshold1) = 0.5;
    blue(1:Threshold1) = 1;
    
    red(Threshold1+1:Threshold2) = 0;
    green(Threshold1+1:Threshold2) = 0.85;
    blue(Threshold1+1:Threshold2) = 0;
    
    red(Threshold2+1:end) = 1;
    green(Threshold2+1:end) = 1;
    blue(Threshold2+1:end) = 0;
    
    cmap = [red; green; blue]';
    
elseif strcmpi(type,'TDoseLog')
    %============================
    % Variable initialization
    %============================
    cmapSize = 260;
    lowDose = 1; % 1
    lethalDoseLow = 41; 
    lethalDoseHigh = 71;
    CEVisibleDoseLow = 151;
    CEVisibleDoseHigh = 261;
    
    % Matrices
    cmap = zeros(3,cmapSize);
    red = zeros(1,cmapSize);
    green = zeros(1,cmapSize);
    blue = zeros(1,cmapSize);
    
    %============================
    % Build colormap
    %============================
    % Gradient from blue to green
    red(1:lethalDoseLow-1) = 0; 
    green(1:lethalDoseLow-1) = 125.*linspace(0,(lethalDoseLow-1-lowDose)/(lethalDoseLow - lowDose),(lethalDoseLow - lowDose));
    blue(1:lethalDoseLow-1) = 255; 
    
    % Green
    red(lethalDoseLow:lethalDoseHigh-1) = 0;
    green(lethalDoseLow:lethalDoseHigh-1) = 216;
    blue(lethalDoseLow:lethalDoseHigh-1) = 0;
    
    % Gradient from green to purple
    red(lethalDoseHigh:CEVisibleDoseLow-1) = 255; 
    green(lethalDoseHigh:CEVisibleDoseLow-1) = 255.*linspace((CEVisibleDoseLow-lethalDoseHigh)/(CEVisibleDoseLow - lethalDoseHigh),0,(CEVisibleDoseLow-lethalDoseHigh));
    blue(lethalDoseHigh:CEVisibleDoseLow-1) = 0; 
    
    % Purple
    red(CEVisibleDoseLow:CEVisibleDoseHigh) = 50; 
    green(CEVisibleDoseLow:CEVisibleDoseHigh) = 50;
    blue(CEVisibleDoseLow:CEVisibleDoseHigh) = 50; 
        
    cmap = [red; green; blue]';
    cmap = cmap(lowDose:end,:)/255;
else
    error('Unrecognized colormap type. Allowed values are ''TUV'' and ''TMap''. You''ve entered %s',type)
end
