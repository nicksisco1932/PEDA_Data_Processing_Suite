function TxParameters = CombineTreatmentSegments(pathPEDA)
load(fullfile(pathPEDA,'SxParameters.mat'));
numberOfSegments = size(SxParameters,2);

% Concatenate the different matrices
for segmentIdx = 1:numberOfSegments
    dux = [SxParameters(segmentIdx).ux(end,:)] - SxParameters(1).ux(end,:);
    duy = [SxParameters(segmentIdx).uy(end,:)] - SxParameters(1).uy(end,:);
    
    load(fullfile(SxParameters(segmentIdx).pathData,'TDose.mat'));
    load(fullfile(SxParameters(segmentIdx).pathData,'TDoseMasked.mat'))
    load(fullfile(SxParameters(segmentIdx).pathData,'TMax.mat'))
    load(fullfile(SxParameters(segmentIdx).pathData,'TMaxMasked.mat'))
    load(fullfile(SxParameters(segmentIdx).pathData,'Masks','Mask.mat'))
    
    if segmentIdx == 1
        TDose_Tx(:,:,:,segmentIdx) = TDose;
        TDoseMasked_Tx(:,:,:,segmentIdx) = TDoseMasked;
        TMax_Tx(:,:,:,segmentIdx) = TMax;
        TMaxMasked_Tx(:,:,:,segmentIdx) = TMaxMasked;
        Mask_Tx(:,:,:,segmentIdx) = Mask(:,:,:,end-1); %can probably get rid of the -1 if Mask has been fixed
    else % map TMax/TDose to last UA center location from Segment 1
        % TS-137
        for sliceNo = 1:SxParameters(segmentIdx).NumberSlices
            numShiftsX = 0;
            numShiftsY = 0;
            if abs(dux(sliceNo)) > 0.5
                numShiftsX = -round(dux(sliceNo));
            end
            if abs(duy(sliceNo)) > 0.5
                numShiftsY = -round(duy(sliceNo));
            end
            TDose_Tx(:,:,sliceNo,segmentIdx) = circshift(circshift(TDose(:,:,sliceNo),numShiftsY,1),numShiftsX,2);
            TDoseMasked_Tx(:,:,sliceNo,segmentIdx) = circshift(circshift(TDoseMasked(:,:,sliceNo),numShiftsY,1),numShiftsX,2);
            TMax_Tx(:,:,sliceNo,segmentIdx) = circshift(circshift(TMax(:,:,sliceNo),numShiftsY,1),numShiftsX,2);
            TMaxMasked_Tx(:,:,sliceNo,segmentIdx) = circshift(circshift(TMaxMasked(:,:,sliceNo),numShiftsY,1),numShiftsX,2);
            Mask_Tx(:,:,sliceNo,segmentIdx) = circshift(circshift(Mask(:,:,sliceNo,end-1),numShiftsY,1),numShiftsX,2);
        end
    end
end

TDose_Tx(:,:,:,segmentIdx+1) = sum(TDose_Tx,4);
TMax_Tx(:,:,:,segmentIdx+1) = max(TMax_Tx,[],4);

TDoseMasked_Tx(:,:,:,segmentIdx+1) = sum(TDoseMasked_Tx,4);
TMaxMasked_Tx(:,:,:,segmentIdx+1) = max(TMaxMasked_Tx,[],4);

clear TDose
clear TDoseMasked
clear TMax
clear TMaxMasked
clear Mask

% We only want to keep pixels that have been masked in all segments
Mask = Mask_Tx(:,:,:,1);
if numberOfSegments > 1
    for segmentIdx = 2:numberOfSegments
        Mask = Mask | Mask_Tx(:,:,:,segmentIdx);
    end
end

TDose = TDose_Tx(:,:,:,segmentIdx+1);
TDoseMasked = TDoseMasked_Tx(:,:,:,segmentIdx+1);
TMax = TMax_Tx(:,:,:,segmentIdx+1);
TMaxMasked = TMaxMasked_Tx(:,:,:,segmentIdx+1);

save(fullfile(pathPEDA,'TDose.mat'),'TDose');
save(fullfile(pathPEDA,'TDoseMasked.mat'),'TDoseMasked');
save(fullfile(pathPEDA,'TMax.mat'),'TMax');
save(fullfile(pathPEDA,'TMaxMasked.mat'),'TMaxMasked');
save(fullfile(pathPEDA,'Mask.mat'),'Mask');

% Build the Tx structure
TxParameters.pathPEDA = SxParameters(1).pathPEDA;
TxParameters.PatientID = SxParameters(1).PatientID;
TxParameters.SliceThickness = SxParameters(1).SliceThickness;
TxParameters.ImageResolution = SxParameters(1).ImageResolution;
TxParameters.FOV = SxParameters(1).FOV;
TxParameters.NumberSlices = SxParameters(1).NumberSlices;
TxParameters.NumberOfRows = SxParameters(1).NumberOfRows;
TxParameters.NumberOfCols = SxParameters(1).NumberOfCols;
TxParameters.MRCenterFrequency = SxParameters(1).MRCenterFrequency;
TxParameters.NumRefImages = SxParameters(1).NumRefImages;
TxParameters.Tc = SxParameters(1).Tc;
TxParameters.SoftwareVersion = SxParameters(1).SoftwareVersion;
TxParameters.InitialRotationDirection = SxParameters(1).InitialRotationDirection;
TxParameters.PixelSize = SxParameters(1).PixelSize;
TxParameters.ThermalDoseThreshold = SxParameters(1).ThermalDoseThreshold;
TxParameters.ThermalDoseCEM = SxParameters(1).ThermalDoseCEM;
TxParameters.MinimumTreatmentRadius = SxParameters(1).MinimumTreatmentRadius;
TxParameters.MinimumTreatmentRadiusMM = SxParameters(1).MinimumTreatmentRadiusMM;
TxParameters.MaximumTreatmentRadiusMM = 28;
TxParameters.MaximumTreatmentRadius = SxParameters(1).MaximumTreatmentRadiusMM/SxParameters(1).PixelSize;
TxParameters.UARadius = SxParameters(1).UARadius;
TxParameters.UARadiusMM = SxParameters(1).UARadiusMM;
TxParameters.UA.LowFrequency = SxParameters(1).UA.LowFrequency;
TxParameters.UA.HighFrequency = SxParameters(1).UA.HighFrequency;
TxParameters.UA.BeamAlign = SxParameters(1).UA.BeamAlign;
TxParameters.ProstateBoundaryTheta = SxParameters(1).ProstateBoundaryTheta;
TxParameters.ControlBoundaryTheta = SxParameters(1).ControlBoundaryTheta;
TxParameters.StabilityThreshold = SxParameters(1).StabilityThreshold;
TxParameters.TUVThreshold = SxParameters(1).TUVThreshold;
TxParameters.ApproachingBoilingThreshold = min(arrayfun(@(x) min(x.ApproachingBoilingThreshold), SxParameters));
TxParameters.ImageNumber = 1; % Used to generate the masks
TxParameters.NumberOfSegments = numberOfSegments;

for segmentIdx = 1:numberOfSegments
    if segmentIdx == 1
        TxThermAngle = SxParameters(segmentIdx).ThermAngle;
        RotationDirection = SxParameters(segmentIdx).RotationDirection;
        isUAactive = SxParameters(segmentIdx).isUAactive;
        % TS-203
        TxParameters.ux = SxParameters(segmentIdx).ux(end,:);
        TxParameters.uy = SxParameters(segmentIdx).uy(end,:);
    else
        TxThermAngle = cat(1, TxThermAngle, SxParameters(segmentIdx).ThermAngle);
        RotationDirection = cat(1, RotationDirection, SxParameters(segmentIdx).RotationDirection);
        isUAactive = cat(1, isUAactive, SxParameters(segmentIdx).isUAactive);
    end
end

TxParameters.ThermAngle = TxThermAngle;
TxParameters.UnwoundThermAngle = UnwindAngle(TxThermAngle);
TxParameters.RotationDirection = RotationDirection;
TxParameters.isUAactive = any(isUAactive);

[outputTimes, outputIndices, CumulativeTreatedSector] = CalculateTreatmentTimeStatistics(SxParameters);

% Combine the Thermal Boost Info per treatent angle
if isfield(SxParameters(1),'ThermalBoostInfo')
    tempStruct = cat(2,SxParameters.ThermalBoostInfo);
    TxParameters.ThermalBoostInfo.ElapsedTime_sec = sum([tempStruct.ElapsedTime_sec]);
    TxParameters.ThermalBoostInfo.TreatmentState = zeros(360, 12);
    TxParameters.ThermalBoostInfo.ControlBoundaryMM = ones(360, 12)*TxParameters.MinimumTreatmentRadiusMM;
    allControlBoundaryMM = cat(3,tempStruct.ControlBoundaryMM);
    allTreatmentState = cat(3,tempStruct.TreatmentState);

    % Use the same logic as before.  Takes the largest treated boundary with its associated treatment state
    for sliceIdx = 1:TxParameters.NumberSlices
        if TxParameters.isUAactive(sliceIdx)
            for angleIdx = 1:360
                currentControlBoundaryMM = squeeze(allControlBoundaryMM(angleIdx,sliceIdx,:));
                currentStates = squeeze(allTreatmentState(angleIdx,sliceIdx,:));
                % Apply ranking
                [~, rankIdx] = sortrows([currentControlBoundaryMM currentStates], [1 2], 'descend');
                TxParameters.ThermalBoostInfo.TreatmentState(angleIdx,sliceIdx) = currentStates(rankIdx(1));
                TxParameters.ThermalBoostInfo.ControlBoundaryMM(angleIdx,sliceIdx) = currentControlBoundaryMM(rankIdx(1));
            end
        end
    end
end

TxParameters.TreatedSector = CumulativeTreatedSector;
TxParameters.TreatmentTimeMIN.FirstPass = outputTimes.FirstPass;
TxParameters.TreatmentTimeMIN.TreatedAgain = outputTimes.TreatedAgain;
TxParameters.TreatmentTimeMIN.NotTreating = outputTimes.NotTreating;
TxParameters.Cumulative.TimeSEC = outputIndices.Time;
TxParameters.Cumulative.AngleDEG = outputIndices.Angle;
TxParameters.Cumulative.FirstPass = outputIndices.FirstPass;
TxParameters.Cumulative.TreatedAgain = outputIndices.TreatedAgain;
TxParameters.Cumulative.NotTreating = outputIndices.NotTreating;

[TxProstateBoundary, TxControlBoundary,TxParameters.ProstateBoundaryXY, TxParameters.ControlBoundaryXY] = CombineBoundaries(SxParameters);

TxParameters.ControlBoundary = TxControlBoundary;
TxParameters.ControlBoundaryMM = TxControlBoundary.*TxParameters.PixelSize;
TxParameters.ProstateBoundary = TxProstateBoundary;
TxParameters.ProstateBoundaryMM = TxProstateBoundary.*TxParameters.PixelSize;
TxParameters.Combined = [];

TxParameters.pathData = pathPEDA;

TxParameters.ProstateMask = CreateSingleBoundaryMask(TxParameters, TxParameters.ProstateBoundary);

save(fullfile(pathPEDA,'TxParameters.mat'),'TxParameters')
    
