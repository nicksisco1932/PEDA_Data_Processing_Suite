function OutputStatistics(Parameters,segmentIdx)
%==========================================================================
% Inputs:
%      - Parameters
% Outputs:
%      - PEDA_Output.txt
%==========================================================================
global PEDA_VERSION

%==========================================================================
% ----- Variable initialization -----
%==========================================================================
if nargin > 1 %This is a segment
    SegmentStatistics = 1;
    SxParameters = Parameters;
    fileFID = fopen(fullfile(Parameters.pathData,sprintf('PEDA_Output_S%d.txt',segmentIdx)),'wt');
else %This is the treatment
    SegmentStatistics = 0;
    load(fullfile(Parameters.pathPEDA,'SxParameters'));
    fileFID = fopen(fullfile(Parameters.pathPEDA,'PEDA_Output.txt'),'wt');
end

% if there are multiple subsegments, use the combined subsegment boundaries
if ~isempty(Parameters.Combined)
   Parameters.ControlBoundaryMM  = Parameters.Combined.ControlBoundaryMM;
end

load(fullfile(Parameters.pathData,'isotherms'));

if ~fileFID
    error( 'Error creating file to write PEDA summary' );
end


%==========================================================================
% ----- Write statistics to file -----
%==========================================================================
% Header
c = clock();
fprintf(fileFID, 'Profound Medical Inc.\n' );
fprintf(fileFID, 'Executed on Matlab %s, %s \n',version,datetime);
fprintf(fileFID, 'PEDA Version %s - TDC Version %s\n',PEDA_VERSION,Parameters.SoftwareVersion);
fprintf(fileFID, 'Used TMaxMasked.mat and TDoseMasked.mat \n' );
fprintf(fileFID, 'Script Run on %s at %02d:%02d\n', date(), c(4),c(5) );
fprintf(fileFID, '\n' );
fprintf(fileFID, '*************  DISCLAIMER ********************************\n');
fprintf(fileFID, 'Treatment statistics outputted by PEDA do not reflect outcomes represented in product requirement RQ_FUNC_4 in DOC-10242 under the following conditions:\n' );
fprintf(fileFID, ' 1. Cases when the thermometry images are corrupted, for example due to motion, RF interference, or any other imaging artifacts inside or near the prostate boundary\n' );
fprintf(fileFID, ' 2. Modifying target boundaries during or in between treatment segments\n' );
fprintf(fileFID, ' 3. Moving the PS linear axis between segments (i.e. the scan volumes between segments aligns with different anatomy)\n' );
fprintf(fileFID, ' 4. Enabling and/or disabling Thermal Boost\n' );
fprintf(fileFID, ' 5. Treatments that are not whole gland\n' );
fprintf(fileFID, '\n' );

%==========================================================================
%----- Treatment statistics -----
%==========================================================================
totalAngularCoverage = 0;
totalAngularExtent = 0;
TotalTreatmentTime = []; TotalThermAngle = [];

possibleDirections = {'Clockwise';'Counterclockwise'};

if ~SegmentStatistics
fprintf(fileFID, '*************  Treatment Statistics  ********************************\n');
end

for SegmentIdx = 1:size(SxParameters,2)
    % Cumulative treatment time and ThermAngle
    if SegmentIdx == 1
        TotalTreatmentTime = [TotalTreatmentTime;SxParameters(SegmentIdx).ImageTime];
    else
        TotalTreatmentTime = [TotalTreatmentTime;SxParameters(SegmentIdx).ImageTime + TotalTreatmentTime(end)];
    end
    TotalThermAngle = [TotalThermAngle;SxParameters(SegmentIdx).ThermAngle];
    
    SegmentDuration(SegmentIdx) = SxParameters(SegmentIdx).ImageTime(end);
    SegmentUnwoundAngle = SxParameters(SegmentIdx).UnwoundThermAngle;
        
    % The intent below is to calculate angular coverage for both CW and CCW
    InitialRotationDirection = SxParameters(SegmentIdx).InitialRotationDirection;
    OppositeRotationDirection = possibleDirections{~strcmp(InitialRotationDirection,possibleDirections)};
    changesInDirection = strcmp(SxParameters(SegmentIdx).RotationDirection,SxParameters(SegmentIdx).InitialRotationDirection);
    angularCoverageGoingInitialDirection = sum(abs(diff(SegmentUnwoundAngle(changesInDirection))));
    angularCoverageGoingOppositeInitialDirection = sum(abs(diff(SegmentUnwoundAngle(~changesInDirection))));
    if isempty(angularCoverageGoingOppositeInitialDirection)
        angularCoverageGoingOppositeInitialDirection = '0';
    end
    angularCoverage(SegmentIdx) = sum(abs(diff(SxParameters(SegmentIdx).UnwoundThermAngle)));
    angularExtent(SegmentIdx) = abs(max(SxParameters(SegmentIdx).UnwoundThermAngle)-min(SxParameters(SegmentIdx).UnwoundThermAngle));
    totalAngularCoverage = totalAngularCoverage + angularCoverage(SegmentIdx);
    totalAngularExtent = totalAngularExtent + angularExtent(SegmentIdx);
    patientTemperature(SegmentIdx) = SxParameters(SegmentIdx).Tb;
    
    fprintf(fileFID, '---- SEGMENT %d\n',SegmentIdx);
    fprintf(fileFID, 'Segment time [minutes]: %.1f\n',SegmentDuration(SegmentIdx)/60);
    fprintf(fileFID, 'Angular extent [�]: %.1f\n',angularExtent(SegmentIdx));
    fprintf(fileFID, 'Angular coverage [�]: %.1f ',angularCoverage(SegmentIdx));
    fprintf(fileFID, '(%s: %.1f� - %s: %.1f�)\n',InitialRotationDirection,angularCoverageGoingInitialDirection,OppositeRotationDirection,angularCoverageGoingOppositeInitialDirection);
    fprintf(fileFID, 'Patient temperature [�C]: %.3f\n',patientTemperature(SegmentIdx));   
    fprintf(fileFID, '\n');
end

if ~SegmentStatistics
    TotalUnwoundThermAngle = UnwindAngle(TotalThermAngle);
    TotalUnwoundThermAngle = abs(TotalUnwoundThermAngle - TotalUnwoundThermAngle(1));
    if max(TotalUnwoundThermAngle) >= 360
        [~,first360Index] = min(abs(TotalUnwoundThermAngle - 360));
        treatmentTime360 = round(TotalTreatmentTime(first360Index))/60;
    else
        treatmentTime360 = NaN;
    end
    
    fprintf(fileFID, '---- OVERALL\n');
    fprintf(fileFID, 'Total treatment time [minutes]: %.1f ',sum(SegmentDuration)/60);
    fprintf(fileFID, '(360� reached after %.0f min)\n',treatmentTime360);
    fprintf(fileFID, 'Total angular extent of treatment [�]: %.1f\n',totalAngularExtent);
    fprintf(fileFID, 'Total angular coverage [�]: %.1f\n',totalAngularCoverage);
    fprintf(fileFID, '\n' );
    
end
%==========================================================================
%----- Volumetric error statistics -----
%==========================================================================
fprintf(fileFID, '*************  Volumetric Error Statistics  ********************************\tCONTROL ISOTHERM-CONTROL BOUNDARY\t240 CEM43-PROSTATE BOUNDARY\t55�C-PROSTATE BOUNDARY\n');
fprintf(fileFID, 'Contoured Prostate Volume [cm^3]\t%.1f\t%.1f\t%.1f\n',                        accuracy_result_0mm.prostate_volume, accuracy_result_0mm_tdose.prostate_volume, accuracy_result_0mm_prostate.prostate_volume  );
fprintf(fileFID, 'Total Target Volume [cm^3]\t%.1f\t%.1f\t%.1f\n',                              accuracy_result_0mm.target_volume, accuracy_result_0mm_tdose.target_volume, accuracy_result_0mm_prostate.target_volume );
fprintf(fileFID, 'Total Target Volume_%.0fmm [cm^3]\t%.1f\t%.1f\t%.1f\n',                       Parameters.MaximumTreatmentRadiusMM, accuracy_result_0mm.target_volumeMaxTR, accuracy_result_0mm_tdose.target_volumeMaxTR,accuracy_result_0mm_prostate.target_volumeMaxTR);
fprintf(fileFID, 'Percent Overshoot Volume [%%]\t%.1f\t%.1f\t%.1f\n',                           accuracy_result_0mm.OSVolumePercent, accuracy_result_0mm_tdose.OSVolumePercent, accuracy_result_0mm_prostate.OSVolumePercent );
fprintf(fileFID, 'Percent Undershoot Volume [%%]\t%.1f\t%.1f\t%.1f\n',                          accuracy_result_0mm.USVolumePercent, accuracy_result_0mm_tdose.USVolumePercent, accuracy_result_0mm_prostate.USVolumePercent );
fprintf(fileFID, 'Percent Undershoot Volume_%.0fmm [%%]\t%.1f\t%.1f\t%.1f\n',                   Parameters.MaximumTreatmentRadiusMM, accuracy_result_0mm.USVolumeExcludingMaxTRPercent, accuracy_result_0mm_tdose.USVolumeExcludingMaxTRPercent, accuracy_result_0mm_prostate.USVolumeExcludingMaxTRPercent );
fprintf(fileFID, 'Absolute Volumetric Error [cm^3]\t%.1f\t%.1f\t%.1f\n',                        accuracy_result_0mm.Volumetric_Error, accuracy_result_0mm_tdose.Volumetric_Error, accuracy_result_0mm_prostate.Volumetric_Error );
fprintf(fileFID, 'Percent Overshoot Volume - 1mm margin [%%]\t%.1f\t%.1f\t%.1f\n',              accuracy_result_1mm.OSVolumePercent, accuracy_result_1mm_tdose.OSVolumePercent, accuracy_result_1mm_prostate.OSVolumePercent );
fprintf(fileFID, 'Percent Undershoot Volume - 1mm margin [%%]\t%.1f\t%.1f\t%.1f\n',             accuracy_result_1mm.USVolumePercent, accuracy_result_1mm_tdose.USVolumePercent, accuracy_result_1mm_prostate.USVolumePercent );
fprintf(fileFID, 'Percent Undershoot Volume_%.0fmm - 1mm margin [%%]\t%.1f\t%.1f\t%.1f\n',      Parameters.MaximumTreatmentRadiusMM, accuracy_result_1mm.USVolumeExcludingMaxTRPercent, accuracy_result_1mm_tdose.USVolumeExcludingMaxTRPercent, accuracy_result_1mm_prostate.USVolumeExcludingMaxTRPercent  );
fprintf(fileFID, 'Absolute Volumetric Error Volume - 1mm margin [cm^3]\t%.1f\t%.1f\t%.1f\n',    accuracy_result_1mm.Volumetric_Error, accuracy_result_1mm_tdose.Volumetric_Error, accuracy_result_1mm_prostate.Volumetric_Error  );
fprintf(fileFID, '\n' );

%==========================================================================
%----- DSC statistics -----
%==========================================================================
fprintf(fileFID, '**************  DSC Statistics  *******************************************\tCONTROL ISOTHERM-CONTROL BOUNDARY\t240 CEM43-PROSTATE BOUNDARY\t55�C-PROSTATE BOUNDARY\n');
fprintf(fileFID, 'DSC Volume \t%.2f\t%.2f\t%.2f\n', accuracy_result_0mm.DSCvol, accuracy_result_0mm_tdose.DSCvol, accuracy_result_0mm_prostate.DSCvol );

for sliceIdx = 1:length(Parameters.isUAactive)
    if( Parameters.isUAactive(sliceIdx) == 1 )
        fprintf(fileFID, 'DSC Area Element %i \t%.2f\t%.2f\t%.2f\n',sliceIdx-1, accuracy_result_0mm.DSCarea(sliceIdx), accuracy_result_0mm_tdose.DSCarea(sliceIdx), accuracy_result_0mm_prostate.DSCarea(sliceIdx) );
    end
end


%==========================================================================
%----- Signed error statistics -----
%==========================================================================
fprintf(fileFID, '\n' );
fprintf(fileFID, '***********  1D Targeting Statistics  *************\tCONTROL ISOTHERM-CONTROL BOUNDARY\t\t\t\t\t240 CEM43-PROSTATE BOUNDARY\t\t\t\t\t55�C-PROSTATE BOUNDARY\n');
fprintf(fileFID, '\tMean\tStd.Dev.\tMinimum\tMaximum\t\tMean\tStd.Dev.\tMinimum\tMaximum\t\tMean\tStd.Dev.\tMinimum\tMaximum\n' );

for sliceIdx = 1:length(Parameters.isUAactive)
    if( Parameters.isUAactive(sliceIdx) == 1 )
        data = accuracy_result_0mm.error1D_eachSlice(sliceIdx).data;
        data_tdose= accuracy_result_0mm_tdose.error1D_eachSlice(sliceIdx).data;
        data_prostate= accuracy_result_0mm_prostate.error1D_eachSlice(sliceIdx).data;
        fprintf(fileFID, 'Element %i -- Signed Targeting Error [mm]\t%.1f\t%.1f\t%.1f\t%.1f\t\t%.1f\t%.1f\t%.1f\t%.1f\t\t%.1f\t%.1f\t%.1f\t%.1f\n', sliceIdx-1, mean(data),std(data),min(data),max(data), mean(data_tdose),std(data_tdose),min(data_tdose),max(data_tdose), mean(data_prostate),std(data_prostate),min(data_prostate),max(data_prostate) );
    end
end
data = accuracy_result_0mm.error1D_allSlices;
data_tdose= accuracy_result_0mm_tdose.error1D_allSlices;
data_prostate= accuracy_result_0mm_tdose.error1D_allSlices;
fprintf(fileFID, '1D - Total Targeting Error [mm]\t%.1f\t%.1f\t%.1f\t%.1f\t\t%.1f\t%.1f\t%.1f\t%.1f\t\t%.1f\t%.1f\t%.1f\t%.1f\n', mean(data),std(data),min(data),max(data), mean(data_tdose),std(data_tdose),min(data_tdose),max(data_tdose), mean(data_prostate),std(data_prostate),min(data_prostate),max(data_prostate) );

%==========================================================================
%----- Radial extent of treatment statistics -----
%==========================================================================
fprintf(fileFID, '\n' );
fprintf(fileFID, '***********  Max Treatment Radius  *************\n');
fprintf(fileFID, 'Max radius\tControl\tTreatment\n' );

max_r = max(isothermRadius);

for sliceIdx = 1:length(Parameters.isUAactive)
    if( Parameters.isUAactive(sliceIdx) == 1 )
        ctrl_r = max(Parameters.ControlBoundaryMM(:,sliceIdx));
        fprintf(fileFID, 'Element %i -- [mm]\t%.1f\t%.1f\n', sliceIdx-1, ctrl_r, max_r(sliceIdx) );
    end
end
ctrl_r = max(max(Parameters.ControlBoundaryMM));
fprintf(fileFID, 'All Elements -- [mm]\t%.1f\t%.1f\n', ctrl_r, max(max_r) );
fprintf(fileFID, '\n' );

%==========================================================================
% --- Compute hot pixels --- 
%==========================================================================
if SegmentStatistics
    [ApproachingBoilingCount,AboveBoilingCount,ControlSliceArea] = CountHotPixels(Parameters,segmentIdx);
else
    [ApproachingBoilingCount,AboveBoilingCount,ControlSliceArea] = CountHotPixels(Parameters);
end
ApproachingBoilingCountTotal = sum(ApproachingBoilingCount);
AboveBoilingCountTotal = sum(AboveBoilingCount);
ControlVolume = sum(ControlSliceArea);

fprintf(fileFID, '*************  Hot Pixel Counts  *********************\n');
fprintf(fileFID,['Element\tCount > ' num2str(min(Parameters.ApproachingBoilingThreshold(:))) ' C\t Count > 100 C\t%%Vol > ' num2str(min(Parameters.ApproachingBoilingThreshold(:))) ' C\t%%Vol > 100 C\n']);


for sliceIdx = 1:12
    elementIdx = sliceIdx - 1;
    if sliceIdx == 1
        fprintf(fileFID,'Monitoring M0\t%d\t%d\tNaN\tNaN\n',ApproachingBoilingCount(sliceIdx),AboveBoilingCount(sliceIdx));
    elseif sliceIdx == Parameters.NumberSlices
        fprintf(fileFID,'Monitoring M11\t%d\t%d\tNaN\tNaN\n',ApproachingBoilingCount(sliceIdx),AboveBoilingCount(sliceIdx));
    else
        fprintf(fileFID,'Element E%d\t%d\t%d\t%.1f\t%.1f\n',elementIdx,ApproachingBoilingCount(sliceIdx),AboveBoilingCount(sliceIdx),100*ApproachingBoilingCount(sliceIdx)/ControlSliceArea(sliceIdx),100*AboveBoilingCount(sliceIdx)/ControlSliceArea(sliceIdx));
    end
end
fprintf(fileFID,'All slices\t%d\t%d\t%.1f\t%.1f\n',ApproachingBoilingCountTotal,AboveBoilingCountTotal,100*ApproachingBoilingCountTotal/ControlVolume,100*AboveBoilingCountTotal/ControlVolume);
fprintf(fileFID, '\n' );

%==========================================================================
%----- Control boundary statistics -----
%==========================================================================
fprintf(fileFID, '\n' );
fprintf(fileFID, '***********  Control Boundary Info  *************\n');
fprintf(fileFID, '\tMean\tStd.Dev.\tMinimum\tMaximum\n' );

for sliceIdx = 1:length(Parameters.isUAactive)
    elementIdx = sliceIdx - 1;
    if( Parameters.isUAactive(sliceIdx) == 1 ) 
        data = Parameters.ControlBoundaryMM(:,sliceIdx);
        fprintf(fileFID, 'Element %i -- [mm]\t%.1f\t%.1f\t%.1f\t%.1f\n', elementIdx, mean(data),std(data),min(data),max(data) );
    end
end

fprintf(fileFID, '\n' );

%==========================================================================
%----- Over/Undershoot statistics -----
%==========================================================================
fprintf(fileFID, '**************  Over/Undershoot Statistics  *******************************************\tCONTROL ISOTHERM-CONTROL BOUNDARY\t\t\t\t240 CEM43-PROSTATE BOUNDARY\t\t\t\t55�C-PROSTATE BOUNDARY\n');
fprintf(fileFID, '');
fprintf(fileFID, '-- 0%% margin\t OverTreatment\tUnderTreatment\tUnderTreatment_%.0fmm \t\tOverTreatment\tUnderTreatment\tUnderTreatment_%.0fmm \t\tOverTreatment\tUnderTreatment\tUnderTreatment_%.0fmm \n',Parameters.MaximumTreatmentRadiusMM,Parameters.MaximumTreatmentRadiusMM,Parameters.MaximumTreatmentRadiusMM);
for sliceIdx = 1:length(Parameters.isUAactive)
    if( Parameters.isUAactive(sliceIdx) == 1 )
        fprintf(fileFID, 'Element %i [%%] \t%.2f\t%.2f\t%.2f \t\t %.2f\t%.2f\t%.2f \t\t %.2f\t%.2f\t%.2f\n',sliceIdx-1,...
            accuracy_result_0mm.overTreatmentPerSlicePercent(sliceIdx), ...
            accuracy_result_0mm.underTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_0mm.underTreatmentPerSliceExcludingMaxTRPercent(sliceIdx),...
            accuracy_result_0mm_tdose.overTreatmentPerSlicePercent(sliceIdx), ...
            accuracy_result_0mm_tdose.underTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_0mm_tdose.underTreatmentPerSliceExcludingMaxTRPercent(sliceIdx),...
            accuracy_result_0mm_prostate.overTreatmentPerSlicePercent(sliceIdx), ...
            accuracy_result_0mm_prostate.underTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_0mm_prostate.underTreatmentPerSliceExcludingMaxTRPercent(sliceIdx));
    end
end
fprintf(fileFID, '\n' );
fprintf(fileFID, '-- 1%% margin\t OverTreatment\tUnderTreatment\tUnderTreatment_%.0fmm \t\tOverTreatment\tUnderTreatment\tUnderTreatment_%.0fmm \t\tOverTreatment\tUnderTreatment\tUnderTreatment_%.0fmm \n',Parameters.MaximumTreatmentRadiusMM,Parameters.MaximumTreatmentRadiusMM,Parameters.MaximumTreatmentRadiusMM);

for sliceIdx = 1:length(Parameters.isUAactive)
    if( Parameters.isUAactive(sliceIdx) == 1 )
        fprintf(fileFID, 'Element %i [%%] \t%.2f\t%.2f\t%.2f \t\t%.2f\t%.2f\t%.2f \t\t %.2f\t%.2f\t%.2f\n',sliceIdx-1,...
            accuracy_result_1mm.overTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_1mm.underTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_1mm.underTreatmentPerSliceExcludingMaxTRPercent(sliceIdx),...
            accuracy_result_1mm_tdose.overTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_1mm_tdose.underTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_1mm_tdose.underTreatmentPerSliceExcludingMaxTRPercent(sliceIdx),...
            accuracy_result_1mm_prostate.overTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_1mm_prostate.underTreatmentPerSlicePercent(sliceIdx),...
            accuracy_result_1mm_prostate.underTreatmentPerSliceExcludingMaxTRPercent(sliceIdx));
    end
end
fprintf(fileFID, '\n' );


%==========================================================================
%----- Image shift statistics -----
%==========================================================================
fprintf(fileFID, '**************  Cumulative UX/UY shift Statistics (from TDC)  *******************************************\n');
for SegmentIdx = 1:size(SxParameters,2)
    totalNumberOfShifts = ceil((SxParameters(SegmentIdx).ImageNumber(end) - 105)/100); %Returns 0 if < 106, 1 if >= 106 & < 206, 2 if >= 206 & < 360, etc...
    shiftUX{SegmentIdx} = SxParameters(SegmentIdx).ux - SxParameters(SegmentIdx).ux(1,:);
    shiftUY{SegmentIdx} = SxParameters(SegmentIdx).uy - SxParameters(SegmentIdx).uy(1,:);
    
    fprintf(fileFID, '---- SEGMENT %d\n',SegmentIdx);
    fprintf(fileFID, ['Dynamic\t' repmat('%d\t',1,totalNumberOfShifts) '\n'], 106:100:SxParameters(SegmentIdx).ImageNumber(end));
    
    for sliceIdx = 1:length(SxParameters(SegmentIdx).isUAactive)
        fprintf(fileFID, 'Element %i [mm] \t',sliceIdx-1);
        for shiftDyn = min(10 + (1:totalNumberOfShifts)*100 - SxParameters(SegmentIdx).ImageNumber(1),SxParameters(SegmentIdx).ImageNumber(end)- SxParameters(SegmentIdx).ImageNumber(1)) % This comfortably lies between 106, 206, 306...
            fprintf(fileFID, '%.2g/%.2g\t', shiftUX{SegmentIdx}(shiftDyn,sliceIdx), shiftUY{SegmentIdx}(shiftDyn,sliceIdx));
        end
        fprintf(fileFID, '\n' );
    end
    fprintf(fileFID, '\n');
end

%==========================================================================
%----- Thermal Boost statistics -----
%==========================================================================
fprintf(fileFID, '**************  ThermalBoost Statistics  **************\n');
if isfield(Parameters,'ThermalBoostInfo')
    ThermalBoostTime_min = round(Parameters.ThermalBoostInfo.ElapsedTime_sec./60, 2);
    fprintf(fileFID, 'Total Treatment Time with ThermalBoost Enabled [minutes]\t%.2f\n', ThermalBoostTime_min);
    ThermalBoostAngles_deg = sum(Parameters.ThermalBoostInfo.TreatmentState==2);
    for sliceIdx = 1:Parameters.NumberSlices
        if Parameters.isUAactive(sliceIdx)
            fprintf(fileFID, 'Angular coverage with ThermalBoost Enabled on Element %d[�]\t%d\n', sliceIdx-1, ThermalBoostAngles_deg(sliceIdx));
        end
    end

else
    ThermalBoostTime_min = NaN;
    ThermalBoostAngles_deg = NaN;
    fprintf(fileFID, ' ----- Thermal Boost not available on this version of TDC -----\n');
end

fclose(fileFID);

%==========================================================================
% --- Save treatment statistics in structure ---
%==========================================================================
if ~SegmentStatistics
    % Global statistics
    PEDAOverallResults.MatlabVersion = version;
    PEDAOverallResults.TDCVersion = Parameters.SoftwareVersion;
    PEDAOverallResults.ExecutionDate = datetime;
    PEDAOverallResults.PEDAVersion = PEDA_VERSION;
        
    % Treatment Statistics
    PEDAOverallResults.SegmentTimeMIN = SegmentDuration/60;
    PEDAOverallResults.AngularExtentDEG = angularExtent;
    PEDAOverallResults.AngularCoverageDEG = angularCoverage;
    PEDAOverallResults.PatientTemperatureDEG = patientTemperature;
    PEDAOverallResults.TotalTreatmentTimeMIN = sum(SegmentDuration)/60;
    PEDAOverallResults.TotalAngularExtentDEG = totalAngularExtent;
    PEDAOverallResults.TotalAngularCoverageDEG = totalAngularCoverage;
    PEDAOverallResults.treatmentTime360 = treatmentTime360;
    
    % Volumetric error statistics
    PEDAOverallResults.Temperature.totalProstateVolumeCM3 = accuracy_result_0mm.prostate_volume;
    PEDAOverallResults.Temperature.totalTargetVolumeCM3 = accuracy_result_0mm.target_volume;
    PEDAOverallResults.Temperature.totalTargetVolumeCM3MaxTR = accuracy_result_0mm.target_volumeMaxTR;
    PEDAOverallResults.Temperature.percentOSVolume = accuracy_result_0mm.OSVolumePercent;
    PEDAOverallResults.Temperature.percentUSVolume = accuracy_result_0mm.USVolumePercent;
    PEDAOverallResults.Temperature.USVolumeExcludingMaxTRPercent = accuracy_result_0mm.USVolumeExcludingMaxTRPercent;
    PEDAOverallResults.Temperature.underTreatmentPerSliceExcludingMaxTRPercent = accuracy_result_0mm.underTreatmentPerSliceExcludingMaxTRPercent;    
    PEDAOverallResults.Temperature.overTreatmentPerSlicePercent = accuracy_result_0mm.overTreatmentPerSlicePercent;
    PEDAOverallResults.Temperature.underTreatmentPerSlicePercent = accuracy_result_0mm.underTreatmentPerSlicePercent;
    PEDAOverallResults.Temperature.absVolumetricErrorCM3 = accuracy_result_0mm.Volumetric_Error;
    PEDAOverallResults.Temperature.percentOSVolume1mm = accuracy_result_1mm.OSVolumePercent;
    PEDAOverallResults.Temperature.percentUSVolume1mm = accuracy_result_1mm.USVolumePercent;
    PEDAOverallResults.Temperature.overTreatmentPerSlicePercent1mm = accuracy_result_1mm.overTreatmentPerSlicePercent;
    PEDAOverallResults.Temperature.underTreatmentPerSlicePercent1mm = accuracy_result_1mm.underTreatmentPerSlicePercent;
    PEDAOverallResults.Temperature.underTreatmentPerSliceExcludingMaxTRPercent1mm = accuracy_result_1mm.underTreatmentPerSliceExcludingMaxTRPercent;    
    PEDAOverallResults.Temperature.overTreatmentPerSlicePercent1mm = accuracy_result_1mm.overTreatmentPerSlicePercent;
    PEDAOverallResults.Temperature.absVolumetricError1mmCM3 = accuracy_result_1mm.Volumetric_Error;
    
    PEDAOverallResults.Dose.totalProstateVolumeCM3 = accuracy_result_0mm_tdose.prostate_volume;
    PEDAOverallResults.Dose.totalTargetVolumeCM3 = accuracy_result_0mm_tdose.target_volume;
    PEDAOverallResults.Dose.totalTargetVolumeCM3MaxTR = accuracy_result_0mm_tdose.target_volumeMaxTR;
    PEDAOverallResults.Dose.percentOSVolume = accuracy_result_0mm_tdose.OSVolumePercent;
    PEDAOverallResults.Dose.percentUSVolume = accuracy_result_0mm_tdose.USVolumePercent;
    PEDAOverallResults.Dose.USVolumeExcludingMaxTRPercent = accuracy_result_0mm_tdose.USVolumeExcludingMaxTRPercent;
    PEDAOverallResults.Dose.underTreatmentPerSliceExcludingMaxTRPercent = accuracy_result_0mm_tdose.underTreatmentPerSliceExcludingMaxTRPercent;
    PEDAOverallResults.Dose.overTreatmentPerSlicePercent = accuracy_result_0mm_tdose.overTreatmentPerSlicePercent;
    PEDAOverallResults.Dose.underTreatmentPerSlicePercent = accuracy_result_0mm_tdose.underTreatmentPerSlicePercent;
    PEDAOverallResults.Dose.absVolumetricErrorCM3 = accuracy_result_0mm_tdose.Volumetric_Error;
    PEDAOverallResults.Dose.percentOSVolume1mm = accuracy_result_1mm_tdose.OSVolumePercent;
    PEDAOverallResults.Dose.percentUSVolume1mm = accuracy_result_1mm_tdose.USVolumePercent;
    PEDAOverallResults.Dose.overTreatmentPerSlicePercent1mm = accuracy_result_1mm_tdose.overTreatmentPerSlicePercent;
    PEDAOverallResults.Dose.underTreatmentPerSlicePercent1mm = accuracy_result_1mm_tdose.underTreatmentPerSlicePercent;
    PEDAOverallResults.Dose.underTreatmentPerSliceExcludingMaxTRPercent1mm = accuracy_result_1mm_tdose.underTreatmentPerSliceExcludingMaxTRPercent;    
    PEDAOverallResults.Dose.overTreatmentPerSlicePercent1mm = accuracy_result_1mm_tdose.overTreatmentPerSlicePercent;
    PEDAOverallResults.Dose.absVolumetricError1mmCM3 = accuracy_result_1mm_tdose.Volumetric_Error;
    
    PEDAOverallResults.Prostate.totalProstateVolumeCM3 = accuracy_result_0mm_prostate.prostate_volume;
    PEDAOverallResults.Prostate.totalTargetVolumeCM3 = accuracy_result_0mm_prostate.target_volume;
    PEDAOverallResults.Prostate.totalTargetVolumeCM3MaxTR = accuracy_result_0mm_prostate.target_volumeMaxTR;
    PEDAOverallResults.Prostate.percentOSVolume = accuracy_result_0mm_prostate.OSVolumePercent;
    PEDAOverallResults.Prostate.percentUSVolume = accuracy_result_0mm_prostate.USVolumePercent;
    PEDAOverallResults.Prostate.USVolumeExcludingMaxTRPercent = accuracy_result_0mm_prostate.USVolumeExcludingMaxTRPercent;
    PEDAOverallResults.Prostate.underTreatmentPerSliceExcludingMaxTRPercent = accuracy_result_0mm_prostate.underTreatmentPerSliceExcludingMaxTRPercent;
    PEDAOverallResults.Prostate.overTreatmentPerSlicePercent = accuracy_result_0mm_prostate.overTreatmentPerSlicePercent;
    PEDAOverallResults.Prostate.underTreatmentPerSlicePercent = accuracy_result_0mm_prostate.underTreatmentPerSlicePercent;
    PEDAOverallResults.Prostate.absVolumetricErrorCM3 = accuracy_result_0mm_prostate.Volumetric_Error;
    PEDAOverallResults.Prostate.percentOSVolume1mm = accuracy_result_1mm_prostate.OSVolumePercent;
    PEDAOverallResults.Prostate.percentUSVolume1mm = accuracy_result_1mm_prostate.USVolumePercent;
    PEDAOverallResults.Prostate.overTreatmentPerSlicePercent1mm = accuracy_result_1mm_prostate.overTreatmentPerSlicePercent;
    PEDAOverallResults.Prostate.underTreatmentPerSlicePercent1mm = accuracy_result_1mm_prostate.underTreatmentPerSlicePercent;
    PEDAOverallResults.Prostate.underTreatmentPerSliceExcludingMaxTRPercent1mm = accuracy_result_1mm_prostate.underTreatmentPerSliceExcludingMaxTRPercent;    
    PEDAOverallResults.Prostate.overTreatmentPerSlicePercent1mm = accuracy_result_1mm_prostate.overTreatmentPerSlicePercent;
    PEDAOverallResults.Prostate.absVolumetricError1mmCM3 = accuracy_result_1mm_prostate.Volumetric_Error;
    
    % DSC Statistics
    PEDAOverallResults.Temperature.DSCVolume = accuracy_result_0mm.DSCvol;
    PEDAOverallResults.Temperature.DSCArea = accuracy_result_0mm.DSCarea;
    PEDAOverallResults.Dose.DSCVolume = accuracy_result_0mm_tdose.DSCvol;
    PEDAOverallResults.Dose.DSCArea = accuracy_result_0mm_tdose.DSCarea;
    PEDAOverallResults.Prostate.DSCVolume = accuracy_result_0mm_prostate.DSCvol;
    PEDAOverallResults.Prostate.DSCArea = accuracy_result_0mm_prostate.DSCarea;
        
    % Control boundary info
    PEDAOverallResults.ControlBoundaryMeanMM = mean(Parameters.ControlBoundaryMM);
    PEDAOverallResults.ControlBoundaryStdMM = std(Parameters.ControlBoundaryMM);
    PEDAOverallResults.ControlBoundaryMinMM = min(Parameters.ControlBoundaryMM);
    PEDAOverallResults.ControlBoundaryMaxMM = max(Parameters.ControlBoundaryMM);
    
    % 1D Targeting accuracy
    PEDAOverallResults.Temperature.TargetingErrorMeanMM = arrayfun(@(k) mean(accuracy_result_0mm.error1D_eachSlice(k).data), 1:numel(accuracy_result_0mm.error1D_eachSlice),'UniformOutput',0);
    PEDAOverallResults.Temperature.TargetingErrorStdMM = arrayfun(@(k) std(accuracy_result_0mm.error1D_eachSlice(k).data), 1:numel(accuracy_result_0mm.error1D_eachSlice),'UniformOutput',0);
    PEDAOverallResults.Temperature.TargetingErrorMinMM = arrayfun(@(k) min(accuracy_result_0mm.error1D_eachSlice(k).data), 1:numel(accuracy_result_0mm.error1D_eachSlice),'UniformOutput',0);
    PEDAOverallResults.Temperature.TargetingErrorMaxMM = arrayfun(@(k) max(accuracy_result_0mm.error1D_eachSlice(k).data), 1:numel(accuracy_result_0mm.error1D_eachSlice),'UniformOutput',0);

    PEDAOverallResults.Temperature.TargetingErrorTotalMeanMM = mean(accuracy_result_0mm.error1D_allSlices);
    PEDAOverallResults.Temperature.TargetingErrorTotalStdMM = std(accuracy_result_0mm.error1D_allSlices);
    PEDAOverallResults.Temperature.TargetingErrorTotalMinMM = min(accuracy_result_0mm.error1D_allSlices);
    PEDAOverallResults.Temperature.TargetingErrorTotalMaxMM = max(accuracy_result_0mm.error1D_allSlices);
    
    PEDAOverallResults.Dose.TargetingErrorMeanMM = arrayfun(@(k) mean(accuracy_result_0mm_tdose.error1D_eachSlice(k).data), 1:numel({accuracy_result_0mm.error1D_eachSlice.data}),'UniformOutput',0);
    PEDAOverallResults.Dose.TargetingErrorStdMM = arrayfun(@(k) std(accuracy_result_0mm_tdose.error1D_eachSlice(k).data), 1:numel({accuracy_result_0mm.error1D_eachSlice.data}),'UniformOutput',0);
    PEDAOverallResults.Dose.TargetingErrorMinMM = arrayfun(@(k) min(accuracy_result_0mm_tdose.error1D_eachSlice(k).data), 1:numel({accuracy_result_0mm.error1D_eachSlice.data}),'UniformOutput',0);
    PEDAOverallResults.Dose.TargetingErrorMaxMM = arrayfun(@(k) max(accuracy_result_0mm_tdose.error1D_eachSlice(k).data), 1:numel({accuracy_result_0mm.error1D_eachSlice.data}),'UniformOutput',0);
    
    PEDAOverallResults.Dose.TargetingErrorTotalMeanMM = mean(accuracy_result_0mm_tdose.error1D_allSlices);
    PEDAOverallResults.Dose.TargetingErrorTotalStdMM = std(accuracy_result_0mm_tdose.error1D_allSlices);
    PEDAOverallResults.Dose.TargetingErrorTotalMinMM = min(accuracy_result_0mm_tdose.error1D_allSlices);
    PEDAOverallResults.Dose.TargetingErrorTotalMaxMM = max(accuracy_result_0mm_tdose.error1D_allSlices);
    
    PEDAOverallResults.Prostate.TargetingErrorMeanMM = arrayfun(@(k) mean(accuracy_result_0mm_prostate.error1D_eachSlice(k).data), 1:numel({accuracy_result_0mm.error1D_eachSlice.data}),'UniformOutput',0);
    PEDAOverallResults.Prostate.TargetingErrorStdMM = arrayfun(@(k) std(accuracy_result_0mm_prostate.error1D_eachSlice(k).data), 1:numel({accuracy_result_0mm.error1D_eachSlice.data}),'UniformOutput',0);
    PEDAOverallResults.Prostate.TargetingErrorMinMM = arrayfun(@(k) min(accuracy_result_0mm_prostate.error1D_eachSlice(k).data), 1:numel({accuracy_result_0mm.error1D_eachSlice.data}),'UniformOutput',0);
    PEDAOverallResults.Prostate.TargetingErrorMaxMM = arrayfun(@(k) max(accuracy_result_0mm_prostate.error1D_eachSlice(k).data), 1:numel({accuracy_result_0mm.error1D_eachSlice.data}),'UniformOutput',0);
    
    PEDAOverallResults.Prostate.TargetingErrorTotalMeanMM = mean(accuracy_result_0mm_prostate.error1D_allSlices);
    PEDAOverallResults.Prostate.TargetingErrorTotalStdMM = std(accuracy_result_0mm_prostate.error1D_allSlices);
    PEDAOverallResults.Prostate.TargetingErrorTotalMinMM = min(accuracy_result_0mm_prostate.error1D_allSlices);
    PEDAOverallResults.Prostate.TargetingErrorTotalMaxMM = max(accuracy_result_0mm_prostate.error1D_allSlices);
    
    % Max Radius
    PEDAOverallResults.MaxControlRadiusMM = max(Parameters.ControlBoundaryMM);
    PEDAOverallResults.MaxTreatmentRadiusMM = max(isothermRadius);
    PEDAOverallResults.MaxControlRadiusOverallMM = max(max(Parameters.ControlBoundaryMM));
    PEDAOverallResults.MaxTreatmentRadiusOverallMM = max(max(isothermRadius));
    
    % Hot pixels
    PEDAOverallResults.HotPixels.PixelsApproachingBoiling = ApproachingBoilingCount;
    PEDAOverallResults.HotPixels.PixelsAboveBoiling = AboveBoilingCount;
    PEDAOverallResults.HotPixels.PixelsApproachingBoilingVol = 100*ApproachingBoilingCount./ControlSliceArea;
    PEDAOverallResults.HotPixels.PixelsAboveBoilingVol = 100*AboveBoilingCount./ControlSliceArea;
    PEDAOverallResults.HotPixels.AllSlices = [sum(ApproachingBoilingCount) sum(AboveBoilingCount) 100*sum(ApproachingBoilingCount)./sum(ControlSliceArea) 100*sum(AboveBoilingCount)./sum(ControlSliceArea)];
    
    % UA Center shift
    PEDAOverallResults.UAShift.ux = shiftUX;
    PEDAOverallResults.UAShift.uy = shiftUY;
    
    % Thermal Boost Statistics
    PEDAOverallResults.ThermalBoostTime = ThermalBoostTime_min;
    PEDAOverallResults.ThermalBoostAngles = ThermalBoostAngles_deg;

    save(fullfile(Parameters.pathPEDA,'PEDAOverallResults'),'PEDAOverallResults');
end
return;

