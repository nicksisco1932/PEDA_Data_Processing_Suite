function GenerateSegmentPlot(TxParameters,SegmentIdx)
%% Load segment parameters
load(fullfile(TxParameters.pathPEDA,'SxParameters'));
%% Initialize figure
ScreenResolution = get(0, 'Screensize');

if length(SxParameters) == 1
    if size(SxParameters.ProstateBoundary,3) > 2 % more than 2 subsegments
        figure('Position',ScreenResolution);
    else
        figure('Position',[ScreenResolution(1:3) ScreenResolution(4)/1.25]);
    end
else
    if length(SxParameters) > 2 % more than 2 treatment segments
        figure('Position',ScreenResolution);
    else
        figure('Position',[ScreenResolution(1:3) ScreenResolution(4)/1.25]);
    end
end
offset = 0.02; % Horizontal offset
spacing = 0.01; % Horizontal spacing
plotWidth = (1/TxParameters.NumberSlices*(1-2*offset-(TxParameters.NumberSlices-1)*spacing));
if nargin > 1
    plotHeight = 1/(size(SxParameters(SegmentIdx).ProstateBoundary,3)+1.5)*(1-2*offset-spacing); % Without colorbar, it should be 1/2*(1-2*offset-spacing). Needs more room with the colorbar
else
    plotHeight = 1/(length(SxParameters)+1.5)*(1-2*offset-spacing); % Without colorbar, it should be 1/2*(1-2*offset-spacing). Needs more room with the colorbar
    SegmentIdx = 1; % Initialize this here in case this is in the Segment loop on any Segment > 1
end
verticalOffset = 2.1*plotHeight;

minApproachingBoilingThreshold = min(arrayfun(@(x) min(x.ApproachingBoilingThreshold), SxParameters));
cmapTMax = CreateColormap('TMap',minApproachingBoilingThreshold);
caxisTMax = [20 101];
TickLabels = {20 55 minApproachingBoilingThreshold};
XTick = [20 55 minApproachingBoilingThreshold];

%% Main loop
if length(SxParameters) > 1 && nargin == 1
    % Each segment is plotted on a new row.  Add a row on the bottom with the combined treatment
    for segmentIdx = 1:length(SxParameters) + 1
        if segmentIdx <= length(SxParameters)
            load(fullfile(SxParameters(segmentIdx).pathData,'TMax.mat'));
            load(fullfile(SxParameters(segmentIdx).pathData,'isotherms.mat'));
            isothermRadius = isothermRadius./SxParameters(segmentIdx).PixelSize;
            [X_UA,Y_UA] = toCartesian(SxParameters(segmentIdx).UARadius);
            if ~isempty(SxParameters(segmentIdx).Combined)
                TreatedSector = SxParameters(segmentIdx).Combined.TreatedSector;
                [XControl, YControl] = toCartesian(SxParameters(segmentIdx).Combined.ControlBoundary);
                [XProstate, YProstate] = toCartesian(SxParameters(segmentIdx).Combined.ProstateBoundary);
            else
                TreatedSector = SxParameters(segmentIdx).TreatedSector;
                [XControl, YControl] = toCartesian(SxParameters(segmentIdx).ControlBoundary);
                [XProstate, YProstate] = toCartesian(SxParameters(segmentIdx).ProstateBoundary);
            end
            UACenterX = SxParameters(segmentIdx).ux(end,:);
            UACenterY = SxParameters(segmentIdx).uy(end,:);
            if length(TreatedSector) == 360
                X_isotherm = zeros(length(TreatedSector)+1,SxParameters(segmentIdx).NumberSlices);
                Y_isotherm = zeros(length(TreatedSector)+1,SxParameters(segmentIdx).NumberSlices);
            else
                X_isotherm = zeros(length(TreatedSector),SxParameters(segmentIdx).NumberSlices);
                Y_isotherm = zeros(length(TreatedSector),SxParameters(segmentIdx).NumberSlices);
            end
            for sliceIdx = 1: length(SxParameters(segmentIdx).isUAactive)
                if SxParameters(segmentIdx).isUAactive(sliceIdx) == 1
                    [X_isotherm(:,sliceIdx),Y_isotherm(:,sliceIdx)] = toCartesian(isothermRadius(:,sliceIdx),TreatedSector);
                end
            end
        else % This is the combined treatment
            load(fullfile(TxParameters.pathData,'TMax.mat'));
            load(fullfile(TxParameters.pathData,'isotherms.mat'));
            isothermRadius = isothermRadius./TxParameters.PixelSize;
            [X_UA,Y_UA] = toCartesian(TxParameters.UARadius);
            [XControl, YControl] = toCartesian(TxParameters.ControlBoundary);
            [XProstate, YProstate] = toCartesian(TxParameters.ProstateBoundary);
            UACenterX = TxParameters.ux(end,:);
            UACenterY = TxParameters.uy(end,:);
            if length(TxParameters.TreatedSector) == 360
                X_isotherm = zeros(length(TxParameters.TreatedSector)+1,TxParameters.NumberSlices);
                Y_isotherm = zeros(length(TxParameters.TreatedSector)+1,TxParameters.NumberSlices);
            else
                X_isotherm = zeros(length(TxParameters.TreatedSector),TxParameters.NumberSlices);
                Y_isotherm = zeros(length(TxParameters.TreatedSector),TxParameters.NumberSlices);
            end
            for sliceIdx = 1: length(TxParameters.isUAactive)
                if TxParameters.isUAactive(sliceIdx) == 1
                    [X_isotherm(:,sliceIdx),Y_isotherm(:,sliceIdx)] = toCartesian(isothermRadius(:,sliceIdx),TxParameters.TreatedSector);
                end
            end
        end

        row = segmentIdx;
        for sliceIdx = 1:TxParameters.NumberSlices
            % Initialize subplots
            hSubplot = subplot('Position',[offset+(plotWidth+spacing)*(sliceIdx-1) 1-((verticalOffset-plotHeight)+(plotHeight+spacing)*(row-1)) plotWidth plotHeight]);
            zoomlevel = 3.5;

            if segmentIdx <= length(SxParameters)
                rowName = ['SEGMENT ' num2str(segmentIdx)];
            else
                rowName = {'COMBINED';'SEGMENTS'};
            end

            % Display matrix
            imshow(TMax(:,:,sliceIdx), caxisTMax); hold on

            % Set titles
            if sliceIdx == 1
                title(sprintf('M%d (APEX)',sliceIdx-1))
            elseif sliceIdx == TxParameters.NumberSlices
                title(sprintf('M%d (BASE)',sliceIdx-1))
            else
                title(['E' num2str(sliceIdx-1)])
            end

            % Set zoom level
            zoomcenter(UACenterX(sliceIdx),UACenterY(sliceIdx),zoomlevel);

            % Set row name
            if sliceIdx == 1
                ylabel(gca,rowName,'FontWeight','Bold','FontSize',10,'Units','Normalized','Position',[hSubplot.Position(1)-0.05 0.5]);
            end

            % Set colorscale and colorbar 
            colormap(gca,cmapTMax);
            if row > length(SxParameters)
                colorbar('Southoutside','TickLabels',TickLabels,'XTick',XTick,'Limits',caxisTMax,'Position', [hSubplot.Position(1:3) 0.015]);
            end
            % Overlay additional plots
            plot(X_UA + UACenterX(sliceIdx),-Y_UA + UACenterY(sliceIdx),'k','linewidth',0.1)

            if (sliceIdx > 1 && sliceIdx < TxParameters.NumberSlices)
                plot(XProstate(:,sliceIdx) + UACenterX(sliceIdx),-YProstate(:,sliceIdx) + UACenterY(sliceIdx),'k','linewidth',0.5)
                plot(XControl(:,sliceIdx) + UACenterX(sliceIdx),-YControl(:,sliceIdx) + UACenterY(sliceIdx),'k','linewidth',0.2)
                plot(X_isotherm(:,sliceIdx) + UACenterX(sliceIdx),-Y_isotherm(:,sliceIdx) + UACenterY(sliceIdx),'r','linewidth',0.1);
            elseif sliceIdx == 1
                if segmentIdx == 1 || segmentIdx == length(SxParameters) + 1
                    plotUAAngleDirection(gca, SxParameters(1).ThermAngle(1), SxParameters(1).RotationDirection(1), SxParameters(1).ux(end,sliceIdx), SxParameters(1).uy(end,sliceIdx), SxParameters(1).PixelSize)
                else
                    plotUAAngleDirection(gca, SxParameters(segmentIdx).ThermAngle(1), SxParameters(segmentIdx).RotationDirection(1), SxParameters(segmentIdx).ux(end,sliceIdx), SxParameters(segmentIdx).uy(end,sliceIdx), SxParameters(segmentIdx).PixelSize)
                end
            end
        end
    end
    print('-r100',gcf, fullfile(TxParameters.pathPEDA,strjoin([TxParameters.PatientID,"_TMaxSegments.png"], '')), '-dpng');
    orient landscape;
    print(gcf, fullfile(TxParameters.pathPEDA,strjoin([TxParameters.PatientID,"_TMaxSegments.pdf"], '')), '-dpdf', '-bestfit' );
    orient portrait;
    close(gcf)
else % For combining multiple subsegments
    load(fullfile(SxParameters(SegmentIdx).pathData,'TMap.mat'));
    for subSegmentIdx = 1:size(SxParameters(SegmentIdx).ProstateBoundary,3) + 1
        [X_UA,Y_UA] = toCartesian(SxParameters(SegmentIdx).UARadius);
        if subSegmentIdx <= size(SxParameters(SegmentIdx).ProstateBoundary,3)
            subSegmentImageNumber = find(SxParameters(SegmentIdx).ImageNumber == SxParameters(SegmentIdx).SubSegmentImageNumber(subSegmentIdx+1));
            previousSubSegmentImageNumber = find(SxParameters(SegmentIdx).ImageNumber == SxParameters(SegmentIdx).SubSegmentImageNumber(subSegmentIdx));
            [XControl, YControl] = toCartesian(SxParameters(SegmentIdx).ControlBoundary(:,:,subSegmentIdx));
            [XProstate, YProstate] = toCartesian(TxParameters.ProstateBoundary(:,:,subSegmentIdx));
            UACenterX = SxParameters(SegmentIdx).ux(subSegmentImageNumber,:);
            UACenterY = SxParameters(SegmentIdx).uy(subSegmentImageNumber,:);
        else % This is the combined subsegments
            [XControl, YControl] = toCartesian(SxParameters(SegmentIdx).Combined.ControlBoundary);
            [XProstate, YProstate] = toCartesian(SxParameters(SegmentIdx).Combined.ProstateBoundary);
            UACenterX = SxParameters(SegmentIdx).ux(end,:);
            UACenterY = SxParameters(SegmentIdx).uy(end,:);
        end

        row = subSegmentIdx;
        for sliceIdx = 1:length(SxParameters(SegmentIdx).isUAactive)
            % Initialize subplots
            hSubplot = subplot('Position',[offset+(plotWidth+spacing)*(sliceIdx-1) 1-((verticalOffset-plotHeight)+(plotHeight+spacing)*(row-1)) plotWidth plotHeight]);
            zoomlevel = 3.5;

            if subSegmentIdx < length(SxParameters(SegmentIdx).SubSegmentImageNumber)
                rowName = {'DYN', [num2str(SxParameters(SegmentIdx).SubSegmentImageNumber(subSegmentIdx)) '-' num2str(SxParameters(SegmentIdx).SubSegmentImageNumber(subSegmentIdx+1))]};
            else
                rowName = 'COMBINED';
            end

            % Display matrix
            if subSegmentIdx == size(SxParameters(SegmentIdx).ProstateBoundary,3) + 1
                imshow(max(squeeze(TMap(:,:,sliceIdx,:)),[],3), caxisTMax); hold on
            else
                imshow(max(squeeze(TMap(:,:,sliceIdx,SxParameters(SegmentIdx).SubSegmentImageNumber(subSegmentIdx):SxParameters(SegmentIdx).SubSegmentImageNumber(subSegmentIdx+1))),[],3), caxisTMax); hold on
            end
            % Set titles
            if sliceIdx == 1
                title(sprintf('M%d (APEX)',sliceIdx-1))
            elseif sliceIdx == TxParameters.NumberSlices
                title(sprintf('M%d (BASE)',sliceIdx-1))
            else
                title(['E' num2str(sliceIdx-1)])
            end

            % Set zoom level
            zoomcenter(UACenterX(sliceIdx),UACenterY(sliceIdx),zoomlevel);

            % Set row name
            if sliceIdx == 1
                ylabel(gca,rowName,'FontWeight','Bold','FontSize',10,'Units','Normalized','Position',[hSubplot.Position(1)-0.02 0.5]);
            end

            % Set colorscale and colorbar 
            colormap(gca,cmapTMax);
            if row > size(SxParameters(SegmentIdx).ProstateBoundary,3)
                colorbar('Southoutside','TickLabels',TickLabels,'XTick',XTick,'Limits',caxisTMax,'Position', [hSubplot.Position(1:3) 0.015]);
            end
            % Overlay additional plots
            plot(X_UA + UACenterX(sliceIdx),-Y_UA + UACenterY(sliceIdx),'k','linewidth',0.1)

            if (sliceIdx > 1 && sliceIdx < TxParameters.NumberSlices)
                plot(XProstate(:,sliceIdx) + UACenterX(sliceIdx),-YProstate(:,sliceIdx) + UACenterY(sliceIdx),'k','linewidth',0.5)
                plot(XControl(:,sliceIdx) + UACenterX(sliceIdx),-YControl(:,sliceIdx) + UACenterY(sliceIdx),'k','linewidth',0.2)
            elseif sliceIdx == 1
                if subSegmentIdx == 1 || subSegmentIdx == size(SxParameters(SegmentIdx).ProstateBoundary,3) + 1
                    plotUAAngleDirection(gca, SxParameters(SegmentIdx).ThermAngle(1), SxParameters(SegmentIdx).RotationDirection(1), SxParameters(SegmentIdx).ux(1,sliceIdx), SxParameters(SegmentIdx).uy(1,sliceIdx), SxParameters(SegmentIdx).PixelSize)
                else
                    plotUAAngleDirection(gca, SxParameters(SegmentIdx).ThermAngle(previousSubSegmentImageNumber), SxParameters(SegmentIdx).RotationDirection(previousSubSegmentImageNumber), SxParameters(SegmentIdx).ux(previousSubSegmentImageNumber,sliceIdx), SxParameters(SegmentIdx).uy(previousSubSegmentImageNumber,sliceIdx), SxParameters(SegmentIdx).PixelSize)
                end
            end
        end
    end
    
    print('-r100',gcf, fullfile(SxParameters(SegmentIdx).pathData, strjoin([SxParameters(SegmentIdx).PatientID "_TMaxSubSegments_Segment_" num2str(SegmentIdx) ".png"], '')), '-dpng');
    orient landscape;
    print(gcf, fullfile(SxParameters(SegmentIdx).pathData, strjoin([SxParameters(SegmentIdx).PatientID "_TMaxSubSegments_Segment_" num2str(SegmentIdx) ".pdf"], '')), '-dpdf', '-bestfit' );
    orient portrait;
    close(gcf)
end

end