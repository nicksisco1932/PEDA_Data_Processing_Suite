function [isothermRadius, MaxProstateRadius,isothermRadiusCW, isothermRadiusCCW] = CalculateIsotherm(TMap, ux, uy, PixelSize, ProstateRadius, treatedSector, Tc, SelectionOption, targetBoundary, AdditionalRadiusMM, UARadius)
%==========================================================================
% Inputs :  tmap: Temperature matrix, typically 128x128
%           ux  : centre x (columns), scalar value
%           uy  : centre y (rows), scalar value
%           dx  : spatial increment per pixel (mm/px)
%           max_rad : maximum radial extent of lesion [angles, radius]
%           start_angle: starting angle
%           step_angle: angle increment in degrees
%           Tc : Target Temperature (isotherm value)
%           SelectionOption: 1,2, or 3; method for selecting isotherm radius
%           target: target radius
%           AdditionalRadius_mm; distance beyond prostate boundary to look for Tc isotherm (mm)
%
% Outputs : radius : Matix corresponding to the measured isotherm in polar coordinates
%           theta : angle values in radians to use with radius
%           MaxProstateRadius: The prostate radius in mm + the additional search radius

%==========================================================================
% --- Initialize Variables --- 
%==========================================================================
isothermRadiusCW = zeros(length(treatedSector),1); %Initialize empty isotherm radius
isothermRadiusCCW = zeros(length(treatedSector),1); %Initialize empty isotherm radius
isothermRadius = zeros(length(treatedSector),1); %Initialize empty isotherm radius

extendedProstateRadius = ProstateRadius + AdditionalRadiusMM/PixelSize; %extra search radius to account for overheating
dr=0.1; %Radius delta 


%==========================================================================
% --- Find isotherm radius at each angle but rotating CW --- 
%==========================================================================
for theta = treatedSector(end:-1:1)
    index = find(treatedSector == theta);
    TransitionRadius=[];
    
    %---In 0.1pix spacial increments, search for a point < Tc where the next point is > Tc
    for currentRadius = UARadius:dr:extendedProstateRadius(index)
        % Find cartesian coordinates for R and R+dr
        [xt,yt] = pol2cart(theta*(pi/180),[currentRadius currentRadius+dr]);
        
        % Interpolate at these two radiuses 
        TemperatureAtR1 = m_get_interpolated_temp(TMap,xt(1)+ux,-yt(1)+uy);
        TemperatureAtR2 = m_get_interpolated_temp(TMap,xt(2)+ux,-yt(2)+uy);
        
        % If there is a transition, store the current radius
        if ((TemperatureAtR1 >= Tc) && (TemperatureAtR2 <= Tc))
            TransitionRadius = [TransitionRadius currentRadius];
        end
    end  
    
    % Look at the extended radius (ProstateBoundary + AdditionalRadius)
    % and interpolate the temperature at this location
    extendedRadius = extendedProstateRadius(index);
    [xt1_1,yt1_1] = pol2cart(theta*(pi/180),extendedRadius);
    interpolatedTMapAtMaxRadius = m_get_interpolated_temp(TMap,xt1_1+ux,-yt1_1+uy);
    
    if isempty(TransitionRadius)
        % If no transition from T < Tc to T > Tc is found
        if interpolatedTMapAtMaxRadius < Tc
            % If the temperature at the maximum radius is < Tc, then there
            % is no isotherm
            TransitionRadius = 0;
        else
            % Else, the isotherm is set at the extended radius
            TransitionRadius = extendedRadius;
        end
    else
        %If a transition is found, but temperature at maximum radius is above Tc, add this value
        if interpolatedTMapAtMaxRadius >= Tc
            TransitionRadius = sort([TransitionRadius extendedRadius],'ascend');
        end
    end
    
    %==========================================================================
    % If multiple isotherm radii are found, find isotherm radius 
    % according to "SelectionOption"
    %==========================================================================
    switch SelectionOption
        case 1
            isothermRadiusCW(index) = TransitionRadius(1);
        case 2
            isothermRadiusCW(index) = TransitionRadius(end);
        case 3
            % Minimize difference in radius between two consecutive isotherms
            if theta ~= treatedSector(end)
                DiffCurrentAndPreviousRadius = abs(TransitionRadius-isothermRadiusCW(index+1));
                [~,foundIndex] = min(DiffCurrentAndPreviousRadius);
                isothermRadiusCW(index) = TransitionRadius(foundIndex);
            else
                isothermRadiusCW(index) = TransitionRadius(end);
            end
    end
end

%==========================================================================
% --- Find isotherm radius at each angle but rotating CCW --- 
%==========================================================================
for theta = treatedSector
    index = find(treatedSector == theta);

    TransitionRadius=[];
    
    for currentRadius = UARadius:dr:extendedProstateRadius(index)
        [xt,yt] = pol2cart(theta*(pi/180),[currentRadius currentRadius+dr]);
        TemperatureAtR1 = m_get_interpolated_temp(TMap,xt(1)+ux,-yt(1)+uy);
        TemperatureAtR2 = m_get_interpolated_temp(TMap,xt(2)+ux,-yt(2)+uy);
        
        if ((TemperatureAtR1 >= Tc) && (TemperatureAtR2 <= Tc))
            TransitionRadius = [TransitionRadius currentRadius];
        end
    end
    
    extendedRadius = extendedProstateRadius(index);
    [xt1,yt1] = pol2cart(theta*(pi/180),extendedRadius);
    interpolatedTMapAtMaxRadius = m_get_interpolated_temp(TMap,xt1+ux,-yt1+uy);
    if isempty(TransitionRadius)
        if interpolatedTMapAtMaxRadius < Tc
            TransitionRadius = 0;
        else
            TransitionRadius = extendedRadius;
        end
    else
        if interpolatedTMapAtMaxRadius >= Tc
            TransitionRadius = sort([TransitionRadius extendedRadius],'ascend');
        end
    end
    
    switch SelectionOption
        case 1
            isothermRadiusCCW(index) = TransitionRadius(1);
        case 2
            isothermRadiusCCW(index) = TransitionRadius(end);
        case 3
            if theta ~= treatedSector(1)
                DiffCurrentAndPreviousRadius = abs(TransitionRadius-isothermRadiusCCW(index-1));
                [~,foundIndex] = min(DiffCurrentAndPreviousRadius);
                isothermRadiusCCW(index) = TransitionRadius(foundIndex);
            else
                isothermRadiusCCW(index) = TransitionRadius(end);
            end
    end
end

%==========================================================================
% --- Determine which radius to use based on closest to target
%==========================================================================
combinedIsotherm = [isothermRadiusCCW isothermRadiusCW];
DifferenceToTarget = abs(bsxfun(@minus,combinedIsotherm, targetBoundary));
[~, ClosestIsothermIndex] = min(DifferenceToTarget,[],2);

for i = 1:size(combinedIsotherm)
        isothermRadius(i) = combinedIsotherm(i,ClosestIsothermIndex(i));
end

%==========================================================================
% Pass outputs
%==========================================================================
isothermRadius = isothermRadius*PixelSize;
MaxProstateRadius = extendedProstateRadius(:)*PixelSize; %convert back to pixels
return;

