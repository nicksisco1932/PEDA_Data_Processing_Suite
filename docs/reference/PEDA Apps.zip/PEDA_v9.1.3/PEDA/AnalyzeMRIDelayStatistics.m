function [TCD_AcquisitionStartToHWUpdateSEC, maxTCD_AcquisitionStartToHWUpdateSEC_99]  = AnalyzeMRIDelayStatistics(TreatmentControllerData)

%----- MRI delay statistics -----
% Determine which dynamics are in Delivery
IsInDelivery = cellfun(@(x) strcmpi(x,'Delivery'), TreatmentControllerData.TreatmentState)';

% Query delay between dynamic fully received and HW updated from TDC
try
    TCD_DelayBetweenDynamicReceivedToHWUpdateSec = TreatmentControllerData.DynamicReceiveToAllHWUpdateOffsetMs;
catch
    TCD_DelayBetweenDynamicReceivedToHWUpdateSec = TreatmentControllerData.DynamicReceiveToAllHWUpdateOffsetSeconds;
end
% Determine time from start of MR acquisition to dynamic received in TDC (assumes next acquisition starts immediately after receiving previous dynamic)
% Datenum is in units of days, so multiply by 24 hrs/day, 60 mins/hr, 60 sec/min
% Cover case where data crosses midnight. Based on https://www.mathworks.com/matlabcentral/answers/431040-time-difference-milliseconds-at-midnight-error
DynamicFullyReceivedAt = TreatmentControllerData.DynamicFullyReceivedAt + cumsum([0;diff(TreatmentControllerData.DynamicFullyReceivedAt)<0])*days(1);
TCD_DelayBetweenFullyReceivingDynamicsSEC = [0; diff(seconds(DynamicFullyReceivedAt))];

% Determine time from start of MR acquisition to updating HW states on all elements
TCD_AcquisitionStartToHWUpdateSEC = TCD_DelayBetweenDynamicReceivedToHWUpdateSec + TCD_DelayBetweenFullyReceivingDynamicsSEC;
% Exclude dynamics with invalid delays
TCD_AcquisitionStartToHWUpdateSEC = TCD_AcquisitionStartToHWUpdateSEC(IsInDelivery); % only valid when in Delivery
TCD_AcquisitionStartToHWUpdateSEC(1) = []; % ignore first dynamic because we use diff to determine time of slice update
TCD_AcquisitionStartToHWUpdateSEC(isnan(TCD_AcquisitionStartToHWUpdateSEC)) = []; % sometimes possible to be in Delivery, but all elements are combination of disabled / not requesting power

%Sort to remove 1% of extrema (positive or negative)  Since the 
sortedTCD_AcquisitionStartToHWUpdateSEC = sort(abs(TCD_AcquisitionStartToHWUpdateSEC));
sortedTCD_AcquisitionStartToHWUpdateSEC_99 = sortedTCD_AcquisitionStartToHWUpdateSEC(1:floor(numel(sortedTCD_AcquisitionStartToHWUpdateSEC)*0.99)); %Only keep the lowest 99% of pixels

maxTCD_AcquisitionStartToHWUpdateSEC_99 = sortedTCD_AcquisitionStartToHWUpdateSEC_99(end);
