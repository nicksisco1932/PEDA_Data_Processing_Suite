function plotUAAngleDirection(ax, ThermAngleDEG, RotationDirection, ux, uy, PixelSize)

BeamOverlayLength_MM = 34;
ArrowOverlayLength_MM = 10;
BeamOverlayLength = BeamOverlayLength_MM/PixelSize;
ArrowOverlayLength = ArrowOverlayLength_MM/PixelSize;

[BeamX, BeamY]   = pol2cart([1 1]*ThermAngleDEG*pi/180, [0 BeamOverlayLength]);
if strcmpi(RotationDirection,'Counterclockwise')
    [ArrowX, ArrowY] = pol2cart((ThermAngleDEG+90)*pi/180, ArrowOverlayLength);
else
    [ArrowX, ArrowY] = pol2cart((ThermAngleDEG-90)*pi/180, ArrowOverlayLength);
end

hold(ax,'on')
hLine = plot(ax, BeamX + ux, -BeamY + uy, '-k', 'LineWidth', 0.1);
% hLine.Color(4) = 0.65; %transparency
hArrow = quiver(ax, BeamX(2) + ux, -BeamY(2) + uy, ArrowX , -ArrowY , 'k', 'LineWidth', 1, 'MarkerFaceColor', 'k', 'MarkerSize', 2, 'MaxHeadSize', 1e3);
% hArrow.Color(4) = 0.65;

end