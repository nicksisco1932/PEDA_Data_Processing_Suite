function UnwoundThermAngle = UnwindAngle(ThermAngle)
% 0� is East. 180� is West
% CCW is decreasing angle. CW is increasing angle.

%Find when there a jump from 360 to 0
AngleDiff = diff(ThermAngle);

%348 should be high enough to distinguish jumps from unwinding UA
AngleThreshold = 348;

AngleJumps = find(abs(AngleDiff) > AngleThreshold);

%Loop over all angle jumps
for JumpIdx = 1:length(AngleJumps)
    currentJump = AngleJumps(JumpIdx);
    if AngleDiff(currentJump) < 0 %Going CCW
        ThermAngle(currentJump+1:end) = ThermAngle(currentJump+1:end) + 360;
    elseif AngleDiff(currentJump) > 0 %Going CW
        ThermAngle(currentJump+1:end) = ThermAngle(currentJump+1:end) - 360;
    end
end

UnwoundThermAngle = ThermAngle;


