function [cartesianMatrixX,cartesianMatrixY] = toCartesian(polarInput, customRangeDEG)
if nargin == 1
    customRangeDEG = 0:360;
end

if numel(polarInput) == 1
    [cartesianMatrixX,cartesianMatrixY] = pol2cart(deg2rad(customRangeDEG)',repmat(polarInput,361,1));
else
    if length(customRangeDEG) < 360 %Not a full treatment. Do not close contour
        [cartesianMatrixX,cartesianMatrixY] = pol2cart(deg2rad(customRangeDEG)',polarInput);
    elseif length(customRangeDEG) == 360
        [cartesianMatrixX,cartesianMatrixY] = pol2cart(deg2rad([customRangeDEG 360])',[polarInput;polarInput(1,:)]);
    else
        [cartesianMatrixX,cartesianMatrixY] = pol2cart(deg2rad(customRangeDEG)',[polarInput;polarInput(1,:)]);
    end
end
% Anonymous version
% toCartesian = @(polarMatrix) pol2cart(deg2rad(0:360)',[polarMatrix;polarMatrix(1,:)]);

