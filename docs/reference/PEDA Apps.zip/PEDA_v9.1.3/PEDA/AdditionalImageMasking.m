function AdditionalImageMasking (TxParameters, TMap)
%======================================
% function AdditionalImageMasking(TxParameters);
%
% Purpose:
% ========
% Apply distance and beam angle masking
%
%======================================
% Created By: unknown
% Creation Date: unknown
% Last Modified By: Alex Bigot
%======================================

%==========================================================================
% ----- Variable initialization -----
%==========================================================================
% Load matrices
load (fullfile(TxParameters.pathData,'TMaxMasked.mat'))
load (fullfile(TxParameters.pathData,'TDoseMasked.mat'))

% Variable initialization
PixelSize = TxParameters.PixelSize;
Tc = TxParameters.Tc;
NoisyPixels = [];
% if there are multiple subsegments, use the combined boundary
if ~isempty(TxParameters.Combined)
    TxParameters.ControlBoundary = TxParameters.Combined.ControlBoundary;
end

%==========================================================================
% ----- Main loop -----
%==========================================================================
for currentSliceIdx = 1:length(TxParameters.isUAactive)
    clear DistanceMaskedPixels
    BeamMaskedPixels = [];
    % Initialize UA center.  Either it is single element (before TDC v2.6.3) or we use the initial UA center which is not slice dependent, so take first value
    ux = TxParameters.ux(1);
    uy = TxParameters.uy(1);
    if TxParameters.isUAactive(currentSliceIdx) == 1
        % Create prostate boundary extended mask
        [X_target_large,Y_target_large] = pol2cart(TxParameters.ProstateBoundaryTheta*pi/180,TxParameters.ControlBoundary(:,currentSliceIdx)+(1.5/PixelSize));
        X_target_large = X_target_large + ux;
        Y_target_large = -Y_target_large + uy;
        BW_extended = poly2mask(X_target_large,Y_target_large,TxParameters.ImageResolution,TxParameters.ImageResolution);
        BW_extended = imcomplement(BW_extended);
        
        % Apply mask
        MaskedImage = TMaxMasked(:,:,currentSliceIdx).*BW_extended;
        
        %==========================================================================
        % ----- Distance masking -----
        %==========================================================================
        % Find any pixel whose temperature is above TC-3
        [I, J] = find (MaskedImage >= Tc-3 );
        
        % Compute distance from the UA Center
        [~,R_pixelinterest] = cart2pol(abs(J-ux),abs(-I+uy));
        R_pixelinterestMM = R_pixelinterest*PixelSize;
        
        %Find which pixels are beyond 48 mm from UA center
        FindHighRadiusPixels = find (R_pixelinterestMM > 48);
        
        %Matrix containing the pixels + one column with the slice index
        DistanceMaskedPixels = [I(FindHighRadiusPixels) J(FindHighRadiusPixels) ones(length(FindHighRadiusPixels),1)*currentSliceIdx];
        
        % Remove these pixels for beam angle masking
        I(FindHighRadiusPixels) = [];
        J(FindHighRadiusPixels) = [];
        
        %==========================================================================
        % ----- Beam angle masking -----
        %==========================================================================
        for i = 1:length(I)
            % Look at pixel location in time and find max temperature increase
            [~, PixelMaxIndice] = max(squeeze(TMap(I(i),J(i),currentSliceIdx,:))); %find max in time/temperature curve
%             PixelMaxIndice = PixelMaxIndice +  TxParameters.ImageNumber(1) - 1; %Take into account the number of images used during initialization (zero-based)
            BeamAngleAtMaxDegrees = round(TxParameters.ThermAngle(TxParameters.ImageNumber == PixelMaxIndice));
            
            % Beam angle is between 0 and 2*pi
            BeamAngleRadians = (BeamAngleAtMaxDegrees*(pi/180));
            
            % Find angle of pixel location to compare with controller beam
            % angle at peak temperature
            [PixelAngleRadians, ~] = cart2pol(J(i)-ux,-I(i)+uy);
            
            % By default, cart2pol outputs PixelAngle between -pi and pi
            % So, wrap to 2pi to compare to beam angle
            PixelAngleRadians = wrapTo2Pi(PixelAngleRadians);
            
            % Compute difference between Bean Angle and Pixel Angle and
            % wrap to pi
            DifferenceAngleDegree = wrapToPi(BeamAngleRadians-PixelAngleRadians)*(180/pi);
            
            %if difference is higher than 40�, then it is a noisy pixel (beam angle masking)
            if abs(DifferenceAngleDegree) > 40
                BeamMaskedPixels(end+1,:) = [I(i) J(i) currentSliceIdx];   
            end
        end
        % Store noisy pixels
        NoisyPixels = [NoisyPixels;BeamMaskedPixels;DistanceMaskedPixels];
    end
end
save(fullfile(TxParameters.pathData,'NoisyPixels'),'NoisyPixels')

% Edit those pixels
for ii = 1:size(NoisyPixels,1)
    TMaxMasked(NoisyPixels(ii,1),NoisyPixels(ii,2), NoisyPixels(ii,3)) = Tc-4;
    TDoseMasked(NoisyPixels(ii,1),NoisyPixels(ii,2), NoisyPixels(ii,3)) = 200;
end

% Save new matrices
save(fullfile(TxParameters.pathData,'TMaxMasked.mat'),'TMaxMasked');
save(fullfile(TxParameters.pathData,'TDoseMasked.mat'),'TDoseMasked');


