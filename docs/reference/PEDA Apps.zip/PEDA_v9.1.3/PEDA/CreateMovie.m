function CreateMovie(SxParameters, inputMatrix, inputSettings, optionalBackgroundMatrix)
%======================================
% function CreateMovie;
%
% Purpose:
% ========
% Generates movie files from 4D matrices
%
%==========================================================================
%==========================================================================
% Variable initialization
%==========================================================================
switch nargin
    case 1
        error('Missing inputMatrix and options argument')
    case 2
        error('Missing options argument')
    case 3
        movieSettings = validateInputs(SxParameters, inputMatrix, inputSettings, []);
    case 4
        movieSettings = validateInputs(SxParameters, inputMatrix, inputSettings, optionalBackgroundMatrix);
end

movieSettings = setstructfields(getDefaultSettings(SxParameters, movieSettings.movieType), movieSettings);

if ~movieSettings.overwriteMovie && exist(movieSettings.savePath,'file') == 2
    return
end

TDCColoraxis = [20 101]; %We want to map from 20 to 100 but somehow Matlab colormap works with intervals. So we need to get to 101
inputMatrix(1,1,:,:) = 1; if exist('optionalBackgroundMatrix'); optionalBackgroundMatrix(1,1,:,:) = 1; end; %Ensure any slices that are all zeros (sometimes due to bug), a nonzero element exists for normalization by forcing corner pixels (which get cropped anyway) to 1
cmapTUV = CreateColormap('TUV');
if strcmp(movieSettings.movieType,'Magnitude'); MagnitudeColoraxis = getGreyscaleLimits(inputMatrix(32:96,47:82,:,:), movieSettings.greyscalePercentileLimits); end;
if strcmp(movieSettings.movieType,'Overlay');   MagnitudeColoraxis = getGreyscaleLimits(optionalBackgroundMatrix(32:96,47:82,:,:), movieSettings.greyscalePercentileLimits); end;
MaximumRadiusMM = 30;
MaximumRadius = MaximumRadiusMM./SxParameters.PixelSize;

%==========================================================================
% Retrieve Prostate, Control, MTR boundaries, Treatment Controller statistics,and element state and frequency
%==========================================================================
[X_UA_CTRL,Y_UA_CTRL]       =  pol2cart(SxParameters.ThermAngle*(pi/180),20); %UA Control Angle
[X_MTR,Y_MTR]               =  toCartesian(SxParameters.MinimumTreatmentRadius);
[MaxRadiusX,MaxRadiusY]     =  toCartesian(MaximumRadius);
[UARadiusX,UARadiusY]       =  toCartesian(SxParameters.UARadius);
for subSegmentIdx = 1:numel(SxParameters.SubSegmentImageNumber)-1
    dynInterval = SxParameters.SubSegmentImageNumber(subSegmentIdx):SxParameters.SubSegmentImageNumber(subSegmentIdx+1);
    [XC,YC]         =  toCartesian(SxParameters.ControlBoundary(:,:,subSegmentIdx));
    [XP,YP]       =  toCartesian(SxParameters.ProstateBoundary(:,:,subSegmentIdx));
    
    XControl(:,:,dynInterval) = repmat(XC,1,1,length(dynInterval));
    YControl(:,:,dynInterval) = repmat(YC,1,1,length(dynInterval));
    XProstate(:,:,dynInterval) = repmat(XP,1,1,length(dynInterval));
    YProstate(:,:,dynInterval) = repmat(YP,1,1,length(dynInterval));
end
[elementFrequencies, normalizedElementPowers] = getHardwareInfo(SxParameters);
load(fullfile(SxParameters.pathData, 'TreatmentControllerInfo.mat'))

%==========================================================================
% Generate movies
%==========================================================================
mov = VideoWriter(movieSettings.savePath,'MPEG-4');
mov.FrameRate = movieSettings.frameRate;
open(mov);
hFig = figure('Position',[100 65 1700 950],'resize', 'off', 'Color',movieSettings.backgroundColor);
set(gca,'NextPlot','replacechildren');

for dynIdx = movieSettings.firstDyn:movieSettings.lastDyn
    for sliceIdx = movieSettings.firstSlice:movieSettings.lastSlice
        elementIdx = sliceIdx - 1;
        offsetDynIdx = dynIdx-(SxParameters.ImageNumber(1)-1);
        InTreatment = dynIdx >= SxParameters.ImageNumber(1);
        notOuterElement = ~(sliceIdx == movieSettings.firstSlice || sliceIdx == movieSettings.lastSlice);
        %==========================================================================
        % Variable and matrix initialization
        %==========================================================================
        if strcmp(movieSettings.movieType,'Overlay')
            if dynIdx == movieSettings.firstDyn
                cmap3 = CreateColormap('TMap',SxParameters.ApproachingBoilingThreshold(dynIdx));
                coloraxis = TDCColoraxis;
            end
            if dynIdx < SxParameters.NumRefImages
                Mask43TMap = zeros(128,128);
            else
                Mask43TMap = inputMatrix(:,:,sliceIdx,dynIdx) >= movieSettings.mask43Lim(2) | inputMatrix(:,:,sliceIdx,dynIdx) < movieSettings.mask43Lim(1);
                if isfield(movieSettings,'mask43Additional'); Mask43TMap = Mask43TMap & movieSettings.mask43Additional(:,:,sliceIdx,dynIdx); end;
            end
            TMapMasked43 = squeeze(inputMatrix(:,:,sliceIdx,dynIdx)).*Mask43TMap;
            TMapMasked43(1,1) = TDCColoraxis(1); TMapMasked43(1,2) = TDCColoraxis(2); %ensure entire range of TMap colours are being used by forcing corner pixels (which get cropped anyway) to limits of colormap
            
            %currentMatrix is the indexed Magnitude (needs to be plotted first under the TMap overlay
            currentMatrix = label2rgb(round(normalizemat(ceilfloor(optionalBackgroundMatrix(:,:,sliceIdx,dynIdx),MagnitudeColoraxis(1),MagnitudeColoraxis(2)),1,255)),gray(256));
            indexedTMapMasked43 = label2rgb(round(normalizemat(ceilfloor(TMapMasked43,TDCColoraxis(1),TDCColoraxis(2)),TDCColoraxis(1) - TDCColoraxis(1) + 1, TDCColoraxis(2) - TDCColoraxis(1))),cmap3);
            currentMatrix = uint8(currentMatrix);
            indexedTMapMasked43 = uint8(indexedTMapMasked43);
        else
            currentMatrix = inputMatrix(:,:,sliceIdx,dynIdx);
            
            if movieSettings.mask
%                 cmap3 = [movieSettings.maskColor;repmat(cmap3(1,:),118,1);cmap3]; %-99 is grey
                currentMask = double(optionalBackgroundMatrix(:,:,sliceIdx,dynIdx));
                currentMatrix = currentMatrix.*currentMask; %Apply masking
                currentMatrix(currentMask == 0) = -99; %Only to display masked pixels as grey.
            end
        end
        
        % Required for the timer
        if InTreatment
            TreatmentTimeMin = SxParameters.ImageTime(offsetDynIdx)/60;
        else
            TreatmentTimeMin = 0;
        end
        Minute = floor(TreatmentTimeMin);
        Second = floor((TreatmentTimeMin-Minute)*60);
        
        %==========================================================================
        % If first frame, create imshow objects, plots, and timer
        %==========================================================================
        if dynIdx == movieSettings.firstDyn
            ax(sliceIdx) = subaxis(movieSettings.displayRows,movieSettings.displayCols,sliceIdx,'Spacing',0.005,'MT',0.05,'MR',0.18,'ML',0.005,'MB',0.005,'PT',0.05);
            imshowHandle(sliceIdx) = imshow(currentMatrix,[]);
            axis equal, zoomcenter(SxParameters.ux(dynIdx),SxParameters.uy(dynIdx),movieSettings.zoomFactor), hold on
            
            % Tick labels
            TickLabels = {20 55 SxParameters.ApproachingBoilingThreshold(dynIdx) 100};
            XTick = [20 55 SxParameters.ApproachingBoilingThreshold(dynIdx) 100];
            cmap3 = CreateColormap('TMap',SxParameters.ApproachingBoilingThreshold(dynIdx));
            if movieSettings.mask
                cmap3 = [movieSettings.maskColor;repmat(cmap3(1,:),118,1);cmap3]; %-99 is grey
            end
            %Add overlay
            if strcmp(movieSettings.movieType,'Overlay')
                imshowHandleOverlay(sliceIdx) = imshow(indexedTMapMasked43,[],'Parent',ax(sliceIdx));
                set(imshowHandleOverlay(sliceIdx),'AlphaData',Mask43TMap)
            end
            
            if movieSettings.simpleDisplay == 1
                hProstatePlot(sliceIdx) = plot(XProstate(:,sliceIdx,dynIdx) + SxParameters.ux(dynIdx),-YProstate(:,sliceIdx,dynIdx) + SxParameters.uy(dynIdx),'Color',movieSettings.boundariesColor,'linewidth',3);
                hAnglePlot(sliceIdx) = plot([SxParameters.ux(1) (X_UA_CTRL(dynIdx) + SxParameters.ux(dynIdx))],[SxParameters.uy(dynIdx) (-Y_UA_CTRL(dynIdx) + SxParameters.uy(dynIdx))],'Color',movieSettings.angleColor,'linewidth',3,'Parent',ax(sliceIdx));
            else
                hProstatePlot(sliceIdx) = plot(XProstate(:,sliceIdx,dynIdx) + SxParameters.ux(dynIdx),-YProstate(:,sliceIdx,dynIdx) + SxParameters.uy(dynIdx),'Color',movieSettings.boundariesColor,'linewidth',1);
                hControlPlot(sliceIdx) = plot(XControl(:,sliceIdx,dynIdx) + SxParameters.ux(dynIdx),-YControl(:,sliceIdx,dynIdx) + SxParameters.uy(dynIdx),'Color',movieSettings.boundariesColor,'linewidth',0.2);
                hMTRPlot(sliceIdx) = plot(X_MTR + SxParameters.ux(dynIdx),-Y_MTR + SxParameters.uy(dynIdx),'Color',movieSettings.MTRcolor,'Color',movieSettings.MTRcolor,'linewidth',0.1);
                hMaxRadPlot(sliceIdx) = plot(MaxRadiusX + SxParameters.ux(dynIdx),-MaxRadiusY + SxParameters.uy(dynIdx),'g--','linewidth',0.2);
                hAnglePlot(sliceIdx) = plot([SxParameters.ux(1) (X_UA_CTRL(dynIdx) + SxParameters.ux(dynIdx))],[SxParameters.uy(dynIdx) (-Y_UA_CTRL(dynIdx) + SxParameters.uy(dynIdx))],'Color',movieSettings.angleColor,'linewidth',1.5,'Parent',ax(sliceIdx));
                if sliceIdx == movieSettings.firstSlice
                    text(MaxRadiusX(90) + SxParameters.ux(dynIdx),-(MaxRadiusY(90) + 2) + SxParameters.uy(dynIdx),[num2str(MaximumRadiusMM) ' mm'],'Color','g','HorizontalAlignment','Center','FontWeight','bold');
                end
            end
            
            %Add subplot titles
            if sliceIdx == movieSettings.firstSlice
                title(sprintf('M%d (APEX)',elementIdx),'Color',movieSettings.foregroundColor,'FontSize',18);
            elseif sliceIdx == movieSettings.lastSlice
                title(sprintf('M%d (BASE)',elementIdx),'Color',movieSettings.foregroundColor,'FontSize',18);
            end
            
            if notOuterElement
                hTitle(elementIdx) = title(sprintf('E%d',elementIdx),'Color',movieSettings.foregroundColor,'FontSize',18);
                
                if ~(strcmp(movieSettings.movieType,'TUV') || strcmp(movieSettings.movieType,'TUVMag')) && any(normalizedElementPowers(:,elementIdx)) %Add power indicators only if there was power
                    hTitle(elementIdx).Position(1) = hTitle(elementIdx).Position(1) - 5; %Off-center title
                    
                    titlePosition(1) = hTitle(elementIdx).Position(1) + 5;
                    titlePosition(2) = hTitle(elementIdx).Position(2) - 1.35;
                    
                    maxWidth = 11;
                    maxHeight = 2;
                    XpatchPosition = [titlePosition(1) titlePosition(1)              titlePosition(1)+maxWidth       titlePosition(1)+maxWidth];
                    YpatchPosition = [titlePosition(2) titlePosition(2)-maxHeight    titlePosition(2)-maxHeight      titlePosition(2)];
                    
                    hPatchEdge(sliceIdx) = patch(ax(sliceIdx),XpatchPosition,YpatchPosition,movieSettings.foregroundColor,'FaceColor','none','EdgeColor',movieSettings.foregroundColor,'Clipping','off');
                    hPatch(sliceIdx) = patch(ax(sliceIdx),XpatchPosition,YpatchPosition,movieSettings.backgroundColor,'FaceColor','none','EdgeColor','none','Clipping','off');
                end
            end

            %Add colorbar
            switch movieSettings.movieType
                case 'TMap'
                    if movieSettings.mask
                        coloraxis = [-99 101]; %Masked values will be assigned the value -99
                    else
                        coloraxis = TDCColoraxis;
                    end
                    colormap(gca,cmap3);
                    caxis(coloraxis);
                    if sliceIdx == movieSettings.lastSlice
                        TextBoxString2 = '[\circC]';
                        annotation('Textbox',[0.95 0.37 0.7 0.15],'String',TextBoxString2,'Color',movieSettings.foregroundColor,'FontSize',22,'EdgeColor','none')
                        hColorbar = colorbar;
                        set(hColorbar,'Position',[0.85 0.05 .0581 0.8150],'FontSize',18,'LineWidth',2,'Color',movieSettings.foregroundColor,'TickLabels',TickLabels,'XTick',XTick,'Limits',TDCColoraxis);
                    end
                case 'Overlay'
                    if sliceIdx == movieSettings.lastSlice
                        TextBoxString2 = '[\circC]';
                        annotation('Textbox',[0.95 0.37 0.7 0.15],'String',TextBoxString2,'Color',movieSettings.foregroundColor,'FontSize',22,'EdgeColor','none')
                        axhidden = subplot('Position',[-0.1 -0.1 0.01 0.01]);
                        imagesc([20 101]);
                        colormap(cmap3)
                        hColorbar = colorbar;
                        set(hColorbar,'Position',[0.85 0.05 .0581 0.8150],'FontSize',18,'LineWidth',2,'Color',movieSettings.foregroundColor,'TickLabels',TickLabels,'XTick',XTick,'Limits',TDCColoraxis);
                    end
                case 'Magnitude'
                    colormap(gca,'gray');
                    caxis(MagnitudeColoraxis);
                case {'TUV', 'TUVMag'}
                    hAnglePlot(sliceIdx).Visible = 'off';
                    if strcmp(movieSettings.movieType,'TUV')
                        colormap(gca,cmapTUV);
                        caxis([0 6]);
                        if sliceIdx == movieSettings.lastSlice
                            TextBoxString2 = '[\circC]';
                            annotation('TextBox',[0.95 0.37 0.7 0.15],'String',TextBoxString2,'Color',movieSettings.foregroundColor,'FontSize',22,'EdgeColor','none')
                            colorbar('Position',[0.85 0.05 .0581 0.8150],'FontSize',18,'LineWidth',2,'Color',movieSettings.foregroundColor,'Ticks',[0 2 4],'TickLabels',{'0' '2' '4'})
                        end
                    end
%                     plot(X_MTR + SxParameters.ux(offsetDynIdx),-Y_MTR + SxParameters.uy(offsetDynIdx),'k','linewidth',0.1)
%                     plot(UARadiusX + SxParameters.ux(offsetDynIdx),-UARadiusY + SxParameters.uy(offsetDynIdx),'r','linewidth',0.2)
            end
            
            if movieSettings.simpleDisplay == 0
            %Create timer
                if sliceIdx == movieSettings.firstSlice
                    if InTreatment
                        TextBoxString = sprintf('Treatment Time: %d:%02d\nDynamic #%d', Minute, Second, dynIdx);
                    else
                        TextBoxString = sprintf('Initialization\nDynamic #%d', dynIdx);
                    end
                    if  (strcmp(movieSettings.movieType,'TUV')) || (strcmp(movieSettings.movieType,'TUVMag'))
                        TextBoxString = sprintf('TUV\nDynamic #%d', dynIdx);
                    end
                    annotation('textbox',[0.2 0.84 0.75 0.15],'String',TextBoxString,'Color',movieSettings.foregroundColor,'FontSize',20,'EdgeColor','none','Tag','elapsedTime','HorizontalAlignment','Right')
                    hTextBox = findall(gcf,'Tag','elapsedTime');
                end
            else
                if sliceIdx == movieSettings.firstSlice
                    if InTreatment
                        TextBoxString = sprintf('\nTime: %d:%02d', Minute, Second);
                    else
                        TextBoxString = sprintf('\nInitialization');
                    end
                    if  (strcmp(movieSettings.movieType,'TUV')) || (strcmp(movieSettings.movieType,'TUVMag'))
                        TextBoxString = sprintf('TUV\nDynamic #%d', dynIdx);
                    end
                    annotation('textbox',[0.2 0.84 0.75 0.15],'string',TextBoxString,'color',movieSettings.foregroundColor,'fontsize',20,'edgecolor','none','Tag','elapsedTime','Horizontalalignment','Right')
                    hTextBox = findall(gcf,'Tag','elapsedTime');                    
                end                
            end
        else
            %==========================================================================
            % Else, update the data
            %==========================================================================
            set(imshowHandle(sliceIdx),'CData',currentMatrix,'Parent',ax(sliceIdx))
            if dynIdx > SxParameters.NumRefImages+1 && strcmp(movieSettings.movieType,'Overlay')
                set(imshowHandleOverlay(sliceIdx),'CData',indexedTMapMasked43,'Parent',ax(sliceIdx),'AlphaData',Mask43TMap)
            end
            if offsetDynIdx > 1 && ~isequal(SxParameters.ApproachingBoilingThreshold(offsetDynIdx),SxParameters.ApproachingBoilingThreshold(offsetDynIdx-1))
                if strcmp(movieSettings.movieType,'Overlay')
%                     set(imshowHandleOverlay(sliceIdx),'CData',indexedTMapMasked43,'Parent',ax(sliceIdx),'AlphaData',Mask43TMap)
                    set(hColorbar,'TickLabels',TickLabels,'XTick',XTick);
                    colormap(axhidden,cmap3);
                    caxis(axhidden,coloraxis);
%                 end
                
                elseif strcmp(movieSettings.movieType,'TMap')
                    TickLabels = {20 55 SxParameters.ApproachingBoilingThreshold(offsetDynIdx) 100};
                    XTick = [20 55 SxParameters.ApproachingBoilingThreshold(offsetDynIdx) 100];
                    cmap3 = CreateColormap('TMap',SxParameters.ApproachingBoilingThreshold(offsetDynIdx));
                    if movieSettings.mask
                        cmap3 = [movieSettings.maskColor;repmat(cmap3(1,:),118,1);cmap3]; %-99 is grey
                    end
                    set(hColorbar,'TickLabels',TickLabels,'XTick',XTick);
                    colormap(ax(sliceIdx),cmap3);
                    caxis(ax(sliceIdx),coloraxis);
                end
            end
            
            if movieSettings.simpleDisplay == 0
                % MTR and beam angle
                set(hMTRPlot(sliceIdx),'XData',X_MTR                                + SxParameters.ux(max(1,offsetDynIdx),sliceIdx));
                set(hMTRPlot(sliceIdx),'YData',-Y_MTR                               + SxParameters.uy(max(1,offsetDynIdx),sliceIdx));
                set(hMaxRadPlot(sliceIdx),'XData',MaxRadiusX                        + SxParameters.ux(max(1,offsetDynIdx),sliceIdx));
                set(hMaxRadPlot(sliceIdx),'YData',-MaxRadiusY                       + SxParameters.uy(max(1,offsetDynIdx),sliceIdx));
            end
            set(hAnglePlot(sliceIdx),'XData',[SxParameters.ux(max(1,offsetDynIdx),sliceIdx) (X_UA_CTRL(max(1,offsetDynIdx)) + SxParameters.ux(max(1,offsetDynIdx),sliceIdx))]);
            set(hAnglePlot(sliceIdx),'YData',[SxParameters.uy(max(1,offsetDynIdx),sliceIdx) (-Y_UA_CTRL(max(1,offsetDynIdx)) + SxParameters.uy(max(1,offsetDynIdx),sliceIdx))]);
            
            % Boundaries
            set(hProstatePlot(sliceIdx),'XData',XProstate(:,sliceIdx,dynIdx)      + SxParameters.ux(max(1,offsetDynIdx),sliceIdx));
            set(hProstatePlot(sliceIdx),'YData',-YProstate(:,sliceIdx,dynIdx)     + SxParameters.uy(max(1,offsetDynIdx),sliceIdx));
            if movieSettings.simpleDisplay == 0
                set(hControlPlot(sliceIdx), 'XData',XControl(:,sliceIdx,dynIdx)       + SxParameters.ux(max(1,offsetDynIdx),sliceIdx));
                set(hControlPlot(sliceIdx), 'YData',-YControl(:,sliceIdx,dynIdx)      + SxParameters.uy(max(1,offsetDynIdx),sliceIdx));
            end
            
            if movieSettings.simpleDisplay == 0
                % Text box
                if InTreatment
                    set(hTextBox,'String',sprintf('Treatment Time: %d:%02d\nDynamic #%d', Minute, Second, dynIdx));
                else
                    set(hTextBox,'String',sprintf('Initialization\nDynamic #%d', dynIdx));
                end
                if  (strcmp(movieSettings.movieType,'TUV')) || (strcmp(movieSettings.movieType,'TUVMag'))
                    set(hTextBox,'String',sprintf('TUV\nDynamic #%d', dynIdx));
                end
            else
                if InTreatment
                    set(hTextBox,'String',sprintf('\nTime: %d:%02d', Minute, Second));
                else
                    set(hTextBox,'String',sprintf('\nInitialization'));
                end
                if  (strcmp(movieSettings.movieType,'TUV')) || (strcmp(movieSettings.movieType,'TUVMag'))
                    set(hTextBox,'String',sprintf('TUV\nDynamic #%d', dynIdx));
                end                
            end
            
            % shift the frame/titles so shifted overlays look static
            if movieSettings.recenterImages && offsetDynIdx > 1
                if SxParameters.ux(offsetDynIdx,sliceIdx) ~= SxParameters.ux(offsetDynIdx - 1,sliceIdx) ||...
                        SxParameters.uy(offsetDynIdx,sliceIdx) ~= SxParameters.uy(offsetDynIdx - 1,sliceIdx)
                    XLimNew = get(ax(sliceIdx),'XLim') + SxParameters.ux(offsetDynIdx,sliceIdx) - SxParameters.ux(dynIdx-SxParameters.ImageNumber(1),sliceIdx);
                    YLimNew = get(ax(sliceIdx),'YLim') + SxParameters.uy(offsetDynIdx,sliceIdx) - SxParameters.uy(dynIdx-SxParameters.ImageNumber(1),sliceIdx);
                    set(ax(sliceIdx),'XLim', XLimNew);
                    set(ax(sliceIdx),'YLim', YLimNew);
                    set(ax(sliceIdx),'DataAspectRatio', [1 1 1]);
                    if notOuterElement
                        XPositionNew = hTitle(elementIdx).Position(1) + SxParameters.ux(offsetDynIdx,sliceIdx) - SxParameters.ux(dynIdx-SxParameters.ImageNumber(1),sliceIdx);
                        YPositionNew = hTitle(elementIdx).Position(2) + SxParameters.uy(offsetDynIdx,sliceIdx) - SxParameters.uy(dynIdx-SxParameters.ImageNumber(1),sliceIdx);
                        hTitle(elementIdx).Position(1) = XPositionNew;
                        hTitle(elementIdx).Position(2) = YPositionNew;
                        if ~(strcmp(movieSettings.movieType,'TUV') || strcmp(movieSettings.movieType,'TUVMag')) && any(normalizedElementPowers(:,elementIdx)) %Add power indicators only if there was power
                            titlePosition(1) = hTitle(elementIdx).Position(1) + 5;
                            titlePosition(2) = hTitle(elementIdx).Position(2) - 1.35;
                            XpatchPosition = [titlePosition(1) titlePosition(1)              titlePosition(1)+maxWidth       titlePosition(1)+maxWidth];
                            YpatchPosition = [titlePosition(2) titlePosition(2)-maxHeight    titlePosition(2)-maxHeight      titlePosition(2)];
                            hPatchEdge(sliceIdx).delete;
                            hPatch(sliceIdx).delete;
                            hPatchEdge(sliceIdx) = patch(ax(sliceIdx),XpatchPosition,YpatchPosition,movieSettings.foregroundColor,'FaceColor','none','EdgeColor',movieSettings.foregroundColor,'Clipping','off');
                            hPatch(sliceIdx) = patch(ax(sliceIdx),XpatchPosition,YpatchPosition,movieSettings.backgroundColor,'FaceColor','none','EdgeColor','none','Clipping','off');
                        end
                    end
                end
            end
            
            % Update title color and power indicators (Green = LF; Red = HF)
            if ~(strcmp(movieSettings.movieType,'TUV') || strcmp(movieSettings.movieType,'TUVMag')) &&...
                    notOuterElement && any(normalizedElementPowers(:,elementIdx)) &&...
                    InTreatment
                updatedXpatchPosition = [  hPatchEdge(sliceIdx).XData(1) hPatchEdge(sliceIdx).XData(2) ...
                    hPatchEdge(sliceIdx).XData(1)+(normalizedElementPowers(offsetDynIdx,elementIdx).*maxWidth)...
                    hPatchEdge(sliceIdx).XData(1)+(normalizedElementPowers(offsetDynIdx,elementIdx).*maxWidth)];
                
                switch elementFrequencies(offsetDynIdx,elementIdx)
                    case SxParameters.UA.LowFrequency
                        hPatch(sliceIdx).XData = updatedXpatchPosition;
                        hPatch(sliceIdx).FaceColor = 'green'; %[0 0.75 0];
                        
                    case SxParameters.UA.HighFrequency
                        hPatch(sliceIdx).XData = updatedXpatchPosition;
                        hPatch(sliceIdx).FaceColor = 'red';
                        
                    otherwise
                        hPatch(sliceIdx).FaceColor = 'none';
                end
                
                if ~SxParameters.IsElementEnabled(offsetDynIdx,sliceIdx)
                    hPatchEdge(sliceIdx).FaceColor = [0.6 0.6 0.6]; % Light gray
                    hTitle(elementIdx).Color = [0.6 0.6 0.6]; % Light gray
                else
                    tcIdx = find((ismember(TreatmentControllerInfo{1, 4}, strcat('E', int2str(elementIdx))) & ismember(TreatmentControllerInfo{1, 2}, dynIdx)) == 1);
                    if ~isempty(tcIdx) && strcmp(string(TreatmentControllerInfo{1, 5}(tcIdx)), 'Boosted')
                        hTitle(elementIdx).Color = [0.9100 0.4100 0.1700];
                    else
                        hPatchEdge(sliceIdx).FaceColor = movieSettings.backgroundColor;
                        hTitle(elementIdx).Color = movieSettings.foregroundColor; % white
                    end
                end
            end
        end
    end %end slice loop
    
    %Write video object
    writeVideo(mov,getframe(hFig));

end
%==========================================================================
% Close objects
%==========================================================================
close(mov)
close(gcf)
end

function movieSettings = validateInputs(SxParameters, inputMatrix, inputSettings, optionalBackgroundMatrix)

if ischar(inputSettings)
    movieSettings.movieType = inputSettings;
else
    movieSettings = inputSettings;
end

if ~any(strcmpi(fieldnames(movieSettings),'movieType'))
    error('Missing movie type')
end

if ~any(cellfun(@(x) any(strfind(lower(x),lower(movieSettings.movieType))),{'TMap','TUV','Magnitude','Overlay','TUVMag'}))
    error('Unrecognized movie type. Allowed values are TMap, TUV, Magnitude, Overlay, TUVMag')
else
    if any(strfind(lower(movieSettings.movieType),lower('Overlay')))
        movieSettings.movieType = 'Overlay';
        if isempty(optionalBackgroundMatrix)
            error('You requested an overlay but forgot to specify an background matrix')
        end
    end
end

if any(strcmpi(fieldnames(movieSettings),'firstDyn'))
    if size(inputMatrix,4) < movieSettings.firstDyn
        error('Requested first dynamic (%d) is greater than number of dynamics of inputMatrix (%d). Aborting...',movieSettings.lastDyn,size(inputMatrix,4));
    end
end
if any(strcmpi(fieldnames(movieSettings),'lastDyn'))
    if size(inputMatrix,4) < movieSettings.lastDyn
        warning('Requested last dynamic (%d) is greater than number of dynamics of inputMatrix size (%d). Will abort movie at dynamic %d.',movieSettings.lastDyn,size(inputMatrix,4),size(inputMatrix,4));
        movieSettings.lastDyn = size(inputMatrix,4);
    end
else
    movieSettings.lastDyn = min(size(inputMatrix,4),SxParameters.ImageNumber(end)+1);
end

if any(strcmpi(fieldnames(movieSettings),'mask')) && movieSettings.mask
    if isempty(optionalBackgroundMatrix)
        error('You requested a masked movie but forgot to input a mask')
    end
    movieSettings.movieName = [SxParameters.PatientID,'_',movieSettings.movieType,'_masked.mp4'];
    movieSettings.savePath = fullfile(SxParameters.pathData,movieSettings.movieName);
end

if isfield(inputSettings,'movieName') && ~isfield(inputSettings,'savePath')
    movieSettings.savePath = fullfile(SxParameters.pathData,inputSettings.movieName);
end

if any(strcmpi(fieldnames(movieSettings),'mask43Lim'))
    if numel(movieSettings.mask43Lim) ~= 2
        error('Temperature masking limits must contain a single value for Minimum and a single value for Maximum')
    end
    if isequal(movieSettings.mask43Lim(1), movieSettings.mask43Lim(2))
        error('Temperature masking limits provided cannot have minimum value equal to maximum value')
    end
    movieSettings.mask43Lim = sort(movieSettings.mask43Lim);
end

if any(strcmpi(fieldnames(movieSettings),'mask43Additional'))
    if size(movieSettings.mask43Additional) ~= size(inputMatrix)
        error('Size of additional temperature mask matrix must be equal to temperature matrix [rows cols slice dyn]')
    end
end

end

function defaultSettings = getDefaultSettings(SxParameters, movieType)
% Defaults options
defaultSettings.mask = 0;
defaultSettings.maskColor = [0.4 0.4 0.4];
defaultSettings.firstSlice = 1;
defaultSettings.lastSlice = 12;
defaultSettings.frameRate = 5;
defaultSettings.displayRows = 2;
defaultSettings.displayCols = 6;
defaultSettings.zoomFactor = 3.5;
defaultSettings.recenterImages = 1;
defaultSettings.backgroundColor =   [0 0 0];
defaultSettings.foregroundColor =   [1 1 1];
defaultSettings.boundariesColor =   [0 0 0];
defaultSettings.angleColor =        [0 0 0];
defaultSettings.MTRcolor =          [0 0 0];
defaultSettings.simpleDisplay = 0;
defaultSettings.overwriteMovie = 0;
defaultSettings.movieName = strjoin([SxParameters.PatientID,"_",movieType,".mp4"], '');
defaultSettings.savePath = fullfile(SxParameters.pathData,defaultSettings.movieName);
defaultSettings.firstDyn = 1;
defaultSettings.mask43Lim = [20 43];
defaultSettings.greyscalePercentileLimits = [0.001 0.997];
end

function structout = setstructfields(structin, newfields)
%SETSTRUCTFIELDS Set fields of a structure using another structure
%   SETSTRUCTFIELDS(STRUCTIN, NEWFIELDS) Set fields of STRUCTIN using
%   another structure NEWFIELDS fields.  If fields exist in STRUCTIN
%   but not in NEWFIELDS, they will not be changed.

%   Author(s): J. Schickler
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.3.4.3 $  $Date: 2007/12/14 15:16:12 $

narginchk(2,2);

% Set the output to the input
structout = structin;

% If newfields is not a structure return
if ~isstruct(newfields), return; end

% Loop over all the fields of newfields and assign them to the output
fields = fieldnames(newfields);
for i = 1:length(fields)
    value = newfields.(fields{i});
    if isstruct(value) && isfield(structout, fields{i}) && isstruct(structout.(fields{i}))
        structout.(fields{i}) = setstructfields(structout.(fields{i}), value);
    else
        structout.(fields{i}) = newfields.(fields{i});
    end
end
end

function [elementFrequencies, normalizedElementPowers] = getHardwareInfo(SxParameters)
load(fullfile(SxParameters.pathData,'HardwareInfo.mat'));
HardwareInfo = HardwareInfo(~isnan(HardwareInfo.ElapsedTime_sec),:);
[~,uniqueIdx] = unique(HardwareInfo{:,2},'legacy');

elementFrequencies  = [ HardwareInfo.Frequency_E1 HardwareInfo.Frequency_E2 HardwareInfo.Frequency_E3 HardwareInfo.Frequency_E4...
    HardwareInfo.Frequency_E5 HardwareInfo.Frequency_E6 HardwareInfo.Frequency_E7 HardwareInfo.Frequency_E8...
    HardwareInfo.Frequency_E9 HardwareInfo.Frequency_E10];
elementPowers       = [ HardwareInfo.PowerNetWa_E1 HardwareInfo.PowerNetWa_E2 HardwareInfo.PowerNetWa_E3 HardwareInfo.PowerNetWa_E4...
    HardwareInfo.PowerNetWa_E5 HardwareInfo.PowerNetWa_E6 HardwareInfo.PowerNetWa_E7 HardwareInfo.PowerNetWa_E8...
    HardwareInfo.PowerNetWa_E9 HardwareInfo.PowerNetWa_E10];

elementFrequencies = elementFrequencies(uniqueIdx,:);
elementPowers = elementPowers(uniqueIdx,:);
normalizedElementPowers = elementPowers./max(elementPowers(:));
end

function GreyscaleLimits = getGreyscaleLimits(Magnitude, PercentileLimits)
Magnitude = Magnitude(:);
Magnitude = sort(Magnitude(~isnan(Magnitude)));
thresholdIdx = fix(numel(Magnitude).*PercentileLimits);
GreyscaleLimits = Magnitude(thresholdIdx);
end

