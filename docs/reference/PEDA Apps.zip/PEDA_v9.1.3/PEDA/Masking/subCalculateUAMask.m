function mask = subCalculateUAMask(uaMaskRadius, voxelSize, numRows, numCols, uaPosX, uaPosY)

radiusPx = uaMaskRadius/voxelSize;

mask = zeros(numRows, numCols);

for m = 1:1:numRows
    
    for n = 1:1:numCols
        
        dist = ((uaPosX - n)^2 + (uaPosY - m)^2)^0.5;
        
        if dist > radiusPx
            mask(m,n) = 1;
        end
    end
end

mask = logical(mask);

end
