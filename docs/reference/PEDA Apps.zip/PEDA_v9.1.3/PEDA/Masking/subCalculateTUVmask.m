%% Generates a single dynamic TUV mask (any TUV pixel above 2degC)

function Mask = subCalculateTUVmask(Parameters)

TUV = importdata(fullfile(Parameters.pathData,'TUV.mat'));
Mask = true(Parameters.NumberOfCols,Parameters.NumberOfRows,Parameters.NumberSlices);
Mask(TUV(:,:,:,end)>Parameters.TUVThreshold) = 0;