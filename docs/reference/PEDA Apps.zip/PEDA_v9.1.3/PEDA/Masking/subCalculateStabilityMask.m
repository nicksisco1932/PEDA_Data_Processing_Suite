function mask = subCalculateStabilityMask(phaseDiff, prevPhaseDiff, stabTempThresh, tempConv)

phasethresh = stabTempThresh / tempConv; 

currentPhaseComplex = cos(phaseDiff) + sqrt(-1)*sin(phaseDiff);
prevPhaseComplex = cos(prevPhaseDiff) + sqrt(-1)*sin(prevPhaseDiff);

diffPhase = angle(currentPhaseComplex.*conj(prevPhaseComplex));    
mask = (abs(diffPhase) < abs(phasethresh));   

mask = logical(mask);

end