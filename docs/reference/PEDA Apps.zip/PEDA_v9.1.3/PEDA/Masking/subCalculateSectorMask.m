% == subCalculateSectorMask.m ================================================
% This function is called once per dynamic to generate the sector mask for
% each slice depending on where the UA is pointed.  The sector is a polygon
% bound by 4 sides.
%       1) outside: prostate boundary
%       2) inside: MTR - 2mm (i.e. eroded MTR)
%       3) Side 1: Starting at the UA center, a line is drawn with angle 
%                   ThermAngle + FanAngle deg.  It is then translated 2 mm normal to 
%                   ThermAngle + FanAngle deg (outward).  The line�s end points are 
%                   defined by its intersection with the prostate boundary and 
%                   the circle about the UA center with radius MTR - 2 mm 
%       4) Side 2: same as Side 1 except with ThermAngle - FanAngle deg
% 
% Inputs:  
%       - ThermAngle: [deg] angle at which the UA is pointed (corrected by BeamAngle offset measured on WTF)
%       - FanAngle: [deg] the sector is define +/- FanAngle about the ThermAngle (set to 15 deg in TDC 2.6.2)
%       - ux0: [px] UA center x position in pixel value
%       - uy0: [px] UA center y position in pixel value
%       - isUAactive: [binary] 12 element vector defining which elements are active.  Sector mask is only created for active elements
%       - MTRmm: [mm] Minimum Treatable Radius (set to 8 mm in TDC 2.6.2)
%       - DilateFactorMM: [mm] this serves 2 purposes, which are coupled but can be decoupled in the future.  This is the amount of erosion into the MTR the sector mask allows and it is also the distance outside of the +/- FanAngle the sector is dilated to include in the sector mask.  This factor is 2mm for both cases so it is coupled. into a single variable, but can easily be decoupled.
%       - ProstateBoundary: [px] 360x12 matrix defining the radius of the prostate boundary for each element in 1 degree angular steps
%       - PixelSize: [mm/px] conversion factor from mm to pixel size
%       - NumSlices: number of elements on the UA (set to 12)
%       - NumRows: number of rows in each slice (set to 128)
%       - NumCols: number of columns in each slice (set to 128)
%       - TUVMask: [binary] matrix with dimensions [NumRows, NumsCols, NumSlices].  This mask is created during the TUV stage where any pixel above 2 degC standard deviation in 25 dyns is masked.  This mask has the same dimensions as the Sector Mask and a logical AND is applied at the end to mask out the TUV Mask pixels with the Sector Mask.
% 
% Outputs:
%       - SectorMask: [binary] matrix with dimensions [NumRows, NumsCols, NumSlices].  The mask is created based on the enclosed polygon described above and a logical AND is applied with the TUV mask at the end.
% 
% By: Ben Leung
% Date: 25-APR-2018
% =========================================================================
function SectorMask = subCalculateSectorMask(ThermAngle, FanAngle, ux0, uy0, isUAactive, MTRmm, DilateFactorMM, ProstateBoundary, PixelSize, NumSlices, NumRows, NumCols, TUVMask)

%% Initialization
DilateFactorPx = DilateFactorMM/PixelSize;
MTRpx = MTRmm/PixelSize;
MTRe = MTRpx - DilateFactorPx; %[px] eroded MTR by the DilateFactor (eroded meaning MTRe < MTR.  It uses the DilateFactor because it can be considered dilation since the original boundary was the MTR and dilating the sector mask with an inner boundary of the MTR would move the boundary inward toward the UA center).
if length(ux0) == 1
    ux0 = repmat(ux0,NumSlices,1);
    uy0 = repmat(uy0,NumSlices,1);
end
%% Calculate sector mask
% Definitions:  suffix "_i" means the pixel of interest (e.g. r_i, theta_i)
%               suffix "_p" means prostate
% Steps:
%   Raster scan each pixel with polar coords [theta_i,r_i] from UA center
%       Define phi = asin(1/r_i): depends on pixel of interest
%           If rMTRe < r_i < r_p (inside prostate, outside eroded MTR) = 1
%           If ThermAngle-FanAngle > theta_i > ThermAngle+FanAngle (outside regular sector) = 0
%           If theta_i < (ThermAngle+FanAngle+phi) AND theta_i > (ThermAngle-FanAngle-phi) = 1 (within dilated sector; this encapsulates previous condition)


SectorMask = false(NumRows,NumCols,NumSlices);

for sliceIdx = 1:NumSlices
    if isUAactive(sliceIdx)
        % define a search area for sector mask
        MaxR_i(sliceIdx) = max(ProstateBoundary(:,sliceIdx));
        x1 = floor(ux0(sliceIdx) - MaxR_i(sliceIdx));
        x2 = ceil( ux0(sliceIdx) + MaxR_i(sliceIdx));
        y1 = floor(uy0(sliceIdx) - MaxR_i(sliceIdx));
        y2 = ceil( uy0(sliceIdx) + MaxR_i(sliceIdx));
        % raster scan the points in search area
        for col = x1:x2
            for row = y1:y2
                % convert point of interest to polar coordinates
                xi = col-(ux0(sliceIdx));
                yi = -(row-(uy0(sliceIdx)));
                r_i = sqrt(xi.^2 + yi.^2);
                theta_i = atan2(yi,xi)*180/pi; %[deg]
                if theta_i < 0
                    theta_i = theta_i + 360;
                end
                % interpolate prostate radius at current angle
                nextTheta = ceil(theta_i) + 1; % theta_i is between [0;359], but indexing requires values [1;360]
                previousTheta = floor(theta_i) + 1;
                nextRadius = ProstateBoundary(wrapTo360(nextTheta),sliceIdx); %WrapTo360 yields 1 if nextTheta+1 == 361
                previousRadius = ProstateBoundary(previousTheta,sliceIdx); 
                
                if nextTheta == previousTheta % In other words, no interpolation is required since it falls on an actual point
                    r_p = ProstateBoundary(previousTheta,sliceIdx);
                else
                    slope = (nextRadius-previousRadius)/(nextTheta - previousTheta);
                    r_p = previousRadius+(theta_i+1-previousTheta)*slope;
                end

                % If rMTRe < r_i < r_p (inside prostate, outside eroded MTR)
                if r_i >= MTRe && r_i <= r_p
                    phi = asin(1/r_i)*180/pi; %[deg]
                    % wrap search angle if necessary
                    if ThermAngle+FanAngle+phi > 360 && theta_i < ThermAngle-FanAngle-phi
                        theta_i = theta_i + 360;
                    elseif ThermAngle-FanAngle-phi < 0 && theta_i > ThermAngle+FanAngle+phi
                        theta_i = theta_i - 360;
                    end
                    % If theta_i < (ThermAngle+FanAngle+phi) AND theta_i > (ThermAngle-FanAngle-phi) (within dilated sector)
                    if theta_i < (ThermAngle+FanAngle+phi) && theta_i > (ThermAngle-FanAngle-phi)
                        SectorMask(row,col,sliceIdx) = 1;
                    end
                    
                end

            end
        end
    end
end

SectorMask = logical(SectorMask) & logical(TUVMask);