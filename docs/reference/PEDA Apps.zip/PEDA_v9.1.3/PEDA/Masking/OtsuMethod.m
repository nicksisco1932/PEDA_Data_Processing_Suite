function thresh = OtsuMethod(magImage, exclusionRadiusPixels, exclusionCentrePixels)

magList = []; % empty list
exclusionRadiusSquared = exclusionRadiusPixels * exclusionRadiusPixels;
for xIndex = 1:size(magImage,1)
  deltaX = xIndex - exclusionCentrePixels(1);
  deltaXsquared = deltaX * deltaX;
  for yIndex = 1:size(magImage,2)
    deltaY = yIndex - exclusionCentrePixels(2);
    deltaYsquared = deltaY * deltaY;
    if (deltaXsquared + deltaYsquared > exclusionRadiusSquared)
      magList = [magList, magImage(xIndex, yIndex)];  % Append
    end
  end
end

[h,x] = hist(magList,256); % 256 bins, h is the counts, x the centres

total = sum(h); % should equal the total length of magList

q1 = zeros(256,1);
q1(1) = h(1);

q2 = zeros(256,1);
q2(1) = total - q1(1);

u1 = zeros(256,1);
u1(1) = x(1);

u2 = zeros(256,1);

summ = 0;

for i = 2:1:256
    summ = h(i)*x(i) + summ;
end

u2(1) = summ/q2(1);

sigma = zeros(256,1);
sigma(1) = q1(1)*(total - q1(1))*(u1(1) - u2(1))^2;

for t=1:1:255

    q1(t+1) = q1(t) + h(t+1);
    q2(t+1) = total - q1(t+1);
    
    if (q2(t+1) ~= 0)
    
        u1(t+1) = (q1(t)*u1(t) + x(t+1)*h(t+1))/q1(t+1);
        u2(t+1) = (q2(t)*u2(t) - x(t+1)*h(t+1))/q2(t+1);
        
        sigma(t+1) = q1(t+1)*q2(t+1)*(u1(t+1) - u2(t+1))^2;
        
    else
    
        sigma(t+1) = 0;
        
    end   
    
end

ind = find(sigma == max(sigma));
thresh = x(ind); % the centre value for the bin with the maximum sigma

end