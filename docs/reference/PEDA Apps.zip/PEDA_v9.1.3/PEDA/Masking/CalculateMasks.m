function mask = CalculateMasks(phaseDiff, prevPhaseDiff, magStack, uaMaskRadius, ...
    voxelSize, uaPosX, uaPosY, rectumHalfWidth, stabTempThresh, tempConv, ...
    exclusionRadiusMillimetres)

maskSNR = subCalculateSNRMask(magStack, exclusionRadiusMillimetres / voxelSize, ...
    [uaPosX uaPosY]);
maskUA = subCalculateUAMask(uaMaskRadius, voxelSize, size(phaseDiff,1), size(phaseDiff,2), uaPosX, uaPosY);
maskRectum = subCalculateRectumMask(voxelSize, size(phaseDiff,1), size(phaseDiff,2), rectumHalfWidth, uaPosX, uaPosY);
maskStability = subCalculateStabilityMask(phaseDiff, prevPhaseDiff, stabTempThresh, tempConv);
mask = maskUA & maskRectum & maskSNR & maskStability;

end
