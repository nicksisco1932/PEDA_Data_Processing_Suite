function mask = subCalculateSNRMask(magStack, exclusionRadiusPixels, exclusionCentrePixels)
       
data = magStack;
thresh = OtsuMethod(data, exclusionRadiusPixels, exclusionCentrePixels);
mask = data >= round(min(thresh));

end