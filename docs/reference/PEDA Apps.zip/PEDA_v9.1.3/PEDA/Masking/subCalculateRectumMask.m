function mask = subCalculateRectumMask(voxelSize, numRows, numCols, rectumHalfWidth, uaPosX, uaPosY)

halfwidthPx = rectumHalfWidth/voxelSize;

mask = zeros(numRows, numCols);

for m = 1:1:numRows
    
    for n = 1:1:numCols
        
        distX = abs(uaPosX - n); 
        
        if (distX > halfwidthPx) || (m < uaPosY)
            mask(m,n) = 1;
        end
        
    end
end

mask = logical(mask);

end