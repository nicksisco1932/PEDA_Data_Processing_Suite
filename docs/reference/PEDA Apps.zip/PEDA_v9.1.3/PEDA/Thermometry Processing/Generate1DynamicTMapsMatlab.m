function [TMap, intermediateMatrices] = Generate1DynamicTMapsMatlab(currentDynamic, currentMagnitudes, currentPhases, driftCorrection, refPhaseStack, maskUA, maskRectum)
% Generate1DynamicTMaps generates the tMaps for all the slices in 1 dynamic
% based on phase data input.  Input phase data has int values from 0 to 4095.
%
% This function does NOT correct for image shift.
% DO NOT modify this function as it is used for verification of TDC MRI
% cartridges. If it needs to be modified, advise the Software Team as the
% same modification needs to be applied to the TDC codebase.

global gc;
persistent referenceMagnitudes referencePhases totalMask refPhase prevPhaseDiffUnwrap prevPhaseDiffCorr cumulativeMask beta;

numRows = size(currentPhases, 1);
numCols = size(currentPhases, 2);
numSlices = size(currentPhases, 3);

if isempty(referenceMagnitudes)
    referenceMagnitudes = zeros(numRows, numCols, numSlices, gc.numRefImages);
end
if isempty(referencePhases)
    referencePhases = zeros(numRows, numCols, numSlices, gc.numRefImages);
end
if isempty(cumulativeMask)
    cumulativeMask = ones(numRows, numCols, numSlices);
end
if isempty(totalMask)
    totalMask = ones(numRows, numCols, numSlices);
end
if isempty(refPhase)
    refPhase = ones(numRows, numCols, numSlices);
end
if isempty(beta)
    beta = zeros(6, numSlices);
end

phaseDiff = zeros(numRows, numCols, numSlices);
phaseDiffUnwrapDriftCorrected = zeros(numRows, numCols, numSlices);
phaseDiffUnwrap = zeros(numRows, numCols, numSlices);
phaseDiffUnwrapDriftCorrectedUnwrap = zeros(numRows, numCols, numSlices);
maskSNR = zeros(numRows, numCols, numSlices);
maskStability = zeros(numRows, numCols, numSlices);
staticMasks = zeros(numRows, numCols, numSlices);
% beta = zeros(6,1);

hotThreshold = 120;
coldThreshold = 0;

hotBound = (hotThreshold - gc.baseTemp) / gc.TempConv;
coldBound = (coldThreshold - gc.baseTemp) / gc.TempConv;
if (hotBound > coldBound)
    maxBound = hotBound;
    minBound = coldBound;
else
    maxBound = coldBound;
    minBound = hotBound;
end

phasesRadians = ConvertPhaseRadians(currentPhases,gc.pipeline);
    
%========================================
% Acquiring reference matrices
%========================================
if (currentDynamic <= gc.numRefImages)
    referenceMagnitudes(:, :, :, currentDynamic) = currentMagnitudes;
    referencePhases(:, :, :, currentDynamic) = phasesRadians;
end

if (currentDynamic == gc.numRefImages)
    refPhase = CalculateReference(referenceMagnitudes, referencePhases);
end

%========================================
% TMap processing
%========================================
if (currentDynamic > gc.numRefImages)
    if ~isempty(refPhaseStack)
        phaseDiff = PhaseDifference(phasesRadians, refPhaseStack(:,:,:,currentDynamic));
    else
        phaseDiff = PhaseDifference(phasesRadians, refPhase);
    end
    
    for sliceIdx = 1:12
        % Phase unwrap
        if (currentDynamic == gc.numRefImages + 1)
            prevPhaseDiffUnwrap = phaseDiff;
        end
        phaseDiffUnwrap(:,:,sliceIdx) = PhaseUnwrap(phaseDiff(:,:,sliceIdx), prevPhaseDiffUnwrap(:,:,sliceIdx));
        
        % Update masks
        maskSNR(:,:,sliceIdx) = subCalculateSNRMask(currentMagnitudes(:,:,sliceIdx),25,[64 64]);
        maskStability(:,:,sliceIdx) = subCalculateStabilityMask(phaseDiffUnwrap(:,:,sliceIdx), prevPhaseDiffUnwrap(:,:,sliceIdx), gc.tempthresh, gc.TempConv);
        cumulativeMask(:,:,sliceIdx) = cumulativeMask(:,:,sliceIdx) & maskSNR(:,:,sliceIdx) & maskStability(:,:,sliceIdx);
        staticMasks(:,:,sliceIdx) = maskUA(:,:,sliceIdx) & maskRectum(:,:,sliceIdx);
        
        totalMask(:,:,sliceIdx) = cumulativeMask(:,:,sliceIdx) & staticMasks(:,:,sliceIdx);

        % Drift correct
        [phaseDiffUnwrapDriftCorrected(:,:,sliceIdx)] = driftCorrection(phaseDiffUnwrap(:,:,sliceIdx), totalMask(:,:,sliceIdx));
        
        % Phase unwrap
        if currentDynamic == gc.numRefImages + 1
            prevPhaseDiffCorr(:,:,sliceIdx) = phaseDiffUnwrapDriftCorrected(:,:,sliceIdx);
        end
        phaseDiffUnwrapDriftCorrectedUnwrap(:,:,sliceIdx) = BoundedPhaseUnwrap(phaseDiffUnwrapDriftCorrected(:,:,sliceIdx), prevPhaseDiffCorr(:,:,sliceIdx), maxBound, minBound);
    end
end

% Convert to temperature
TMap = ConvertToTemp(phaseDiffUnwrapDriftCorrectedUnwrap, gc.TempConv, gc.baseTemp);

% Pass to next loop
prevPhaseDiffUnwrap = phaseDiffUnwrap;
prevPhaseDiffCorr = phaseDiffUnwrapDriftCorrectedUnwrap;

% Assign additional outputs
intermediateMatrices = {totalMask, phaseDiff, phaseDiffUnwrap, phaseDiffUnwrapDriftCorrected, phaseDiffUnwrapDriftCorrectedUnwrap, maskSNR, maskStability, beta};
end
