function [shiftedUAX,shiftedUAY] = calculateUACenterShifts(UAX, UAY, xShifts, yShifts, numberOfDynamics, shiftPattern)
%============================
% Variable initialization
%============================
totalNumberOfShifts = size(xShifts,1);

if totalNumberOfShifts == 0
    % No image shift here. Just return the input matrix
    shiftedUAX = repmat(UAX,numberOfDynamics,1); 
    shiftedUAY = repmat(UAY,numberOfDynamics,1); 
    return
else
    % Nothing on the first 105 dynamics
    shiftedUAX = zeros(numberOfDynamics,12);
    shiftedUAY = zeros(numberOfDynamics,12);
    
    for sliceIdx = 1:12
        shiftedUAX(1:100 + shiftPattern(sliceIdx),sliceIdx) = repmat(UAX(sliceIdx),100 + shiftPattern(sliceIdx),1); 
        shiftedUAY(1:100 + shiftPattern(sliceIdx),sliceIdx) = repmat(UAY(sliceIdx),100 + shiftPattern(sliceIdx),1);
    end

    tempUAX = zeros(1,12);
    tempUAY = zeros(1,12);
end
%============================
% Main loop
%============================
for shiftIndex = 1:totalNumberOfShifts
    
    % Get the cumulative X and Y shifts
    cumulativeXShifts = sum(xShifts(1:shiftIndex,:),1);
    cumulativeYShifts = sum(yShifts(1:shiftIndex,:),1);
    
    for sliceIdx = 1:size(xShifts,2)
        % Get vector of dynamics, starting at 106, 206... up to min(205,size(stack)), min(305,size(stack))...
        interpolationInterval = ((shiftIndex)*100+shiftPattern(sliceIdx)):min([((shiftIndex+1)*100+shiftPattern(sliceIdx)-1) numberOfDynamics]);
        
        if abs(cumulativeXShifts(sliceIdx)) >= 0.1 || abs(cumulativeYShifts(sliceIdx)) >= 0.1
            tempUAX(:,sliceIdx) = UAX(sliceIdx) + cumulativeXShifts(sliceIdx);
            tempUAY(:,sliceIdx) = UAY(sliceIdx) + cumulativeYShifts(sliceIdx);
        else
            tempUAX(:,sliceIdx) = UAX(sliceIdx);
            tempUAY(:,sliceIdx) = UAY(sliceIdx);
        end
        % ... and copy the results to the other 104 dynamics left
        shiftedUAX(interpolationInterval,sliceIdx) = repmat(tempUAX(sliceIdx),interpolationInterval(end)-interpolationInterval(1) + 1,1);
        shiftedUAY(interpolationInterval,sliceIdx) = repmat(tempUAY(sliceIdx),interpolationInterval(end)-interpolationInterval(1) + 1,1);
    end
    
end