function interpolatedImageStack = applyShift(imageStack, xShift, yShift, interpolationType)
    
%============================
% Variable initialization
%============================
totalNumberOfShifts = ceil((size(imageStack,4) - 105)/100); %Returns 0 if < 106, 1 if >= 106 & < 206, 2 if >= 206 & < 360, etc...

if totalNumberOfShifts == 0
    % No image shift here. Just return the input matrix
    interpolatedImageStack = imageStack; 
    return
end

interpolatedImageStack = zeros(size(imageStack,1),size(imageStack,2),size(imageStack,3),size(imageStack,4));

if strcmpi(interpolationType ,'Magnitude')
    % Create 128x128 grid
    [xGrid, yGrid] = deal(ndgrid(1:size(imageStack,1))); 
    % Create interpolant object
    magnitudeInterpolant = griddedInterpolant({xGrid, yGrid, 1:size(imageStack,3),1:size(imageStack,4)},imageStack,'linear','none'); 
elseif strcmpi(interpolationType ,'Phase')
    % Phase interpolation only works with radians
    imageStack = ConvertPhaseRadians(imageStack);
end

% No interpolation on the first 105 dynamics
interpolatedImageStack(:,:,:,1:105) = imageStack(:,:,:,1:105);


%============================
% Main loop
%============================
for shiftIndex = 1:totalNumberOfShifts
    % Get vector of dynamics, starting at 106, 206... up to min(205,size(stack)), min(305,size(stack))...
    interpolationInterval = ((shiftIndex)*100+6):min([((shiftIndex+1)*100+5) size(imageStack,4)]); 
    
    % Get the cumulative X and Y shifts
    cumulativeXShifts = sum(xShift(1:shiftIndex,:),1);
    cumulativeYShifts = sum(yShift(1:shiftIndex,:),1);
    
    for sliceIdx = 1:size(imageStack,3)
        if abs(cumulativeXShifts(sliceIdx)) >= 0.1 || abs(cumulativeYShifts(sliceIdx)) >= 0.1
            if strcmpi(interpolationType ,'Magnitude') %Fast
                % Shift the interpolation grid
                shiftedInterpolationGrid = {xGrid+cumulativeYShifts(sliceIdx) yGrid+cumulativeXShifts(sliceIdx) sliceIdx interpolationInterval};
                % Return interpolated values using the interpolant object
                interpolatedImageStack(:,:,sliceIdx,interpolationInterval) = magnitudeInterpolant(shiftedInterpolationGrid);
            elseif strcmpi(interpolationType ,'Phase') %Slow...
                % Housemade function that takes into account phase wraps... This needs to be optimized
                interpolatedImageStack(:,:,sliceIdx,interpolationInterval) = shiftMatrix(imageStack(:,:,sliceIdx,interpolationInterval),cumulativeXShifts(sliceIdx),cumulativeYShifts(sliceIdx));
            end
        end
    end
end

if strcmpi(interpolationType ,'Magnitude') 
    %Because griddedInterpolant uses NaN for edges, we need to replace them with zeros
    interpolatedImageStack(isnan(interpolatedImageStack)) = 0;
elseif strcmpi(interpolationType ,'Phase')
    %Convert back to phase values to stay consistent
    interpolatedImageStack = ConvertRadiansPhase(imageStack); 
end




