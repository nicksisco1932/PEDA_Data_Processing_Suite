% In this approach we take the FFT of the two images, then embed them into
% a larger zero-filled matrix. This is a zero-padding operation and
% equivalent to interpolating in the image domain. Then the
% cross-correlation is performed and the peak extracted.
%

function [cs, rs] = method_zpad (img, img2, sf)

[r,c] = size(img);


k1 = fft2(img);
k2 = fft2(img2);

kz1 = zeros(sf*r,sf*c);
kz2 = zeros(sf*r,sf*c);

rr = sf*r;
cc = sf*c;

% Lets assuming square (easy enough to generalize...)
ed = rr - (r/2); 
mp = r / 2;  

% These steps for embedding the FFT'd matrix into the zero-pad 
% matrix are dependent on the FFT implemention (so MATLAB's in this case)
kz1(1:mp,1:mp) = k1(1:mp,1:mp);
kz1(ed+1:end,1:mp) = k1(mp+1:end,1:mp);
kz1(1:mp,ed+1:end) = k1(1:mp,mp+1:end);
kz1(ed+1:end,ed+1:end) = k1(mp+1:end,mp+1:end);

kz2(1:mp,1:mp) = k2(1:mp,1:mp);
kz2(ed+1:end,1:mp) = k2(mp+1:end,1:mp);
kz2(1:mp,ed+1:end) = k2(1:mp,mp+1:end);
kz2(ed+1:end,ed+1:end) = k2(mp+1:end,mp+1:end);


% The magic happens here (Fourier xcorr theorem)
CC = ifft2(kz1.*conj(kz2));


% Find the location of the peak
[~,b] = max(abs(CC(:)));
[ri,ci] = ind2sub_pl([rr cc],b);

% Return the coordinates in the original image - need to account for what
% quadant the xcorr peak falls in...

%% Before TDC 2.7, use this section - see TDC-4524 for more information
% if (ri < rr/2)
%     rs = double((-ri+1) / single(sf));
% else
%     rs = double((rr-ri+1)/single(sf));
% end
% 
% if (ci < cc/2)
%     cs = double((-ci+1) / single(sf));
% else
%     cs = double((cc-ci+1)/single(sf));
% end

%% After TDC 2.7, use this section - see TDC-4524 for more information
if (ri < rr/2)
    rs = (-ri+1) / sf;
else
    rs = (rr-ri+1)/sf;
end

if (ci < cc/2)
    cs = (-ci+1) / sf;
else
    cs = (cc-ci+1)/sf;
end


end

function [rows,cols] = ind2sub_pl (sz,ind)
% mod and ceil I think are standard c functions...
rows = mod(ind, sz(1));
cols = ceil( ind / sz(1));
end