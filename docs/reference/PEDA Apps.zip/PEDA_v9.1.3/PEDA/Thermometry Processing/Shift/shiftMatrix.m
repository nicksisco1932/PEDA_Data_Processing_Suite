function shiftedMatrix = shiftMatrix(imageStack, xShifts, yShifts)

shiftedMatrix = zeros(size(imageStack,1),size(imageStack,2),1,size(imageStack,4));

for dynIdx = 1:size(imageStack,4)
    for row = 1:size(imageStack,1)
        for col = 1:size(imageStack,2)
            shiftedMatrix(row,col,1,dynIdx) = Interpolate2dCircular(imageStack(:,:,:,dynIdx), col - xShifts, row - yShifts);
        end
    end
end