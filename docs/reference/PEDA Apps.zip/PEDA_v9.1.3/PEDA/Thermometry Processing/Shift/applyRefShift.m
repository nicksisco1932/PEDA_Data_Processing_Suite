function interpolatedImageStack = applyRefShift(refImageStack, xShift, yShift, numDynamics, shiftPattern)

%============================
% Variable initialization
%============================
totalNumberOfShifts = ceil((numDynamics - 105)/100); %Returns 0 if < 106, 1 if >= 106 & < 206, 2 if >= 206 & < 360, etc...

if totalNumberOfShifts == 0
    % No image shift here. Just return the input matrix
    interpolatedImageStack = repmat(refImageStack,1,1,1,numDynamics); 
    return
else
    % No interpolation on the first 105 dynamics
    interpolatedImageStack = zeros(128,128,12,105);
    for sliceIdx = 1:12
        interpolatedImageStack(:,:,sliceIdx,6:100 + shiftPattern(sliceIdx) - 1) = repmat(refImageStack(:,:,sliceIdx),1,1,1,100 + shiftPattern(sliceIdx) - 6); 
    end
    interpolatedSliceStack = zeros(128,128,12);
end

%============================
% Main loop
%============================
for shiftIndex = 1:totalNumberOfShifts
    % Get the cumulative X and Y shifts
    cumulativeXShifts = sum(xShift(1:shiftIndex,:),1);
    cumulativeYShifts = sum(yShift(1:shiftIndex,:),1);
    
    for sliceIdx = 1:size(refImageStack,3)
        % Get vector of dynamics, starting at 106, 206... up to min(205,size(stack)), min(305,size(stack))...
        interpolationInterval = ((shiftIndex)*100+shiftPattern(sliceIdx)):min([((shiftIndex+1)*100+shiftPattern(sliceIdx)-1) numDynamics]);
        
        if abs(cumulativeXShifts(sliceIdx)) >= 0.1 || abs(cumulativeYShifts(sliceIdx)) >= 0.1
            % Only need to interpolate one dynamic...
            interpolatedSliceStack(:,:,sliceIdx) = shiftMatrix(refImageStack(:,:,sliceIdx),cumulativeXShifts(sliceIdx),cumulativeYShifts(sliceIdx));
        else
            interpolatedSliceStack(:,:,sliceIdx) = refImageStack(:,:,sliceIdx);
        end
        % ... and copy the results to the other 104 dynamics left
        interpolatedImageStack(:,:,sliceIdx,interpolationInterval) = repmat(interpolatedSliceStack(:,:,sliceIdx),1,1,1,interpolationInterval(end)-interpolationInterval(1) + 1);
    end
    
end



