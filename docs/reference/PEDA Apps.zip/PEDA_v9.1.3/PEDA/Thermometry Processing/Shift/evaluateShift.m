function [xShifts, yShifts] = evaluateShift(Magnitude)

%============================
% Variable initialization
%============================
totalNumberOfShifts = ceil((size(Magnitude,4) - 105)/100); %Returns 0 if < 106, 1 if >= 106 & < 206, 2 if >= 206 & < 360, etc...
upsamplingFactor = 10;
xShifts = zeros(totalNumberOfShifts,12);
yShifts = zeros(totalNumberOfShifts,12);

if totalNumberOfShifts == 0
    return
end

%============================
% Main loop
%============================
for shiftIndex = 1:totalNumberOfShifts
    % Return vector [101, 102, 103, 104, 105], then [201, 202, 203, 204, 205]...
    currentDynamicInterval = (1:5) + shiftIndex*100;
    % Return vector [1, 2, 3, 4, 5] then [101, 102, 103, 104, 105]...
    referenceDynamicInterval = (1:5) + (shiftIndex-1)*100;
    
    for sliceIdx = 1:size(Magnitude,3)
        % Reference image is taken 100 dynamics before
        referenceImage = squeeze(mean(Magnitude(:,:,sliceIdx,referenceDynamicInterval),4));
        currentImage = squeeze(mean(Magnitude(:,:,sliceIdx,currentDynamicInterval),4));
        
        % Normalize images
        referenceImage = referenceImage./ max(abs(referenceImage(:)));
        currentImage = currentImage ./ max(abs(currentImage(:)));
        
        % Compute shift
        [xShifts(shiftIndex,sliceIdx), yShifts(shiftIndex,sliceIdx)] = method_zpad(referenceImage,currentImage,upsamplingFactor);
    end
end



