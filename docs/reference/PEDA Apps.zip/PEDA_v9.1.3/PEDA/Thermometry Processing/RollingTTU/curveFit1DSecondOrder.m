function fitMatrix = curveFit1DSecondOrder(inputMatrix)
%======================================
% function curveFit1DSecondOrder(); 
%
% Purpose:
% ========
% Fit a 2nd order fit to a curve
%
% Input(s):
% =========
% - inputMatrix: must have 3 "valid dimensions", i.e after squeeze, ndims(inputMatrix) = 3, and fit is done along the 3rd dimension. Exemple: size(inputMatrix) = [X,Y,1,WindowWidth]
%
% Output(s):
% ==========
% - fitMatrix, which is the fit, reshaped to the same size as inputMatrix.
%
%======================================
% Created By: Alexandre Bigot
%======================================

%==========================================================================
% Variable initialization
%==========================================================================
persistent vectorGrid vectorGridSquare 
windowWidth = size(inputMatrix,4);

Y = reshape(inputMatrix,size(inputMatrix,1)*size(inputMatrix,2),windowWidth)';

% Make Vandermonde matrix. Easy because sample rate is 1 (dynamic)
vector = 1:size(Y,1);
vandermondeMatrix = [ones(size(vector,2),1) vector' vector'.^2];

% Least-square method
beta = ((transpose(vandermondeMatrix)*vandermondeMatrix)\transpose(vandermondeMatrix))*Y;

if isempty(vectorGrid) % Initialize only once to speed up execution
    vectorGrid = meshgrid(1:size(Y,1),1:size(Y,2))';
    vectorGridSquare = vectorGrid.^2;
end

fit = beta(1,:) + beta(2,:).*vectorGrid + beta(3,:).*vectorGridSquare;

% Reshape into final matrix
fitMatrix = reshape(fit',size(inputMatrix,1),size(inputMatrix,2),size(inputMatrix,3), windowWidth);

