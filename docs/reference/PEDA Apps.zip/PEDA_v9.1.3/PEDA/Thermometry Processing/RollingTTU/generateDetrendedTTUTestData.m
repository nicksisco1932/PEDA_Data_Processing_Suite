%======================================
% Purpose:
% ========
% Generate rolling TTU maps, based on detrended TMaps
%
%======================================
% Created By: Alexandre Bigot
%======================================

%==========================================================================
% Variable initialization
%==========================================================================

% Load TMap. Assume *Current* files are in a folder called Input
mainPath = 'N:\Engineering\AlexB\_FromPeter\NewData\2017.11.07 -- 001-117';
TMap = LoadSessionFiles(fullfile(mainPath,'Input'),'Curr',100);

if ~exist(fullfile(mainPath,'Output'))
    mkdir(fullfile(mainPath,'Output'));
end
% %==========================================================================
% % Save some inputs (for unit tests)
% %==========================================================================
% for dynIdx = 1:NumberOfDynamics
%     CurrentTMap = TMap(:,:,1,dynIdx);    
% 
%     fid = fopen(fullfile(mainPath,['Input\TMapMatI1S' num2str(dynIdx) '.dat']), 'w'); %notice the transpose operator '
%     fwrite(fid, CurrentTMap', 'single'); % double ???
%     fclose(fid);
% end

%==========================================================================
% Perform calculations
%==========================================================================
fprintf('Calculating TTU Map...\n')
TTUMap = calculateDetrendedTTUMap(TMap);

%==========================================================================
% Save results (for unit tests)
%==========================================================================
fprintf('Writing TTU files...')
fprintf('    ');
for dynIdx = 1:60 %size(TTUMap,4)
    for sliceIdx = 1:size(TTUMap,3)
        %TDC is zero-based
        filename = sprintf('i%04d-s%02d-TTUMatlab.dat',dynIdx-1,sliceIdx-1);
        
        fid = fopen(fullfile(fullfile(mainPath,'Output'),filename),'w');        
        if fid ~= -1
            fwrite(fid,TTUMap(:,:,sliceIdx,dynIdx)','float');
        end
        fclose(fid);
        progressPercentage = min(round(dynIdx/size(TTUMap,4)*100),100);
        backspaceChars = repmat('\b',1,length(num2str(progressPercentage))+1);
        fprintf([backspaceChars '%d%%'],progressPercentage);
    end
end
fprintf(' - %d dynamics written\n',dynIdx);
% fid = fopen(fullfile(mainPath,'Output\Element1_LastTtu.dat'), 'w');
% fwrite(fid, Element1_LastTtu', 'single');  
% fclose(fid);
% 
% fprintf('Saving results...\n')
% save(fullfile(mainPath,['Output\rollingTTU-' num2str(TTURollingWindowWidth) '-' num2str(detrendedWindowWidth) '-' num2str(fitOrder) '.mat']),'rollingTTU')
% save(fullfile(mainPath,['Output\detrendedTMap-' num2str(TTURollingWindowWidth) '-' num2str(detrendedWindowWidth) '-' num2str(fitOrder) '.mat']),'detrendedTMap')

%{ 
%% Show some results
% Single slice
hFig = figure; % Matlab built-in
sliceIdx = 1;
dynIdx = NumberOfSamples - 1;
imshow(rollingTTU(:,:,sliceIdx,dynIdx));
colormap(gca,CreateColormap('TUV'));
caxis(gca,[0 6]);
colorbar;

% Multi-slice
dynIdx = NumberOfSamples - 1;
for sliceIdx = 1:12
    initializeSubplots(sliceIdx);
    imshow(rollingTTU(:,:,sliceIdx,dynIdx));
    colormap(gca,CreateColormap('TUV'));
    caxis(gca,[0 6]);
    if sliceIdx == 12
        colorbar;
    end
end
%}