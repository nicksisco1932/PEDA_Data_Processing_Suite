function [TTUMap, detrendedTMap, trendTMap] = calculateDetrendedTTUMap(TMap, order, detrendedWindowWidth)
%======================================
% function calculateTTUMap 
%
% Purpose:
% ========
% Detrend TMap by computing a linear fit of the temperature values, and then substracting the fit from the actual values
%
% Input(s):
% =========
% - TMap: size is [NRows, NCols, NSlices, NDyns]
% - fitWindowWidth: width of the window across which fit is performed
% - order: 1 for 1st order fit, 2 for 2nd order fit
% - Mask: optional. If specified, will only performed fit on the unmasked pixels
%
% Output(s):
% ==========
% - TTUMap: standard deviation of the detreandedTMap
% - detrendedTMap: equal to (TMap - trendTMap)
% - trendTMap: is the result of the fit
%
%======================================
% Created By: Alexandre Bigot
%======================================

%==========================================================================
% Variable initialization
%==========================================================================
switch nargin
    case 1
        detrendedWindowWidth = 15;
        order = 1;
    case 2
        detrendedWindowWidth = 15;
    case 3
    otherwise
        error('Error in the function inputs')
end

detrendedTMap = zeros(size(TMap));
trendTMap = zeros(size(TMap));
TTUMap = zeros(size(TMap));

%==========================================================================
% Generate detrended maps
%==========================================================================
for sliceIdx = 1:12
    rollingWindow = -1;
    for dynIdx = 1:size(TMap,4)
        
        if ~any(any(TMap(:,:,sliceIdx,dynIdx))) %TMap is all zeros
            continue
        end
        
        % Grow vector
        if rollingWindow == -1
            rollingWindow = dynIdx;
            continue
        else
            rollingWindow = [rollingWindow dynIdx];
        end
        
        % Once it reached the desired size, just discard the first element of the vector
        if numel(rollingWindow) == detrendedWindowWidth + 1
            rollingWindow = rollingWindow(2:end);
        elseif numel(rollingWindow) < detrendedWindowWidth
            continue
        end
               
        % Perform linear fit
        if order == 1
            tempTrend = curveFit1DFirstOrder(TMap(:,:,sliceIdx,rollingWindow));
        elseif order == 2
            tempTrend = curveFit1DSecondOrder(TMap(:,:,sliceIdx,rollingWindow));
        end

        trendTMap(:,:,sliceIdx,rollingWindow) = tempTrend;
        detrendedTMap(:,:,sliceIdx,rollingWindow) = TMap(:,:,sliceIdx,rollingWindow) - tempTrend;
        TTUMap(:,:,sliceIdx,rollingWindow(end)) = std(detrendedTMap(:,:,sliceIdx,rollingWindow),0,4);
    end
end
