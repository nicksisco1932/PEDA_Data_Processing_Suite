function [magImage, phaseImage] = LoadDICOMDataMTR(inputDirectory)

global gc

gc.NumDynamic = 200;
gc.NumRows = 108;
gc.NumCols = 128;
gc.TE = 8.1;

gc.UAX = 66; %c# zero index
gc.UAY = 55; %c# zero index

load(strcat(inputDirectory, '\Data_0011_EPI_DRIFTTEST'));

magImage = Data(:,:,:,:,1);
phaseImage = Data(:,:,:,:,2);

end