function result = Interpolate2dLinear(T, xx, yy)
%==========================================================================
% function result = interpolate2d(T, xx, yy)
%
% Purpose:
% ========
%     Interpolates points on a 2D image.
%
% Input(s):
% =========
%     T:       2D Matrix where the interpolation is performed
%     xx, yy:  x and y coordinates where for which we want the interpolated
%              value
%
% Output(s):
% ==========
%
%
%==========================================================================
% Author: Michael Sprague
% Created: July 16 2014
%
%==========================================================================

result = [];

 for i = 1:length(xx)
       
      xt = xx(i);
      yt = yy(i);
      
      x1 = floor(xt);
      x2 = ceil(xt);
      y1 = floor(yt);
      y2 = ceil(yt);
      
      if (x1 == x2 && y1 == y2)
         result_t = T(y1,x1);
      elseif (y1 == y2)
         result_t = T(y1,x2)*(xt-x1) + T(y1,x1)*(x2-xt); 
      elseif (x1 == x2)
         result_t = T(y1,x1)*(y2-yt) + T(y2,x1)*(yt-y1);
      else
        r1 = T(y1,x1)*(y2-yt)*(x2-xt);
        r2 = T(y2,x1)*(yt-y1)*(x2-xt);
        r3 = T(y1,x2)*(y2-yt)*(xt-x1);
        r4 = T(y2,x2)*(yt-y1)*(xt-x1);
        result_t = r1 + r2 + r3 + r4;
      end
      
      result = [result; result_t];
 end

 return;