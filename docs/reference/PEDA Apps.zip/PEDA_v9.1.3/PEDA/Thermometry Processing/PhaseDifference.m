function differences = PhaseDifference(phases, refPhase)
currentComplexImage = cos(phases) + 1i*sin(phases);
refComplexImage =     cos(refPhase) - 1i*sin(refPhase);

differences = angle(currentComplexImage .* refComplexImage);

end