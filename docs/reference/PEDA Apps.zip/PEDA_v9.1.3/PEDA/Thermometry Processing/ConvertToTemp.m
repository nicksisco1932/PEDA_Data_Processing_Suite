function tMap = ConvertToTemp(phaseDiffCorr, tempConv, baseTemp)

tMap = phaseDiffCorr*tempConv + baseTemp;

end