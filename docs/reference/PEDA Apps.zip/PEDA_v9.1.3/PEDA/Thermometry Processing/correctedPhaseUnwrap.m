function phaseUnwrap = correctedPhaseUnwrap(phaseDiff, prevPhaseDiff, mask, hotThreshold, coldThreshold)
global gc

diffPhase = phaseDiff - prevPhaseDiff;
phaseUnwrapOffset = round(diffPhase / (2 * pi))*-2*pi;

tempPhaseUnwrap = phaseDiff + phaseUnwrapOffset;

% Convert to temp
tempTMap = ConvertToTemp(tempPhaseUnwrap,gc.TempConv,gc.baseTemp);

% Hot mask
hotPixelMask = tempTMap.*mask >= hotThreshold;
[hotPixelsRow,hotPixelsCol] = find(hotPixelMask & mask);

% Cold mask
coldPixelMask = tempTMap.*mask <= coldThreshold;
[coldPixelsRow,coldPixelsCol] = find(coldPixelMask & mask);

incorrectPixels = [hotPixelsRow,hotPixelsCol;coldPixelsRow,coldPixelsCol];

if ~isempty(incorrectPixels)
    for pixelIdx = 1:size(incorrectPixels,1)
        % Un-unwrap those pixels
        tempPhaseUnwrap(incorrectPixels(pixelIdx,1),incorrectPixels(pixelIdx,2)) = tempPhaseUnwrap(incorrectPixels(pixelIdx,1),incorrectPixels(pixelIdx,2)) - phaseUnwrapOffset(incorrectPixels(pixelIdx,1),incorrectPixels(pixelIdx,2));
    end
end

phaseUnwrap = tempPhaseUnwrap;
end