function [TMap, TDoseMap] = GenerateTDoseMaps(mainPath, generate_random_delta)
%==========================================================================
% Variable initialization
%==========================================================================
TDOSE_THRESHOLD = 43;
NUM_REF_IMAGES = 5;
output_folder = fullfile(mainPath,'Output');
input_folder = fullfile(mainPath,'Input');

% Load TMap. Assume *Current* files are in a folder called Input
TMap = read_TDC_TMap_files(input_folder);

if ~exist(output_folder)
    mkdir(output_folder);
end

if nargin > 1 && generate_random_delta == 1
    % Prepare file to write time information
    fid_cumulative_time = fopen(fullfile(input_folder,'Metadata.tsv'),'wt');
    fprintf(fid_cumulative_time,'Filename\tDelta_time (min)\n');
    % Generate random heating period (in minutes).
    delta_min = (5 + rand(1,size(TMap,4)))/60; 
    delta_min = reshape(repmat(delta_min,12,1),12*size(TMap,4),1);
    
else
    % Read the time information
    fid_cumulative_time = fopen(fullfile(input_folder,'Metadata.tsv'),'r');
    tsv_header = fgetl(fid_cumulative_time); %stores header
    tsv = textscan(fid_cumulative_time,'%s\t%.16f');
    tMapFiles = tsv{1,1};
    delta_min = tsv{1,2};
    fclose(fid_cumulative_time);
end

tMapIndex = 0;

% Initialize matrix
TDoseMap = zeros(size(TMap));  

%==========================================================================
% Generate TDose and save files
%==========================================================================
fprintf('Generating TDose maps...')
fprintf('    ');
for dynIdx = NUM_REF_IMAGES+1:size(TMap,4)  
%     fprintf('Writing dynamic number: %d\n',dynIdx)
    for sliceIdx = 1:size(TMap,3)
        tMapIndex = tMapIndex + 1;
        
        currentTMap = TMap(:,:,sliceIdx,dynIdx);
        currentTDose = TDoseMap(:,:,sliceIdx,dynIdx);
        
        ind_43 = currentTMap >= TDOSE_THRESHOLD;
        ind_rest = currentTMap < TDOSE_THRESHOLD;
        
        currentTDose(ind_43) = currentTDose(ind_43) + (0.5 .^(TDOSE_THRESHOLD - currentTMap(ind_43))) * delta_min(tMapIndex);
        currentTDose(ind_rest) = currentTDose(ind_rest) + (0.25 .^(TDOSE_THRESHOLD - currentTMap(ind_rest))) * delta_min(tMapIndex);
        
        TDoseMap(:,:,sliceIdx,dynIdx) = TDoseMap(:,:,sliceIdx,dynIdx-1) + currentTDose;
        
        % Save to disk
        tdose_filename = sprintf('i%04d-s%02d-TDoseMatlab.dat',dynIdx-1,sliceIdx-1);
        if nargin > 1 && generate_random_delta == 1
            TMap_filename = sprintf('i%04d-s%02d-CurrentTemperature.dat',dynIdx-1,sliceIdx-1);
            fprintf(fid_cumulative_time,'%s\t%.3f\n',TMap_filename, delta_min(tMapIndex));
        end
        write_file(TDoseMap(:,:,sliceIdx,dynIdx),output_folder,tdose_filename)
    end
    % Update display
    progressPercentage = min(round(dynIdx/size(TMap,4)*100),100);
    backspaceChars = repmat('\b',1,length(num2str(progressPercentage))+1);
    fprintf([backspaceChars '%d%%'],progressPercentage);
end
fclose('all');
fprintf('\n%d dynamics TDose written\n',dynIdx);

function write_file(input_matrix,output_path,filename)
fid = fopen(fullfile(output_path,filename),'w');
if fid ~= -1
    fwrite(fid,input_matrix','float');
end
fclose(fid);

function TMap = read_TDC_TMap_files(inputPath)
files = dir(fullfile(inputPath,'*Curr*.dat'));
fprintf('Loading TMap...')
fprintf('    ');
for filesIdx = 1:length(files)
    pathToCurrentFile = fullfile(inputPath,files(filesIdx).name);
    fileInfo = textscan(files(filesIdx).name,'i%4d-s%2d-%s');
    currentDynamic = fileInfo{1} + 1; % File name is zero-based
    currentSlice = fileInfo{2} + 1; % File name is zero-based
    fid = fopen(pathToCurrentFile);
    TMap(:,:,currentSlice,currentDynamic) = (fread(fid,[128 128],'single')');
    fclose(fid);
    
    % Update display
    progressPercentage = min(round(filesIdx/length(files)*100),100);
    backspaceChars = repmat('\b',1,length(num2str(progressPercentage))+1);
    fprintf([backspaceChars '%d%%'],progressPercentage);
end

fprintf(' - %d dynamics TMap loaded\n',currentDynamic);
