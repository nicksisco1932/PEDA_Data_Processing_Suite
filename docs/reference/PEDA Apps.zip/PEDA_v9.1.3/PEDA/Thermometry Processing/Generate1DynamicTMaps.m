function [tMap, varargout] = Generate1DynamicTMaps(currentDynamic, currentMagnitudes, currentPhases, ...
        numRefImages, driftCorrection, varargin)
% Generate1DynamicTMaps generates the tMaps for all the slices in 1 dynamic
% based on phase data input.  Input phase data has int values from 0 to 4095.
%
% This function does NOT correct for image shift.
% DO NOT modify this function as it is used for verification of TDC MRI
% cartridges. If it needs to be modified, advise the Software Team as the
% same modification needs to be applied to the TDC codebase.
    global gc;        

    gc.TempConv = gc.temperatureConversionSign * 1/(2*pi*gc.gamma*gc.alpha*gc.magnet*gc.TE/1000);
    
    exclusionRadiusMillimetres = 50;
    
    persistent referenceMagnitudes;
    persistent referencePhases;
    persistent totalMask;
    persistent refPhase;
    persistent prevPhaseDiffUnwrap;
    persistent prevPhaseDiffFinal;
    numRows = size(currentPhases, 1);
    numCols = size(currentPhases, 2);
    numSlices = size(currentPhases, 3);

    if currentDynamic == 1
        referenceMagnitudes = [];
        referencePhases = [];
        totalMask = [];
        refPhase = [];
        prevPhaseDiffUnwrap = [];
        prevPhaseDiffFinal = [];
    end
    if isempty(referenceMagnitudes)
        referenceMagnitudes = zeros(numRows, numCols, numSlices, numRefImages);
    end
    if isempty(referencePhases)
        referencePhases = zeros(numRows, numCols, numSlices, numRefImages);
    end
    if isempty(totalMask)
        totalMask = ones(numRows, numCols, numSlices);
    end

    phaseDiff = zeros(numRows, numCols, numSlices);
    phaseDiffUnwrap = zeros(numRows, numCols, numSlices);
    phaseDiffCorrected = zeros(numRows, numCols, numSlices);
    phaseDiffFinal = zeros(numRows, numCols, numSlices);
    tMap = zeros(numRows, numCols, numSlices);

    % Additional inputs
    useCorrections = false;
    if nargin == 8
        customCorrectedTMapMask = varargin{1};
        hotThreshold = varargin{2};
        hotBound = (hotThreshold - gc.baseTemp) / gc.TempConv;
        coldThreshold = varargin{3};
        coldBound = (coldThreshold - gc.baseTemp) / gc.TempConv;
        useCorrections = 1;
        if (hotBound > coldBound)
            maxBound = hotBound;
            minBound = coldBound;
        else
            maxBound = coldBound;
            minBound = hotBound;
        end
    elseif nargin > 5
        error('You probably wanted to apply correction but forgot to add all required inputs (mask, hotThreshold, coldThreshold')
    end

    if strcmp(gc.pipeline,'WIP1118')
        phasesRadians = ConvertPhaseRadians(currentPhases, 'SIEMENSWIP1118');
    else
        phasesRadians = ConvertPhaseRadians(currentPhases);
    end
            
    if (currentDynamic <= numRefImages)
        referenceMagnitudes(:, :, :, currentDynamic) = currentMagnitudes;
        referencePhases(:, :, :, currentDynamic) = phasesRadians;
    end
      
    if (currentDynamic == numRefImages)
        refPhase = CalculateReference(referenceMagnitudes, referencePhases);
    end
      
    if (currentDynamic > numRefImages)
        phaseDiff = PhaseDifference(phasesRadians, refPhase);
        if (currentDynamic == numRefImages + 1)
            prevPhaseDiffUnwrap = phaseDiff;
        end
                  
        for s = 1:12
            sliceUnwrap = PhaseUnwrap(phaseDiff(:,:,s), prevPhaseDiffUnwrap(:,:,s));
            phaseDiffUnwrap(:,:,s) = sliceUnwrap;         
              
            mask = CalculateMasks(sliceUnwrap, prevPhaseDiffUnwrap(:,:,s), currentMagnitudes(:,:,s), ...
                    gc.rad, gc.voxelsize, gc.UAX, gc.UAY, gc.halfwidth, ...
                    gc.tempthresh, gc.TempConv, exclusionRadiusMillimetres);
              
            totalMask(:,:,s) = totalMask(:,:,s) & mask;
             
            correctedSlice = driftCorrection(sliceUnwrap, totalMask(:,:,s));
            phaseDiffCorrected(:,:,s) = correctedSlice;

            if (currentDynamic == numRefImages + 1)
                if useCorrections
                    % apply bounds
                    phaseDiffFinal(:,:,s) = BoundedPhaseUnwrap(correctedSlice, correctedSlice, ...
                            maxBound, minBound);
                else
                    phaseDiffFinal(:,:,s) = correctedSlice;
                end    
            else
                if useCorrections
                    phaseDiffFinal(:,:,s) = BoundedPhaseUnwrap(correctedSlice, prevPhaseDiffFinal(:,:,s), ...
                            maxBound, minBound);
                else
                    phaseDiffFinal(:,:,s) = PhaseUnwrap(correctedSlice, prevPhaseDiffFinal(:,:,s));
                end
            end
        end

        prevPhaseDiffUnwrap = phaseDiffUnwrap;
        prevPhaseDiffFinal = phaseDiffFinal;

        tMap = ConvertToTemp(phaseDiffFinal, gc.TempConv, gc.baseTemp);
    end

    % Assign additional outputs
    varargout{1} = totalMask;
    varargout{2} = phaseDiff;
    varargout{3} = phaseDiffUnwrap;
    varargout{4} = phaseDiffCorrected;
    varargout{5} = phaseDiffFinal;
end
