load('\\PMIFS03\Test$\Investigations\MRI Test Data\SkyraDrift\S1_data.mat');
[mag, ph] = ZeroPadMagPhase(mag, ph);
numImages = size(ph, 4);
numSlices = size(ph, 3);
numX = size(mag, 2);
numY = size(mag, 1);
fid = 0;
try
    for image = 1:numImages
        for slice = 1:numSlices
            filename = sprintf('i%04d-s%02d-Raw.dat', image - 1, slice - 1);
            filename = fullfile('c:\TestOutput\', filename);
            fid = fopen(filename, 'w+');
            fwrite(fid, mag(:, :, slice, image)', 'single');
            fwrite(fid, ph(:, :, slice, image)', 'single');
            fclose(fid);
            disp(['completed ' filename]);
        end
    end
catch MExc
    fclose(fid);
    rethrow(MExc);
end