function result = ZeroPad(matrix)
    dim1 = size(matrix, 1);
    dim2 = size(matrix, 2);
    imageResolution = max(dim1, dim2);
    result = matrix;
    if dim1 < imageResolution
        result = zeros(imageResolution, imageResolution);
        newDim1 = floor((imageResolution - dim1)/2);
        result(newDim1 + 1:(newDim1 + dim1), :) = matrix(:, :);
    elseif dim2 < imageResolution
        result = zeros(imageResolution, imageResolution);
        newDim2 = floor((imageResolution - dim2)/2);
        result(:, newDim2 + 1:(newDim2 + dim2)) = matrix(:, :);
    end
end