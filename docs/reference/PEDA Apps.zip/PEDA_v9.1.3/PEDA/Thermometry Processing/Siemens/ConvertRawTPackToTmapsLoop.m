function ConvertRawTPackToTmapsLoop(rawInputDirectory, tmapOutputDirectory, varargin)
% ConvertRawSiemensToTmaps Computes the tMaps based on the phase files in the
% input directory.  Input phase file data is not in radians, its values are
% between 0 and 4095.
%
% The var args are: num ref images, base temperature, output directory for masks.
%
% This function does NOT correct for image shift.
% DO NOT modify this function as it is used for verification of TDC MRI
% cartridges. If it needs to be modified, advise the Software Team as the
% same modification needs to be applied to the TDC codebase.

    addpath('..');
    addpath('../DriftCorrection');
    addpath('../../Masking');

    global gc;
    SetSiemens_SyngoTherm_Globals();
    
    numRefImages = gc.numRefImages;
    if (nargin >= 3)
        numRefImages = varargin{1};
    end
    if (nargin >= 4)
        gc.baseTemp = varargin{2};
    end
    maskOutputDirectory = '';
    if (nargin >= 5)
        maskOutputDirectory = varargin{3};
    end

    files = dir(rawInputDirectory);
    datFiles = cell(ceil(size(files,1)/12), 12);
    maxDynamic = 0;
    for i = 1:length(files)
        curFile = files(i).name;
        if ~isempty(strfind(curFile, '-Raw.dat'))
            token = regexp(curFile, 'i(\d{4})-s(\d{2})-Raw.dat', 'tokens');
            dynamic = str2num(token{1}{1}) + 1;
            slice = str2num(token{1}{2}) + 1;

            if (dynamic > maxDynamic)
                maxDynamic = dynamic;
            end
            if (size(datFiles, 1) < dynamic)
                resize(datFiles, dynamic, 12);
            end
            datFiles{dynamic, slice} = curFile;
        end
    end
    
    for dynamic = 1:maxDynamic
        magnitudes = zeros(128, 128, 12);
        phases = zeros(128, 128, 12);
        
        for (slice = 1:12)
            curFile = datFiles{dynamic, slice};
            fid = fopen(fullfile(rawInputDirectory, curFile), 'r');
            magnitudes(:, :, slice) = double(fread(fid, [128 128], 'single')');
            phases(:, :, slice) = double(fread(fid, [128 128], 'single')');
            fclose(fid);
        end
        
        [tMap, mask, phDiff, phUnwrap, phCorrected, phFinal] = Generate1DynamicTMaps(dynamic, magnitudes, ...
                phases, numRefImages, @AutomaticFirstOrderDriftCorrection, ones(128, 128), 120, 0);

        if (dynamic > numRefImages)
            for slice = 1:12
                filePath = strcat(tmapOutputDirectory, sprintf('\\TMapMatI%03dS%02d', dynamic - 1, slice - 1), '.dat');
                fid = fopen(filePath, 'w');             
                fwrite(fid, tMap(:,:,slice), 'float');
                fclose(fid);  

                if (nargin >= 5)
                    filePath = strcat(maskOutputDirectory, sprintf('\\MaskMatI%03dS%02d', dynamic - 1, slice - 1), '.dat');
                    fid = fopen(filePath, 'w');             
                    fwrite(fid, mask(:,:,slice), 'uint8');
                    fclose(fid);
                end
            end
        end
    end
end
