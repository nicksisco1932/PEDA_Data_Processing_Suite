% Reads DICOM file as a text file to find identifier if thermometry
% sequence is based on ep_seg_therm (ie. Syngo Therm) or ep_seg_phs (Phase
% Imaging)
function sequenceType = DetermineSiemensThermometrySequenceType(pathToDICOM)

% Determine number of lines in file
fid = fopen(pathToDICOM,'r');
firstpass = textscan(fid,'%s','delimiter','\n');
numberOfLines = length(firstpass{1});

% Go back to beginning of file
frewind(fid)

sequenceType = [];

% Run through line by line
for ii = 1:numberOfLines
    currentLine = fgetl(fid);
    if regexpi(currentLine, 'epfid3d')
        sequenceType = 'SiemensFreeMax3D';
        return
    elseif regexpi(currentLine, 'epfid2d')
        sequenceType = 'SiemensFreeMax2D';
        return
    end
    if regexp(currentLine, 'tSequenceFileName')
        if regexpi(currentLine, 'ep_seg_therm')
            sequenceType = 'SiemensSyngoTherm';
        elseif regexpi(currentLine, 'ep_seg_phs')
            sequenceType = 'SiemensPhaseImaging';
        elseif regexpi(currentLine, 'EPI_THERM_WIP1118')
            sequenceType = 'SiemensWIP1118';
        else
            if isempty(sequenceType) % i.e. don't set back to 0 if it has found a previously valid string
                sequenceType = 0;
            end
        end
    end
end

fclose(fid);

if isequal(sequenceType,0)
    error('Not a recognized Siemens thermometry sequence.')
end

if isempty(sequenceType)
    warning('Did not find sequence type.  Possibly not a Siemens DICOM.')
end