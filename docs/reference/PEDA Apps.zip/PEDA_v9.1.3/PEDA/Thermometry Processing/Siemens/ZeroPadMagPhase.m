function [magStack, phaseStack] = ZeroPadMagPhase(magStack, phaseStack)
    padded = ZeroPad(magStack(:, :, 1, 1));
    tempMagStack = zeros(size(padded,1),size(padded,2),size(magStack,3),size(magStack,4));
    tempPhaseStack = zeros(size(padded,1),size(padded,2),size(phaseStack,3),size(phaseStack,4));
    for i = 1:size(phaseStack,4)
        for s = 1:size(phaseStack,3)
            tempMagStack(:,:,s,i) = ZeroPad(magStack(:, :, s, i));
            tempPhaseStack(:,:,s,i) = ZeroPad(phaseStack(:,:,s,i));
        end
    end
    phaseStack = tempPhaseStack;
    magStack = tempMagStack;
end