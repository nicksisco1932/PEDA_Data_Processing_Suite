function [magImage, phaseImage] = LoadDataWithHeader() 

%Load MRI emulator data with header

global gc

magImage = zeros(gc.NumCols, gc.NumRows, gc.NumSlice, gc.NumImage/gc.NumSlice/2);
phaseImage = zeros(gc.NumCols, gc.NumRows, gc.NumSlice, gc.NumImage/gc.NumSlice/2);


for i = 1:1:gc.NumImage/gc.NumSlice/2
    
    for s = 1:1:gc.NumSlice*2
        
        t = (s-1)+(i-1)*gc.NumSlice*2;
        
        filePath = strcat(sprintf('D:\\TestCartridge\\imageData%d', t), '.dat');
    
        if (mod(t,2) == 0)
            
            fidMag = fopen(filePath, 'r');
            dataSizeMag = fread(fidMag, 2, 'int32');
            fseek(fidMag, dataSizeMag(1), 'cof');   
            
            magOrient = fread(fidMag, [gc.NumRows,gc.NumCols], 'single');
            fclose(fidMag);
            
            chronSliceMag = (s+1)/2;
            
            if chronSliceMag <= gc.NumSlice/2;
                anatSliceMag = 2*chronSliceMag;
            else
                anatSliceMag = 2*(chronSliceMag - 6) - 1;
            end
            
            magImage(:,:,anatSliceMag,i) = fliplr(magOrient');
            
        
        else

            fidPhase = fopen(filePath, 'r');
            dataSizePhase = fread(fidPhase, 2, 'int32');
            fseek(fidPhase, dataSizePhase(1), 'cof');   
            
            phaseOrient = fread(fidPhase, [gc.NumRows,gc.NumCols], 'single');
            fclose(fidPhase);
            
            chronSlicePhase = s/2;
            
            if chronSlicePhase <= gc.NumSlice/2;
                anatSlicePhase = 2*chronSlicePhase;
            else
                anatSlicePhase = 2*(chronSlicePhase - 6) - 1;
            end
            
            phaseImage(:,:,anatSlicePhase,i) = fliplr(phaseOrient');
           
            
        end
    end     
end


