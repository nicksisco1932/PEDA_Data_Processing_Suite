function phaseImageRad = ConvertPhaseRadians(phaseStack, pipeline)
if nargin == 1
    scalingFactor = 1;
else
    if strcmp(pipeline, 'SIEMENSWIP1118')
        scalingFactor = 4;
    else
        scalingFactor = 1;
    end
end

if strcmp(pipeline, 'GE')
    phaseImageRad = phaseStack;
else
    phaseImageRad = scalingFactor*(phaseStack/4095*2*pi - pi);
end

end
