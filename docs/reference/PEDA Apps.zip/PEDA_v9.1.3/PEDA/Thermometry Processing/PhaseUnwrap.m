function phaseUnwrap = PhaseUnwrap(phaseDiff, prevPhaseDiff)

diffPhase = phaseDiff - prevPhaseDiff;
phaseUnwrapOffset = round(diffPhase / (2 * pi))*-2*pi;

phaseUnwrap = phaseDiff + phaseUnwrapOffset;

end