function SaveMaskDataFiles(mask, outputDirectory)

global gc;
%TODO don't depend of gc.

for i=1:1:(gc.NumImages - gc.NumRefImage)    
    for s = 1:1:gc.NumSlice
        
        filePath = strcat(outputDirectory, sprintf('\\MaskMatI%03dS%02d', i + gc.NumRefImage - 1, s - 1), '.dat');
        fid = fopen(filePath, 'w');             
        fwrite(fid, mask(:,:,s,i), 'uint8');
        fclose(fid);
    end
end

fclose('all');

end
