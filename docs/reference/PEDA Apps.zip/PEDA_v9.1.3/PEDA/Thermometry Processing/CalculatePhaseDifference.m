function diffStack = CalculatePhaseDifference(phaseStack, refPhase, numRefImage)

diffStack = zeros(size(phaseStack,1), size(phaseStack,2), size(phaseStack,3), size(phaseStack,4));
j = 1;
for i = numRefImage+1:1:size(phaseStack,4)
    
    currentPhaseImage = phaseStack(:,:,:,i);
    
    currentComplexImage = cos(currentPhaseImage) + sqrt(-1)*sin(currentPhaseImage);    
    refComplexImage = cos(refPhase) + sqrt(-1)*sin(refPhase);    
    
    diffStack(:,:,:,j) = angle(currentComplexImage.*conj(refComplexImage));
    j = j+1;
    
end

end