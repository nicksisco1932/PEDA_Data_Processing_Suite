function phaseCorr = AutomaticZeroOrderDriftCorrection(phaseDiff, mask, nullPhaseMask)
% 5.4 specific mask
if nargin < 3
    nullPhaseMask = zeros(128,128);
end

maskedPhase = phaseDiff.*mask;
% calculate mean of all data not masked
meanPhase = mean(maskedPhase(mask == 1));
% subtract mean phase drift
phaseCorr = phaseDiff - meanPhase.*~nullPhaseMask;

end