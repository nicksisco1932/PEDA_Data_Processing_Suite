function result = AutomaticFirstOrderDriftCorrection(phaseDiff, mask, nullPhaseMask)
% 5.4 specific mask
if nargin < 3
    nullPhaseMask = zeros(128,128);
end

    n = 0;
    M1 = 0;
    M2 = 0;
    sumX = 0;
    sumY = 0;
    sumZ = 0;
    sumXSquared = 0;
    sumYSquared = 0;
    sumXY = 0;
    sumXZ = 0;
    sumYZ = 0;

    for y = 1:size(phaseDiff, 1)
        for x = 1:size(phaseDiff, 2)
            if mask(y, x) 
                n = n + 1;
                z = phaseDiff(y, x);
                delta = z - M1;
                M1 = M1 + delta / n;
                M2 = M2 + delta * (z - M1);

                sumX = sumX + x;
                sumY = sumY + y;
                sumZ = sumZ + z;
                sumXSquared = sumXSquared + x * x;
                sumYSquared = sumYSquared + y * y;
                sumXY = sumXY + y * x;
                sumXZ = sumXZ + x * z;
                sumYZ = sumYZ + y * z;
            end
        end
    end

    sumXZ = sumXZ - sumX * sumZ / n;
    sumYZ = sumYZ - sumY * sumZ / n;
    sumXY = sumXY - sumX * sumY / n;
    sumXSquared = sumXSquared - sumX * sumX / n;
    sumYSquared = sumYSquared - sumY * sumY / n;

    bX = (sumYSquared * sumXZ - sumXY * sumYZ) / (sumXSquared * sumYSquared - sumXY * sumXY);
    bY = (sumXSquared * sumYZ - sumXY * sumXZ) / (sumXSquared * sumYSquared - sumXY * sumXY);
    a = M1 - (bX * sumX / n) - (bY * sumY / n);
    
    result = zeros(size(phaseDiff, 1), size(phaseDiff, 2));
    for y = 1:size(phaseDiff, 1)
        for x = 1:size(phaseDiff, 2)
            result(y, x) = phaseDiff(y, x) - (a + bX * x + bY * y).*~nullPhaseMask(y,x);
        end
    end
end