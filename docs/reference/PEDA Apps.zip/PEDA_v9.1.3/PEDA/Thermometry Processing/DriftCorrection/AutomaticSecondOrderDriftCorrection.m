function [phaseCorr,beta] =  AutomaticSecondOrderDriftCorrection(phaseDiff, mask, nullPhaseMask)
%%-------------------------------------------------------------------------
% Corrects phase drift by fitting 2D 2nd-order polynomial over all unmasked 
% voxels in the phase-difference image and subtracting drift. Returns 
% corrected phase image.
%
% References:
% - http://reliawiki.org/index.php/Multiple_Linear_Regression_Analysis
% - https://profoundmedical.atlassian.net/wiki/display/MSDTS/Implementation+of+Second-Order+drift+correction
%%--------------------------------------------------------------------------
% 5.4 specific mask
if nargin < 3
    nullPhaseMask = zeros(128,128);
end

% Apply mask to phase-difference image
maskedPhase = phaseDiff.*mask;

% Get coordinates of Masked pixels
[maskedCols,maskedRows] = find(mask == 1);

% Get a vector of all phase values
phaseVector = maskedPhase(mask == 1);

% Make Vandermonde matrix with pixel coordinates
vandermondeMatrix = [ones(size(maskedRows,1),1) maskedRows maskedCols maskedRows.*maskedCols maskedRows.^2 maskedCols.^2];

% Least-square method
beta = ((transpose(vandermondeMatrix)*vandermondeMatrix)\transpose(vandermondeMatrix))*phaseVector;

% creates meshgrid for 2D 2nd-order polynomial
nX = size(maskedPhase,1);
nY = size(maskedPhase,2);
[gx, gy] = meshgrid(1:1:nX, 1:1:nY);

% create 2D 2nd-order polynomial drift correction with fit parameters
secondOrderSurface = beta(1) + beta(2)*gx + beta(3)*gy + beta(4).*gx.*gy + ...
                        beta(5).*gx.*gx + beta(6).*gy.*gy;
         
% correct Phase only on nonZero phase values
secondOrderSurfaceMasked = secondOrderSurface.*~nullPhaseMask;
phaseCorr = phaseDiff - secondOrderSurfaceMasked;

end