function [phaseCorr, beta] = AutomaticFirstOrderDriftCorrectionFast(phaseDiff, mask)
%%-------------------------------------------------------------------------
% Corrects phase drift by fitting 1st-order polynomial over all unmasked 
% voxels in the phase-difference image and subtracting drift. Returns 
% corrected phase image.
%
% References:
% - http://reliawiki.org/index.php/Multiple_Linear_Regression_Analysis
% - https://profoundmedical.atlassian.net/wiki/display/MSDTS/Implementation+of+Second-Order+drift+correction
%%--------------------------------------------------------------------------

% Apply mask to phase-difference image
maskedPhase = phaseDiff.*mask;

% Get coordinates of Masked pixels
[maskedCols,maskedRows] = find(mask == 1);

% Get a vector of all phase values
phaseVector = maskedPhase(mask == 1);

% Make Vandermonde matrix with pixel coordinates
vandermondeMatrix = [ones(size(maskedRows,1),1) maskedRows maskedCols];

% Least-square method
beta = ((transpose(vandermondeMatrix)*vandermondeMatrix)\transpose(vandermondeMatrix))*phaseVector;

% creates meshgrid for 2D 2nd-order polynomial
nX = size(maskedPhase,1);
nY = size(maskedPhase,2);
[gx, gy] = meshgrid(1:1:nX, 1:1:nY);

% create 1st-order polynomial drift correction with fit parameters
firstOrderPlane = beta(1) + beta(2)*gx + beta(3)*gy;
         
% correct Phase
phaseCorr = phaseDiff - firstOrderPlane;

end