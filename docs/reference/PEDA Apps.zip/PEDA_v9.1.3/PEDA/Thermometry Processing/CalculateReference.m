function refPhase = CalculateReference(magRef, phaseRef)
    complexRef = magRef.*(cos(phaseRef) + 1i*sin(phaseRef));
    refComplex = squeeze(mean(complexRef, 4));
    refPhase = angle(refComplex);
end
