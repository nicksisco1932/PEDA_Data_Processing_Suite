function [tMap, totalMask] = GeneratesTMapFromTestData(magStack, phaseStack,
        driftCorrection, echoTime, baseTemperature = 37)
% GENERATESTMAPFROMTESTDATA Computes the tmaps based on the
% magStack, phaseStack, and driftCorrection function.
% phaseStack is not in radians, its values are between 0 and 4095.
% driftCorrection is a function taking two arguments: a 2-D phase map and a 2-D mask
% echoTime is in milliseconds
%
% This function does NOT correct for image shift.
% DO NOT modify this function as it is used for verification of TDC MRI
% cartridges. If it needs to be modified, advise the Software Team as the
% same modification needs to be applied to the TDC codebase.

    addpath('..');

    global gc
    gc.magnet = 3; %Tesla
    gc.NumRefImage = 5;
    gc.rad = 48;
    gc.halfwidth = 30;
    gc.tempthresh = 10;
    gc.voxelsize = 2;
    gc.UAX = 64;
    gc.UAY = 64;

    gc.baseTemp = baseTemperature;
    gc.TE = echoTime;

    numDynamics = size(phaseStack, 4);
    numRows = size(phaseStack, 1);
    numCols = size(phaseStack, 2);
    numSlice = size(phaseStack, 3);

    tMap = zeros(numRows, numCols, numSlice, numDynamics - gc.NumRefImage);
    totalMask = zeros(numRows, numCols, numSlice, numDynamics - gc.NumRefImage);

    for img = 1:1:(numDynamics - gc.NumRefImage)
        dynamic = img + gc.NumRefImage;
        [dynamicTMap, dynamicMask] = Generate1DynamicTMaps(dynamic,
                magStack(:,:,:,dynamic), phaseStack(:,:,:,dynamic), gc.NumRefImage,
                driftCorrection);
        tMap(:,:,:,img) = dynamicTMap;
        totalMask(:,:,:,img) = dynamicMask;
    end
end
