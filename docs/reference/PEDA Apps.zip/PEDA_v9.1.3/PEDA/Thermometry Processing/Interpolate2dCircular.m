%==========================================================================
% function result = Interpolate2dCircular(T, x, y)
%
% Purpose:
% ========
%     Interpolates phase values for points on a 2D image.  Ensures returned
%     result is in the range [-pi,+pi].
%
% Input(s):
% =========
%     T:     2D array where the interpolation is performed.  Entries should
%            be within a 2 pi range (from smallest entry to largest) though
%            differences up to 4 pi should work.
%     x, y:  x and y coordinates where for which we want the interpolated
%              value
%
% Output(s):
% ==========
%
%
%==========================================================================
% Author: Michael Sprague, Cary Timar, Alexandre Bigot
% Created: July 16 2014
% Altered: Mar 07, 2018
%==========================================================================
function result = Interpolate2dCircular(T, x, y)
xFloor = floor(x);
xCeil = ceil(x);
yFloor = floor(y);
yCeil = ceil(y);

if (xFloor <= 0 || xCeil > size(T, 2) || yFloor <= 0 || yCeil > size(T, 1))
    result = 0;
elseif (xFloor == xCeil && yFloor == yCeil)
    result = T(y, x);
elseif (yFloor == yCeil)
    result = interpolate1D(T(y, xFloor), (x - xFloor), T(y, xCeil));
elseif (xFloor == xCeil)
    result = interpolate1D(T(yFloor, x), (y - yFloor), T(yCeil, x));
else
    tU0Vt = interpolate1D(T(yFloor,xFloor),y-yFloor,T(yCeil,xFloor));
    tU1Vt = interpolate1D(T(yFloor,xCeil),y-yFloor,T(yCeil,xCeil));
    result = interpolate1D(tU0Vt,x-xFloor,tU1Vt);
end
end

function result = interpolate1D(left, proportion, right)
delta = right - left;
if (delta > pi || delta < -pi)
    delta = delta - round(delta / (2*pi)) * (2*pi);
end
result =  left + proportion * delta;
end

