function [tMap, totalMask] = GeneratesTMapFromTestDataXTC(magStack, phaseStack, ...
        varargin)
% GENERATESTMAPFROMTESTDATAXTC Computes the tmaps based on the
% magStack, phaseStack. phaseStack is not in radians, its values are
% between 0 and 4095.
%
% The var args are: base temperature
%
% This function does NOT correct for image shift.
% DO NOT modify this function as it is used for verification of TDC MRI
% cartridges. If it needs to be modified, advise the Software Team as the
% same modification needs to be applied to the TDC codebase.

    addpath('..');
    addpath('../DriftCorrection');
    addpath('../../Masking');

    global gc;
    SetXTCGlobals();
    if (nargin >= 3)
        gc.baseTemp = varargin{1};
    end    

    numDynamics = size(phaseStack, 4);
    numRows = size(phaseStack, 1);
    numCols = size(phaseStack, 2);
    numSlice = size(phaseStack, 3);
    
    tMap = zeros(numRows, numCols, numSlice, numDynamics - gc.numRefImages);
    totalMask = zeros(numRows, numCols, numSlice, numDynamics - gc.numRefImages);

    for i = 1:1:(numDynamics - gc.NumRefImage)
        dynamic = gc.NumRefImage + i;
        [dynamicTMap, dynamicMask] = Generate1DynamicTMaps(dynamic, ...
                magStack(:,:,:,dynamic), phaseStack(:,:,:,dynamic), gc.numRefImages, ...
                @AutomaticFirstOrderDriftCorrection, ones(128, 128), 120, 0);
        tMap(:,:,:,i) = dynamicTMap;
        totalMask(:,:,:,i) = dynamicMask;
    end
end
