function [magImage, phaseImage] = LoadXTCData(inputDirectory)

global gc

gc.NumDynamic = 520;
gc.NumRows = 128;
gc.NumCols = 128;
gc.TE = 12;

gc.UAX = 53; %c# zero index
gc.UAY = 60; %c# zero index

magImage = zeros(gc.NumRows, gc.NumCols, gc.NumSlice, gc.NumDynamic);
phaseImage = zeros(gc.NumRows, gc.NumCols, gc.NumSlice, gc.NumDynamic);

for iD = 1:1:gc.NumDynamic

    for iS = 1:1:gc.NumSlice
    
        fileMag = sprintf('Img_I%d_S%d_Magn.dat', iD, iS-1);        
        magRaw = dlmread(strcat(inputDirectory, fileMag), '\n');
        magImage(:,:,iS,iD) = reshape(magRaw(1:end-1), [gc.NumRows, gc.NumCols]);

        filePhase = sprintf('Img_I%d_S%d_Phase.dat', iD, iS-1);        
        phaseRaw = dlmread(strcat(inputDirectory, filePhase), '\n');
        phaseImage(:,:,iS,iD) = reshape(phaseRaw(1:end-1), [gc.NumRows, gc.NumCols]);

                
    end

    disp(sprintf('Finished dynamic %d', iD))
    
end


end