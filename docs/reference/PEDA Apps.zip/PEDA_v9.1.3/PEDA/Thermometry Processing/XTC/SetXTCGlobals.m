function SetXTCGlobals(baseTemperature, UACenter, MRFrequency, echoTime)

    global gc
    gc.pipeline = 'XTC';
    gc.alpha = -9.7e-9;
    gc.gamma = 4.258e7;
    gc.TE = 12;
    gc.temperatureConversionSign = +1;
    gc.magnet = 3; %Tesla
    gc.baseTemp = 37;
    gc.UAX = 64;
    gc.UAY = 64;
    
    switch nargin
        case 1
            gc.baseTemp = baseTemperature;
        case 2
            gc.baseTemp = baseTemperature;
            gc.UAX = UACenter(1);
            gc.UAY = UACenter(2);
        case 3
            gc.magnet = MRFrequency/gc.gamma; %Tesla
            gc.baseTemp = baseTemperature;
            gc.UAX = UACenter(1);
            gc.UAY = UACenter(2);
        case 4
            gc.magnet = MRFrequency/gc.gamma; %Tesla
            gc.baseTemp = baseTemperature;
            gc.UAX = UACenter(1);
            gc.UAY = UACenter(2);
            gc.TE = echoTime;
    end
    
    gc.rad = 48;
    gc.halfwidth = 30;
    gc.tempthresh = 10;
    gc.voxelsize = 2;
    
    gc.numRefImages = 5;
    
    gc.TempConv = gc.temperatureConversionSign * 1/(2*pi*gc.gamma*gc.alpha*gc.magnet*gc.TE/1000);

