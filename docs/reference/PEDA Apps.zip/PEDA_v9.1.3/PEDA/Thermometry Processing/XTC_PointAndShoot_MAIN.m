function XTC_PointAndShoot_MAIN(directory)

LoadXTCDICOM([directory 'DICOM\'], [directory 'TMaps\'])

end