function phaseUnwrap = BoundedPhaseUnwrap(phaseDiff, prevPhaseDiff, maxBound, minBound)

    diffPhase = phaseDiff - prevPhaseDiff;
    phaseUnwrapOffset = round(diffPhase / (2 * pi)) * (-2 * pi);

    phaseUnwrap = phaseDiff + phaseUnwrapOffset;

    highPixels = phaseUnwrap > maxBound;
    bound = highPixels .* maxBound;
    highPixels = highPixels .* phaseUnwrap;
    highPixelLoops = ceil((highPixels - bound) / (2 * pi));
    phaseUnwrap = phaseUnwrap - (2 * pi) * highPixelLoops;

    lowPixels = phaseUnwrap < minBound;
    bound = lowPixels .* minBound;
    lowPixels = lowPixels .* phaseUnwrap;
    lowPixelLoops = ceil((bound - lowPixels) / (2 * pi));
    phaseUnwrap = phaseUnwrap + (2 * pi) * lowPixelLoops;

end