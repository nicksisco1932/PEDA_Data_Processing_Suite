function SaveTMapDataFiles(tMaps, outputDirectory, numRefImages)

for i=1:1:size(tMaps,4)    
    for s = 1:1:size(tMaps,3)
        
        filePath = strcat(outputDirectory, sprintf('\\TMapMatI%03dS%02d', i + numRefImages - 1, s - 1), '.dat');
        fid = fopen(filePath, 'w');             
        fwrite(fid, tMaps(:,:,s,i), 'float');
        fclose(fid);  
    end
end

fclose('all');

end