function [magStack, phaseStack] = LoadRawDataFromTDC_TPackOrXTC(directory)

datFiles = {};
files = dir(directory);
for i = 1:length(files)
    curFile = files(i).name;
    if(strendswith(curFile, 'Raw.dat'))
        datFiles = [datFiles, curFile];
    end
end

magStack = zeros(128, 128, 12, length(datFiles)/12);
phaseStack = zeros(128, 128, 12, length(datFiles)/12);

for file = datFiles
    token = regexp(file{1}, 'i(\d{4})-s(\d{2})-Raw.dat', 'tokens');
    image = str2num(token{1}{1}) + 1;
    slice = str2num(token{1}{2}) + 1;
    
    fid = fopen(fullfile(directory, file{1}), 'r');
    magStack(:, :, slice, image) = fread(fid, [128 128], 'single')';
    phaseStack(:, :, slice, image) = fread(fid, [128 128], 'single')';
    fclose(fid);
end

end

function b = strendswith(s, pat)
%STRENDSWITH Determines whether a string ends with a specified pattern
%
%   b = strstartswith(s, pat);
%       returns whether the string s ends with a sub-string pat.
%

%   History
%   -------
%       - Created by Dahua Lin, on Oct 9, 2008
%

%% main

sl = length(s);
pl = length(pat);

b = (sl >= pl && strcmp(s(sl-pl+1:sl), pat)) || isempty(pat);

end