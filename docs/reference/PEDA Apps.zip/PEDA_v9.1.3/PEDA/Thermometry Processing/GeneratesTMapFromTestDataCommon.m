function [TMap, varargout] = GeneratesTMapFromTestDataCommon(magStack, phaseStack, pipeline, baseTemperature, UACenter, MRIcenterFrequencyHz, echoTime, refPhaseStack, driftCorrection)
%==========================================================================
% Purpose:  Computes TMaps based on magStack, phaseStack.
%
% Inputs:
%      - magStack: matrix 128 x 128 x 12 x NumDynamics
%      - phaseStack: matrix 128 x 128 x 12 x NumDynamics (NOT IN RADIANS)
%      - pipeline: possible options are 'XTCA' (Achieva), 'XTCI' (Ingenia), 'Siemens' (Prisma, Skyra), 'Siemens-AccessI'. Used to choose drift correction order
%      - baseTemperature (OPTIONAL): temperature in �C. Default is 37
%      - enableImageShift (OPTIONAL): set to 1 to apply image shift. Default is on
%      - UACenter (OPTIONAL): default is [64 64]
%      - MRIcenterFrequencyHz (OPTIONAL): default is 3T
%      - echoTime (OPTIONAL): default is 3T echo times
%      - refPhaseStack (OPTIONAL)
%      - driftCorrection (OPTIONAL)

% Outputs:
%      - "isotherms.mat"
%==========================================================================

%==========================================================================
% Variable initialization
%==========================================================================
global gc
% Clear any existing persistent variable
clear Generate1DynamicTMapsMatlab 

if nargin < 3
    error('Missing arguments')
end

% Set variables
numRows = size(phaseStack, 1);
numCols = size(phaseStack, 2);
numSlice = size(phaseStack, 3);
numDynamics = size(phaseStack, 4);
TMap = zeros(numRows, numCols, numSlice, numDynamics);

% For memory management, only create these variables is the user requests them
if nargout >= 4
    outputTotalMask = zeros(numRows, numCols, numSlice, numDynamics);
end
if nargout >= 5
    phaseDiff = zeros(numRows, numCols, numSlice, numDynamics);
end
if nargout >= 6
    phaseDiffUnwrap = zeros(numRows, numCols, numSlice, numDynamics);
end
if nargout >= 7
    phaseDiffUnwrapDriftCorrected = zeros(numRows, numCols, numSlice, numDynamics);
end
if nargout >= 8
    phaseDiffUnwrapDriftCorrectedUnwrap = zeros(numRows, numCols, numSlice, numDynamics);
end
if nargout >= 9
    maskSNR = zeros(numRows, numCols, numSlice, numDynamics);
end
if nargout >= 10
    maskStability = zeros(numRows, numCols, numSlice, numDynamics);
end
if nargout >= 11
    beta = zeros(6, numSlice, numDynamics);
end

%==========================================================================
% Set parameters
%==========================================================================
%%
switch upper(pipeline)
    case 'XTCA'
        setPipelineParameters = @SetXTCGlobals;
        if ~exist('driftCorrection','var')
            driftCorrection = @AutomaticFirstOrderDriftCorrectionFast;
        end
        % Assuming dynamic stabilization is turned off
        warning('Achieva pipeline assumes no dynamic stabilization, therefore applying ImageShift correction.')
        enableImageShift = 1;
        useReferenceImage = 1;
    case 'XTCI'
        setPipelineParameters = @SetXTCGlobals;
        if ~exist('driftCorrection','var')
            driftCorrection = @AutomaticSecondOrderDriftCorrection;
        end
        enableImageShift = 1;
        useReferenceImage = 1;
    case 'SIEMENSSYNGOTHERM'
        setPipelineParameters = @SetSiemens_SyngoTherm_Globals;
        if ~exist('driftCorrection','var')
            driftCorrection = @AutomaticFirstOrderDriftCorrectionFast;
        end
        enableImageShift = 1;
        useReferenceImage = 1;
    case 'SIEMENSPHASEIMAGING'
        setPipelineParameters = @SetSiemens_PhaseImaging_Globals;
        if ~exist('driftCorrection','var')
            % Confirmed on Skyra, but assumes Aera with Phase Imaging will still be 2nd order
            driftCorrection = @AutomaticSecondOrderDriftCorrection;
        end
        enableImageShift = 1;
        useReferenceImage = 1;
    case 'SIEMENSWIP1118'
        setPipelineParameters = @SetSiemens_WIP1118_Globals;
        if ~exist('driftCorrection','var')
            driftCorrection = @AutomaticFirstOrderDriftCorrectionFast;
        end
        enableImageShift = 1;
        useReferenceImage = 1;
    case 'SIEMENSFREEMAX'
        setPipelineParameters = @SetSiemens_FreeMax_Globals;
        if ~exist('driftCorrection','var')
            driftCorrection = @AutomaticSecondOrderDriftCorrection;
        end
        enableImageShift = 1;
        useReferenceImage = 1;
        
    case 'GE'
        setPipelineParameters = @SetGEGlobals;
        if ~exist('driftCorrection','var')
            driftCorrection = @AutomaticSecondOrderDriftCorrection;
        end
        enableImageShift = 1;
        useReferenceImage = 1;
    otherwise
        error('Unknown pipeline argument')
end
%%
warning off backtrace
switch nargin
    case 3
        setPipelineParameters();
        warning('Results may not exactly match TDC because of missing base temperature, UA Center, and MR center frequency')
    case 4
        setPipelineParameters(baseTemperature);
        warning('Results may not exactly match TDC because of missing UA Center, and MR center frequency')
    case 5
        setPipelineParameters(baseTemperature, UACenter);
        warning('Results may not exactly match TDC because of missing MR center frequency')
    case 6
        setPipelineParameters(baseTemperature, UACenter, MRIcenterFrequencyHz);
    otherwise
        setPipelineParameters(baseTemperature, UACenter, MRIcenterFrequencyHz, echoTime);
end

%==========================================================================
% Image shift pre-processing
%==========================================================================
if enableImageShift
    [xShifts, yShifts] = evaluateShift(magStack);
    % shiftPattern allows to specify a delay sequence to apply the shifts in order to match TDC delay, i.e. in this example [6 7 6 7 6 7 7 7 7 8 7 8],
    % slice 1 will be shifted at dynamic X06 (106, 206 etc...), slice 2 will be shifted at dynamic X07 (107, 207 etc...), and so on...
    % Default is to shift at 106.
    shiftPattern = [6 6 6 6 6 6 6 6 6 6 6 6];    
    
    if useReferenceImage % This is the default
        if nargin < 8 % Since user specified a refPhaseStack, just skip the calculation
            refPhase = CalculateReference(magStack(:,:,:,1:gc.numRefImages), ConvertPhaseRadians(phaseStack(:,:,:,1:gc.numRefImages),gc.pipeline));
            refPhaseStack  = applyRefShift(refPhase, xShifts, yShifts, numDynamics, shiftPattern);
        end
    else
        magStack    = applyShift(magStack, xShifts, yShifts, 'Magnitude');
        phaseStack  = applyShift(phaseStack, xShifts, yShifts, 'Phase');
        refPhaseStack = [];
    end
    [maskUA, maskRectum] = calculateShiftedMasks(xShifts, yShifts, numDynamics, shiftPattern);
else
    if nargin < 8 % Since user specified a refPhaseStack, just skip the calculation
        refPhaseStack = [];
    end
    [maskUA, maskRectum] = calculateShiftedMasks([], [], numDynamics, []);
end

%========================================
% Main loop
%========================================
fprintf('Generating TMaps...\n');
fprintf('======================================\n')
fprintf('Pipeline: %s\n',pipeline);
fprintf('Echo time: %.2f ms\n', gc.TE);
fprintf('Drift correction: %s\n',func2str(driftCorrection));
fprintf('MRI field strength: %.2fT\n',gc.magnet);
fprintf('Base temperature: %.2f�C\n',gc.baseTemp);
fprintf('UA Center: [%.2f %.2f]\n',gc.UAX, gc.UAY);
fprintf('======================================\n    ')

for dynIdx = 1:numDynamics
    currentMagnitudeImage = magStack(:,:,:,dynIdx);
    currentPhaseImage = phaseStack(:,:,:,dynIdx);
    
    [dynamicTMap, intermediateMatrices]...
        = Generate1DynamicTMapsMatlab(dynIdx, currentMagnitudeImage, currentPhaseImage, driftCorrection, refPhaseStack, maskUA(:,:,:,dynIdx), maskRectum(:,:,:,dynIdx));
    
    if dynIdx > gc.numRefImages
        TMap(:,:,:,dynIdx) = dynamicTMap;
        % Again, for memory management
        if nargout >= 4
            outputTotalMask(:,:,:,dynIdx) = intermediateMatrices{1};
        end
        if nargout >= 5
            phaseDiff(:,:,:,dynIdx) = intermediateMatrices{2};
        end
        if nargout >= 6
            phaseDiffUnwrap(:,:,:,dynIdx) = intermediateMatrices{3};
        end
        if nargout >= 7
            phaseDiffUnwrapDriftCorrected(:,:,:,dynIdx) = intermediateMatrices{4};
        end
        if nargout >= 8
            phaseDiffUnwrapDriftCorrectedUnwrap(:,:,:,dynIdx) = intermediateMatrices{5};
        end
        if nargout >= 9
            maskSNR(:,:,:,dynIdx) = intermediateMatrices{6};
        end
        if nargout >= 10
            maskStability(:,:,:,dynIdx) = intermediateMatrices{7};
        end
        if nargout >= 11
            beta(:,:,dynIdx) = intermediateMatrices{8};
        end
    end
    % Update display
    progressPercentage = min(round(dynIdx/numDynamics*100),100);
    backspaceChars = repmat('\b',1,length(num2str(progressPercentage))+1);
    fprintf([backspaceChars '%d%%'],progressPercentage);
end
fprintf('\n');

% Assign varargout outputs
if enableImageShift  
    if useReferenceImage
        varargout{1} = refPhaseStack;
        varargout{2} = [];
    else
    varargout{1} = magStack;
    varargout{2} = phaseStack;
    end
else
    varargout{1} = [];
    varargout{2} = [];
end
if nargout >= 4
    varargout{3} = outputTotalMask;
end
if nargout >= 5
    varargout{4} = phaseDiff;
end
if nargout >= 6
    varargout{5} = phaseDiffUnwrap;
end
if nargout >= 7
    varargout{6} = phaseDiffUnwrapDriftCorrected;
end
if nargout >= 8
    varargout{7} = phaseDiffUnwrapDriftCorrectedUnwrap;
end
if nargout >= 9
    varargout{8} = maskSNR;
end
if nargout >= 10
    varargout{9} = maskStability;
end
if nargout >= 11
    varargout{10} = maskUA;
end
if nargout >= 12
    varargout{11} = maskRectum;
end
if nargout >= 13
    varargout{12} = beta;
end
end

function [maskUA, maskRectum] = calculateShiftedMasks(xShifts, yShifts, numDynamics, shiftPattern)
global gc
[shiftedUAX,shiftedUAY] = calculateUACenterShifts(repmat(gc.UAX,1,12), repmat(gc.UAY,1,12), xShifts, yShifts, numDynamics, shiftPattern);
maskUA = zeros(128,128,12,numDynamics);
maskRectum = zeros(128,128,12,numDynamics);

for dynIdx = 1:numDynamics
    for sliceIdx = 1:12
        maskUA(:,:,sliceIdx,dynIdx) = subCalculateUAMask(gc.rad, gc.voxelsize, 128, 128, shiftedUAX(dynIdx, sliceIdx), shiftedUAY(dynIdx, sliceIdx));
        maskRectum(:,:,sliceIdx,dynIdx) = subCalculateRectumMask(gc.voxelsize, 128, 128, gc.halfwidth, shiftedUAX(dynIdx, sliceIdx), shiftedUAY(dynIdx, sliceIdx));
    end
end
end

