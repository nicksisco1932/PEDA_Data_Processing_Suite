%% TUV CMap
%%From TDC source code
%% coloraxis = [0 5]

%%%%%%%%%%%%%%%%%%%%%%%
% Initialize variables
%%%%%%%%%%%%%%%%%%%%%%%
% Since we need to have a color gradient, we need to oversample the
% colormap
cmapSize = 600;

MinimumTemperatureUncertainty = 1;
Threshold3 = cmapSize;
Threshold2 = 2/3*cmapSize  + 1;
Threshold1 = 1/3*cmapSize  + 1 ;

red = zeros(1,cmapSize);
green = zeros(1,cmapSize);
blue = zeros(1,cmapSize);

%%%%%%%%%%%%%%%%%
% Build colormap
%%%%%%%%%%%%%%%%%
% Comments are TDC code

% MinimumTemperatureUncertainty = 0; 
% Threshold1 = 2;
% Threshold2 = 4;
% if (value >= ProstateBoundaryValidator.MinimumTemperatureUncertainty &&
%     value < ProstateBoundaryValidator.Threshold1)
%     {
%         red = 0;
%         green = (byte) Math.Round((value*256)/2);
%         blue = 0xFF;
%         
%     }
red(MinimumTemperatureUncertainty:Threshold1-1) = 0;
blue(MinimumTemperatureUncertainty:Threshold1-1) = 255;
green(MinimumTemperatureUncertainty:Threshold1-1) = linspace(0,255,(Threshold1-MinimumTemperatureUncertainty));

% else if (value >= ProstateBoundaryValidator.Threshold1 &&
%                     value < ProstateBoundaryValidator.Threshold2)
%            {
%                red = 0xFF;
%                green = (byte) (byte.MaxValue - (byte) (Math.Round(((value - 2f)*256)/2)));
%                blue = 0;
%            }
red(Threshold1:Threshold2-1) = 255;
green(Threshold1:Threshold2-1) = linspace(255,0,(Threshold2-Threshold1));
blue(Threshold1:Threshold2-1) = 0;

% else if (value >= ProstateBoundaryValidator.Threshold2)
%            {
%                red = 128;
%                green = 64;
%                blue = 128;
%            }
red(Threshold2:Threshold3) = 128;
green(Threshold2:Threshold3) = 64;
blue(Threshold2:Threshold3) = 128;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Make it a Matlab colormap
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cmapTUV = [red; green; blue]';
cmapTUV = cmapTUV/255;
% imshow(TUV(:,:,12,end));caxis([0 6]);colormap (cmapTUV);
% colorbar('Ticks',[0 2 4],'TickLabels',{'0' '2' '4'});

%% TDC Cmap
% coloraxis = [20 101]; %We want to map from 20 to 100 but somehow Matlab colormap works with intervals. So we need to get to 101
% TickLabels = {20 55 90 100};
% XTick = [20 55 90 100];

%%From TDC Source code
clear cmap4

%%%%%%%%%%%%%%%%%%%%%%%
% Initialize matrices
%%%%%%%%%%%%%%%%%%%%%%%
cmap3 = zeros(3,100);
red = zeros(1,100);
green = zeros(1, 100);
blue = zeros(1,100);

%%%%%%%%%%%%%%%%%
% Build colormap
%%%%%%%%%%%%%%%%%
% Comments are TDC code

% red = (byte) (value >= 55 ? 0xFF : 0x00)
red(55:end) = 255; %0xFF
red(1:54) = 0; %0x00

%blue = (byte) (value >= 52 ? 0x00 : 0xFF)
blue(52:end) = 0; %0x00
blue(1:51) = 255; %0xFF

%else if (value >= 20 && value <= 89)
%green = greenValuesByTemperature[(int) Math.Truncate(value)];
green(20:89) = [0 7 15 23 31 39 47 55 63 71 
        79 87 95 103 111 119 127 135 143 151
        159 167 175 183 191 199 207 215 223 231
        239 247 191 191 191 255 247 240 233 225 
        218 211 204 196 189 182 174 167 160 153
        145 138 131 123 116 109 102 94 87 80
        72 65 58 50 43 36 29 21 14 7]';
    
% else if (value > 89)
%             {
%                 green = 63;
%             }
green(90:end) = 63;

% if (value >= 90 & value < 100)
%             {
%                 red = 127;
%                 blue = 127;
%             }    
red(90:99) = 127;
blue(90:99) = 127;

% else if (value >= 100)
%             {
%                 red = 89;
%                 blue = 89;
%             }
red(100) = 89;
blue(100) = 89;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Make it a Matlab colormap
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cmap3 = [red; green; blue]';
cmap3 = cmap3(20:end,:)/255;

