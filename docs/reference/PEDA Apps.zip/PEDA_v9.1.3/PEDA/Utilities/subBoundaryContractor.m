% == subBoundaryContractor.m ==============================================
% This function is transcribed from TDC code to generate a contracted
% boundary from an original boundary (e.g. generate a control boundary
% given a prostate boundary input).  It smooths out sharp corners in the
% original boundary and also provides a margin along the sides of partially
% defined boundaries.
% 
% Inputs:  
%       - OriginalBoundaryMM: [mm] [360 x 1] radius values in mm in 1 degree steps mapping to 0:359
%       - ContractionFactorMM: [mm] [1 x 1] the margin between inner and outer boundaries
%       
% Outputs:
%       - ContractedBoundaryMM: [mm] [360 x 1] the inner boundary corresponding to the original outer boundary
% 
% By: Ben Leung
% Date: 10-SEP-2018
% =========================================================================


function ContractedBoundaryMM = subBoundaryContractor(OriginalBoundaryMM, ContractionFactorMM)

%% ======================Initialization====================================
MTRMM = 8; %[mm] minimum treatable radius
ContractedBoundaryMM = ones(size(OriginalBoundaryMM)).*MTRMM; % Initialize new boundary at MTR

maximumAngleOfShadowDegrees = rad2deg(asin(ContractionFactorMM ./ MTRMM ));
maximumShadowedPoints = floor(maximumAngleOfShadowDegrees);

angleStepDegrees = 1;
degreesInFullCircle = 360;
numberPointsOnBoundary =  round(degreesInFullCircle ./ angleStepDegrees);

%% =====================Main Loop==========================================
for angleIdx = 1:length(OriginalBoundaryMM)
    % Simple truncation of current radius
    ContractedBoundaryMM(angleIdx) = OriginalBoundaryMM(angleIdx) - ContractionFactorMM;
    
    % does line parallel to next edge intersect current radius?
    nextAngleIdx = wrapTo360(angleIdx + 1);
    if nextAngleIdx == 0
        nextAngleIdx = numberPointsOnBoundary;
    end
    nextRadiusMM = OriginalBoundaryMM(nextAngleIdx);
    currentRadiusMM = OriginalBoundaryMM(angleIdx);
    
    displacement = (nextRadiusMM - currentRadiusMM);
    
    if displacement.^2 + currentRadiusMM.^2 >= nextRadiusMM.^2
        % radius at current angle may intersect the line parallel to this edge
        truncationMM = displacement * ContractionFactorMM ./ (nextRadiusMM.*sin(deg2rad(angleStepDegrees)));
        
        if truncationMM.^2 <= displacement.^2 + ContractionFactorMM.^2
            % radius at current angle does intersect the line parallel to this edge
            if currentRadiusMM - truncationMM < ContractedBoundaryMM(angleIdx)
                ContractedBoundaryMM(angleIdx) = currentRadiusMM - ContractionFactorMM;
            end
        end
    end
    
    % does line parallel to next edge intersect current radius?
    previousAngleIdx = wrapTo360(angleIdx - 1);
    if previousAngleIdx == 0
        previousAngleIdx = numberPointsOnBoundary;
    end
    previousRadiusMM = OriginalBoundaryMM(previousAngleIdx);
    currentRadiusMM = OriginalBoundaryMM(angleIdx);
    
    displacement = (previousRadiusMM - currentRadiusMM);
    
    if displacement.^2 + currentRadiusMM.^2 >= previousRadiusMM.^2
        % radius at current angle may intersect the line parallel to this edge
        truncationMM = displacement * ContractionFactorMM ./ (previousRadiusMM.*sin(deg2rad(angleStepDegrees)));
        
        if truncationMM.^2 <= displacement.^2 + ContractionFactorMM.^2
            % radius at current angle does intersect the line parallel to this edge
            if currentRadiusMM - ContractionFactorMM < ContractedBoundaryMM(angleIdx)
                ContractedBoundaryMM(angleIdx) = currentRadiusMM - ContractionFactorMM;
            end
        end
    end
    
    % does the current radius come within the margin of any other vertex?
    for indexOffset = 1:maximumShadowedPoints
        angleOffsetRadians = indexOffset .* deg2rad(angleStepDegrees);
        pointIndex = wrapTo360(mod(angleIdx + indexOffset, numberPointsOnBoundary));
        if pointIndex == 0
            pointIndex = numberPointsOnBoundary;
        end
        orthogonalDistanceMM = OriginalBoundaryMM(pointIndex) .* sin(angleOffsetRadians);
        
        if orthogonalDistanceMM <= ContractionFactorMM
            d = ContractionFactorMM.^2 - orthogonalDistanceMM.^2;
            affectedRadiusMM = OriginalBoundaryMM(pointIndex).*cos(angleOffsetRadians) - sqrt(d);
            if affectedRadiusMM < ContractedBoundaryMM(angleIdx)
               ContractedBoundaryMM(angleIdx) = affectedRadiusMM; 
            end
        end
        
        pointIndex = wrapTo360(mod(angleIdx - indexOffset, numberPointsOnBoundary));
        if pointIndex == 0
            pointIndex = numberPointsOnBoundary;
        end
        orthogonalDistanceMM = OriginalBoundaryMM(pointIndex) .* sin(angleOffsetRadians);
        
        if orthogonalDistanceMM <= ContractionFactorMM
            d = ContractionFactorMM.^2 - orthogonalDistanceMM.^2;
            affectedRadiusMM = OriginalBoundaryMM(pointIndex).*cos(angleOffsetRadians) - sqrt(d);
            if affectedRadiusMM < ContractedBoundaryMM(angleIdx)
               ContractedBoundaryMM(angleIdx) = affectedRadiusMM; 
            end
        end
        
    end

end