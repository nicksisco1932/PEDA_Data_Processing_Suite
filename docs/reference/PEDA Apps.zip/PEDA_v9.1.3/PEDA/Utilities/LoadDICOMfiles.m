function varargout = LoadDICOMfiles(inputDirectory, outputDirectory, dicomParameters)
%======================================
% function varargout = LoadDICOMfiles(inputDirectory, outputDirectory, dicomParameters)
%
% Purpose:
% ========
% Read and load DICOM files
%
% Input(s):
% =========
% - inputDirectory:     path to the folder where the DICOM files are located
% - outputDirectory:    optional argument. Path where to save Magnitude and
%                       Phase matrices. Default is inputDirectory.
% - dicomParameters:    optional argument. Must be [NumSlice NumRows NumCols].
%                       Default is [128 128 12]
%
% Output(s):
% ==========
% - Specify which output is needed and function will load files appropriately.
% - Order is [Magnitude, Phase, Re, Im]
% - Example: Magnitude = LoadDICOMfiles(src) will only load Magnitude files
%======================================

if nargin == 1
    outputDirectory = inputDirectory;
    NumSlices = 12;
    NumRows = 128;
    NumCols = 128;
elseif nargin == 2
    NumSlices = 12;
    NumRows = 128;
    NumCols = 128; 
elseif nargin == 3
    NumSlices = dicomParameters(1);
    NumRows = dicomParameters(2);
    NumCols = dicomParameters(3);
end

% Variable initialization
displayIncompleteWarning = 0;
displayMismatchWarning = 0;

% After DicomClean, each file have proper suffix
listMag = dir(fullfile(inputDirectory,'*-Mag*'));
listPhase = dir(fullfile(inputDirectory,'*-Phase*'));
listRe = dir(fullfile(inputDirectory,'*-Re*'));
listIm = dir(fullfile(inputDirectory,'*-Im*'));

% However, for backward compatibility, older version of DicomClean does not
% append a -Phase with Siemens Dicom files. Therefore, look for *TMap*
% files
if isempty(listPhase)
    listPhase = dir(fullfile(inputDirectory,'*TMap*'));
end

list_cell = {'Magnitude', 'Phase', 'Re', 'Im'; ...
            listMag, listPhase, listRe, listIm};

% Filter files to load based on requested outputs
list_cell = list_cell(:, 1:nargout);

non_empty_lists = list_cell(2, ~cellfun(@isempty,list_cell(2,:)));

if isempty(non_empty_lists)
    error('Could not find any DICOM files. Check filepath and string pattern')
end

%Detect if mismatch between any of the file lists (missing slices?)
struct_lengths = cellfun(@length,non_empty_lists);
if ~all(struct_lengths == struct_lengths(1))
    displayMismatchWarning = 1;
end

% output_arrays = cell(1, length(non_empty_lists));
for list_index = 1:length(list_cell(1,:))
    MatName = list_cell{1, list_index};
    Filelist = list_cell{2, list_index};
    
    if isempty(Filelist)
        fprintf('Cell index skipped');
        continue
    end
    
    %Determine the size of the arrays
    NumDynamic = length(Filelist)/NumSlices;
    NumImages = length(Filelist);
    
    %Detect if any incomplete dynamic
    if ~(round(NumDynamic) == NumDynamic)
        displayIncompleteWarning = 1;
        NumDynamic = floor(NumDynamic);
        NumImages = NumDynamic*NumSlices;
    end
    
    fprintf(['Reading ' MatName '... '])
    inputArray = zeros(NumRows, NumCols, NumSlices, NumDynamic);
    outputArray = load_dcms(Filelist, inputArray);
    varargout{list_index} = outputArray;
    
    disp('...Saving');
    % Needed to save outputArray as MatName
    % See https://www.mathworks.com/matlabcentral/answers/84518-save-variables-in-mat-files-with-desired-name
    tmp.(MatName) = outputArray;
    save(fullfile(outputDirectory,[MatName '.mat']),'-struct','tmp', MatName);
end

% Display warning is incomplete dynamic(s) found
if displayMismatchWarning | displayIncompleteWarning
    fprintf('\n******************************************\n');
    warning('on')
    if displayMismatchWarning
        warning('Dimension mismatch found between matrices');
    end
    if displayIncompleteWarning
        warning('\nSkipped incomplete dynamic(s)');
    end
    fprintf('******************************************\n');
    warning('off')
end

end

function array = load_dcms(filelist, array)
Nfiles = length(filelist);
MaxSize = size(array, 4);
for fileidx = 1:Nfiles
    fileInfo = textscan(filelist(fileidx).name,'i%4d-s%2d-%s');
    filePath = fullfile(filelist(fileidx).folder, filelist(fileidx).name);
    
    currentDynamic = fileInfo{1} + 1; % File name is zero-based
    currentSlice = fileInfo{2} + 1; % File name is zero-based
    
        if currentDynamic == MaxSize + 1
            break
        end
    array(:,:,currentSlice,currentDynamic) = dicomread(filePath);
    
    show_progress(fileidx, Nfiles)
end
end

function show_progress(current, total)
% Number of trailing zeros
numberTrailingZeros = numel(num2str(total));
formatString = sprintf('%%0%dd',numberTrailingZeros);
if current == 1
    backspaceChars = [];
else
    backspaceChars = repmat('\b',1,2*numberTrailingZeros+1); %Two numbers with numberTrailingZeros digits + 1 symbol (/)
end

fprintf([backspaceChars formatString '/%d'],current,total);
end
%%

