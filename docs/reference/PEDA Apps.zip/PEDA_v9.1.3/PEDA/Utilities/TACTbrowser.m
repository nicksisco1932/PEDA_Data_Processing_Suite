%% TACTbrowser.m ==============================================
% A small GUI to quickly browse through PEDA and PostTreatmentOverlay
% images, movies, and DICOMs in the TACT folder
% 
% By Ben Leung
% Date: 20-OCT-2017
% =========================================================================
function TACTbrowser
% find all patients with DICOMs and populate drop down list
patientroot = '\\PMIFS03\ClinicalData$\Clinical Trial Pivotal (TACT)';
handles.siteList = {'All sites', '001: UWO', '002: DKFZ', '003: William Beaumont', '004: Johns Hopkins', '005: Sunnybrook', '006: Vanderbilt', '007: Indiana', '008: UCLA', '009: Radboud', '011: ResoFUS', '012: Chicago', '013: UTSW', '014: Cologne'};
handles.patientroot = patientroot;
handles.currentSite = 'All';
handles.firstLoadPatientList = 1;
[handles.patientdir,~,~] = loadPatientList(handles);
handles.currentPatientID = '';
handles.currentPath = patientroot;
handles.firstPlot = 0;
handles.FeedbackFormPath = '';
handles.currentImage = 'TMax';
handles.currentMovie = '';
handles.currentNumSegments = 1;

hFig = figure('units','normalized','Position',[0.05 0 .9 .9]);

handles.listSites = uicontrol('Style','popupmenu','units','normalized','position',[0.01 .98 .1 .01],'String',handles.siteList,'Callback', @FilterSites);
handles.listPatients = uicontrol('Style','popupmenu','units','normalized','position',[0.01 .955 .1 .01],'String',{handles.patientdir.name},'Callback', @SelectPatient);
handles.axes1 = axes('units','normalized','Position',[.13 .02 .89 .92],'NextPlot','replacechildren','visible','off','ButtonDownFcn', @openFileOrFolder);
handles.editPath = uicontrol('Style','Edit','Units','normalized','Position',        [.13 .97 .57 .02],'string',patientroot,'horizontalalignment','left');
handles.openFile = uicontrol('Style','pushbutton','Units','normalized','Position',  [.7 .97 .04 .02],'String','Open','Callback', @openFile);
handles.openFolder = uicontrol('Style','pushbutton','Units','normalized','Position',  [.74 .97 .06 .02],'String','Show Folder','Callback', @openFolder);
handles.openDICOMFolder = uicontrol('Style','pushbutton','Units','normalized','Position',  [.8 .97 .07 .02],'String','Show DICOM Folder','Callback', @openDICOMFolder);

handles.PanelDetails = uipanel('title','Details','units','normalized','position',[0.01 0.61 .1 .33]);
handles.textDetails = uicontrol('parent',handles.PanelDetails,'Style','Text','Units','normalized','Position', [0 0 1 1],'string','','horizontalalignment','left');

handles.PanelOptions = uipanel('title','Options','units','normalized','position',[0.01 0.02 .1 .58]);
handles.TMax = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','Position',               [0.05 .93 .9 .06],'String','TMax','Callback', @ShowTMax);
handles.TDose = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','Position',              [0.05 .86 .9 .06],'String','TDose','Callback', @ShowTDose);
handles.ControllerSummary = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','Position',  [0.05 .79 .9 .06],'String','Treatment Controller Summary','Callback', @ShowControllerSummary);
handles.ElementSummary = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','Position',     [0.05 .72 .9 .06],'String','Element Summary','Callback', @ShowElementSummary);
handles.AngularSummary = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','Position',     [0.05 .65 .9 .06],'String','Treatment Summary','Callback', @ShowAngularSummary);
handles.SegmentSummary = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','Position',     [0.05 .58 .9 .06],'String','Segment Summary','Callback', @ShowSegmentSummary);
handles.PostTreament = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','Position',       [0.05 .51 .9 .06],'String','PostTreatmentOverlay','Callback', @ShowPostTreatment);

handles.PanelMovies = uipanel('parent', handles.PanelOptions,'title','Movies','units','normalized','position',            	[0.05 .27 .9 .22]);
handles.CurrentTemperature = uicontrol('parent', handles.PanelMovies,'Style','pushbutton','Units','normalized','Position',  [0.05 .69 .4 .3],'String','Current','Callback', @OpenCurrentTemperature);
handles.MaxTemperature = uicontrol('parent', handles.PanelMovies,'Style','pushbutton','Units','normalized','Position',      [0.05 .36 .4 .3],'String','Max','Callback', @OpenMaxTemperature);
handles.Magnitude = uicontrol('parent', handles.PanelMovies,'Style','pushbutton','Units','normalized','Position',           [0.05 .03 .4 .3],'String','Magnitude','Callback', @OpenMagnitude);

handles.TUV = uicontrol('parent', handles.PanelMovies,'Style','pushbutton','Units','normalized','Position',                 [0.55 .69 .4 .3],'String','TUV','Callback', @OpenTUV);
handles.TUVMag = uicontrol('parent', handles.PanelMovies,'Style','pushbutton','Units','normalized','Position',              [0.55 .36 .4 .3],'String','TUVMag','Callback', @OpenTUVMag);
handles.CheckMasked = uicontrol('parent', handles.PanelMovies,'Style','Checkbox','Units','normalized','Position',           [0.55 .03 .4 .3],'String','Overlay');%,'Callback', @chkMasked);

handles.PanelSegment = uipanel('parent', handles.PanelOptions,'title','Segment','units','normalized','position',            [0.05 .16 .9  .1]);
handles.CheckAllSegments = uicontrol('parent', handles.PanelSegment,'Style','Checkbox','Units','normalized','Position',     [0.35 .15 .65 .6],'String','All segments?','Callback', @chkAllSegments);
handles.listSegment = uicontrol('parent', handles.PanelSegment,'Style','popupmenu','Units','normalized','Position',         [0.05 .1  .22 .7], 'String', '1','Callback', @SwitchSegment);

handles.OpenPatientFile = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','position',   [0.05 0.08 0.9 0.06], 'String', 'TMF Patient Folder', 'Callback', @OpenPatientFile);
handles.OpenFeedbackForm = uicontrol('parent', handles.PanelOptions,'Style','pushbutton','Units','normalized','position',   [0.05 0.01 0.9 0.06], 'String', 'Treatment Feedback Form', 'Callback', @OpenFeedbackForm);

guidata(hFig,handles);

%% Callbacks
    function FilterSites(hFig,eventData)
        myhandles = guidata(hFig);
        myhandles.currentSite = myhandles.listSites.String{myhandles.listSites.Value}(1:3);
        [myhandles.patientdir,myhandles.firstLoadPatientList,myhandles.currentSite] = loadPatientList(myhandles);
        myhandles.listPatients.String = {myhandles.patientdir.name};
        myhandles.listPatients.Value = 1;
        guidata(hFig,myhandles)
        SelectPatient(hFig,myhandles);
        guidata(hFig,myhandles)
    end

    function [dirPatientList,firstLoadPatientList,currentSite] = loadPatientList(handles)
        firstLoadPatientList = handles.firstLoadPatientList;
        currentSite = handles.currentSite;
        dirPatientList = dir(handles.patientroot);
        dirPatientList = dirPatientList([dirPatientList(:).isdir]);
        dirPatientList = dirPatientList(3:end); %get rid of . and ..
        patientindex = zeros(1,length(dirPatientList));
        if strcmp(handles.currentSite, 'All')
            for ii = 1:length(dirPatientList)
                if exist(fullfile(handles.patientroot,dirPatientList(ii).name,'DICOMs'))
                    patientindex(ii) = 1;
                end
            end
        else
            for ii = 1:length(dirPatientList)
                if strfind(dirPatientList(ii).name,handles.currentSite) & exist(fullfile(handles.patientroot,dirPatientList(ii).name,'DICOMs'))
                    patientindex(ii) = 1;
                end
            end
        end
        dirPatientList = dirPatientList(find(patientindex));
        
        if handles.firstLoadPatientList
            firstLoadPatientList = 0;
        else
            currentSite = handles.listSites.String{handles.listSites.Value}(1:3);
        end

    end

    function pathSessions = findSessionPath(handles)
       patientID = handles.listPatients.String(handles.listPatients.Value);
       ind = regexp(patientID{1}, '[0-9]+[0-9]+[0-9]+-+[0-9]+[0-9]+[0-9]');
       patientID = patientID{1}(ind:ind+6);
       pathSessions = fullfile(fileparts(fullfile(handles.patientroot,handles.patientdir(handles.listPatients.Value).name,'DICOMs')),'Sessions');
    end

    function pathPEDA = findPEDAPath(handles)
       pathSessions = findSessionPath(handles);
       dirSessions = dir(pathSessions);
       indPEDA = 0;
       for jj = 1:length(dirSessions)
            if strfind(dirSessions(jj).name,'PEDA')
                indPEDA = jj;
            end
       end
       if indPEDA ~=0
           verPEDA = dirSessions(indPEDA).name;
           pathPEDA = fullfile(fileparts(fullfile(handles.patientroot,handles.patientdir(handles.listPatients.Value).name,'DICOMs')),'Sessions',verPEDA);
       else
           pathPEDA = fullfile(fileparts(fullfile(handles.patientroot,handles.patientdir(handles.listPatients.Value).name,'DICOMs')),'Sessions');
       end
    end

    function pathPatientFile = findPatientTMFPath(handles)
        root = '\\Pmifs03\qara$\Records\1_Clinical\TULSA\TACT\Phase II_Clinical Sites';
        siteID = handles.currentPatientID(1:3);
        rootdir = dir(root);
        sitedir = dir(fullfile(rootdir(~cellfun('isempty',strfind({rootdir.name},siteID))).folder,rootdir(~cellfun('isempty',strfind({rootdir.name},siteID))).name));
        TMFdir = dir(fullfile(sitedir(~cellfun('isempty',strfind({sitedir.name},'TMF'))).folder,sitedir(~cellfun('isempty',strfind({sitedir.name},'TMF'))).name));
        subjectdir = dir(fullfile(TMFdir(~cellfun('isempty',strfind({TMFdir.name},'Subject File'))).folder,TMFdir(~cellfun('isempty',strfind({TMFdir.name},'Subject File'))).name));
        patientdir = dir(fullfile(subjectdir(~cellfun('isempty',strfind({subjectdir.name},handles.currentPatientID))).folder,subjectdir(~cellfun('isempty',strfind({subjectdir.name},handles.currentPatientID))).name));
        pathPatientFile = patientdir(1).folder;
    end

    function pathFeedbackForm = findFeedbackFormPath(handles)
        dirFeedbackForm = subdir(fullfile(fileparts(fileparts(findPEDAPath(handles))),'GCP*.docx'));
        pathFeedbackForm = dirFeedbackForm(1).name;
    end
%% GUI Callbacks
    function openFile(hFig,eventData)
        myhandles = guidata(hFig);
        winopen(myhandles.editPath.String);
    end

    function openFolder(hFig,eventData)
        myhandles = guidata(hFig);
        
        if isempty(strfind(myhandles.editPath.String,'.png')) & isempty(strfind(myhandles.editPath.String,'.mp4'))
            winopen(myhandles.editPath.String);
        else
            winopen(fileparts(myhandles.editPath.String));
        end
    end
    
    function openFileOrFolder(hFig,eventData)
        myhandles = guidata(hFig);
        if eventData.Button == 1 %left click
            openFile(hFig,eventData)
        elseif eventData.Button == 2 %middle click
            openFolder(hFig,eventData)
        elseif eventData.Button == 3 %right click
            openDICOMFolder(hFig,eventData)
        end
    end

    function openDICOMFolder(hFig,eventData)
        myhandles = guidata(hFig);

        if ~isempty(strfind(myhandles.editPath.String,'DICOMs'))
            winopen(myhandles.editPath.String);
        elseif isempty(strfind(myhandles.editPath.String,'Sessions'))
            %do nothing
        else
            ind = strfind(myhandles.editPath.String,'Sessions');
            strPath = fullfile(myhandles.editPath.String(1:ind-1),'DICOMs');
            myhandles.editPath.String = strPath;
            winopen(myhandles.editPath.String);
        end
    end

    % if a new patient is selected, populate text fields with path
    function SelectPatient(hFig,eventData)
       myhandles = guidata(hFig);
       pathPEDA = findPEDAPath(myhandles);
       myhandles.editPath.String = pathPEDA;
       myhandles.listSegment.Value = 1;
       dirPEDA = dir(pathPEDA);
       folders = find(arrayfun(@(x) x.isdir,dirPEDA));
       patientID = myhandles.listPatients.String(myhandles.listPatients.Value);
       ind = regexp(patientID{1}, '[0-9]+[0-9]+[0-9]+-+[0-9]+[0-9]+[0-9]');
       myhandles.currentPatientID = patientID{1}(ind:ind+6);
       
       numSegments = 0;
       for jj = 1:length(folders)
           if ~isempty(strfind(dirPEDA(folders(jj)).name,'Segment'))
               numSegments = numSegments+1;
           end
       end
       myhandles.currentNumSegments = numSegments;
       cellSegments = cell(1,numSegments);
       for jj = 1:numSegments
           cellSegments{jj} = num2str(jj);
       end
       myhandles.listSegment.String = cellSegments;
       if numSegments > 1
           set(myhandles.SegmentSummary,'Enable', 'on');
           set(myhandles.CheckAllSegments,'Enable','on');
       else
           set(myhandles.SegmentSummary,'Enable', 'off');
           set(myhandles.CheckAllSegments,'Enable','off');
       end
       
       stats = load(fullfile(pathPEDA,'PEDAOverallResults.mat'));
       
       counter = 1;
       details{counter} = ['Prostate volume (cc): ' num2str(stats.PEDAOverallResults.Temperature.totalProstateVolumeCM3,'%3.1f')];
       counter = counter+1;
       details{counter} = ['Treatment time (min): ' num2str(stats.PEDAOverallResults.TotalTreatmentTimeMIN,'%4.1f')];
       if numSegments > 1
           for jj = 1:numSegments
               counter = counter+1;
               details{counter} = ['   Segment ' num2str(jj) ' (min): ' num2str(stats.PEDAOverallResults.SegmentTimeMIN(jj),'%4.1f')];
           end
       end
       counter = counter+1;
       details{counter} = ['Angular extent (�): ' num2str(stats.PEDAOverallResults.TotalAngularExtentDEG,'%4.1f')];
       if numSegments > 1
           for jj = 1:numSegments
               counter = counter+1;
               details{counter} = ['   Segment ' num2str(jj) ' (�): ' num2str(stats.PEDAOverallResults.AngularExtentDEG(jj),'%4.1f')];
           end
       end
       counter = counter+1;
       details{counter} = 'Patient Temperature (�C)';
       for jj = 1:numSegments
           counter = counter+1;
           details{counter} = ['   Segment ' num2str(jj) ' (�C): ' num2str(stats.PEDAOverallResults.PatientTemperatureDEG(jj))];
       end
       
       counter = counter+1; details{counter} = ''; counter = counter+1;
       details{counter} = ['DSC: ' num2str(stats.PEDAOverallResults.Temperature.DSCVolume,'%0.2f')];
       counter = counter+1;
       details{counter} = ['Overshoot 1mm (%): ' num2str(stats.PEDAOverallResults.Temperature.percentOSVolume1mm,'%2.1f')];
       counter = counter+1;
       details{counter} = ['Undershoot 1mm (%): ' num2str(stats.PEDAOverallResults.Temperature.percentUSVolume1mm,'%2.1f')];
       
       myhandles.textDetails.String = details;
       
       if strcmp(myhandles.currentImage,'TMax')
            pathPEDA = findPEDAPath(myhandles);
            if ~myhandles.CheckAllSegments.Value
                pathSegment = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)]);
            else
                pathSegment = pathPEDA;
            end
            TMax = imread(fullfile(pathSegment,[myhandles.currentPatientID, '_TMax.png']));
            ShowImage(myhandles,TMax)

            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID, '_TMax.png']);
            myhandles.currentPath = myhandles.editPath.String;
       elseif strcmp(myhandles.currentImage,'TDose')
            pathPEDA = findPEDAPath(myhandles);
            if ~myhandles.CheckAllSegments.Value
                pathSegment = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)]);
            else
                pathSegment = pathPEDA;
            end
            TDose = imread(fullfile(pathSegment,[myhandles.currentPatientID, '_TDose.png']));
            ShowImage(myhandles,TDose)

            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID, '_TDose.png']);
            myhandles.currentPath = myhandles.editPath.String;
       elseif strcmp(myhandles.currentImage,'ControllerSummary')
            pathPEDA = findPEDAPath(myhandles);
            if ~myhandles.CheckAllSegments.Value
                pathTreatmentController = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)],'Treatment Controller');
            else
                warning('No option for All Segments')
                return
            end

            dirTreatmentController = dir(fullfile(pathTreatmentController,'*.png'));

            ControllerSummary = imread(fullfile(pathTreatmentController,dirTreatmentController(3).name));
            ShowImage(myhandles,ControllerSummary)

            myhandles.editPath.String = fullfile(pathTreatmentController,dirTreatmentController(3).name);
            myhandles.currentPath = myhandles.editPath.String;
       elseif strcmp(myhandles.currentImage,'ElementSummary')
            pathPEDA = findPEDAPath(myhandles);
            if ~myhandles.CheckAllSegments.Value
                pathTreatmentController = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)],'Treatment Controller');
            else
                warning('No option for All Segments')
                return
            end

            dirTreatmentController = dir(fullfile(pathTreatmentController,'*.png'));

            ElementSummary = imread(fullfile(pathTreatmentController,dirTreatmentController(2).name));
            ShowImage(myhandles,ElementSummary)

            myhandles.editPath.String = fullfile(pathTreatmentController,dirTreatmentController(2).name);
            myhandles.currentPath = myhandles.editPath.String;
       elseif strcmp(myhandles.currentImage,'AngularSummary')
            pathPEDA = findPEDAPath(myhandles);
            if ~myhandles.CheckAllSegments.Value
                pathTreatmentController = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)],'Treatment Controller');
            else
                warning('No option for All Segments')
                return
            end

            dirTreatmentController = dir(fullfile(pathTreatmentController,'*.png'));

            AngularSummary = imread(fullfile(pathTreatmentController,dirTreatmentController(1).name));
            ShowImage(myhandles,AngularSummary)

            myhandles.editPath.String = fullfile(pathTreatmentController,dirTreatmentController(1).name);
            myhandles.currentPath = myhandles.editPath.String;
        elseif strcmp(myhandles.currentImage,'TMaxSegments')
            pathPEDA = findPEDAPath(myhandles);
            
            if myhandles.currentNumSegments == 1
                pathSegment = fullfile(pathPEDA,'Segment 1');
                
                TMax = imread(fullfile(pathSegment,[myhandles.currentPatientID, '_TMax.png']));
                ShowImage(myhandles,TMax)
                myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID, '_TMax.png']);
                myhandles.currentImage = 'TMax';
            else
                TMaxSegments = imread(fullfile(pathPEDA,[myhandles.currentPatientID, '_TMaxSegments.png']));
                ShowImage(myhandles,TMaxSegments)       
                myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID, '_TMaxSegments.png']);
            end
            myhandles.currentPath = myhandles.editPath.String;
       elseif strcmp(myhandles.currentImage,'PostTreatment')
            pathPostTreatment = fullfile(findSessionPath(myhandles),'Post Treatment Overlay');
            dirPostTreatment = dir(fullfile(pathPostTreatment,'*.png'));

            PostTreatment = imread(fullfile(pathPostTreatment,dirPostTreatment(1).name));
            ShowImage(myhandles,PostTreatment)

            myhandles.editPath.String = fullfile(pathPostTreatment,dirPostTreatment(1).name);
            myhandles.currentPath = myhandles.editPath.String;
       end
    
           myhandles.currentPath = myhandles.editPath.String;
           guidata(hFig,myhandles);
           
    end

    function chkAllSegments(hFig,eventData)
        myhandles = guidata(hFig);
        if myhandles.CheckAllSegments.Value
            set(myhandles.listSegment,'Enable','off')
        else
            set(myhandles.listSegment,'Enable','on')
        end
        SwitchSegment(hFig,eventData)
        guidata(hFig,myhandles);
    end
    
    function SwitchSegment(hFig,eventData)
        myhandles = guidata(hFig);
        if strcmp(myhandles.currentImage, 'TMax')
            ShowTMax(hFig,eventData)
        elseif strcmp(myhandles.currentImage, 'TDose')
            ShowTDose(hFig,eventData)
        elseif strcmp(myhandles.currentImage, 'ControllerSummary')
            ShowControllerSummary(hFig,eventData)
        elseif strcmp(myhandles.currentImage, 'ElementSummary')
            ShowElementSummary(hFig,eventData)
        elseif strcmp(myhandles.currentImage, 'AngularSummary')
            ShowAngularSummary(hFig,eventData)
        end
        guidata(hFig,myhandles);
    end

    function ShowTMax(hFig,eventData)
        myhandles = guidata(hFig);
        pathPEDA = findPEDAPath(myhandles);
        
        if ~myhandles.CheckAllSegments.Value
            pathSegment = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)]);
        else
            pathSegment = pathPEDA;
        end
        TMax = imread(fullfile(pathSegment,[myhandles.currentPatientID, '_TMax.png']));
        ShowImage(myhandles,TMax)
        
        myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID, '_TMax.png']);
        myhandles.currentPath = myhandles.editPath.String;
        myhandles.currentImage = 'TMax';
        guidata(hFig,myhandles);
    end
    
    function ShowTDose(hFig,eventData)
        myhandles = guidata(hFig);
        pathPEDA = findPEDAPath(myhandles);
        
        if ~myhandles.CheckAllSegments.Value
            pathSegment = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)]);
        else
            pathSegment = pathPEDA;
        end
        TDose = imread(fullfile(pathSegment,[myhandles.currentPatientID, '_TDose.png']));
        ShowImage(myhandles,TDose)
        
        myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID, '_TDose.png']);
        myhandles.currentPath = myhandles.editPath.String;
        myhandles.currentImage = 'TDose';
        guidata(hFig,myhandles);
    end
    
    function ShowControllerSummary(hFig,eventData)
        myhandles = guidata(hFig);
        pathPEDA = findPEDAPath(myhandles);
        if ~myhandles.CheckAllSegments.Value
            pathTreatmentController = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)],'Treatment Controller');
        else
            warning('No option for All Segments')
            return
        end
        
        dirTreatmentController = dir(fullfile(pathTreatmentController,'*.png'));
        
        ControllerSummary = imread(fullfile(pathTreatmentController,dirTreatmentController(3).name));
        ShowImage(myhandles,ControllerSummary)
        
        myhandles.editPath.String = fullfile(pathTreatmentController,dirTreatmentController(3).name);
        myhandles.currentPath = myhandles.editPath.String;
        myhandles.currentImage = 'ControllerSummary';
        guidata(hFig,myhandles);
    end

    function ShowElementSummary(hFig,eventData)
        myhandles = guidata(hFig);
        pathPEDA = findPEDAPath(myhandles);
        if ~myhandles.CheckAllSegments.Value
            pathTreatmentController = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)],'Treatment Controller');
        else
            warning('No option for All Segments')
            return
        end
        
        dirTreatmentController = dir(fullfile(pathTreatmentController,'*.png'));
        
        ElementSummary = imread(fullfile(pathTreatmentController,dirTreatmentController(2).name));
        ShowImage(myhandles,ElementSummary)
        
        myhandles.editPath.String = fullfile(pathTreatmentController,dirTreatmentController(2).name);
        myhandles.currentPath = myhandles.editPath.String;
        myhandles.currentImage = 'ElementSummary';
        guidata(hFig,myhandles);
    end

    function ShowAngularSummary(hFig,eventData)
        myhandles = guidata(hFig);
        pathPEDA = findPEDAPath(myhandles);
        if ~myhandles.CheckAllSegments.Value
            pathTreatmentController = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)],'Treatment Controller');
        else
            warning('No option for All Segments')
            return
        end
        
        dirTreatmentController = dir(fullfile(pathTreatmentController,'*.png'));
        
        AngularSummary = imread(fullfile(pathTreatmentController,dirTreatmentController(1).name));
        ShowImage(myhandles,AngularSummary)
        
        myhandles.editPath.String = fullfile(pathTreatmentController,dirTreatmentController(1).name);
        myhandles.currentPath = myhandles.editPath.String;
        myhandles.currentImage = 'AngularSummary';
        guidata(hFig,myhandles);
    end
    
    function ShowSegmentSummary(hFig,eventData)
        myhandles = guidata(hFig);
        pathPEDA = findPEDAPath(myhandles);
        
        TMaxSegments = imread(fullfile(pathPEDA,[myhandles.currentPatientID, '_TMaxSegments.png']));
        ShowImage(myhandles,TMaxSegments)
        set(myhandles.CheckAllSegments,'Value',1);
        set(myhandles.listSegment,'Enable','off');
        
        myhandles.editPath.String = fullfile(pathPEDA,[myhandles.currentPatientID, '_TMaxSegments.png']);
        myhandles.currentPath = myhandles.editPath.String;
        myhandles.currentImage = 'TMaxSegments';
        guidata(hFig,myhandles);
    end

    function ShowPostTreatment(hFig,eventData)
        myhandles = guidata(hFig);
        pathPostTreatment = fullfile(findSessionPath(myhandles),'Post Treatment Overlay');
        dirPostTreatment = dir(fullfile(pathPostTreatment,'*.png'));
        
        PostTreatment = imread(fullfile(pathPostTreatment,dirPostTreatment(1).name));
        ShowImage(myhandles,PostTreatment)
        
        myhandles.editPath.String = fullfile(pathPostTreatment,dirPostTreatment(1).name);
        myhandles.currentPath = myhandles.editPath.String;
        myhandles.currentImage = 'PostTreatment';
        guidata(hFig,myhandles);
    end
    
    function OpenCurrentTemperature(hFig,eventData)
        myhandles = guidata(hFig);
        if ~myhandles.CheckMasked.Value
            myhandles.currentMovie = 'Current';
        else
            myhandles.currentMovie = 'CurrentMasked';
        end
        OpenMovie(hFig,myhandles);
        guidata(hFig,myhandles);
    end

    function OpenMaxTemperature(hFig,eventData)
        myhandles = guidata(hFig);
        if ~myhandles.CheckMasked.Value
            myhandles.currentMovie = 'Max';
        else
            myhandles.currentMovie = 'MaxMasked';
        end
        OpenMovie(hFig,myhandles);
        guidata(hFig,myhandles);
    end

    function OpenMagnitude(hFig,eventData)
        myhandles = guidata(hFig);
        myhandles.currentMovie = 'Magnitude';
        OpenMovie(hFig,myhandles);
        guidata(hFig,myhandles);
    end

    function OpenTUV(hFig,eventData)
        myhandles = guidata(hFig);
        myhandles.currentMovie = 'TUV';
        OpenMovie(hFig,myhandles);
        guidata(hFig,myhandles);
    end

    function OpenTUVMag(hFig,eventData)
        myhandles = guidata(hFig);
        myhandles.currentMovie = 'TUVMag';
        OpenMovie(hFig,myhandles);
        guidata(hFig,myhandles);
    end

    function OpenMovie(hFig,myhandles)
        pathPEDA = findPEDAPath(myhandles);
        if ~myhandles.CheckAllSegments.Value
            pathSegment = fullfile(pathPEDA,['Segment ' num2str(myhandles.listSegment.Value)]);
        else
            pathSegment = pathPEDA;
        end
        
        if strcmp(myhandles.currentMovie,'Current')
            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID '_Current Temperature.mp4']);
        elseif strcmp(myhandles.currentMovie,'CurrentMasked')
            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID '_Current Temperature Overlay.mp4']);
        elseif strcmp(myhandles.currentMovie,'Max')
            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID '_Maximum Temperature.mp4']);
        elseif strcmp(myhandles.currentMovie,'MaxMasked')
            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID '_Maximum Temperature Overlay.mp4']);
        elseif strcmp(myhandles.currentMovie,'Magnitude')
            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID '_Magnitude.mp4']);
        elseif strcmp(myhandles.currentMovie,'TUV')
            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID '_TUV.mp4']);
        elseif strcmp(myhandles.currentMovie,'TUVMag')
            myhandles.editPath.String = fullfile(pathSegment,[myhandles.currentPatientID '_TUVMag.mp4']);
        end
        myhandles.currentPath = myhandles.editPath.String;
        winopen(myhandles.currentPath)
        guidata(hFig,myhandles);
    end

    function OpenPatientFile(hFig,eventData)
        myhandles = guidata(hFig);
        myhandles.PatientFilePath = findPatientTMFPath(myhandles);
        winopen(myhandles.PatientFilePath);
        guidata(hFig,myhandles);
    end

    function OpenFeedbackForm(hFig,eventData)
        myhandles = guidata(hFig);
        myhandles.FeedbackFormPath = findFeedbackFormPath(myhandles);
        winopen(myhandles.FeedbackFormPath);
        guidata(hFig,myhandles);
    end

    function ShowImage(handles, currentImage)
        if ~handles.firstPlot
            ax1b = get(handles.axes1, 'ButtonDownFcn');
            handles.axes1.Visible = 'on';
            handles.axes1 = imshow(currentImage,'InitialMagnification','fit');
            handles.firstPlot = 1;
            set(handles.axes1, 'ButtonDownFcn', ax1b);
        else 
            set(handles.axes1,'CData',currentImage)
        end
    end
end