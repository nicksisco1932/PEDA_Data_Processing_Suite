function DicomClean(DICOMFolder)
%======================================
% function DicomClean(DICOMFolder);
%
% Purpose:
% ========
% Process and clean DICOM files exported from MR scanners
%
% Input(s):
% =========
% - DICOMFolder: path to the folder where the DICOM files are located
%
% Output(s):
% ==========
% - None
%======================================

% Variable initialisation
SiemensSequenceIdx = 0;
previousSeriesNumber = 0;
previousManufacturer = '';
numMagBaseline = 0;
numMagDiff = 0;
numPhaseBaseline = 0;
numPhaseDiff = 0;
previousThermType = '';
zipFileAtEnd = 0;
tic

% Look for zip files
zipFile = dir(fullfile(DICOMFolder,'*.zip'));
if ~isempty(zipFile)
    fprintf('Unzipping %s...\n',zipFile.name)
    unzip(fullfile(DICOMFolder,zipFile.name),DICOMFolder)
else
%     zipFileAtEnd = 1;
    zipFileAtEnd = 0;
end

% Initialize folder list
folderContent = dir(DICOMFolder); %List folder contents
folderContent = folderContent([1 3:end]); % Remove '..' but keep '.' (current folder)
% Reorder files using natsort to be equivalent to Windows sort
[~,natsort_index] = natsortfiles({folderContent(:).name});
folderContent = folderContent(natsort_index);
dirFlags = [folderContent.isdir] ; %Look for sub-folders only
subFolders = folderContent(dirFlags);

for folderIdx = 1:length(subFolders)
    %Look for dicom files in each subfolder
    currentFolder = fullfile(DICOMFolder,subFolders(folderIdx).name);
    DICOMFiles = dir(currentFolder); %List folder contents
    [~,natsort_index] = natsortfiles({DICOMFiles(:).name});
    DICOMFiles = DICOMFiles(natsort_index);
    notAdirFlags = ~[DICOMFiles.isdir]; %List files from the list (i.e not folders)
    DICOMFiles = DICOMFiles(notAdirFlags); %Remove folders from the list
    
    for dcmIndex = 1:length(DICOMFiles)
        
        currentDICOMFilepath = fullfile(currentFolder,DICOMFiles(dcmIndex).name);
        
        %Skip non-dicom files
        if contains(DICOMFiles(dcmIndex).name,'.zip') || contains(DICOMFiles(dcmIndex).name,'DICOMDIR')
            continue
        end
        
        try
            imageInfo = dicominfo(currentDICOMFilepath);
        catch
            continue
        end
        
        try
            Manufacturer = imageInfo.Manufacturer; % Different routines from Philips and Siemens
        catch
            continue
        end
        
        if ~strcmp(previousManufacturer,Manufacturer) && regexpi(Manufacturer,'Siemens')
            SiemensType = questdlg('Detected Siemens DICOMs.  Select cartridge.', 'Siemens', 'SyngoTherm', 'PhaseImaging', 'XA20 SyngoTherm', 'SyngoTherm');
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%% New Filename %%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%
%         if strfind(DICOMFiles(dcmIndex).name,'IM')
        if strfind(DICOMFiles(dcmIndex).name,'Pro') %temporary change for Sola export
            
            if (~isempty(strfind(lower(imageInfo.ProtocolName),'tmap')) || ~isempty(strfind(lower(imageInfo.SeriesDescription),'tmap')))...
                    || (~isempty(strfind(lower(imageInfo.ProtocolName),'therm')) || ~isempty(strfind(lower(imageInfo.SeriesDescription),'therm')))
                
                if regexpi(Manufacturer,'Philips')
                    sliceIdx = imageInfo.(dicomlookup('2001','100a'));
                    dynIdx = imageInfo.TemporalPositionIdentifier;
                elseif regexpi(Manufacturer,'Siemens')
                    if mod(imageInfo.InstanceNumber,12)
                        sliceIdx = mod(imageInfo.InstanceNumber,12);
                    else
                        sliceIdx = 12;
                    end
%                     if regexp(SiemensType, 'XA20')
                        if ~isfield(imageInfo,'AcquisitionNumber')
                            imageInfo.AcquisitionNumber = 1;
                        end
                        dynIdx = imageInfo.AcquisitionNumber;
%                             [~,dynIdx] = parseXA20Series(imageInfo.SeriesNumber, SiemensSequenceIdx);
%                         end
%                     else
%                         dynIdx = imageInfo.AcquisitionNumber;
%                     end
                end
                
                %To have it zero-based as TDC
                dynIdx = dynIdx - 1;
                sliceIdx = sliceIdx - 1;
                
                % Use same naming convention as TDC
                renamedDICOMFilename = sprintf('i%04d-s%02d-%s',dynIdx,sliceIdx,imageInfo.SeriesDescription);
                
                if regexpi(Manufacturer,'Siemens')
                    % MOSAIC and Motion files
                    if ~isempty(strfind(imageInfo.SeriesDescription,'MOSAIC')) || ~isempty(strfind(imageInfo.SeriesDescription,'Motion'))
                        renamedDICOMFilename = sprintf('i%04d-%s',dynIdx,imageInfo.SeriesDescription);
                        imageInfo.SequenceName = '';
                    end
                    
                    if strfind(imageInfo.ImageType,'\P\')
                        renamedDICOMFilename = strcat(renamedDICOMFilename,'-Phase');
                    else
                        renamedDICOMFilename = strcat(renamedDICOMFilename,'-Mag');
                    end
                elseif strfind(Manufacturer,'Philips')
                    % Append Phase or Mag to the name
                    if strfind(imageInfo.ImageType,'PHASE')
                        renamedDICOMFilename = strcat(renamedDICOMFilename,'-Phase');
                    else
                        renamedDICOMFilename = strcat(renamedDICOMFilename,'-Mag');
                    end
                end
                
            else
                %If not from a TMap or therm sequence (e.g 2D, 3D...)
                renamedDICOMFilename = sprintf('%04d_%s',imageInfo.InstanceNumber, imageInfo.SeriesDescription);
            end
            
            if regexpi(Manufacturer,'Siemens')
                %Append the original file extension
                [~,~,fileExtension] = fileparts(DICOMFiles(dcmIndex).name);
                renamedDICOMFilename = strcat(renamedDICOMFilename,fileExtension);
            end
            
        else
            %If not an image, do not rename the file
            renamedDICOMFilename = DICOMFiles(dcmIndex).name;
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%% New Folder %%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if regexpi(Manufacturer,'Siemens')
            if strcmpi(SiemensType,'PhaseImaging') % AccessI
                if imageInfo.SeriesNumber ~= previousSeriesNumber
                    SiemensSequenceIdx = SiemensSequenceIdx + 1;
                    newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName));
                end

                % If it is a therm series
                if regexpi(imageInfo.SequenceName,'epfid')
                    currentThermType = thermType(imageInfo);
                    % If the type of therm DICOM switches from one type to another, check if new folder has to be created. 
                    if ~strcmp(currentThermType,previousThermType) 
                        if strcmpi(currentThermType, 'MagBaseline')
                            numMagBaseline = numMagBaseline + 1;
                            SiemensSequenceIdx = SiemensSequenceIdx - 1;
                            newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName),'Baseline');
                        elseif strcmpi(currentThermType, 'MagDiff')
                            numMagDiff = numMagDiff+1;
                            SiemensSequenceIdx = SiemensSequenceIdx - 1;
                            newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName));
                        elseif strcmpi(currentThermType, 'PhaseBaseline')
                            numPhaseBaseline = numPhaseBaseline+1;
                            SiemensSequenceIdx = SiemensSequenceIdx - 1;
                            newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName),'Baseline');
                        elseif strcmpi(currentThermType, 'PhaseDiff')
                            numPhaseDiff = numPhaseDiff+1;
                            SiemensSequenceIdx = SiemensSequenceIdx - 1;
                            newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName));
                        end

                        % If the new therm series was part of a new execution, create a new folder in the root directory
                        if mod( (numMagBaseline + numMagDiff + numPhaseBaseline + numPhaseDiff), 4) == 1
                            SiemensSequenceIdx = SiemensSequenceIdx + 1;
                            if strcmpi(currentThermType, 'MagBaseline') || strcmpi(currentThermType, 'PhaseBaseline')
                                newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName),'Baseline');
                            else
                                newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName));
                            end
                        end
                        % Don't think this applies anymore but will keep it here just in case
                        if ~isempty(strfind(imageInfo.ProtocolName,'Phoenix')) %Phoenix report files
                            newDICOMfolderName = fullfile(DICOMFolder,sprintf('%s',imageInfo.ProtocolName));
                        end
                    end
                    previousThermType = currentThermType;
                else
                    currentThermType = 'N/A';
                end
                previousSeriesNumber = imageInfo.SeriesNumber;
                
            elseif strcmpi(SiemensType,'XA20 SyngoTherm') % XA20 SyngoTherm
                [SiemensSequenceIdx,~] = parseXA20Series(imageInfo.SeriesNumber, imageInfo.AcquisitionNumber);
                newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName)); %can't use SeriesNumber because in XA20, each new dyn is a new SeriesNumber with the Dyn number embedded in it
                if ~exist(newDICOMfolderName)
                    newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName));
                    if ~isempty(strfind(imageInfo.ProtocolName,'Phoenix')) %Phoenix report files
                        newDICOMfolderName = fullfile(DICOMFolder,sprintf('%s',imageInfo.ProtocolName));
                    end
                end
                %Create a subfolder for these Motion and MOSAIC files
                if ~isempty(strfind(imageInfo.SeriesDescription,'MOSAIC')) || ~isempty(strfind(imageInfo.SeriesDescription,'Motion'))
                    newDICOMfolderName = fullfile(newDICOMfolderName,sprintf('%s',imageInfo.SeriesDescription));
                end
                
            elseif strcmpi(SiemensType,'SyngoTherm') % VE11 SyngoTherm
                newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName));
%                 newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',imageInfo.SeriesNumber,imageInfo.ProtocolName));
                %Very ugly way of making sure there a single folder per sequence (ie single Therm_REF, Therm_TUV etc...)
                if ~exist(newDICOMfolderName)
                    SiemensSequenceIdx = SiemensSequenceIdx + 1;
                    newDICOMfolderName = fullfile(DICOMFolder,sprintf('%02d - %s',SiemensSequenceIdx,imageInfo.ProtocolName));
                    if ~isempty(strfind(imageInfo.ProtocolName,'Phoenix')) %Phoenix report files
                        newDICOMfolderName = fullfile(DICOMFolder,sprintf('%s',imageInfo.ProtocolName));
                    end
                end

                %Create a subfolder for these Motion and MOSAIC files
                if ~isempty(strfind(imageInfo.SeriesDescription,'MOSAIC')) || ~isempty(strfind(imageInfo.SeriesDescription,'Motion'))
                    newDICOMfolderName = fullfile(newDICOMfolderName,sprintf('%s',imageInfo.SeriesDescription));
                end
            end

        elseif strfind(Manufacturer,'Philips')
            newDICOMfolderName = fullfile(fileparts(currentFolder),sprintf('%0.2d - %s',imageInfo.SeriesNumber,imageInfo.ProtocolName));
        end
        
        if ~exist(newDICOMfolderName)
            mkdir(newDICOMfolderName)
        end

        try
%             movefile(fullfile(currentDICOMFilepath),fullfile(newDICOMfolderName,renamedDICOMFilename));
            copyfile(fullfile(currentDICOMFilepath),fullfile(newDICOMfolderName,renamedDICOMFilename));
        catch
            warning('Movefile skipped for %s...',renamedDICOMFilename);
        end
        
        fprintf('Copied file %s to %s. Renamed as %s \n',DICOMFiles(dcmIndex).name, newDICOMfolderName,renamedDICOMFilename);
        previousManufacturer = Manufacturer;
    end
end
% Delete empty DICOM folder
folderContent = dir(fullfile(DICOMFolder,'*DICOM*')); %List folder contents
folderContent = folderContent([folderContent.isdir]); %Look for sub-folders only
if ~isempty(folderContent)
    if size(dir(fullfile(DICOMFolder,folderContent.name)),1) == 2 % Only '.' and '..'
        rmdir(fullfile(DICOMFolder,folderContent.name));
    end
end

% If not zipped, create archive
if zipFileAtEnd
    fprintf('Creating archive DICOMs.zip...\n')
    zip(fullfile(DICOMFolder,'DICOMs'),DICOMFolder)
end

% Finally, delete DICOMDIR
DICOMDIRFile = dir(fullfile(DICOMFolder,'*DICOMDIR*'));
if ~isempty(DICOMDIRFile)
    delete(fullfile(DICOMFolder,DICOMDIRFile.name))
end

elapsedTime = toc;
fprintf('DICOM cleaning done in %0.2fsec \n',(elapsedTime))

end


function type = thermType(imageInfo)
    if regexpi(imageInfo.SeriesDescription, 'Mag') & regexpi(imageInfo.ImageComments, 'Baseline')
        type = 'MagBaseline';
    elseif regexpi(imageInfo.SeriesDescription, 'Mag') & regexpi(imageInfo.ImageComments, 'Diff')
        type = 'MagDiff';
    elseif regexpi(imageInfo.SeriesDescription, 'Phase') & regexpi(imageInfo.ImageComments, 'Baseline')
        type = 'PhaseBaseline';
    elseif regexpi(imageInfo.SeriesDescription, 'Phase') & regexpi(imageInfo.ImageComments, 'Diff')
        type = 'PhaseDiff';
    else
        type = '';
    end
end

function [seriesIdx, dynIdx] = parseXA20Series(SeriesNumber, AcquisitionNumber)
    if AcquisitionNumber >= 1000
        modOrder = 4;
    else
        modOrder = 3;
    end
    dynIdx = mod(SeriesNumber, 10.^modOrder);
    seriesIdx = (SeriesNumber - dynIdx) ./ 10.^modOrder;
end