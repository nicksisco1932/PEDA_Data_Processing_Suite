function [Magnitude, Phase, TMap] = CreateOrLoadMatrices(inputDirectory, pathToDICOMFiles, varargin)

p = inputParser;
addParameter(p,'UAcenter',           [64 64],   @(x)validateattributes(x,{'double'},{'nonempty','positive','numel',2}))
addParameter(p,'BaselineTemperature', 37,       @(x)validateattributes(x,{'double'},{'nonempty','>=',0,'<',100}))
addParameter(p,'DICOMwildcard',       '*IM*',   @(x)validateattributes(x,{'char'},{'nonempty'}))
parse(p,varargin{:})

if ~exist(inputDirectory)
    mkdir(inputDirectory)
end

listDICOM = dir(fullfile(pathToDICOMFiles,p.Results.DICOMwildcard));

% Pick a DICOM file to determine which thermometry pipeline to use
infoDICOM = dicominfo(fullfile(pathToDICOMFiles,listDICOM(5).name));

MRImanufacturer = infoDICOM.Manufacturer;
MRImodel = infoDICOM.ManufacturerModelName;
MRIcenterFrequencyHz = infoDICOM.ImagingFrequency.*1e6;
MRIEchoTime = infoDICOM.EchoTime;

if regexpi(MRImanufacturer,'GE')
    if ~exist(fullfile(inputDirectory,'Phase.mat')) || ~exist(fullfile(inputDirectory,'Magnitude.mat'))
        [~, ~, Re, Im] = LoadDICOMfiles(pathToDICOMFiles, inputDirectory);
        Magnitude = abs(Re + Im * i);
        save(fullfile(inputDirectory, 'Magnitude.mat'), 'Magnitude');
        Phase = atan2(Im, Re);
        save(fullfile(inputDirectory, 'Phase.mat'), 'Phase');
    else
        disp('Loading Magnitude data...');
        load(fullfile(inputDirectory,'Magnitude.mat'));
        disp('Loading Phase data...');
        load(fullfile(inputDirectory,'Phase.mat'));
    end
else
    if ~exist(fullfile(inputDirectory,'Phase.mat')) || ~exist(fullfile(inputDirectory,'Magnitude.mat'))
        [Magnitude, Phase] = LoadDICOMfiles(pathToDICOMFiles, inputDirectory);
    else
        disp('Loading Magnitude data...');
        load(fullfile(inputDirectory,'Magnitude.mat'));
        disp('Loading Phase data...');
        load(fullfile(inputDirectory,'Phase.mat'));
    end
end

% Look at type of scanner to decide on the pipeline and whether the first dynamic is discarded
first_dyn = 1;
if regexpi(MRImanufacturer,'Philips') & regexpi(MRImodel,'Achieva')
    pipeline = 'XTCA';
elseif regexpi(MRImanufacturer,'Philips') & regexpi(MRImodel,'Ingenia')
    pipeline = 'XTCI';
    if MRIcenterFrequencyHz < 70*1e6 %1.5T
        first_dyn = 2;
    end
elseif regexpi(MRImanufacturer,'SIEMENS')
    pipeline = upper(DetermineSiemensThermometrySequenceType(fullfile(pathToDICOMFiles,listDICOM(5).name)));
    first_dyn = 2;
elseif regexpi(MRImanufacturer,'GE')
    pipeline = 'GE';
    first_dyn = 2;
else
    error('No manufacturer found');
end

%% Generate Temperature Maps
if ~exist(fullfile(inputDirectory,'TMap.mat'))
    TMap = GeneratesTMapFromTestDataCommon(Magnitude(:,:,:,first_dyn:end), Phase(:,:,:,first_dyn:end), pipeline, p.Results.BaselineTemperature, p.Results.UAcenter, MRIcenterFrequencyHz, MRIEchoTime);
    disp('Saving TMap.mat file');
    save(fullfile(inputDirectory,'TMap.mat'),'TMap');
else
    disp('Loading Temperature data...');
    load(fullfile(inputDirectory,'TMap.mat'));
end