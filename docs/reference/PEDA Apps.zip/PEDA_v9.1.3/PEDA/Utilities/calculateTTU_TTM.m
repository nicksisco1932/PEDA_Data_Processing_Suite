function [TTU,TTM] = calculateTTU_TTM(TMap,TUWindow)
%======================================
% function calculateTTU 
%
% Purpose:
% ========
% Calculate a temporal temperature uncertainty (TTU) and a temporal temperature mean (TTM)
%
% Input(s):
% =========
% - TMap: size is [NRows, NCols, NSlices, NDyns]
% - TUWindow [OPTIONAL. Default = 25]: width of the window across which the TTU and TTM is calculated
%
% Output(s):
% ==========
% - TTU
% - TTM
%
%======================================
% Created By: Alexandre Bigot
%======================================

%==========================================================================
% Variable initialization
%==========================================================================
TTU = zeros(size(TMap));
if nargout > 1
    TTM = zeros(size(TMap));
end

if nargin < 2
    TUWindow = 25;
end

%==========================================================================
% Generate TTU and TTM
%==========================================================================
for sliceIdx = 1:size(TMap,3)
    rollingWindow = -1;
    for dynIdx = 1:size(TMap,4)
        if ~any(any(TMap(:,:,sliceIdx,dynIdx))) %inputMatrix is all zeros
            continue
        end
        % Grow rolling window
        if rollingWindow == -1
            rollingWindow = dynIdx;
            continue
        else
            rollingWindow = [rollingWindow dynIdx];
        end
        
        % Once it reached the desired size, just discard the first element of the vector
        if numel(rollingWindow) == TUWindow+1
            rollingWindow = rollingWindow(2:end);
        end
        
        % Calculate standard deviation and mean across the rolling window.
        TTU(:,:,sliceIdx,dynIdx) = std(TMap(:,:,sliceIdx,rollingWindow),[],4);
        if nargout > 1
            TTM(:,:,sliceIdx,dynIdx) = mean(TMap(:,:,sliceIdx,rollingWindow),4);
        end
    end
end