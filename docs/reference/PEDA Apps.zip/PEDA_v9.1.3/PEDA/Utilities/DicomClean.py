# -*- coding: utf-8 -*-
"""
Created on Mon Jul 18 10:47:01 2016

@author: abigot

Updated: K.Borsos (17-OCT-2022)
Updated: B.Coles (06-JUN-2024): Added Synaptive DICOM processing. Simplified code for
"""
import pydicom, os, time, glob, sys, argparse, bisect
from shutil import move, copyfile

parser = argparse.ArgumentParser()
parser.add_argument('-v', action='store_true')
parser.add_argument("fileDirectory")
parser.add_argument('-p', action='store_true')
args = parser.parse_args()

def create_lookup_table(base):
    slice_locations = []
    file_list = []

    for files in os.listdir(base):
        file_list.append(os.path.join(base, files))

    for file in file_list:
        ds = pydicom.read_file(file)
        slice_locations.append(ds.SliceLocation)

    lookup_table = sorted(list(set(slice_locations)))
    return lookup_table

def printProgressBar(iteration, total, prefix = '', suffix = '', decimals = 1, length = 100, fill = '█', printEnd = "\r"):
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print(f'\r{prefix} |{bar}| {percent}% {suffix}', end = printEnd)

def DicomClean(dirName):
    t = time.time()
    i = 0
    skipped_files = []
    numFiles = 0
    for _,_,files in os.walk(dirName):
        numFiles += len(files)

    for base,folder,file in os.walk(dirName):

        # GE Code to handle missing inStackPositionNumber
        if file:
            slice_location_lookup = create_lookup_table(base)

        for f_idx,f in enumerate(file):
            filePath = os.path.join(base, f)
            if (args.p) and (numFiles > 0):
                i += 1
                printProgressBar(i, numFiles, prefix = 'Progress:', suffix = 'Complete', length = 100)

            if f.startswith('DICOMDIR')or f.startswith('XX') or f.startswith('PS'):
                skipped_files.append(f)
                continue

            try:
                imageInfo = pydicom.read_file(filePath)
            except pydicom.errors.InvalidDicomError:
                skipped_files.append(f)
                continue

            # Ensure similar DICOM tags are used to determine if the images is from the thermometry sequence
            try:
                imageInfo.SequenceName
            except:
                imageInfo.SequenceName = 'NA'
            try:
                imageInfo.ScanningSequence
            except:
                imageInfo.ScanningSequence = 'NA'
            try:
                imageInfo.ProtocolName
            except:
                imageInfo.ProtocolName = 'NA'
            try:
                imageInfo.ImageType
            except:
                imageInfo.ImageType = 'NA'
            try:
                imageInfo.Manufacturer
            except:
                imageInfo.Manufacturer = 'NA'
            try:
                imageInfo.PatientName
                imageInfo.PatientName = imageInfo.PatientName if imageInfo.PatientName else 'NONE'
            except:
                imageInfo.PatientName = 'NONE'

            try:
                imageInfo.SeriesDescription
                if imageInfo.SeriesDescription == '':
                    imageInfo.SeriesDescription = 'NOSERIESDESC'
            except:
                try:
                    imageInfo.SeriesDescription = imageInfo.SequenceName #Best I could do if there is no SeriesDescription
                except:
                    imageInfo.SeriesDescription = imageInfo.MRAcquisitionType; #Can't even read SequenceName...

            # Skips extra files from Siemens scanners
            if 'Phoenix' in imageInfo.ProtocolName or 'MOSAIC' in imageInfo.SeriesDescription or 'Motion' in imageInfo.SeriesDescription:
                skipped_files.append(f)
                continue

            # remove these characters to avoid issues with file names
            removeChars = ['\\','/','*',':','^']
            imageInfo.SeriesDescription = imageInfo.SeriesDescription.translate({ord(x): '' for x in removeChars})
            imageInfo.PatientName = str(imageInfo.PatientName).translate({ord(x): '' for x in removeChars})

            # Checking if the image is from the thermometry sequence
            isThermSequence = ('therm' in str.lower(imageInfo.ProtocolName) or
                               'therm' in str.lower(imageInfo.SeriesDescription) or
                                all(x in imageInfo.ScanningSequence for x in ['EP', 'GR']) or
                               'epi2d' in str.lower(imageInfo.SequenceName) or
                                 'FFE' in imageInfo.ImageType)

            if isThermSequence and imageInfo.Rows == 128:
                # Determining the image type, dyanmic, and slice index for renaming
                if 'Philips' in imageInfo.Manufacturer:
                    if 'PHASE MAP' in imageInfo.ImageType:
                        imageType = '-Phase.dcm'
                    elif 'R_FFE' in imageInfo.ImageType:
                        imageType = '-Real.dcm'
                    elif 'I_FFE' in imageInfo.ImageType:
                        imageType = '-Im.dcm'
                    elif 'M_FFE' in imageInfo.ImageType:
                        imageType = '-Mag.dcm'
                    dynIdx = imageInfo.TemporalPositionIdentifier - 1
                    sliceIdx = imageInfo[0x2001, 0x100a].value - 1 #Philips has a private tag that stores the current slice number

                elif 'siemens' in str.lower(imageInfo.Manufacturer):
                    if 'P' in imageInfo.ImageType:
                       imageType = '-Phase.dcm'
                    else:
                       imageType = '-Mag.dcm'
                    dynIdx = imageInfo.AcquisitionNumber - 1
                    if imageInfo.InstanceNumber%12:
                        sliceIdx = imageInfo.InstanceNumber%12 - 1
                    else:
                        sliceIdx = 11

                elif 'ge' in str.lower(imageInfo.Manufacturer):
                    image_type = {0: '-Mag.dcm',
                                  1: '-Phase.dcm',
                                  2: '-Real.dcm',
                                  3: '-Im.dcm'}
                    # For GE, tag 0043,102F contains RawDataType
                    imageType = image_type[imageInfo['0043102f'].value]
                    dynIdx = imageInfo.TemporalPositionIdentifier - 1
                    try:
                        sliceIdx = imageInfo.InStackPositionNumber - 1
                    except:
                        sliceIdx = slice_location_lookup.index(imageInfo.SliceLocation)

                elif 'synaptive' in str.lower(imageInfo.Manufacturer):
                    if 'P' in imageInfo.ImageType[2]:
                        imageType = '-Phase.dcm'
                    elif 'M' in imageInfo.ImageType[2]:
                        imageType = '-Mag.dcm'
                    dynIdx = imageInfo.TemporalPositionIdentifier
                    if imageInfo.InstanceNumber % 12:
                        sliceIdx = imageInfo.InstanceNumber % 12 - 1
                    else:
                        sliceIdx = 11

                # renaming the thermometry dicoms using the same naming convention as TDC
                renamedDICOMFilename = (f'i{dynIdx:04d}-s{sliceIdx:02d}-{imageInfo.SeriesDescription}') + imageType

            # If not a therm scan
            else:
                try:
                    renamedDICOMFilename = (f'{imageInfo.InstanceNumber:04d}_{imageInfo.SeriesDescription}') + '.dcm'
                except:
                    #If all fails, keep the name
                    renamedDICOMFilename = f

            # Some siemens series numbers contain the series number and the image number together
            # i.e 14034 -series 14 -image 34 we only want the series number for determining the folder name
            if 'siemens' in str.lower(imageInfo.Manufacturer):
                newSeriesNumber = str(imageInfo.SeriesNumber)[:-3] if len(str(imageInfo.SeriesNumber)) > 3 else imageInfo.SeriesNumber
            else:
                newSeriesNumber = str(imageInfo.SeriesNumber)

            # determining the folder name, creating the directory if it doesn't exist, and copying the image to the folder
            newDICOMfolderName = os.path.join(dirName, str(imageInfo.PatientName), (f'{newSeriesNumber:00} - {imageInfo.SeriesDescription}'))
            if not os.path.exists(newDICOMfolderName):
                os.makedirs(newDICOMfolderName)
            copyfile(filePath,os.path.join(newDICOMfolderName,renamedDICOMFilename))

            if (args.v):
                print(f'Copied file {f} to {os.path.join(str(imageInfo.PatientName), os.path.split(newDICOMfolderName)[1])}. Renamed as {renamedDICOMFilename}')

    elapsed = time.time() - t
    print()
    print(f'Processed {numFiles} files in {elapsed:.2f}s')
    print(f'Skipped files: {skipped_files}')

if __name__ == '__main__':
    if len(sys.argv) > 1:
        DicomClean(args.fileDirectory)
        # Added to ensure the cmd window does not automatically close
        input()
