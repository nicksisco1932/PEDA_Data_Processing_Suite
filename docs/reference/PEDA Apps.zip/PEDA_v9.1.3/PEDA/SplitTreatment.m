function SxParameters = SplitTreatment (SxParameters,Angle)
%======================================
% function SplitTreatment(); 
%
% Purpose:
% ========
% This function removes all data after a given angle. This can be used to 
% separately analyze specific part of the treatment
% e.g. 1st revolution
%
% Input(s):
% =========
% TxParameters
% Angle : angle where to stop the analysis. Set to -1 to skip this function
%
% Output(s):
% ==========
% TxParameters 
% 
%======================================
% Created By: Alex Bigot
% Creation Date: 11-JUL-2016
%======================================

global PEDA_VERSION

%Skip the function
if Angle == -1
    return
end

% Find and remove values above the specified angle
AngleIdx = find(abs(SxParameters.UnwoundThermAngle-SxParameters.UnwoundThermAngle(1)) >= Angle);

% Remove data 
SxParameters.ThermAngle(AngleIdx(1)+1:end) = [];
SxParameters.ImageNumber(AngleIdx(1)+1:end) = [];
SxParameters.ImageTime(AngleIdx(1)+1:end) = [];
SxParameters.UnwoundThermAngle(AngleIdx(1)+1:end) = [];
% SxParameters.RotationDirection(AngleIdx(1)+1:end) = [];
[SxParameters.TreatedSector, SxParameters.CombinedTreatedSector] = GetTreatedSectorSubsegment(SxParameters.ThermAngle,SxParameters.RotationDirection);

%Replace PEDA path to create a separate folder
mainDir = fileparts(SxParameters.pathPEDA);
[~,SegmentDir] = fileparts(SxParameters.pathData);

%Rename folder
newPath = fullfile(mainDir,['PEDA' PEDA_VERSION '_split_' num2str(Angle) 'deg']);
if exist(newPath) %This is required because Matlab would simply move pathPEDA into newPath since newPath already exists
    movefile(fullfile(SxParameters.pathPEDA,'*'),newPath,'f');
    rmdir(SxParameters.pathPEDA);
else
    movefile(SxParameters.pathPEDA,newPath,'f');
end

%Update parameters
SxParameters.pathPEDA = newPath;
SxParameters.pathData = fullfile(SxParameters.pathPEDA,SegmentDir);
SxParameters.pathData = SxParameters.pathData;
save(fullfile(SxParameters.pathPEDA,'SxParameters.mat'),'SxParameters')



    