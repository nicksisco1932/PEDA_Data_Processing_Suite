%% Control_Algorithm
function [w,p,f,w_max] = Control_Algorithm(r,TMax,f_low,f_high,Tr,element_location,first_TMap,Predicted_Temperature_Max,Th)
%% Initialization
%definition of inputs
%r = control radius
% TMax = highest temperature in -15 to +15 degree sector
%f_low =  low frequency
%f_high = high frequency
%Tr = control radius temperature
%element_location: Is the element 
%first_TMap: Is the first TMap where the controller actually makes a
%control decision
%TMap_curr: Current TMap (3 dimensions0

%% Alarm Constants
% Th = 90;
Tc = 57;
T_delta = Tc - Tr;
T_delta_predicted = Tc-Predicted_Temperature_Max;
%If tmperature is under or equal to 10 degrees power should be 0
T_min = 10;

%% Rotation Constants
w_min = 4; %in dpm
w_max = 120; %in dpm

%% Frequency Constants
rf = 12;

%% Power Constants
p_low = 4;
p_high = 2;

%% Tuning Constants
Center_low_tuning = 28; %in mm
Outer_low_tuning = 24; %in mmm


%% Tuning Constants - Low Frequency
A0_center_power_low = 6.2854900000E+00;
A1_center_power_low = -1.4017400000E+00;
A2_center_power_low = 1.2490000000E-01;
A3_center_power_low = -4.8300000000E-03;
A4_center_power_low = 7.1242300000E-05;

A0_outer_power_low = 1.2589730000E+01;
A1_outer_power_low = -3.0931800000E+00;
A2_outer_power_low = 2.9794000000E-01;
A3_outer_power_low = -1.2620000000E-02;
A4_outer_power_low = 2.0523200000E-04;

A0_center_rotation_low = 2.9653530000E+01;
A1_center_rotation_low = 6.3697700000E+00;
A2_center_rotation_low = 0;
A3_center_rotation_low = 1;
A4_center_rotation_low = -2.7146000000E-01;

A0_outer_rotation_low = 2.1911480000E+01;
A1_outer_rotation_low = 5.4614900000E+00;
A2_outer_rotation_low = 0;
A3_outer_rotation_low = 1;
A4_outer_rotation_low = -2.0675000000E-01;


%% Tuning Constants - High Frequency
A0_center_power_high = 1.0761980000E+01;
A1_center_power_high = -4.2503100000E+00;
A2_center_power_high = 6.3997000000E-01;
A3_center_power_high = -4.2700000000E-02;
A4_center_power_high = 1.0800000000E-03;

A0_outer_power_high = 1.1944820000E+01;
A1_outer_power_high = -5.1528300000E+00;
A2_outer_power_high = 8.5937000000E-01;
A3_outer_power_high = -6.4120000000E-02;
A4_outer_power_high = 1.8300000000E-03;

A0_center_rotation_high = 3.9052170000E+01;
A1_center_rotation_high = 7.3502900000E+00;
A2_center_rotation_high = 0;
A3_center_rotation_high = 1;
A4_center_rotation_high = -5.8746500000E+00;

A0_outer_rotation_high = 2.8491550000E+01;
A1_outer_rotation_high = 5.1160500000E+00;
A2_outer_rotation_high = 0;
A3_outer_rotation_high = 1;
A4_outer_rotation_high = -2.2613000000E+00;



%% Tuning Equation
%% Low Frequency

if strcmp(element_location,'Centre') == 1 && r <= 28 
    
    kp_center_low = A0_center_power_low + A1_center_power_low*r + A2_center_power_low*r^2 + A3_center_power_low*r^3 + A4_center_power_low*r^4;
    kw_center_low = A0_center_rotation_low*exp(-r/A1_center_rotation_low) + A2_center_rotation_low*exp(-r/A3_center_rotation_low) + A4_center_rotation_low;
    
    
elseif strcmp(element_location,'Outer') == 1 && r <= 24   
       
    kp_outer_low = A0_outer_power_low + A1_outer_power_low*r + A2_outer_power_low*r^2 + A3_outer_power_low*r^3 + A4_outer_power_low*r^4;
    kw_outer_low = A0_outer_rotation_low*exp(-r/A1_outer_rotation_low) + A2_outer_rotation_low*exp(-r/A3_outer_rotation_low) + A4_outer_rotation_low;  
    
    
else
    
    kp_center_low = A0_center_power_low + A1_center_power_low*28 + A2_center_power_low*28^2 + A3_center_power_low*28^3 + A4_center_power_low*28^4;
    kw_center_low = A0_center_rotation_low*exp(-28/A1_center_rotation_low) + A2_center_rotation_low*exp(-28/A3_center_rotation_low) + A4_center_rotation_low;
    
    kp_outer_low = A0_outer_power_low + A1_outer_power_low*24 + A2_outer_power_low*24^2 + A3_outer_power_low*24^3 + A4_outer_power_low*24^4;
    kw_outer_low = A0_outer_rotation_low*exp(-24/A1_outer_rotation_low) + A2_outer_rotation_low*exp(-24/A3_outer_rotation_low) + A4_outer_rotation_low;  
    
    
end
       


%% High Frequency
if r >= 8
    kp_center_high = A0_center_power_high + A1_center_power_high*r + A2_center_power_high*r^2 + A3_center_power_high*r^3 + A4_center_power_high*r^4;
    kp_outer_high = A0_outer_power_high + A1_outer_power_high*r + A2_outer_power_high*r^2 + A3_outer_power_high*r^3 + A4_outer_power_high*r^4;
    
    kw_center_high = A0_center_rotation_high*exp(-r/A1_center_rotation_high) + A2_center_rotation_high*exp(-r/A3_center_rotation_high) + A4_center_rotation_high;
    kw_outer_high = A0_outer_rotation_high*exp(-r/A1_outer_rotation_high) + A2_outer_rotation_high*exp(-r/A3_outer_rotation_high) + A4_outer_rotation_high;
    
else
    kp_center_high = A0_center_power_high + A1_center_power_high*8 + A2_center_power_high*8^2 + A3_center_power_high*8^3 + A4_center_power_high*8^4;
    kp_outer_high = A0_outer_power_high + A1_outer_power_high*8 + A2_outer_power_high*8^2 + A3_outer_power_high*8^3 + A4_outer_power_high*8^4;
    
    kw_center_high = A0_center_rotation_high*exp(-8/A1_center_rotation_high) + A2_center_rotation_high*exp(-8/A3_center_rotation_high) + A4_center_rotation_high;
    kw_outer_high = A0_outer_rotation_high*exp(-8/A1_outer_rotation_high) + A2_outer_rotation_high*exp(-8/A3_outer_rotation_high) + A4_outer_rotation_high;
end


%% Compute which gain factors to use, depending on radius and element location
if r < rf && strcmp(element_location,'Centre') == 1
    kp = kp_center_high;
    kw = kw_center_high;
    
elseif r < rf && strcmp(element_location,'Outer') == 1
    
    kp = kp_outer_high;
    kw = kw_outer_high;  
    
elseif r >= rf && strcmp(element_location,'Centre') == 1
    
    kp = kp_center_low;
    kw = kw_center_low;  
    
elseif r >= rf && strcmp(element_location,'Outer') == 1
    
    kp = kp_outer_low;
    kw = kw_outer_low;  

else
end
  
%% Compute which rotation rates to use
if TMax > Th && first_TMap == 0
    w = w_max;
    
elseif T_delta_predicted <= 0 && first_TMap == 0
    w = w_max;
    
elseif T_delta <= 0 && first_TMap == 0
    w = w_max;

elseif T_delta > 0 && first_TMap == 0
    w = 60*(kw/T_delta); %convert from dph to dpm
    
    if w < w_min
        w = w_min;
    end

elseif first_TMap == 1
    w = w_max;
    
end

if w > w_max
    w = w_max;
end

%% Compute Power
if TMax > Th || T_delta <= 0 || T_delta_predicted <= 0 || Tr <= T_min
    p = 0;

elseif TMax <= Th && T_delta > 0
    p = kp* T_delta;

end
   
    
%% Compute Frequency   
if r < 8 || T_delta <= 0 || T_delta_predicted <= 0 || TMax >= Th || Tr <= T_min
    f = 0;
    p = 0;
    w = w_max;
elseif r >= 8 && r < rf
    f = f_high;
else
    f = f_low;
end

%% need to bring power to max power if exceeded
if r < rf && r>= 8 && p > p_high
    p = 2;

elseif r >= rf && p > p_low
    p = 4;
end



    