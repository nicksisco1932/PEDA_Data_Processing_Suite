function [outputMatrix,outputPhase] = ReadData(mainFolder, fileFilter, NumberOfDynsToRead, Manufacturer)

% List files in folder
fileList = dir(fullfile(mainFolder,fileFilter));

if nargin < 3
    fileInfo = textscan(fileList(end).name,'i%4d-s%2d-%s'); % Read last file dynamic number
    NumberOfDynsToRead = double(fileInfo{1}) + 1;
end

fprintf('    ');
if isempty(fileList)
    error('Could not find any file to read')
end
% Main loop
for fileIdx = 1:length(fileList)
    
    %Get file fid and parse name
    fileFID = fopen(fullfile(fileList(fileIdx).folder,fileList(fileIdx).name));
    fileInfo = textscan(fileList(fileIdx).name,'i%4d-s%2d-%s'); % For instance, i0000-s00-Raw
    
    % Retrieve dynamic and slice number
    currentDynamic = double(fileInfo{1}) + 1; % File name is zero-based
    currentSlice = double(fileInfo{2}) + 1; % File name is zero-based
        
    if currentDynamic == NumberOfDynsToRead + 1
        fclose(fileFID);
        break
    end
    
    % Store and close. Read twice if Raw files
    if strfind(fileFilter, 'Raw')
        if Manufacturer=='GE'
            if compareFileSize(fileList)
                outputMatrix(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'int16')';
                if strfind(fileFilter,'Raw')
                   outputPhase(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'int16')';
                end
            else
                outputMatrix(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'float')';
                if strfind(fileFilter,'Raw')
                    outputPhase(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'float')';
                end
            end
        else
            if compareFileSize(fileList)
                outputMatrix(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'ushort')';
                if strfind(fileFilter,'Raw')
                   outputPhase(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'ushort')';
                end
            else
                outputMatrix(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'float')';
                if strfind(fileFilter,'Raw')
                    outputPhase(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'float')';
                end
            end
        end
    else
        outputMatrix(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'float')';
        if strfind(fileFilter,'Raw')
            outputPhase(:,:,currentSlice,currentDynamic) = fread(fileFID,[128 128],'float')';
        end
    end 
    
    % Update display
    progressPercentage = min(round(currentDynamic/NumberOfDynsToRead*100),100);
    backspaceChars = repmat('\b',1,length(num2str(progressPercentage))+1);
    fprintf([backspaceChars '%d%%'],progressPercentage);
    fclose(fileFID);
    
end
fprintf(backspaceChars);
end 

function n = compareFileSize(fileList)
% ========= TDC 2.10 Updates =========
% Check average Raw.dat file size to fread using correct data type. TDC
% 2.10 exports Raw.dat files as ushorts compared to previous versions. PEDA
% needs to assign the correct data type for fread for top-level function
% (ie. ReadData.m) to properly create the Magnitude and Phase matrices. 
% 
% Input:
% =========
% - Directory for Raw filtered data
%
% Output: 
% =========
% - Boolean:
%   - True - Average Raw.dat file = 64kB = data type read as ushort
%   - False - Average Raw.dat file != 64kB = data type read as float
%
% Last Updated
% =========
% Date: 05-OCT-2020
% Updated By: Sid Shekhar

    expectedFileSize = 65536; % 64kB file
    allowableDiff = 0.10; % Tolerance for file size differences
    avgFileSize = sum([fileList(:).bytes])/length(fileList);

    if abs(avgFileSize - expectedFileSize) <= (expectedFileSize * allowableDiff)
        n = true;
    else 
        n = false;
    end
end

