function temp = m_get_interpolated_temp( tmap, Ut, Vt )
%
%   Ut = (x-coordinate) column #
%   Vt = (y-coordinate) row #
%

    U0 = floor( Ut );
    U1 = ceil( Ut );
    V0 = floor( Vt );
    V1 = ceil( Vt );
    
    dUt = Ut - U0;
    dVt = Vt - V0;

    T00 = tmap( V0,U0 );
    T10 = tmap( V0,U1 );
    T01 = tmap( V1,U0 );
    T11 = tmap( V1,U1 );
    
    T_U0_Vt = T00 + dVt * ( T01 - T00 );
    T_U1_Vt = T10 + dVt * ( T11 - T10 );
    T_Ut_Vt = T_U0_Vt + dUt * ( T_U1_Vt - T_U0_Vt );

    temp = T_Ut_Vt;
    
return