% Normalizes a matrix to values between 0 and 1.  Alternatively, additional
% input arguments allows user to input min and max of normalized matrix
function M = normalizemat(N, varargin)
N = double(N);
M = N - min(N(:));
M = M./max(M(:));

if nargin == 3 && varargin{2} > varargin{1}
    M = M.*(varargin{2} - varargin{1}) + varargin{1};
end
