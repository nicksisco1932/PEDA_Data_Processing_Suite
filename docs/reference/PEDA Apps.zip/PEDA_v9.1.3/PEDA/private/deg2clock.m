%% deg2clock.m ============================================================
% Converts a string indicating the position of the hour hand into a
% numerical value in degrees.  0 degrees corresponds with 3:00 position
% (positive x axis) and positive rotation is in the counterclockwise
% direction.
% 
% INPUTS:
%   - deg: number of degrees from 3:00 position (0 degrees)
% 
% OUTPUTS:
%   - strclock: can have notation 'HH:MM' or 'H:MM'
%   - dblclock: double value HH.MM, with MM normalized from base 60 to base 10
% 
% By: Ben Leung
% Date: 15-DEC-2016
%% ========================================================================
function [strclock, dblclock] = deg2clock(deg)

strclock = cell(1,length(deg));
dblclock = zeros(1,length(deg));

for ii = 1:length(deg)
    % Wrap function using modulo 360
    deg(ii) = mod(deg(ii),360);

    % Calculate hours and minutes
    H = mod(floor(((deg(ii)-90)./0.5)./(-60)),12);
    if H == 0; H = 12; end
    M = 60-mod(((deg(ii)-90)./0.5),60);
    if M == 60; M = 0; end

    % Convert to string
    if M < 10
        strclock{ii} = [num2str(H) ':0' num2str(M)];
    else
        strclock{ii} = [num2str(H) ':' num2str(M)];
    end

    dblclock(ii) = H + M/60;
end



