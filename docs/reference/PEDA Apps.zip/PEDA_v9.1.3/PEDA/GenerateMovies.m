function GenerateMovies(SxParameters, TMap, Magnitude, MaxTemperatureTime, TUV, TUVMag)

% Unmasked
CreateMovie(SxParameters,TUV,'TUV')
CreateMovie(SxParameters,TUVMag,'TUVMag')
CreateMovie(SxParameters,Magnitude,'Magnitude')

% TMap types
movieSettings.movieType = 'TMap';
movieSettings.movieName = strjoin([SxParameters.PatientID,"_Current Temperature.mp4"], ''); 
CreateMovie(SxParameters,TMap,movieSettings)

movieSettings.movieName = strjoin([SxParameters.PatientID,"_Maximum Temperature.mp4"], '');% [SxParameters.PatientID,'_Maximum Temperature.mp4'];
CreateMovie(SxParameters,MaxTemperatureTime,movieSettings)

% Overlay types
movieSettings.movieType = 'Overlay';
movieSettings.movieName = strjoin([SxParameters.PatientID,"_Current Temperature Overlay.mp4"], '');% [SxParameters.PatientID,'_Current Temperature Overlay.mp4'];
CreateMovie(SxParameters,TMap,movieSettings, Magnitude)

movieSettings.movieName = strjoin([SxParameters.PatientID,"_Maximum Temperature Overlay.mp4"], '');%[SxParameters.PatientID,'_Maximum Temperature Overlay.mp4'];
CreateMovie(SxParameters,MaxTemperatureTime,movieSettings, Magnitude)
