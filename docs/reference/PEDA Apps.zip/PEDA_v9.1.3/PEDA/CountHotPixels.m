function [ApproachingBoilingCount,AboveBoilingCount,ControlSliceArea] = CountHotPixels(Parameters,segmentIdx)
%==========================================================================
% Purpose:  loads TMaxMasked.mat; records count of hot pixels (T > ApproachingBoilingThreshold
% and T > 100 C) within control volume.
% All 12 slices are counted, independently of the number of active
% elements.  The number of hot pixels as a percentage of the control
% volume is also reported.
%
% Inputs:
%      - TxParameters: holds the path where files are stored
%
% Outputs:
%      - appends "PEDA_Output.txt"

%==========================================================================
%----- load temperature information -----
load( fullfile(Parameters.pathData, 'TMaxMasked') );
NumDynsReference = 5;
NumDynsPerShift = 100;


%==========================================================================
%----- open file to write summary of results -----
if nargin > 1 %This is a segment
    fid = fopen(fullfile(Parameters.pathData,sprintf('PEDA_Output_S%d.txt',segmentIdx)),'a');
else %This is the treatment
    fid = fopen(fullfile(Parameters.pathPEDA,'PEDA_Output.txt'),'a');
end

[X_MTR,Y_MTR] = pol2cart(Parameters.ControlBoundaryTheta*(pi/180),Parameters.MinimumTreatmentRadius);
if size(Parameters.ux,1) == 1
    for jj = 1:Parameters.NumberSlices
        MTRmask(:,:,jj) = poly2mask(X_MTR + Parameters.ux(jj),-Y_MTR + Parameters.uy(jj), Parameters.ImageResolution, Parameters.ImageResolution);
    end
else
    % Combine all masks over treatment (exclude largest combined MTR mask)
    NumShifts = floor((Parameters.ImageNumber(end)-5)./100);
    MTRmask = zeros(Parameters.ImageResolution,Parameters.ImageResolution,Parameters.NumberSlices,NumShifts);
    
    
    % Only need to take one copy of each ImageShifted location
    for ii = 1:(NumShifts+1)
        for jj = 1:Parameters.NumberSlices
            if ii == 1
                MTRmask(:,:,jj,ii) = poly2mask(X_MTR + Parameters.ux(ii,jj),-Y_MTR + Parameters.uy(ii,jj), Parameters.ImageResolution, Parameters.ImageResolution);
            else
                MTRmask(:,:,jj,ii) = poly2mask(X_MTR + Parameters.ux((ii-1)*NumDynsPerShift-Parameters.ImageNumber(1)+1+NumDynsReference,jj),-Y_MTR + Parameters.uy((ii-1)*NumDynsPerShift-Parameters.ImageNumber(1)+1+NumDynsReference,jj), Parameters.ImageResolution, Parameters.ImageResolution);
            end
        end
    end
    MTRmask = logical(prod(~MTRmask,4));
end

% Combine all masks over treatment (include smallest combined ControlMask)
if nargin > 1 %This is a segment
    load(fullfile(Parameters.pathData,'Masks','ControlMask.mat'));
    ControlMask = logical(prod(ControlMask(:,:,:,Parameters.ImageNumber(1):end),4));
    HotPixelMask = ControlMask.*MTRmask;
    save(fullfile(Parameters.pathData,'Masks','HotPixelMask.mat'),'HotPixelMask');
else %This is the treatment
    if ~isempty(Parameters.Combined)
        ControlMask = CreateSingleBoundaryMask(Parameters, Parameters.Combined.ControlBoundary);
    else
        ControlMask = CreateSingleBoundaryMask(Parameters, Parameters.ControlBoundary);
    end
    HotPixelMask = ControlMask.*MTRmask;
    save(fullfile(Parameters.pathData,'HotPixelMask.mat'),'HotPixelMask');
end

TMaxMasked = TMaxMasked.*HotPixelMask;%repmat(~MTRmask,1,1,size(TMaxMasked,3));

ApproachingBoilingCount = squeeze(sum(sum(TMaxMasked>min(Parameters.ApproachingBoilingThreshold(:))))); %pixels above 90C per slice
AboveBoilingCount = squeeze(sum(sum(TMaxMasked>100))); %pixels above 100C per slice
ControlSliceArea = squeeze(sum(sum(ControlMask(:,:,:,1)))); %number of pixels inside control area per slice


end
