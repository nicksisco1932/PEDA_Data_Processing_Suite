function [outputTimes, outputIndices, CumulativeTreatedSector] = CalculateTreatmentTimeStatistics(SxParameters)
%==========================================================================
% Classify treatment states of prostate as function of angle and time
%==========================================================================
% Load in entire treatment sequentially.  Calculate TreatedSector in the
% same way as GetTreatedSector.m, but ignoring changes in boundary within
% each Treatment Segment.  Classify treatment at each ThermAngle as either
% FirstPass, TreatedAgain, or NotTreating as a function of time.
% 
% Angles discretized into in 1 degree increments
% ----------------------Time Rules-----------------------------------------
% NotTreating:
% (N1) Treatment Controller was not in 'Delivery' state and no UA elements 
%      were Active (using moving average filter)
% 
% OTHERWISE
% 
% FirstPass: 
% (A1) True if within the first dyn
% (A2) True if at least one angle increment spanned during current dynamic 
%      has not been previously marked as Treated
% (A3) True if only single angle increment (marked as Treated) was spanned 
%      during the current dynamic and either adjacent angle increment is 
%      marked as NotTreated
% TreatedAgain:
% (B1) True if multiple angle increments spanned during current dynamic and 
%      all such angles have been marked as Treated
% (B2) True if only single angle increment (marked as Treated) was spanned 
%      during the current dynamic and either adjacent angle increment is 
%      marked as Treated
% ----------------------Angle Rules----------------------------------------
% AngleIsTreated:
% (C1) False if within the first dyn (since UA is rotating 120 dpm, it 
%      spans about 12 degrees which should not be considered as Treated)
% (C2) True if during FirstPass

%=======================INPUTS=============================================
% 
%    - SxParameters: Multi-segment or Single segment to access ImageTime,
%                    ThermAngle, IsElementEnabled, and TreatmentState
% 
%======================OUTPUTS=============================================
% 
%    - outputTimes:   Structure containing distribution of treatment time
%                     (in minutes) into FirstPass, TreatedAgain, and 
%                     NotTreating
%    - outputIndices: Structure containing N-element vectors corresponding
%                     to combined Time and ThermAngle, as well as filters
%                     for FirstPass, TreatedAgain, and NotTreating (sum of
%                     the last 3 items should equal N minus number of 
%                     treatment segments due to using diffs)
%    - CumulativeTreatedSector: This is a vector identifying all angle 
%                               increments marked as Treated
%==========================================================================
%% Initialize variables
% Number of dyns to use in smoothing function
WindowLength = 3;

AngleIsTreated = zeros(1,360);

FirstPassTimeMIN = [];
TreatedAgainTimeMIN = [];
NotTreatingTimeMIN = [];
CumulativeFirstPass = [];
CumulativeTreatedAgain = [];
CumulativeNotTreating = [];
CumulativeAngle = [];
CumulativeTime = [];
CumulativeSegmentLength = [];

%% Sequentially loop through entire treatment
for segmentIdx = 1:length(SxParameters)
    load(fullfile(SxParameters(segmentIdx).pathData,'TreatmentControllerData.mat'));
    
    IsPowerOn = movmean( strcmpi(TreatmentControllerData.TreatmentState,'Delivery') & any(SxParameters(segmentIdx).IsElementEnabled,2) , WindowLength) > 0;
    
    dtime = [0; diff(SxParameters(segmentIdx).ImageTime)];
    FirstPassIdx =        false( size(dtime) );
    TreatedAgainIdx = false( size(dtime) );
    NotTreatingIdx =          false( size(dtime) );

    for dynIdx = 2:length(SxParameters(segmentIdx).ImageTime)  
        
        % Find the angles spanned in this dynamic (unwrap if crossing 360)
        start_and_end_angles = [round(SxParameters(segmentIdx).ThermAngle(dynIdx-1))  round(SxParameters(segmentIdx).ThermAngle(dynIdx)) ];
        start_and_end_angles( start_and_end_angles==0 ) = 360;        
        angles_in_this_dynamic = min(start_and_end_angles):1:max(start_and_end_angles);            
        if numel(angles_in_this_dynamic) > 180
            angles_in_this_dynamic = [ 1:1:min(start_and_end_angles) max(start_and_end_angles):1:360 ];            
        end
        
        if IsPowerOn(dynIdx)      
            
            % (A1,C1) Since UA is rotating 120 dpm, it is FirstPass but not Treated 
            if dynIdx==2 
                FirstPassIdx(dynIdx) = 1;
                
            % (A2,C2) If part of current dynamic Treats new angle, it's First Pass
            elseif min( AngleIsTreated(angles_in_this_dynamic) ) == 0
                AngleIsTreated(angles_in_this_dynamic) = 1;
                FirstPassIdx(dynIdx) = 1;
            
            % (B1) If multiple angle increments spanned and they've all marked as Treated, it's TreatedAgain
            elseif length(angles_in_this_dynamic) > 1                
                TreatedAgainIdx(dynIdx) = 1;
            
            % (A3,B2) If just 1 angle marked as Treated but a neighboring angle hasn't been Treated, it's first pass (check for wrap)
            else
                if angles_in_this_dynamic(1) == 360
                    if min(AngleIsTreated(359),AngleIsTreated(1)) == 0
                        FirstPassIdx(dynIdx) = 1;
                    else
                        TreatedAgainIdx(dynIdx) = 1;
                    end
                elseif angles_in_this_dynamic(1) == 1
                    if min(AngleIsTreated(360),AngleIsTreated(2)) == 0
                        FirstPassIdx(dynIdx) = 1;
                    else
                        TreatedAgainIdx(dynIdx) = 1;
                    end
                else
                    if min(AngleIsTreated(angles_in_this_dynamic(1)+1),AngleIsTreated(angles_in_this_dynamic(1)-1)) == 0
                        FirstPassIdx(dynIdx) = 1; %(A3)
                    else
                        TreatedAgainIdx(dynIdx) = 1; %(B2)
                    end
                end
            end
        else

            % (N1) if treatment state is not 'Delivery' or no UA elements are Active
            NotTreatingIdx(dynIdx) = 1;
        end

    end

    FirstPassTimeMIN(segmentIdx) = sum(dtime.*FirstPassIdx)/60; %#ok<AGROW>
    TreatedAgainTimeMIN(segmentIdx) = sum(dtime.*TreatedAgainIdx)/60; %#ok<AGROW>
    NotTreatingTimeMIN(segmentIdx) = sum(dtime.*NotTreatingIdx)/60; %#ok<AGROW>
    
    % Before end of Segment, concatenate temporary time vectors to main time vector
    if isempty(CumulativeTime)
        CumulativeTime = [CumulativeTime; SxParameters(segmentIdx).ImageTime]; %#ok<AGROW>
    else
        CumulativeTime = [CumulativeTime; SxParameters(segmentIdx).ImageTime + CumulativeTime(end)]; %#ok<AGROW>
    end
    
    CumulativeSegmentLength = [CumulativeSegmentLength; length(SxParameters(segmentIdx).ImageNumber)]; %#ok<AGROW>
    CumulativeFirstPass = [CumulativeFirstPass; FirstPassIdx]; %#ok<AGROW>
    CumulativeTreatedAgain = [CumulativeTreatedAgain; TreatedAgainIdx]; %#ok<AGROW>
    CumulativeNotTreating = [CumulativeNotTreating; NotTreatingIdx]; %#ok<AGROW>
    CumulativeAngle = [CumulativeAngle; SxParameters(segmentIdx).ThermAngle]; %#ok<AGROW>
end
% Replace zeros with NaNs for plotting
CumulativeFirstPass(CumulativeFirstPass==0) = NaN;
CumulativeTreatedAgain(CumulativeTreatedAgain==0) = NaN;
CumulativeNotTreating(CumulativeNotTreating==0) = NaN;

outputTimes.FirstPass = FirstPassTimeMIN;
outputTimes.TreatedAgain = TreatedAgainTimeMIN;
outputTimes.NotTreating = NotTreatingTimeMIN;
outputIndices.Time = CumulativeTime;
outputIndices.SegmentLength = [0; CumulativeSegmentLength];
outputIndices.Angle = CumulativeAngle;
outputIndices.FirstPass = CumulativeFirstPass;
outputIndices.TreatedAgain = CumulativeTreatedAgain;
outputIndices.NotTreating = CumulativeNotTreating;

CumulativeTreatedSector = find(AngleIsTreated)-1; % TreatedSector defined between 0:359

% figure;
% stairs(AllTime,FirstPass .* Angle,'b'); hold on;
% stairs(AllTime,Touchup .* Angle,'r');
% stairs(AllTime,Paused .* Angle,'g'); 
% ylim([-10 370]);
% ylabel('Angle'); xlabel('Time');
% legend('First Pass','Touch Up','Not Treating');
% hold off;
% 
% fprintf('Cumulative Time = %.1f min\n', sum(DeltaTime)/60);
% fprintf('FirstPassTime = %.1f min\n', firstpasstime);
% fprintf('TouchupTime = %.1f min\n', touchuptime);
% fprintf('PauseTime = %.1f min\n', pausetime);
% fprintf('Sum = %.1f min\n', firstpasstime + touchuptime + pausetime );

