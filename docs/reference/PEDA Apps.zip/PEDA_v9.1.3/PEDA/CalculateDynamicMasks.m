function Mask = CalculateDynamicMasks(Parameters, Anatomy, TMap)

%==========================================================================
% Variable initialization
%==========================================================================
[ProstateMask, ControlMask, UAMask, SectorMask] = deal(false(size(TMap)));
TUVMask = deal(true(size(TMap)));
[NRows, NCols, NSlices, NDyns] = size(TMap);
Mask = ones(NRows, NCols, NSlices, NDyns);
SNRMask = [];
StabilityMask = zeros(NRows,NCols,NSlices,5);

currentSubSegment = 1;
triggerSubSegmentChange = 0;

% Parameters for sector mask
FanAngle = 15;
MTRMM = 8;
DilateFactorMM = 2;

% Pre-compute for image shift
[diffNumPixelShiftsX, diffNumPixelShiftsY] = InitializeImageShift(Parameters);

%==========================================================================
% Calculate image-shifted masks
%==========================================================================
for dynIdx = 1:Parameters.ImageNumber(end)
    if dynIdx >= Parameters.SubSegmentImageNumber(currentSubSegment+1) && dynIdx ~= Parameters.ImageNumber(end)
        currentSubSegment = currentSubSegment + 1;
        triggerSubSegmentChange = 1;
    end
    offsetDynIdx = dynIdx-(Parameters.ImageNumber(1)-1);
    InTreatment = dynIdx >= Parameters.ImageNumber(1);
    firstDynInTreatment = dynIdx == Parameters.ImageNumber(1);
    if firstDynInTreatment
        TUVMask(:,:,:,dynIdx) = subCalculateTUVmask(Parameters);
    end
    for sliceIdx = 1:NSlices
        [X_UAMask,Y_UAMask] = pol2cart(Parameters.ProstateBoundaryTheta*(pi/180),Parameters.UARadius);
        [X_ProstateMask,Y_ProstateMask] = pol2cart(Parameters.ProstateBoundaryTheta*(pi/180),Parameters.ProstateBoundary(:,sliceIdx,currentSubSegment));
        [X_ControlMask,Y_ControlMask] = pol2cart(Parameters.ControlBoundaryTheta*(pi/180),Parameters.ControlBoundary(:,sliceIdx,currentSubSegment));
                
        if InTreatment
            if firstDynInTreatment
                UAMask(:,:,sliceIdx,dynIdx) = poly2mask(X_UAMask+Parameters.ux(offsetDynIdx,sliceIdx),-Y_UAMask+Parameters.uy(offsetDynIdx,sliceIdx),Parameters.ImageResolution,Parameters.ImageResolution);
                ProstateMask(:,:,sliceIdx,dynIdx) = poly2mask(X_ProstateMask+Parameters.ux(offsetDynIdx,sliceIdx),-Y_ProstateMask+Parameters.uy(offsetDynIdx,sliceIdx),Parameters.ImageResolution,Parameters.ImageResolution);
                ControlMask(:,:,sliceIdx,dynIdx) = poly2mask(X_ControlMask+Parameters.ux(offsetDynIdx,sliceIdx),-Y_ControlMask+Parameters.uy(offsetDynIdx,sliceIdx),Parameters.ImageResolution,Parameters.ImageResolution);
            else
                ProstateMask(:,:,sliceIdx,dynIdx) = ProstateMask(:,:,sliceIdx,dynIdx-1);
                ControlMask(:,:,sliceIdx,dynIdx) = ControlMask(:,:,sliceIdx,dynIdx-1);
                UAMask(:,:,sliceIdx,dynIdx) = UAMask(:,:,sliceIdx,dynIdx-1);
                TUVMask(:,:,sliceIdx,dynIdx) = TUVMask(:,:,sliceIdx,dynIdx-1);
                imageShiftOccurred = Parameters.ux(offsetDynIdx,sliceIdx) ~= Parameters.ux(offsetDynIdx-1,sliceIdx) || Parameters.uy(offsetDynIdx,sliceIdx) ~= Parameters.uy(offsetDynIdx-1,sliceIdx);
        
                if imageShiftOccurred | triggerSubSegmentChange
                    UAMask(:,:,sliceIdx,dynIdx) = poly2mask(X_UAMask+Parameters.ux(offsetDynIdx,sliceIdx),-Y_UAMask+Parameters.uy(offsetDynIdx,sliceIdx),Parameters.ImageResolution,Parameters.ImageResolution);
                    ProstateMask(:,:,sliceIdx,dynIdx) = poly2mask(X_ProstateMask+Parameters.ux(offsetDynIdx,sliceIdx),-Y_ProstateMask+Parameters.uy(offsetDynIdx,sliceIdx),Parameters.ImageResolution,Parameters.ImageResolution);
                    ControlMask(:,:,sliceIdx,dynIdx) = poly2mask(X_ControlMask+Parameters.ux(offsetDynIdx,sliceIdx),-Y_ControlMask+Parameters.uy(offsetDynIdx,sliceIdx),Parameters.ImageResolution,Parameters.ImageResolution);
                    if diffNumPixelShiftsX(offsetDynIdx, sliceIdx) || diffNumPixelShiftsY(offsetDynIdx, sliceIdx)
                        TUVMask(:,:,sliceIdx,dynIdx) = circshift(circshift(TUVMask(:,:,sliceIdx,dynIdx-1),diffNumPixelShiftsY(offsetDynIdx, sliceIdx),1),diffNumPixelShiftsX(offsetDynIdx, sliceIdx),2);
                    end
                end
            end
        end
    end
    if InTreatment
        SectorMask(:,:,:,dynIdx) = subCalculateSectorMask(Parameters.ThermAngle(offsetDynIdx), FanAngle, ...
            Parameters.ux(offsetDynIdx,:), Parameters.uy(offsetDynIdx,:), Parameters.isUAactive, MTRMM, DilateFactorMM, Parameters.ProstateBoundary(:,:,currentSubSegment),...
            Parameters.PixelSize(1), NSlices, NRows, NCols, TUVMask(:,:,:,dynIdx));
    end
    triggerSubSegmentChange = 0;
end

%==========================================================================
% Combine masks
%==========================================================================
SubSegmentImageNumber = Parameters.SubSegmentImageNumber;

for subSegmentIdx = 1:numel(SubSegmentImageNumber)-1
    if subSegmentIdx == numel(SubSegmentImageNumber)-1
        dynInterval = SubSegmentImageNumber(subSegmentIdx):SubSegmentImageNumber(subSegmentIdx+1);
    else
        dynInterval = SubSegmentImageNumber(subSegmentIdx):SubSegmentImageNumber(subSegmentIdx+1)-1;
    end
    
    % SNRMask can be calculated from dynamic 1
    SNRMask = logical(cat(4,SNRMask,Anatomy(:,:,:,dynInterval) >= round(OtsuMethod4D(Anatomy(:,:,:,dynInterval)))));
    
    % However, we only start calculating the Stability mask and the cumulative mask after acquiring the 5 reference images on the first subSegment
    % Therefore, modify the first index of the dynInterval 
    dynInterval = max(Parameters.NumRefImages+1,dynInterval(1)):dynInterval(end);
    
    StabilityMask = logical(cat(4,StabilityMask,abs(diff(cat(4,TMap(:,:,:,dynInterval(1)),TMap(:,:,:,dynInterval)),[],4)) > Parameters.StabilityThreshold));
    
    % Apply masks
    Mask(:,:,:,dynInterval) = Mask(:,:,:,dynInterval) & cumprod(~StabilityMask(:,:,:,dynInterval),4);        % Any pixel above stability threshold is set to 0
    Mask(:,:,:,dynInterval) = Mask(:,:,:,dynInterval) & cumprod(SNRMask(:,:,:,dynInterval),4);               % Any pixel in the SNR mask is set to 1
    Mask(:,:,:,dynInterval) = Mask(:,:,:,dynInterval) | logical(cumsum(ProstateMask(:,:,:,dynInterval),4));  % Any pixel - included pixels that could have been masked before - in the eroded prostate mask is set to 1
    Mask(:,:,:,dynInterval) = Mask(:,:,:,dynInterval) & cumprod(~UAMask(:,:,:,dynInterval),4);               % Any pixel in UA mask is set to 0
end

% Save
save(fullfile(Parameters.pathData,'Masks','Mask.mat'),'Mask');
save(fullfile(Parameters.pathData,'Masks','SectorMask.mat'),'SectorMask');
save(fullfile(Parameters.pathData,'Masks','TUVMask.mat'),'TUVMask');
save(fullfile(Parameters.pathData,'Masks','SNRMask.mat'),'SNRMask');
save(fullfile(Parameters.pathData,'Masks','StabilityMask.mat'),'StabilityMask');
save(fullfile(Parameters.pathData,'Masks','ProstateMask.mat'),'ProstateMask');
save(fullfile(Parameters.pathData,'Masks','ControlMask.mat'),'ControlMask');
save(fullfile(Parameters.pathData,'Masks','UAMask.mat'),'UAMask');
end

function [diffNumPixelShiftsX, diffNumPixelShiftsY] = InitializeImageShift(Parameters)
shiftUX = round(Parameters.ux - Parameters.ux(1,:)); % Only apply whole pixel shift
shiftUY = round(Parameters.uy - Parameters.uy(1,:)); % Only apply whole pixel shift
diffNumPixelShiftsX = [shiftUX(1,:);diff(shiftUX)]; % Matrix with 1s on the first dyn of a shift. 0 all other dynamics
diffNumPixelShiftsY = [shiftUY(1,:);diff(shiftUY)]; % Matrix with 1s on the first dyn of a shift. 0 all other dynamics
end
