function [CombinedProstateBoundary, CombinedControlBoundary, CombinedProstateBoundaryXY, CombinedControlBoundaryXY, CombinedUX, CombinedUY] = CombineBoundaries(SxParameters)

numberOfTreatmentSegments =  length(SxParameters);
minRadiusProstateMM = 7;
minRadiusControlMM  = 5;
CombinedProstateBoundary =   ones(360,SxParameters(1).NumberSlices).*(minRadiusProstateMM./SxParameters(1).PixelSize(1));
CombinedControlBoundary =    ones(360,SxParameters(1).NumberSlices).*( minRadiusControlMM./SxParameters(1).PixelSize(1));
CombinedProstateBoundaryXY = zeros(361,2,SxParameters(1).NumberSlices);
CombinedControlBoundaryXY =  zeros(361,2,SxParameters(1).NumberSlices);

if numberOfTreatmentSegments > 1 % CombineTreatmentSegments
    thetaTreated = zeros(360,numberOfTreatmentSegments);
    ProstateBoundaryAll = zeros(360,SxParameters.NumberSlices,numberOfTreatmentSegments);
    ControlBoundaryAll = zeros(360,SxParameters.NumberSlices,numberOfTreatmentSegments);

    numShiftsX = zeros(numberOfTreatmentSegments-1, SxParameters(1).NumberSlices);
    numShiftsY = zeros(numberOfTreatmentSegments-1, SxParameters(1).NumberSlices);

    % Concatenate the different matrices
    for segmentIdx = 1:numberOfTreatmentSegments
        if ~isempty(SxParameters(segmentIdx).Combined)
            thetaTreated(SxParameters(segmentIdx).Combined.TreatedSector + 1, segmentIdx) = 1; %create indexing matrix, add 1 since theta is encoded 0:359
            ProstateBoundaryAll(:,:,segmentIdx) = SxParameters(segmentIdx).Combined.ProstateBoundary;
            ControlBoundaryAll(:,:,segmentIdx)  = SxParameters(segmentIdx).Combined.ControlBoundary;
        else
            thetaTreated(SxParameters(segmentIdx).TreatedSector + 1, segmentIdx) = 1; %create indexing matrix, add 1 since theta is encoded 0:359
            ProstateBoundaryAll(:,:,segmentIdx) = SxParameters(segmentIdx).ProstateBoundary;
            ControlBoundaryAll(:,:,segmentIdx)  = SxParameters(segmentIdx).ControlBoundary;
        end
    end
else % Combine Boundaries within SubSegment
    numberOfSubSegments = length(SxParameters.SubSegmentImageNumber)-1;
    thetaTreated = zeros(360,numberOfSubSegments);
    ProstateBoundaryAll = zeros(360,SxParameters.NumberSlices,numberOfSubSegments);
    ControlBoundaryAll = zeros(360,SxParameters.NumberSlices,numberOfSubSegments);

     % Concatenate the different matrices
    for subSegmentIdx = 1:numberOfSubSegments
        thetaTreated(SxParameters.TreatedSector{subSegmentIdx} + 1, subSegmentIdx) = 1; %create indexing matrix, add 1 since theta is encoded 0:359
        
        % TS-204
        ProstateBoundaryAll(:,:,subSegmentIdx) = SxParameters.ProstateBoundary(:,:,subSegmentIdx);
        ControlBoundaryAll(:,:,subSegmentIdx)  = SxParameters.ControlBoundary(:,:,subSegmentIdx);
    end
end

% TS-188 and TS-202
for angleIdx = 1:360
    thetaIdx = find(thetaTreated(angleIdx,:));
    if ~isempty(thetaIdx)
        CombinedProstateBoundary(angleIdx,:) = max(ProstateBoundaryAll(angleIdx,:,thetaIdx),[],3);
        CombinedControlBoundary(angleIdx,:)  = max(ControlBoundaryAll(angleIdx,:,thetaIdx),[],3);
    end
end

CombinedUX = size(SxParameters(1).ProstateBoundary,2);
CombinedUY = size(SxParameters(1).ProstateBoundary,2);
for sliceIdx = 1:size(SxParameters(1).ProstateBoundary,2)
    % go from polar (defined at X = Y = 0) to XY with UA center defined at end of Segment 1 (multiple segments) or end of current segment (if combining subsegments)
    [X_CombinedProstateBoundary,Y_CombinedProstateBoundary] = toCartesian(CombinedProstateBoundary(:,sliceIdx));
    [X_CombinedControlBoundary, Y_CombinedControlBoundary] =  toCartesian(CombinedControlBoundary(:,sliceIdx));
    if numberOfTreatmentSegments > 1
        %UA center at Segment 1 end (multiple segments)
        CombinedUX(sliceIdx) = SxParameters(1).ux(end,sliceIdx);
        CombinedUY(sliceIdx) = SxParameters(1).uy(end,sliceIdx);
        X_CombinedProstateBoundary =  X_CombinedProstateBoundary + CombinedUX(sliceIdx);
        Y_CombinedProstateBoundary = -Y_CombinedProstateBoundary + CombinedUY(sliceIdx);
        X_CombinedControlBoundary =   X_CombinedControlBoundary  + CombinedUX(sliceIdx);
        Y_CombinedControlBoundary =  -Y_CombinedControlBoundary  + CombinedUY(sliceIdx);

    else
        %UA center at end of single segment
        CombinedUX(sliceIdx) = SxParameters.ux(end,sliceIdx);
        CombinedUY(sliceIdx) = SxParameters.uy(end,sliceIdx);
        X_CombinedProstateBoundary =  X_CombinedProstateBoundary + CombinedUX(sliceIdx);
        Y_CombinedProstateBoundary = -Y_CombinedProstateBoundary + CombinedUY(sliceIdx);
        X_CombinedControlBoundary =   X_CombinedControlBoundary  + CombinedUX(sliceIdx);
        Y_CombinedControlBoundary =  -Y_CombinedControlBoundary  + CombinedUY(sliceIdx);
    end
    
    CombinedProstateBoundaryXY(:,:,sliceIdx) = [X_CombinedProstateBoundary,Y_CombinedProstateBoundary];
    CombinedControlBoundaryXY(:,:,sliceIdx) =  [X_CombinedControlBoundary,Y_CombinedControlBoundary];
end