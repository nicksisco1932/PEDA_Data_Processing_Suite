function AnalyzeHardwareLogs(TxParameters)
global PEDA_VERSION

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% HARDWARE INFO ANALYSIS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% HardwareInfo updates every time the hardware is updated (~0.5sec) %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load(fullfile(TxParameters.pathData,'HardwareInfo.mat'));

%%% !! I remove all values where it is still Pre-Treatment !! %%%
HardwareInfo = HardwareInfo(~isnan(HardwareInfo.ElapsedTime_sec),:);
if HardwareInfo{:,2}(1) ~= 24
    HardwareInfo = HardwareInfo(2:end,:); %Removing first line because it sometimes reports incorrect value (TDC bug)
end
if HardwareInfo{:,2}(end) == 0
    HardwareInfo = HardwareInfo(1:end-1,:); %Removing last line because it sometimes reports incorrect value (TDC bug)
end

HWAnalysisPath = fullfile(TxParameters.pathData,'HWAnalysis');
if ~exist(HWAnalysisPath)
    mkdir(HWAnalysisPath);
end

ImageShiftPath = fullfile(TxParameters.pathData,'ImageShift');
if ~exist(ImageShiftPath)
    mkdir(ImageShiftPath);
end

%----- open file to write summary of results -----
%outFile = fopen(fullfile(HWAnalysisPath,[TxParameters.PatientID '_HardwareStatistics.txt']), 'w');
outFile = fopen(fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_HardwareStatistics.txt"], '')), 'w');


%----- add date/time stamp to output file -----
fprintf( outFile, 'Profound Medical Inc.\n' );
fprintf( outFile, 'Executed on Matlab %s, %s \n',version,datetime);
fprintf( outFile, 'PEDA Version %s \n',PEDA_VERSION);
fprintf( outFile, '\n' );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%==========================================================================
%----- Retrieve the Dynamic Number and Elasped Time  -----
HL_ElapsedTimeSEC = HardwareInfo.ElapsedTime_sec; 
HL_ElapsedTimeMIN = HL_ElapsedTimeSEC/60;
HL_DynamicNumber = HardwareInfo{:,2};

%==========================================================================
%----- Calculate Start and End Indice for each new incoming dynamic  -----
[a b c] = unique(HL_DynamicNumber);
% a = a(3:end);                                 %skip first two indices for logging 
% b = b(3:end);                                 %skip first two indices for logging 

%%
% ==========================================================================
% ----- Evaluate Fluid Circuit logs  -----
% ==========================================================================

%Retrieve the Ambient Temperature, UA Pressure, ECD Pressure, UA Volume and ECD Volume
HL_AmbientTemperatureCelsius   = HardwareInfo.AmbientTempCelcius;
HL_UAPressurePsi               = HardwareInfo.UAPressurePsi;
HL_ECDPressurePsi              = HardwareInfo.ECDPressurePsi;
HL_UAVolumeMl                  = HardwareInfo.UAVolumeMl;
HL_ECDVolumeMl                 = HardwareInfo.ECDVolumeMl;
    
%Compute the mean, std, min and max ambient temperature rise
AmbientTemperatureCelsius_Statistics = [mean(HL_AmbientTemperatureCelsius) std(HL_AmbientTemperatureCelsius) min(HL_AmbientTemperatureCelsius) max(HL_AmbientTemperatureCelsius)];

%Compute the mean, std, min and max UA and ECD pressure
UAPressurePsi_Statistics    = [mean(HL_UAPressurePsi) std(HL_UAPressurePsi) min(HL_UAPressurePsi) max(HL_UAPressurePsi)];
ECDPressurePsi_Statistics   = [mean(HL_ECDPressurePsi) std(HL_ECDPressurePsi) min(HL_ECDPressurePsi) max(HL_ECDPressurePsi)];

%Compute the mean, std, min and max UA and ECD volume
UAVolumeMl_Statistics   = [mean(HL_UAVolumeMl) std(HL_UAVolumeMl) min(HL_UAVolumeMl) max(HL_UAVolumeMl)];
ECDVolumeMl_Statistics  = [mean(HL_ECDVolumeMl) std(HL_ECDVolumeMl) min(HL_ECDVolumeMl) max(HL_ECDVolumeMl)];

%Plot the FC logs
myFig = figure('Position',get(0, 'Screensize'));

subplot(2,2,1)
plot(HL_ElapsedTimeMIN,HL_UAPressurePsi,'-',HL_ElapsedTimeMIN,HL_ECDPressurePsi,'r'), hold on, 
xlabel('Time (min)','fontsize',14)
ylabel('Pressure [psi]','fontsize',14)
legend('UA','ECD')
title('UA and ECD Pressure')
grid on
set(gca,'fontsize',14)

subplot(2,2,2)
plot(HL_ElapsedTimeMIN,HL_AmbientTemperatureCelsius)
xlabel('Time (min)','fontsize',14)
ylabel('SE Temperature [�C]','fontsize',14)
grid on
title('SE Temperature readings')
set(gca,'fontsize',14)

subplot(2,2,3)
plot(HL_ElapsedTimeMIN,HL_UAVolumeMl,'-',HL_ElapsedTimeMIN,HL_ECDVolumeMl,'r')
xlabel('Time (min)','fontsize',14)
ylabel('Volume [ml]','fontsize',14)
title('UA and ECD Volumes')
legend('UA','ECD')
grid on
set(gca,'fontsize',14)

h = subplot(2,2,4);
tablePos = get(h,'Position');
set(h,'Visible','off')
t = uitable('Data',[AmbientTemperatureCelsius_Statistics;UAPressurePsi_Statistics;ECDPressurePsi_Statistics;UAVolumeMl_Statistics;ECDVolumeMl_Statistics],...
    'ColumnName',{'Mean','Std. Dev.','Minimum','Maximum'},...
    'RowName',{'SE Temp [�C]','UA Pressure [psi]','ECD Pressure[psi]','UA Volume[mL]','ECD Volume[mL]'});
t.Position(3:4) = t.Extent(3:4);
set(t,'Units','normalized');
t.Position(1) = h.Position(1);
t.Position(2) = h.Position(2) + h.Position(4)/2;

print(myFig,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_FCStatistics.png"], '')),'-dpng','-r200');
close(myFig)

% Write FC logs 
fprintf( outFile, '*************  Fluid Circuit Statistics  ********************************\n');
fprintf( outFile, '\tMean\tStd.Dev.\tMinimum\tMaximum\n' );
fprintf( outFile, 'Ambient Temperature -- [�C]\t%.1f\t%.1f\t%.1f\t%.1f\n',AmbientTemperatureCelsius_Statistics(1),AmbientTemperatureCelsius_Statistics(2),AmbientTemperatureCelsius_Statistics(3),AmbientTemperatureCelsius_Statistics(4));
fprintf( outFile, 'UA Pressure -- [psi]\t%.1f\t%.1f\t%.1f\t%.1f\n',UAPressurePsi_Statistics(1),UAPressurePsi_Statistics(2),UAPressurePsi_Statistics(3),UAPressurePsi_Statistics(4));
fprintf( outFile, 'UA Volume -- [mL]\t%.1f\t%.1f\t%.1f\t%.1f\n',UAVolumeMl_Statistics(1),UAVolumeMl_Statistics(2),UAVolumeMl_Statistics(3),UAVolumeMl_Statistics(4));
fprintf( outFile, 'ECD Pressure -- [psi]\t%.1f\t%.1f\t%.1f\t%.1f\n',ECDPressurePsi_Statistics(1),ECDPressurePsi_Statistics(2),ECDPressurePsi_Statistics(3),ECDPressurePsi_Statistics(4));
fprintf( outFile, 'ECD Volume -- [mL]\t%.1f\t%.1f\t%.1f\t%.1f\n',ECDVolumeMl_Statistics(1),ECDVolumeMl_Statistics(2),ECDVolumeMl_Statistics(3),ECDVolumeMl_Statistics(4));
fprintf( outFile, '\n' );

% ==========================================================================
% ----- End of Fluid Circuit logs  -----
% ==========================================================================

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% TREATMENTCONTROLLER DATA ANALYSIS %%%%%%%%%%%%%%%%%%%%%%%%%%%
% TreatmentControllerData updates every time a dynamic is received(~6sec)%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialization
load(fullfile(TxParameters.pathData,'TreatmentControllerData.mat'));

MINIMUM_NUMBER_SAMPLES = 100;
MAXIMUM_ALLOWABLE_TIME_BETWEEN_MRI_START_AND_HW_UPDATE_SEC = 8;
LOWERBOUND_PERCENT_POWER_DEVIATION = -30;
UPPERBOUND_PERCENT_POWER_DEVIATION = 50;
MRIDelayBins = [4.5:0.1:8.5]; % [sec]

[TCD_AcquisitionStartToHWUpdateSEC, maxTCD_AcquisitionStartToHWUpdateSEC_99]  = AnalyzeMRIDelayStatistics(TreatmentControllerData);

% Plot the statistics
figure('Position',[500 300 800 600]);
histogram(TCD_AcquisitionStartToHWUpdateSEC,MRIDelayBins)
set(gca,'FontSize',12)

xlabel('Time between start of MR acquisition and HW update (sec)')
ylabel('Counts')
title({'MRI delay statistics'; ['n = ' num2str(length(TCD_AcquisitionStartToHWUpdateSEC))]})

print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_MRIDelayStatistics.png"], '')),'-dpng','-r200');
close(gcf)

% write to file
fprintf( outFile, '*************  MRI Acquisition Time to Hardware Update Timing Statistics  ********************************\n');
if length(TCD_AcquisitionStartToHWUpdateSEC) < MINIMUM_NUMBER_SAMPLES
    fprintf( outFile, 'Not enough samples for statistical significance on MRI timing.\n');
else
    fprintf( outFile, 'Number of samples\t%d\n',length(TCD_AcquisitionStartToHWUpdateSEC));
    fprintf( outFile, 'Mean -- [sec]\t%.2f\n',mean(TCD_AcquisitionStartToHWUpdateSEC));
    fprintf( outFile, 'Standard Deviation -- [sec]\t%.2f\n',std(TCD_AcquisitionStartToHWUpdateSEC));
    fprintf( outFile, 'Maximum (top 99%%) -- [sec]\t%.2f\n',maxTCD_AcquisitionStartToHWUpdateSEC_99);

    if maxTCD_AcquisitionStartToHWUpdateSEC_99 < MAXIMUM_ALLOWABLE_TIME_BETWEEN_MRI_START_AND_HW_UPDATE_SEC
        PassFailString = 'PASS';
    else
        PassFailString = 'FAIL';
    end
    fprintf( outFile, 'The maximum delay between each dynamic received by TDC and the hardware state updates for 99%% of treatment is less than %.2f sec? %s\n', MAXIMUM_ALLOWABLE_TIME_BETWEEN_MRI_START_AND_HW_UPDATE_SEC,  PassFailString);
end

fprintf( outFile, '\n' );

%%==========================================================================
% ----- Evaluate Power Deviations -----
% ==========================================================================

% Initialization
NumActiveElements = sum(TxParameters.isUAactive);
ActiveElements = find(TxParameters.isUAactive(2:end-1));
ElapsedTime_min = HardwareInfo.ElapsedTime_sec./60;
PowerDeviatedBins = -100:100;

[HL_PowerDeviatedPercent, HL_PowerDesiredWa, HL_PowerNetWa, meanHL_PowerDeviatedPercentWa, stdevHL_PowerDeviatedPercentWa, NumberOfSamplesPerElement, PercentPowerWithinSpec] = AnalyzePowerDeviations(HardwareInfo,LOWERBOUND_PERCENT_POWER_DEVIATION,UPPERBOUND_PERCENT_POWER_DEVIATION);

% Define based on table headers
HL_PowerDesiredWe   = [HardwareInfo.PowerDesiredWe_E1 HardwareInfo.PowerDesiredWe_E2 HardwareInfo.PowerDesiredWe_E3 HardwareInfo.PowerDesiredWe_E4 HardwareInfo.PowerDesiredWe_E5 HardwareInfo.PowerDesiredWe_E6 HardwareInfo.PowerDesiredWe_E7 HardwareInfo.PowerDesiredWe_E8 HardwareInfo.PowerDesiredWe_E9 HardwareInfo.PowerDesiredWe_E10];
HL_PowerNetWe       = [HardwareInfo.PowerNetWe_E1 HardwareInfo.PowerNetWe_E2 HardwareInfo.PowerNetWe_E3 HardwareInfo.PowerNetWe_E4 HardwareInfo.PowerNetWe_E5 HardwareInfo.PowerNetWe_E6 HardwareInfo.PowerNetWe_E7 HardwareInfo.PowerNetWe_E8 HardwareInfo.PowerNetWe_E9 HardwareInfo.PowerNetWe_E10];
HL_PowerForward     = [HardwareInfo.PowerForward_E1 HardwareInfo.PowerForward_E2 HardwareInfo.PowerForward_E3 HardwareInfo.PowerForward_E4 HardwareInfo.PowerForward_E5 HardwareInfo.PowerForward_E6 HardwareInfo.PowerForward_E7 HardwareInfo.PowerForward_E8 HardwareInfo.PowerForward_E9 HardwareInfo.PowerForward_E10];
HL_PowerForwardWa   = [HardwareInfo.PowerForwardWa_E1 HardwareInfo.PowerForwardWa_E2 HardwareInfo.PowerForwardWa_E3 HardwareInfo.PowerForwardWa_E4 HardwareInfo.PowerForwardWa_E5 HardwareInfo.PowerForwardWa_E6 HardwareInfo.PowerForwardWa_E7 HardwareInfo.PowerForwardWa_E8 HardwareInfo.PowerForwardWa_E9 HardwareInfo.PowerForwardWa_E10];
HL_PowerReflected   = [HardwareInfo.PowerReflected_E1 HardwareInfo.PowerReflected_E2 HardwareInfo.PowerReflected_E3 HardwareInfo.PowerReflected_E4 HardwareInfo.PowerReflected_E5 HardwareInfo.PowerReflected_E6 HardwareInfo.PowerReflected_E7 HardwareInfo.PowerReflected_E8 HardwareInfo.PowerReflected_E9 HardwareInfo.PowerReflected_E10];
HL_PowerReflectedWa = [HardwareInfo.PowerReflectedWa_E1 HardwareInfo.PowerReflectedWa_E2 HardwareInfo.PowerReflectedWa_E3 HardwareInfo.PowerReflectedWa_E4 HardwareInfo.PowerReflectedWa_E5 HardwareInfo.PowerReflectedWa_E6 HardwareInfo.PowerReflectedWa_E7 HardwareInfo.PowerReflectedWa_E8 HardwareInfo.PowerReflectedWa_E9 HardwareInfo.PowerReflectedWa_E10];
HL_SWR              = [HardwareInfo.SWR_E1 HardwareInfo.SWR_E2 HardwareInfo.SWR_E3 HardwareInfo.SWR_E4 HardwareInfo.SWR_E5 HardwareInfo.SWR_E6 HardwareInfo.SWR_E7 HardwareInfo.SWR_E8 HardwareInfo.SWR_E9 HardwareInfo.SWR_E10];


% Plot power deviation distributions per slice
nRows = [1 1 1 1 2 2 2 2 2 2];
nCols = [1 2 3 4 3 3 4 4 5 5];
subplotLoc = 1;

if NumActiveElements > 4 
    figure('units','normalized', 'position', [0 0 1 1])
else
    figure('units','normalized', 'position', [0 0.25 1 0.5])
end

for elemIdx = ActiveElements
    NonzeroPowerIdx = HL_PowerDesiredWa(:,elemIdx) ~= 0;
    PowerDeviatedDistribution{elemIdx} = HL_PowerDeviatedPercent(NonzeroPowerIdx,elemIdx);
    h = hist(PowerDeviatedDistribution{elemIdx}, PowerDeviatedBins);
    %subplot(nRows(NumActiveElements),nCols(NumActiveElements),elemIdx - ActiveElements(1) + 1) % To handle case where E1 is not the first element
    subplot(nRows(NumActiveElements),nCols(NumActiveElements), subplotLoc);
    subplotLoc = subplotLoc + 1; 
    bar(PowerDeviatedBins, h, 1, 'b');
    xlabel('Power deviated (%)')
%     xlim([LOWERBOUND_PERCENT_POWER_DEVIATION UPPERBOUND_PERCENT_POWER_DEVIATION]*1.05)
    title({['E' num2str(elemIdx)]; ['n = ' num2str(length(PowerDeviatedDistribution{elemIdx})) ' samples']; ['\mu = ' num2str(mean(PowerDeviatedDistribution{elemIdx}),2) ', \sigma = ' num2str(std(PowerDeviatedDistribution{elemIdx}),3)]})
    if elemIdx == ActiveElements(1)
        maxbin = max(h);
    else
        maxbin = max(maxbin,max(h));
    end
    if maxbin ~= 0 % Handle case where some elements are part of ActiveElements even though they did not fire at all  
        ylim([0 1.1*maxbin]);
    end  
end

print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_PowerDeviationsPerSlice.png"], '')),'-dpng','-r200');
close(gcf)


fprintf( outFile, '*************  Power Deviation Statistics  ********************************\n');
fprintf( outFile, '\tNumber of samples\tMean [Wa]\tStandard Deviation [Wa]\t Percent Within Specification [%%]\tPass Or Fail\n');
for elemIdx = 1:TxParameters.NumberSlices-2
    if PercentPowerWithinSpec(elemIdx) > 99
        PassFailString = 'PASS';
    else
        PassFailString = 'FAIL';
    end
    if NumberOfSamplesPerElement(elemIdx) < MINIMUM_NUMBER_SAMPLES
        PassFailString = 'Not enough samples';
    end
    fprintf( outFile, 'Element E%d\t%d\t%0.2f\t%0.2f\t%0.1f\t%s\n',elemIdx, NumberOfSamplesPerElement(elemIdx), meanHL_PowerDeviatedPercentWa(elemIdx), stdevHL_PowerDeviatedPercentWa(elemIdx), PercentPowerWithinSpec(elemIdx), PassFailString);
end



% Reduce matrix size to only active elements
HL_PowerDesiredWe   = HL_PowerDesiredWe(:,ActiveElements);
HL_PowerDesiredWa   = HL_PowerDesiredWa(:,ActiveElements); 
HL_PowerNetWa       = HL_PowerNetWa(:,ActiveElements);
HL_PowerNetWe       = HL_PowerNetWe (:,ActiveElements);
HL_PowerForward     = HL_PowerForward(:,ActiveElements);
HL_PowerForwardWa   = HL_PowerForwardWa(:,ActiveElements);
HL_PowerReflected   = HL_PowerReflected(:,ActiveElements);
HL_PowerReflectedWa = HL_PowerReflectedWa(:,ActiveElements);
HL_SWR              = HL_SWR(:,ActiveElements);

% TDC-947: Report alarm if desired power > 0.5 Wa and power deviation is > 10% for more than 5 sec
HL_PowerDeviatedPercent  =(HL_PowerDesiredWa - HL_PowerNetWa)./HL_PowerDesiredWa.*100;
HL_PowerDeviatedPercent(HL_PowerDesiredWa < 0.5) = 0;
bin_PowerDeviatedPercent = abs(HL_PowerDeviatedPercent) > 10; % generate ones whenever deviated power goes over 10%

% [PowerDeviatedDyn, PowerDeviatedElem] = find(abs(HL_PowerDeviatedPercent)>10);
counter = 0;
figure('units','normalized','position',[0 0 1 1])
for ii = ActiveElements
    counter     = counter+1;
    wrap        = [0; bin_PowerDeviatedPercent(:,counter); 0] ;
    temp        = diff( wrap ~= 0 ) ;
    blockStart  = find( temp == 1 ) + 1 ;
    blockEnd    = find( temp == -1 ) ;
    blocks      = (cat(2,blockStart,blockEnd));
%     blockLengths = block(:,2)-blocks(:,1);
    blockLengths_SEC = zeros(length(blockStart),1);
    for jj = 1:length(blockStart)
        blockLengths_SEC(jj) = HL_ElapsedTimeSEC(blockEnd(jj)) - HL_ElapsedTimeSEC(blockStart(jj));
    end
    subplot(round(NumActiveElements/2),2,counter)
    plot(ElapsedTime_min, HL_PowerDeviatedPercent(:,counter),'-b')
    if find(blockLengths_SEC>5)
        hold on
%         plot(ElapsedTime_min(reshape(blocks(find(blockLengths_SEC>5),:)',2*length(find(blockLengths_SEC>5)),1)), HL_PowerDeviatedPercent(reshape(blocks(find(blockLengths_SEC>5),:)',2*length(find(blockLengths_SEC>5)),1),counter),'-r','linewidth',2)
        plot(ElapsedTime_min(blockEnd(find(blockLengths_SEC>5))), HL_PowerDeviatedPercent(blockEnd(find(blockLengths_SEC>5))-1,counter),'or','markerfacecolor',[1 0 0],'markersize',3)
        hlegend = legend('Power deviated', 'Power deviated info message');
        set(hlegend,'units','normalized','position',[0.826 0.93 0.05 0.05])
    end
%     plot(
%     text(0.01*ElapsedTime_min(end),1*max([max(HL_PowerDesiredWa(:)) max(HL_PowerNetWa(:))]),['E' num2str(ii)],'FontSize',14)
    ylabel({['E' num2str(ii) ' Power']; 'Deviated (%)'})
%     axis([0 ElapsedTime_min(end) 1.1*min(HL_PowerDeviatedPercent(:)) 1.1*max(HL_PowerDeviatedPercent(:))])
%     legend(['Deviated E' num2str(ii)])
    if ii == ActiveElements(end-1) || ii == ActiveElements(end)
        xlabel('Elapsed Time (min)')
    end
end
print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_Deviated_Power.png"], '')),'-dpng','-r200');
close(gcf)


counter = 0;
figure('units','normalized','position',[0 0 1 1])
for ii = ActiveElements
    counter = counter+1;
    subplot(round(NumActiveElements/2),2,counter)
    plot(ElapsedTime_min, HL_PowerNetWa(:,counter))
    hold on
    plot(ElapsedTime_min, HL_PowerDesiredWa(:,counter))
%     text(0.01*ElapsedTime_min(end),1*max([max(HL_PowerDesiredWa(:)) max(HL_PowerNetWa(:))]),['E' num2str(ii)],'FontSize',14)
    ylabel('Power (Wa)')
    if sum(max(HL_PowerDesiredWa(:))) <= 0
        axis([0 ElapsedTime_min(end) -1 1])
    else
        axis([0 ElapsedTime_min(end) 0 1.1*max([max(HL_PowerDesiredWa(:)) max(HL_PowerNetWa(:))])])
    end
    legend(['Net E' num2str(ii)], ['Desired E' num2str(ii)])
    if ii == ActiveElements(end-1) || ii == ActiveElements(end)
        xlabel('Elapsed Time (min)')
    end
end
print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_Desired_vs_Net_Power_Wa.png"], '')),'-dpng','-r200');
close(gcf)

counter = 0;
figure('units','normalized','position',[0 0 1 1])
for ii = ActiveElements
    counter = counter+1;
    subplot(round(NumActiveElements/2),2,counter)
    plot(ElapsedTime_min, HL_PowerNetWe(:,counter))
    hold on
    plot(ElapsedTime_min, HL_PowerDesiredWe(:,counter))
%     text(0.01*ElapsedTime_min(end),1*max([max(HL_PowerDesiredWe(:)) max(HL_PowerNetWe(:))]),['E' num2str(ii)],'FontSize',14)
    ylabel('Power (We)')
    if sum(max(HL_PowerDesiredWe(:))) <= 0
        axis([0 ElapsedTime_min(end) -1 1])
    else
        axis([0 ElapsedTime_min(end) 0 1.1*max([max(HL_PowerDesiredWe(:)) max(HL_PowerNetWe(:))])])
    end
    legend(['Net E' num2str(ii)], ['Desired E' num2str(ii)])
    if ii == ActiveElements(end-1) || ii == ActiveElements(end)
        xlabel('Elapsed Time (min)')
    end
end
print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_Desired_vs_Net_Power_We.png"], '')),'-dpng','-r200');
close(gcf)


counter = 0;
figure('units','normalized','position',[0 0 1 1])
for ii = ActiveElements
    counter = counter+1;
    subplot(round(NumActiveElements/2),2,counter)
    plot(ElapsedTime_min, HL_PowerForwardWa(:,counter))
    hold on
    plot(ElapsedTime_min, HL_PowerReflectedWa(:,counter))
%     text(0.01*ElapsedTime_min(end),1*max([max(HL_PowerDesiredWe(:)) max(HL_PowerNetWe(:))]),['E' num2str(ii)],'FontSize',14)
    ylabel('Power (Wa)')
    if sum(max(HL_PowerDesiredWe(:))) <= 0
        axis([0 ElapsedTime_min(end) -1 1])
    else
        axis([0 ElapsedTime_min(end) 0 1.1*max([max(HL_PowerForwardWa(:)) max(HL_PowerReflectedWa(:))])])
    end
    legend(['Forward E' num2str(ii)], ['Reflected E' num2str(ii)])
    if ii == ActiveElements(end-1) || ii == ActiveElements(end)
        xlabel('Elapsed Time (min)')
    end
end
print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_Forward_vs_Reflected_Power_Wa.png"], '')),'-dpng','-r200');
close(gcf)

counter = 0;
figure('units','normalized','position',[0 0 1 1])
for ii = ActiveElements
    counter = counter+1;
    subplot(round(NumActiveElements/2),2,counter)
    plot(ElapsedTime_min, HL_PowerDesiredWa(:,counter) - HL_PowerNetWa(:,counter))

%     text(0.01*ElapsedTime_min(end),max(max(HL_PowerDesiredWa - HL_PowerNetWa)),['E' num2str(ii)],'FontSize',14)
    ylabel('Power Deviation (Wa)')
    if sum(max(HL_PowerDesiredWa)) <= 0
        axis([0 ElapsedTime_min(end) -1 1])
    else
        axis([0 ElapsedTime_min(end) 1.1*min(min(HL_PowerDesiredWa - HL_PowerNetWa)) 1.1*max(max(HL_PowerDesiredWa - HL_PowerNetWa))])
    end
    
    legend(['E' num2str(ii)])
    if ii == ActiveElements(end-1) || ii == ActiveElements(end)
        xlabel('Elapsed Time (min)')
    end
end
print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_Power_Deviation_Wa.png"], '')),'-dpng','-r200');
close(gcf)

counter = 0;
figure('units','normalized','position',[0 0 1 1])
for ii = ActiveElements
    counter = counter+1;
    subplot(round(NumActiveElements/2),2,counter)
    plot(ElapsedTime_min, HL_PowerDesiredWe(:,counter) - HL_PowerNetWe(:,counter))
%     text(0.01*ElapsedTime_min(end),max(max(HL_PowerDesiredWe - HL_PowerNetWe)),['E' num2str(ii)],'FontSize',14)
    ylabel('Power Deviation (We)')
    if max(HL_PowerDesiredWe) <= 0
        axis([0 ElapsedTime_min(end) -1 1])
    else
        axis([0 ElapsedTime_min(end) 1.1*min(min(HL_PowerDesiredWe - HL_PowerNetWe)) 1.1*max(max(HL_PowerDesiredWe - HL_PowerNetWe))])
    end
    
    legend(['E' num2str(ii)])
    if ii == ActiveElements(end-1) || ii == ActiveElements(end)
        xlabel('Elapsed Time (min)')
    end
end
print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_Power_Deviation_We.png"], '')),'-dpng','-r200');
close(gcf)

counter = 0;
figure('units','normalized','position',[0 0 1 1])
for ii = ActiveElements
    counter = counter+1;
    subplot(round(NumActiveElements/2),2,counter)
    plot(ElapsedTime_min, HL_SWR(:,counter))

%     text(0.01*ElapsedTime_min(end),max(HL_SWR(:)),['E' num2str(ii)],'FontSize',14)
    ylabel('SWR')
%     axis([0 ElapsedTime_min(end) 0 1.1*max(HL_SWR(:))])
    legend(['E' num2str(ii)])
    if ii == ActiveElements(end-1) || ii == ActiveElements(end)
        xlabel('Elapsed Time (min)')
    end
end

print(gcf,fullfile(HWAnalysisPath,strjoin([TxParameters.PatientID,"_SWR.png"], '')),'-dpng','-r200');
close(gcf)

%% ==========================================================================
%  ----- Plot ImageShifts  -----
%  ==========================================================================
ShiftX = cat(1,zeros(1,12),cumsum(diff(TxParameters.ux)));
ShiftY = cat(1,zeros(1,12),cumsum(diff(TxParameters.uy)));
figure('units','normalized','position',[0 .3 1 .5])
for sliceIdx = 1:12
    subplot(2,12,sliceIdx)
    plot(TxParameters.ImageNumber, ShiftX(:,sliceIdx),'-b')
    hold on
    plot([0 TxParameters.ImageNumber(end)+24], [1 1]*0.5, '--k')
    axis([0 TxParameters.ImageNumber(end)+24 min(ShiftX(:))-0.2 max(ShiftX(:))+0.2])
    grid on
    if sliceIdx == 1
        ylabel('ImageShift X (px)')
        title('M0')
    elseif sliceIdx == 12
        title('M11')
    else
        title(['E' num2str(sliceIdx-1)])
    end
    
    subplot(2,12,sliceIdx+12)
    plot(TxParameters.ImageNumber, ShiftY(:,sliceIdx),'-r')
    hold on
    plot([0 TxParameters.ImageNumber(end)+24], [1 1]*0.5, '--k')
    axis([0 TxParameters.ImageNumber(end)+24 min(ShiftY(:))-0.2 max(ShiftY(:))+0.2])
    grid on
    if sliceIdx == 1
        ylabel('ImageShift Y (px)')
    end
    xlabel('ImageNumber')
end

print(gcf,fullfile(ImageShiftPath,strjoin([TxParameters.PatientID,"_ImageShift.png"], '')),'-dpng','-r200');
close(gcf)


%% ==========================================================================
%  ----- Evaluate the PS logs  -----
%  ==========================================================================
% 
% % Position
% HL_PSPositionActualDEG        = HardwareInfo.PSPositionDeg_Actual;
% HL_PSPositionDesiredDEG       = HardwareInfo.PSPositionDeg_Desired;
% HL_PSPositionActualRAD        = deg2rad(HL_PSPositionActualDEG);
% 
% % Velocity
% HL_PSVelocityActualDPM        = HardwareInfo.PSVelocityDpm_Actual;
% HL_PSVelocityDesiredDPM       = HardwareInfo.PSVelocityDpm_Desired;
% HL_PSCommandVelocityErrorDPM  = HardwareInfo.PSVelocityDpm_Error;
% 
% % Direction
% HL_Direction                  = HardwareInfo.UARotationDirection;
% 
% %Identify second revolution
% initialBeamAngle = HL_PSPositionActualDEG(1);
% firstRevolutionIndex = find(abs(HL_PSPositionActualDEG - initialBeamAngle) == 360);
% if isempty(firstRevolutionIndex) firstRevolutionIndex = size(HL_PSPositionActualDEG); end
% 
% %Compute the desired position
% for i = 2:length(HL_PSVelocityDesiredDPM) %because you sum you need to do one less iteration
%     AngleStart = HL_PSPositionActualDEG(i-1);
%     Speed = HL_PSVelocityDesiredDPM(i-1);
%     ElapsedTimeMinDelta = HL_ElapsedTimeMIN(i) - HL_ElapsedTimeMIN(i-1);
% 
%     if strcmp(HL_Direction(i),'Clockwise') == 1
%         HL_PSPositionDesiredDEG(i,:) = AngleStart - Speed*ElapsedTimeMinDelta;
%     else
%         HL_PSPositionDesiredDEG(i,:) = AngleStart + Speed*ElapsedTimeMinDelta;
%     end
% end
% 
% %Compute the Error between Actual and Desired Position of the UA, but
% %ignore first value
% HL_PSPositionErrorDEG = (HL_PSPositionActualDEG(2:end) - HL_PSPositionDesiredDEG(2:end)); 
% HL_PSPositionFractionalError = (HL_PSPositionErrorDEG./(HL_PSPositionDesiredDEG(2:end)))*100;
% 
% %PS statistics
% HL_PSPositionErrorStats = [mean(HL_PSPositionErrorDEG) std(HL_PSPositionErrorDEG) min(HL_PSPositionErrorDEG) max(HL_PSPositionErrorDEG)];
% % HL_PSCommandPositionErrorStats = [mean(HL_PSCommandPositionErrorDEG) std(HL_PSCommandPositionErrorDEG) min(HL_PSCommandPositionErrorDEG) max(HL_PSCommandPositionErrorDEG)];
% 
% HL_PSVelocityStats = [mean(HL_PSVelocityActualDPM) std(HL_PSVelocityActualDPM) min(HL_PSVelocityActualDPM) max(HL_PSVelocityActualDPM)];
% % HL_PSCommandVelocityErrorStats = [mean(HL_PSCommandVelocityErrorDPM) std(HL_PSCommandVelocityErrorDPM) min(HL_PSCommandVelocityErrorDPM) max(HL_PSCommandVelocityErrorDPM)];


% %% Plot the PS logs
% %CARTESIAN PLOTS
% myFig = figure('Position',get(0, 'Screensize'));
% 
% %PS Position
% %%%%%%%%%%%%%%%%%%%%
% subplot(2,2,1)
% hold on, grid on
% plot(HL_ElapsedTimeSEC,HL_PSPositionActualDEG,'-');
% plot(HL_ElapsedTimeSEC,HL_PSPositionDesiredDEG,'--k');
% 
% 
% xlabel('Elapsed Time (min)','fontsize',14)
% ylabel('PS Position [deg]','fontsize',14)
% yyaxis right
% % plot(HL_ElapsedTimeSEC,HL_PSCommandPositionErrorDEG,'-');
% % ylabel('PS Command Error [deg]','fontsize',14)
% title('PS Position','fontsize',14)
% legend('Position Actual','Position Desired','Location','northoutside','Orientation','horizontal')
% 
% % hSubplot = subplot(2,2,3); hSubplot.Visible = 'off';
% % polaraxes('ThetaTick',[-90:15:360],'ThetaTickLabel',{num2str((-90:15:265)')},'RLim',[min(HL_PSCommandPositionErrorDEG) max(HL_PSCommandPositionErrorDEG)],'RLimMode','manual','Position',hSubplot.Position); hold on
% % polarplot(HL_PSPositionActualRAD,HL_PSCommandPositionErrorDEG,'-');
% % polarplot(HL_PSPositionActualRAD(firstRevolutionIndex:end),HL_PSCommandPositionErrorDEG(firstRevolutionIndex:end),'-y');
% % polarplot([HL_PSPositionActualRAD(1) HL_PSPositionActualRAD(1)],[min(HL_PSCommandPositionErrorDEG) max(HL_PSCommandPositionErrorDEG)],'r','LineWidth',2)
% % polarplot(HL_PSPositionActualRAD,ones(1,length(HL_PSPositionActualRAD))*mean(HL_PSCommandPositionErrorDEG),'--k','LineWidth',1)
% % title(sprintf('PS Command Position Error [deg]\nMean %.2f�',mean(HL_PSCommandPositionErrorDEG)),'fontsize',10)
% % legend('1st revolution','2nd revolution','Start angle',sprintf('Mean: %.2f�',mean(HL_PSCommandPositionErrorDEG)),'Location','westoutside') %,'Orientation','horizontal')
% %%%%%%%%%%%%%%%%%%%
% 
% %PS Velocity
% %%%%%%%%%%%%%%%%%%%
% subplot(2,2,2)
% hold on, grid on
% plot(HL_ElapsedTimeSEC,HL_PSVelocityActualDPM,'-');
% plot(HL_ElapsedTimeSEC,HL_PSVelocityDesiredDPM,'--k');
% xlabel('Elapsed Time (min)','fontsize',14)
% ylabel('PS Velocity [DPM]','fontsize',14)
% % yyaxis right
% % plot(HL_ElapsedTimeSEC,HL_PSCommandVelocityErrorDPM,'-');
% % ylabel('PS Command Error [DPM]','fontsize',14)
% % title('PS Velocity','fontsize',14)
% % legend('Position Actual','Position Desired','Position Command Error','Location','northoutside','Orientation','horizontal')
% 
% % hSubplot = subplot(2,2,4); hSubplot.Visible = 'off';
% % polaraxes('ThetaTick',[-90:15:360],'ThetaTickLabel',{num2str((-90:15:265)')},'RLim',[min(HL_PSCommandVelocityErrorDPM) max(HL_PSCommandVelocityErrorDPM)],'RLimMode','manual','Position',hSubplot.Position); hold on
% % polarplot(HL_PSPositionActualRAD,HL_PSCommandVelocityErrorDPM,'-');
% % polarplot(HL_PSPositionActualRAD(firstRevolutionIndex:end),HL_PSCommandVelocityErrorDPM(firstRevolutionIndex:end),'-y');
% % polarplot([HL_PSPositionActualRAD(1) HL_PSPositionActualRAD(1)],[min(HL_PSCommandVelocityErrorDPM) max(HL_PSCommandVelocityErrorDPM)],'r','LineWidth',2)
% % polarplot(HL_PSPositionActualRAD,ones(1,length(HL_PSPositionActualRAD))*mean(HL_PSCommandVelocityErrorDPM),'--k','LineWidth',1)
% % title(sprintf('PS Command Velocity Error [DPM]\nMean %.2f DPM',mean(HL_PSCommandVelocityErrorDPM)),'fontsize',10)
% % % legend('1st revolution','2nd revolution','Start angle', sprintf('Mean: %.2f DPM',mean(HL_PSCommandVelocityErrorDPM)),'Location','northoutside','Orientation','horizontal')
% 
% print(myFig,fullfile(HWAnalysisPath,'PSStatistics.png'),'-dpng','-r200');
% close(myFig)
% 
% % %%
% % subplot(2,3,2)
% % plot(HL_ElapsedTimeSEC(2:end),HL_PSPositionErrorDEG); hold on
% % xlabel('Elapsed Time (min)','fontsize',14)
% % ylabel('PS Angular Error [deg]','fontsize',14)
% % grid on, hold on
% % set(gca,'fontsize',14), title('Relative Angular Error','fontsize',14)
% % % plot(HL_ElapsedTimeSEC,ones(length(HL_ElapsedTimeSEC(2:end))),'k--','linewidth',2),plot(a(3:end),-1*ones(length(a(3:end))),'k--','linewidth',2)
% % % hold on, plot(a(3:end),ones(length(a(3:end))),'k--','linewidth',2),plot(a(3:end),-1*ones(length(a(3:end))),'k--','linewidth',2)
% % % xlim([26 a(end)]),ylim([-2 2])
% % 
% % subplot(2,3,3)
% % plot(HL_ElapsedTimeSEC,HL_PSCommandPositionErrorDEG)
% % hold on
% % xlabel('Elapsed Time (min)','fontsize',14)
% % ylabel('PS Command Position Error [deg]','fontsize',14)
% % yyaxis right
% % plot(HL_ElapsedTimeSEC,HL_PSCommandVelocityErrorDPM)
% % ylabel('PS Command Velocity Error [DPM]','fontsize',14)
% % grid on, hold on
% % set(gca,'fontsize',14), title('PS Command Error','fontsize',14)
% % 
% % subplot(2,3,4)
% % polarplot(HL_PSPositionActualRAD,HL_PSCommandPositionErrorDEG); hold on
% % polarplot(HL_PSPositionActualRAD(firstRevolutionIndex:end),HL_PSCommandPositionErrorDEG(firstRevolutionIndex:end),'r');
% % polarplot([HL_PSPositionActualRAD(1) HL_PSPositionActualRAD(1)],[0 HL_PSCommandPositionErrorDEG(1)],'LineWidth',3)
% % grid on, hold on
% % set(gca,'fontsize',14)
% % title(sprintf('PS Command Position Error [deg]\nGoing %s',HL_Direction{1}),'fontsize',14)
% % legend('1st revolution','2nd revolution','Start angle')
% % 
% % h = subplot(2,2,4);
% % tablePos = get(h,'Position');
% % set(h,'Visible','off')
% % t = uitable('Data',[HL_PSPositionErrorStats;HL_PSCommandPositionErrorStats;HL_PSVelocityStats;HL_PSCommandVelocityErrorStats],...
% %     'ColumnName',{'Mean','Std. Dev.','Minimum','Maximum'},...
% %     'RowName',{'PS Position Error [deg]','PS Command Position Error [DPM]','PS Velocity [DPM]','PS Command Position Error [DPM]'});
% % t.Position(3:4) = t.Extent(3:4);
% % set(t,'Units','normalized');
% % t.Position(1) = h.Position(1);
% % t.Position(2) = h.Position(2) + h.Position(4)/2;
% 
% % Write PS log 
% fprintf( outFile, '*************  Positioning System Statistics  ********************************\n');
% fprintf( outFile, '\tMean\tStd.Dev.\tMinimum\tMaximum\n' );
% fprintf( outFile, 'PS Position Error -- [deg]\t%.1f\t%.1f\t%.1f\t%.1f\n',HL_PSPositionErrorStats(1),HL_PSPositionErrorStats(2),HL_PSPositionErrorStats(3),HL_PSPositionErrorStats(4));
% % fprintf( outFile, 'PS Command Position Error -- [DPM]\t%.1f\t%.1f\t%.1f\t%.1f\n',HL_PSCommandPositionErrorStats(1),HL_PSCommandPositionErrorStats(2),HL_PSCommandPositionErrorStats(3),HL_PSCommandPositionErrorStats(4));
% fprintf( outFile, 'PS Velocity -- [DPM]\t%.1f\t%.1f\t%.1f\t%.1f\n',HL_PSVelocityStats(1),HL_PSVelocityStats(2),HL_PSVelocityStats(3),HL_PSVelocityStats(4));
% fprintf( outFile, 'PS Command Position Error -- [DPM]\t%.1f\t%.1f\t%.1f\t%.1f\n',HL_PSCommandVelocityErrorStats(1),HL_PSCommandVelocityErrorStats(2),HL_PSCommandVelocityErrorStats(3),HL_PSCommandVelocityErrorStats(4));
% fprintf( outFile, '\n' );

% ==========================================================================
% ----- End of PS log analysis -----
% ==========================================================================

%% ==========================================================================
%  ----- Evaluate additional metrics  -----
%  ==========================================================================
% HL_HardwareDelay = [0;diff(HL_ElapsedTimeSEC)];
% figure
% plot(HL_HardwareDelay)
% xlabel('Index','fontsize',14)
% ylabel('Refresh rate [sec]','fontsize',14)
% grid on
% close (gcf)
% 
% HardwareDelayStatsMS = [mean(HL_HardwareDelay) std(HL_HardwareDelay) min(HL_HardwareDelay) max(HL_HardwareDelay)]./1000;
% AngularCoverageDEG = abs(max(TxParameters.UnwoundThermAngle)-min(TxParameters.UnwoundThermAngle));
% AngularTravelDEG = sum(diff(TxParameters.UnwoundThermAngle));
% 
% fprintf( outFile, '*************  Additional Statistics  ********************************\n');
% fprintf( outFile, '\tMean\tStd.Dev.\tMinimum\tMaximum\n' );
% fprintf( outFile, 'Hardware refresh rate -- [ms]\t%.2f\t%.2f\t%.2f\t%.2f\n',HardwareDelayStatsMS(1),HardwareDelayStatsMS(2),HardwareDelayStatsMS(3),HardwareDelayStatsMS(4));
% fprintf( outFile, 'Angular coverage -- [deg]\t%.2f\n',AngularCoverageDEG);
% fprintf( outFile, 'Angular travel -- [deg]\t%.2f\n',AngularTravelDEG);
% fprintf( outFile, '\n' );

%%

% TCD_DelayBetweenDynamics = diff(TCD_ElapsedTimeSEC);
% [minDelay,indexMinDelay] = min(TCD_DelayBetweenDynamics);
% [maxDelay,indexMaxDelay] = max(TCD_DelayBetweenDynamics);

%==========================================================================
% %----- PS statistics -----
% dtMIN = diff(TCD_ElapsedTimeSEC)/60;
% 
% % for i = 1:length(TCD_TreatmentState)
% %     if strcmp(TCD_TreatmentState(i),'Delivery') & i > 1
% %         if strcmp(TCD_RotationDirection(i),'Counterclockwise')
% %             TCD_PSPositionDesiredDeg(i) = TCD_ControlAngleDEG(i-1)+(TCD_RotationVelocityDPM(i-1)*dtMIN(i-1));
% %         elseif strcmp(TCD_RotationDirection(i),'Clockwise')
% %             TCD_PSPositionDesiredDeg(i) = TCD_ControlAngleDEG(i-1)-(TCD_RotationVelocityDPM(i-1)*dtMIN(i-1));
% %         end
% %         TCD_PSPositionErrorDeg(i,1) = wrapTo180(TCD_ControlAngleDEG(i) - TCD_PSPositionDesiredDeg(i));
% %     end
% % end
% 
% myFig = figure('Position',get(0, 'Screensize'));
% subplot(2,2,1)
% plot(TCD_ImageNumber(2:end),TCD_DelayBetweenDynamics,'-',TCD_ImageNumber(2:end),mean(TCD_DelayBetweenDynamics)*ones(1,length(TCD_DelayBetweenDynamics)),'--k');hold on
% xlabel('Dynamic number','fontsize',14)
% ylabel('Dynamic receive rate [s]','fontsize',14)
% axis([-inf inf 0 8])
% 
% yyaxis right
% plot(a,HL_HardwareDelay(b));hold on
% ylabel('Hardware refresh rate [s]','fontsize',14)
% 
% grid on
% axis([-inf inf 0 1])
% title('Dynamic receive rate')
% set(gca,'fontsize',14)
% 
% subplot(2,2,2)
% polar(TCD_ControlAngleRAD(2:end),TCD_DelayBetweenDynamics); hold on
% xlabel('Dynamic number','fontsize',14)
% ylabel('Dynamic receive rate [s]','fontsize',14)
% grid on
% axis tight
% title('Dynamic receive rate')
% set(gca,'fontsize',14)
% 
% % subplot(2,2,2)
% % plot(TCD_ImageNumber(strcmp(TCD_TreatmentState,'Delivery')),TCD_PSPositionErrorDeg(strcmp(TCD_TreatmentState,'Delivery')),'-',TCD_ImageNumber(strcmp(TCD_TreatmentState,'Delivery')),mean(TCD_PSPositionErrorDeg)*ones(1,length(TCD_ElapsedTimeSEC(strcmp(TCD_TreatmentState,'Delivery')))),'--k');
% % xlabel('Dynamic Number','fontsize',14)
% % ylabel('PS Angular Error [deg]','fontsize',14)
% % axis([-inf inf -1 1])
% % yyaxis right
% % plot(a,HL_PSPositionErrorDEG(b));hold on
% % ylabel('PS Angular Error (from HWInfo.txt) [deg]','fontsize',14)
% % grid on, hold on
% % set(gca,'fontsize',14)
% % axis([-inf inf -1 1])
% % title('Relative Angular Error','fontsize',14)
% 
% subplot(2,2,3)
% % plot(HL_ElapsedTimeSEC(2:end),HL_HardwareDelay);hold on
% plot(HL_ElapsedTimeSEC,HL_HardwareDelay);hold on
% xlabel('Dynamic number','fontsize',14)
% ylabel('Hardware refresh rate [s]','fontsize',14)
% grid on
% title('Hardware refresh rate (from HWInfo.txt)')
% set(gca,'fontsize',14)
% 
% subplot(2,2,4)
% polar(TCD_ControlAngleRAD,HL_HardwareDelay(b));hold on
% xlabel('Dynamic number','fontsize',14)
% ylabel('Hardware refresh rate [s]','fontsize',14)
% grid on
% title('Hardware refresh rate (from HWInfo.txt)')
% set(gca,'fontsize',14)
% 
% print(myFig,fullfile(HWAnalysisPath,[TxParameters.PatientID '_HardwareStatistics.png']),'-dpng','-r200');
% close(myFig)

%%
%%% POLAR PLOTS %%%
% myFig = figure('Position',get(0, 'Screensize'));
% subplot(2,2,1)
% polar(TCD_ControlAngleRAD(2:end),TCD_DelayBetweenDynamics); hold on
% xlabel('Dynamic number','fontsize',14)
% ylabel('Dynamic receive rate [s]','fontsize',14)
% grid on
% axis tight
% title('Dynamic receive rate')
% set(gca,'fontsize',14)

% subplot(2,2,2)
% polar(TCD_ControlAngleRAD(strcmp(TCD_TreatmentState,'Delivery')),TCD_PSPositionErrorDeg(strcmp(TCD_TreatmentState,'Delivery')))
% xlabel('Dynamic Number','fontsize',14)
% ylabel('PS Angular Error [deg]','fontsize',14)
% grid on, hold on
% set(gca,'fontsize',14)
% title('Relative Angular Error','fontsize',14)

% subplot(2,2,3)
% polar(TCD_ControlAngleRAD,HL_HardwareDelay(b));hold on
% xlabel('Dynamic number','fontsize',14)
% ylabel('Hardware refresh rate [s]','fontsize',14)
% grid on
% title('Hardware refresh rate (from HWInfo.txt)')
% set(gca,'fontsize',14)
% 
% print(myFig,fullfile(HWAnalysisPath,'HardwareStatisticsPolar.png'),'-dpng','-r200');
% close(myFig)
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% POWER OUTPUT ANALYSIS %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% HardwareInfo updates every time the hardware is updated (~0.5sec) %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % ==========================================================================
% PowerDesiredWaUA = [HardwareInfo.PowerDesiredWa_E1 HardwareInfo.PowerDesiredWa_E2 HardwareInfo.PowerDesiredWa_E3 HardwareInfo.PowerDesiredWa_E4...
%     HardwareInfo.PowerDesiredWa_E5 HardwareInfo.PowerDesiredWa_E6 HardwareInfo.PowerDesiredWa_E7 HardwareInfo.PowerDesiredWa_E8...
%     HardwareInfo.PowerDesiredWa_E9 HardwareInfo.PowerDesiredWa_E10];
% 
% PowerDesiredWeUA = [HardwareInfo.PowerDesiredWe_E1 HardwareInfo.PowerDesiredWe_E2 HardwareInfo.PowerDesiredWe_E3 HardwareInfo.PowerDesiredWe_E4...
%     HardwareInfo.PowerDesiredWe_E5 HardwareInfo.PowerDesiredWe_E6 HardwareInfo.PowerDesiredWe_E7 HardwareInfo.PowerDesiredWe_E8...
%     HardwareInfo.PowerDesiredWe_E9 HardwareInfo.PowerDesiredWe_E10];
% 
% PowerNetActualSE = [HardwareInfo.PowerNetWe_E1 HardwareInfo.PowerNetWe_E2 HardwareInfo.PowerNetWe_E3 HardwareInfo.PowerNetWe_E4...
%     HardwareInfo.PowerNetWe_E5 HardwareInfo.PowerNetWe_E6 HardwareInfo.PowerNetWe_E7 HardwareInfo.PowerNetWe_E8...
%     HardwareInfo.PowerNetWe_E9 HardwareInfo.PowerNetWe_E10];
% 
% PowerNetWaSE = [HardwareInfo.PowerNetWa_E1 HardwareInfo.PowerNetWa_E2 HardwareInfo.PowerNetWa_E3 HardwareInfo.PowerNetWa_E4...
%     HardwareInfo.PowerNetWa_E5 HardwareInfo.PowerNetWa_E6 HardwareInfo.PowerNetWa_E7 HardwareInfo.PowerNetWa_E8...
%     HardwareInfo.PowerNetWa_E9 HardwareInfo.PowerNetWa_E10];
% 
% PowerFwdWeSE = [HardwareInfo.PowerForward_E1 HardwareInfo.PowerForward_E2 HardwareInfo.PowerForward_E3 HardwareInfo.PowerForward_E4...
%     HardwareInfo.PowerForward_E5 HardwareInfo.PowerForward_E6 HardwareInfo.PowerForward_E7 HardwareInfo.PowerForward_E8...
%     HardwareInfo.PowerForward_E9 HardwareInfo.PowerForward_E10];
% 
% PowerRefWeSE = [HardwareInfo.PowerReflected_E1 HardwareInfo.PowerReflected_E2 HardwareInfo.PowerReflected_E3 HardwareInfo.PowerReflected_E4...
%     HardwareInfo.PowerReflected_E5 HardwareInfo.PowerReflected_E6 HardwareInfo.PowerReflected_E7 HardwareInfo.PowerReflected_E8...
%     HardwareInfo.PowerReflected_E9 HardwareInfo.PowerReflected_E10];
% 
% PowerSWRSE = [HardwareInfo.SWR_E1 HardwareInfo.SWR_E2 HardwareInfo.SWR_E3 HardwareInfo.SWR_E4 HardwareInfo.SWR_E5...
%     HardwareInfo.SWR_E6 HardwareInfo.SWR_E7 HardwareInfo.SWR_E8 HardwareInfo.SWR_E9 HardwareInfo.SWR_E10];
% 


% % for i = 1:10
% %     PowerDesiredWeUA(:,i) = HardwareInfo{:,i+51};
% %     PowerNetActualSE(:,i) = HardwareInfo{:,i+51+30};
% %     PowerFwdWeSE(:,i) = HardwareInfo{:,i+51+60};
% %     PowerRefWeSE(:,i) = HardwareInfo{:,i+51+80};
% %     PowerSWRSE(:,i) = HardwareInfo{:,i+51+110};
% %     PowerDesiredWaUA(:,i) = HardwareInfo{:,i+51+10};
% %     PowerNetWaSE(:,i) = HardwareInfo{:,i+51+20};    
% % end
% 
% %Compute the power error at each sample increment
% %PowerErrorWe = PowerNetWe - PowerDesiredWe; %
% 
% %Compute electric power delivered at UA
% for d = 2:length(c)
%     for i = 1:10
%         CableLossFactor(d,i) = 0.24*PowerSWR(d-1,i) + 0.84;
%         PowerNetDesiredSE(d,i) = PowerDesiredWeUA(d,i).*10^(CableLossFactor(d,i)/10);
%     end
% end
% 
% PowerNetWeUA = PowerNetDesiredSE./10.^(CableLossFactor/10);
% 
% %Compute power error at UA
% PowerError = PowerNetWeUA - PowerDesiredWeUA;
% 
% %Compute the average power error at each image increment
% for d = 1:length(a)
%     for i = 1:10
%         if d == length(a)
%             temp = PowerErrorWe(b(d):length(c),i);
%         else
%             temp = PowerErrorWe(b(d):b(d+1)-1,i);
%         end
%         avgErrorWe(d,i) = mean(temp);
%         stdErrorWe(d,i) = std(temp);
%     end
% end
% 
% %==========================================================================
% %----- Plot the SE logs  -----
% for i = 1:10
%     figure; plot(ElapsedTimeMin,PowerErrorWe(:,i)),title(['Power Error: E' num2str(i)],'fontsize',14),xlabel('Time [min]','fontsize',14), ylabel('Error [We]','fontsize',14), set(gca,'fontsize',14)
% end

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% TREATMENTCONTROLLER INFO ANALYSIS %%%%%%%%%%%%%%%%%%%%%%%%%%%
% TreatmentControlerInfo updates every time a dynamic is received(~0.5sec)%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load(fullfile(TxParameters.pathData,'TreatmentControllerInfo.mat'));
% 
% lineidx = 1;
% for idx = 1:length(TreatmentControllerInfo{1,5})
%     if ~mod(idx,10) %1 if idx is multiplier of 10
%         ControlAngle(lineidx,10) = TreatmentControllerInfo{1,5}(idx);
%         ControlRadiusMM(lineidx,10) = TreatmentControllerInfo{1,6}(idx);
%         ControlTemp(lineidx,10) = TreatmentControllerInfo{1,7}(idx);
%         lineidx = lineidx + 1;
%     else
%         ControlAngle(lineidx,mod(idx,10)) = TreatmentControllerInfo{1,5}(idx);
%         ControlRadiusMM(lineidx,mod(idx,10)) = TreatmentControllerInfo{1,6}(idx);
%         ControlTemp(lineidx,mod(idx,10)) = TreatmentControllerInfo{1,7}(idx);
%     end
% end
% 
% ControlTempSliced = [zeros(size(ControlTemp,1),1) ControlTemp zeros(size(ControlTemp,1),1)];
% ControlAngleSliced = [zeros(size(ControlAngle,1),1) ControlAngle zeros(size(ControlTemp,1),1)]*pi/180; 
% ControlRadiusSliced = [zeros(size(ControlRadiusMM,1),1) ControlRadiusMM zeros(size(ControlRadiusMM,1),1)]./2; 
% 
% ControlAngleRad = deg2rad(TreatmentControllerData.ControlAngle_deg);
% 
% ChannelFrequencySliced = [zeros(size(TreatmentControllerData.Frequency_E1,1),1)...
%     TreatmentControllerData.Frequency_E1 TreatmentControllerData.Frequency_E2 TreatmentControllerData.Frequency_E3...
%     TreatmentControllerData.Frequency_E4 TreatmentControllerData.Frequency_E5 TreatmentControllerData.Frequency_E6...
%     TreatmentControllerData.Frequency_E7 TreatmentControllerData.Frequency_E8 TreatmentControllerData.Frequency_E9...
%     TreatmentControllerData.Frequency_E10 zeros(size(TreatmentControllerData.Frequency_E1,1),1)];
% 
% ChannelNetPowerSliced = [zeros(size(TreatmentControllerData.PowerNetWe_E1,1),1)...
%     TreatmentControllerData.PowerNetWe_E1 TreatmentControllerData.PowerNetWe_E2 TreatmentControllerData.PowerNetWe_E3...
%     TreatmentControllerData.PowerNetWe_E4 TreatmentControllerData.PowerNetWe_E5 TreatmentControllerData.PowerNetWe_E6...
%     TreatmentControllerData.PowerNetWe_E7 TreatmentControllerData.PowerNetWe_E8 zeros(size(TreatmentControllerData.PowerNetWe_E1,1),1)...
%     zeros(size(TreatmentControllerData.PowerNetWe_E1,1),1)];
% ChannelNetPower = ChannelNetPowerSliced(:,2:11);
% 
% ControlBoundary = TxParameters.ControlBoundary;
% ControlBoundarySliced = [2.5*ones(size(TxParameters.ControlBoundary,1),1) TxParameters.ControlBoundary TxParameters.ControlBoundary(:,end)];
% ControlBoundaryTheta = TxParameters.ControlBoundaryTheta*pi/180;
% 
% meanControlBoundary = mean(ControlBoundary,1);
% meanControlTemp = mean(ControlTemp,1);


%%
% for elementIdx = 1:10
%     isActive(:,elementIdx) = ChannelNetPower(:,elementIdx) > 2;
%     ActiveChannelNetPower{elementIdx} = ChannelNetPower(:,elementIdx).* isActive(:,elementIdx);
%     ActiveControlAngleRad{elementIdx} = ControlAngleRad.* isActive(:,elementIdx);
%     correctedControlTemp(:,elementIdx) = ControlTemp(:,elementIdx) - meanControlTemp(elementIdx);
%     [XControlTemp(:,elementIdx),YControlTemp(:,elementIdx)] = pol2cart(ControlAngleRad,ControlTemp(:,elementIdx)/6);
%     [XIsotherm(:,elementIdx),YIsotherm(:,elementIdx)] = pol2cart(ControlAngleRad,55*ones(length(ControlAngleRad),1)/6);
%     [X_control(:,elementIdx),Y_control(:,elementIdx)]   = pol2cart(TxParameters.ControlBoundaryTheta*(pi/180),TxParameters.ControlBoundary(:,elementIdx));
% end

%%
% figure
% for elementIdx = 1:8
%     titleStr = sprintf('Element %d',elementIdx);
%     hPlot(elementIdx) = initializeSubplots(elementIdx,4,0.01,0.05);
%     hPlot(elementIdx).Visible = 'off';
%     pax(elementIdx) = polaraxes('ThetaTick',[0:45:360],'Position',hPlot(elementIdx).Position,'RLim',[0 max(max(ControlTemp))+2],'RLimMode','auto');     hold on
%     polarplot(pax(elementIdx),ControlAngleRad,ControlTemp(:,elementIdx),'LineWidth', 2);
%     polarplot(pax(elementIdx),ControlBoundaryTheta,ControlBoundary(:,elementIdx)*4,'--k','LineWidth', 0.5);
%     polarplot(pax(elementIdx),ControlAngleRad,55*ones(length(ControlAngleRad),1),'r','LineWidth', 0.5);
%     polarplot(pax(elementIdx),ActiveControlAngleRad{elementIdx},ActiveChannelNetPower{elementIdx}.*8,'-','LineWidth', 0.5);
%     
%     htitle(elementIdx) = title(titleStr);
% end
%%
% myFig = figure('Position',get(0, 'Screensize'));
% for elementIdx = 1:10
%     titleStr = sprintf('Element %d',elementIdx);
%     hPlot(elementIdx) = initializeSubplots(elementIdx,5,0.01,0.05);
%     hPlot(elementIdx).Visible = 'off';
%     imshow(TMax{elementIdx+1},[20 101])
%     coloraxis = [20 101]; %We want to map from 20 to 100 but somehow Matlab colormap works with intervals. So we need to get to 101
%     TickLabels = {20 55 90 100};
%     XTick = [20 55 90 100];
%     colormap(cmap3), caxis(coloraxis), zoomcenter(TxParameters.ux,TxParameters.uy,2), hold on
%     plot(XControlTemp(:,elementIdx)+TxParameters.ux,-YControlTemp(:,elementIdx)+TxParameters.uy,'-k','LineWidth',1); hold on
%     plot(X_control(:,elementIdx) + TxParameters.ux,-Y_control(:,elementIdx) + TxParameters.uy,'linewidth',0.5)
%     plot(XIsotherm(:,elementIdx) + TxParameters.ux,-YIsotherm(:,elementIdx) + TxParameters.uy,'r','linewidth',1)
%                    
% end

