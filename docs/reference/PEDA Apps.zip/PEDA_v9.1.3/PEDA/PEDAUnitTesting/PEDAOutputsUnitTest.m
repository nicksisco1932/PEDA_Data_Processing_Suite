% Initialization
global UnitTestParameters

%% TS-25 - PEDA shall output PNG files along with PDF files 
listOfFiles = {'_TDose';'_TMax'};
fileExtensions = {'.pdf';'.png'};

for i = 1:length(listOfFiles)
    for j = 1:length(fileExtensions)
        assert(logical(exist(fullfile(UnitTestParameters.SegmentPath,strcat(listOfFiles{i},fileExtensions{j})))),sprintf('File %s does not exist',strcat(listOfFiles{i},fileExtensions{j})));
    end
end

%% TS-51 - PEDA shall generate a two-dimensional thermal dose map and a two-dimensional maximum temperature map for each active slice treated at the end of each experiment 
assert(logical(exist(fullfile(UnitTestParameters.SegmentPath,'TDose.mat'))),'TDose matrix does not exist')
assert(logical(exist(fullfile(UnitTestParameters.SegmentPath,'TMax.mat'))),'TMax matrix does not exist')

assert(logical(~isempty(fullfile(UnitTestParameters.SegmentPath,'TDose.mat'))),'TDose matrix is empty')
assert(logical(~isempty(fullfile(UnitTestParameters.SegmentPath,'TMax.mat'))),'TMax matrix is empty')

%% TS-91 - PEDA shall store treatment statistics in a Matlab structure
assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,'PEDAOverallResults.mat'))),'PEDAOverallResults structure does not exist')
load(fullfile(UnitTestParameters.PEDAPath,'PEDAOverallResults.mat'));
assert(~isempty(PEDAOverallResults),'PEDAOverallResults structure is empty');

%% TS-94 - PEDA shall analyze and output hardware statistics
PEDAsegments = dir(fullfile(UnitTestParameters.PEDAPath,'*Seg*'));
PEDAsegments = PEDAsegments([PEDAsegments.isdir]);
numberOfSegments = length(PEDAsegments);

for segmentIdx = 1:numberOfSegments
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'HWAnalysis'))),sprintf('HWAnalysis folder does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'HWAnalysis','_FCStatistics.png'))),sprintf('FC Statistics do not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'HWAnalysis','_HardwareStatistics.txt'))),sprintf('Hardware Statistics textfile do not exist for segment %d',segmentIdx))
end

%% TS-95 - PEDA shall generate TUV matrix and generate a TUV movie for each segment
%List the number of segments
PEDAsegments = dir(fullfile(UnitTestParameters.PEDAPath,'*Seg*'));
PEDAsegments = PEDAsegments([PEDAsegments.isdir]);
numberOfSegments = length(PEDAsegments);

for segmentIdx = 1:numberOfSegments
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'_TUV.mp4'))),sprintf('TUV movie does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'TUV.mat'))),sprintf('TUV matrix does not exist for segment %d',segmentIdx))
end

%% TS-105/TS-261 - PEDA shall save raw Phase & Magnitude matrices for each segment
%List the number of segments
PEDAsegments = dir(fullfile(UnitTestParameters.PEDAPath,'*Seg*'));
PEDAsegments = PEDAsegments([PEDAsegments.isdir]);
numberOfSegments = length(PEDAsegments);

for segmentIdx = 1:numberOfSegments
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Phase.mat'))),sprintf('Phase matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath, PEDAsegments(segmentIdx).name,'Magnitude.mat'))), sprintf('Magnitude matrix does not exist for segment %d', segmentIdx))
end

%% TS-189 - PEDA shall output all generated masks
PEDAsegments = dir(fullfile(UnitTestParameters.PEDAPath,'*Seg*'));
PEDAsegments = PEDAsegments([PEDAsegments.isdir]);
numberOfSegments = length(PEDAsegments);

for segmentIdx = 1:numberOfSegments
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','HotPixelMask.mat'))),sprintf('HotPixelMask matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','Mask.mat'))),sprintf('Mask matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','ProstateMask.mat'))),sprintf('ProstateMask matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','ControlMask.mat'))),sprintf('ControlMask matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','SectorMask.mat'))),sprintf('SectorMask matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','TUVMask.mat'))),sprintf('TUVMask matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','SNRMask.mat'))),sprintf('SNRMask matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','StabilityMask.mat'))),sprintf('StabilityMask matrix does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'Masks','UAMask.mat'))),sprintf('UAMask matrix does not exist for segment %d',segmentIdx))
end

%% TS-199 - For each segment, PEDA shall output movies of current temperature, maximum temperature, and magnitude 
%List the number of segments
PEDAsegments = dir(fullfile(UnitTestParameters.PEDAPath,'*Seg*'));
PEDAsegments = PEDAsegments([PEDAsegments.isdir]);
numberOfSegments = length(PEDAsegments);

for segmentIdx = 1:numberOfSegments
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'_Magnitude.mp4'))),sprintf('Magnitude movie does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'_Maximum Temperature.mp4'))),sprintf('Maximum Temperature movie does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'_Current Temperature.mp4'))),sprintf('Current Temperature movie does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'_TUV.mp4'))),sprintf('TUV movie does not exist for segment %d',segmentIdx))
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,PEDAsegments(segmentIdx).name,'_TUVMag.mp4'))),sprintf('TUV Magnitude movie does not exist for segment %d',segmentIdx))
end

%% TS-206 - PEDA shall save UA calibration data
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'));
assert(isfield(SxParameters, 'UA'),'UA calibration data field in SxParamaters is empty');
