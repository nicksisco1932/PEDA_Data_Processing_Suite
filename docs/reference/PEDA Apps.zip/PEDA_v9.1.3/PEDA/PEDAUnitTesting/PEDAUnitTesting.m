%==========================================================================
% ----- PEDA Unit test and functional test -----
%==========================================================================
global UnitTestParameters

fprintf('UNIT TESTING OF PEDA %s STARTED... \n',UnitTestParameters.PEDAVersion);
disp('============================================');

GelTestPEDAPath = fullfile(UnitTestParameters.ModifiedGelDataSetPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
TwoSegmentPEDAPath = fullfile(UnitTestParameters.ModifiedTwoSegmentDataSetPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
ImageShiftPEDAPath = fullfile(UnitTestParameters.ModifiedImageShiftDataSetPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
MultipleSSPEDAPath = fullfile(UnitTestParameters.MultipleSSDataSetPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
FirstElementNotE1PEDAPath = fullfile(UnitTestParameters.FirstElementNotE1PEDAPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
RawFolderAndThermalBoostPEDAPath = fullfile(UnitTestParameters.RawFolderAndThermalBoostPEDAPath, ['PEDA', PEDA_VERSION_UNDER_TEST]);
GEAndTDCv211PEDAPath = fullfile(UnitTestParameters.GEAndTDCv211PEDAPath, ['PEDA', PEDA_VERSION_UNDER_TEST]);
UApAndTDCv212PEDAPath = fullfile(UnitTestParameters.TDCv212PEDAPath, ['PEDA', PEDA_VERSION_UNDER_TEST]);


% Make sure the PEDA folders do not exist
if exist(GelTestPEDAPath)
    rmdir(GelTestPEDAPath,'s')
end

if exist(TwoSegmentPEDAPath)
    rmdir(TwoSegmentPEDAPath,'s')
end

if exist(ImageShiftPEDAPath)
    rmdir(ImageShiftPEDAPath,'s')
end

if exist(MultipleSSPEDAPath)
    rmdir(MultipleSSPEDAPath,'s')
end

if exist(FirstElementNotE1PEDAPath)
    rmdir(FirstElementNotE1PEDAPath,'s')
end

if exist(RawFolderAndThermalBoostPEDAPath)
    rmdir(RawFolderAndThermalBoostPEDAPath, 's')
end

if exist(GEAndTDCv211PEDAPath)
    rmdir(GEAndTDCv211PEDAPath, 's')
end

if exist(GEAndTDCv211PEDAPath)
    rmdir(GEAndTDCv211PEDAPath, 's')
end


%==========================================================================
% ----- PEDA execution -----
%==========================================================================
fprintf('\tExecuting PEDA in silent mode...\n')
fprintf('\tGel test...\n')

% Execute PEDA without pop-ups, or console output
set(0,'DefaultFigureVisible','off')
evalc('MAIN_PEDA(UnitTestParameters.ModifiedGelDataSetPath)');

% Second, patient data, two-segment
fprintf('\tPatient data - Two Segments...\n')
evalc('MAIN_PEDA(UnitTestParameters.ModifiedTwoSegmentDataSetPath)');

% Third, 2.6.3 with image shift data,
fprintf('\tImage-shifted data...\n')
evalc('MAIN_PEDA(UnitTestParameters.ModifiedImageShiftDataSetPath)');

% Fourth, 2.7 data with multiple subsegments,
fprintf('\tMultiple subsegments data...\n')
evalc('MAIN_PEDA(UnitTestParameters.MultipleSSDataSetPath)');

% Fifth, data with treatment not using E1,
fprintf('\tFirst element not E1 data...\n')
evalc('MAIN_PEDA(UnitTestParameters.FirstElementNotE1PEDAPath)');

% Sixth, 2.10 data with thermal boost enabled
fprintf('\tTDC 2.10 and Thermal Boosted data...\n')
evalc('MAIN_PEDA(UnitTestParameters.RawFolderAndThermalBoostPEDAPath)');

% Seventh, GE TDC v2.11 data 
fprintf('\tGE TDC v2.11...\n')
evalc('MAIN_PEDA(UnitTestParameters.GEAndTDCv211PEDAPath)');

% Eigth, UAp TDC v2.12 data 
fprintf('\tUA+ TDC v2.12...\n')
evalc('MAIN_PEDA(UnitTestParameters.TDCv212PEDAPath)');


%==========================================================================
% ----- Tests -----
%==========================================================================
UnitTestParameters.PEDAPath = fullfile(UnitTestParameters.ModifiedGelDataSetPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
UnitTestParameters.SegmentPath = fullfile(UnitTestParameters.PEDAPath,'Segment 1');

%% Low level Functions unit testing
resultsPEDAFunctionsUnitTest = runtests('PEDAFunctionsUnitTest');
resultsPEDAFunctionsUnitTest = table(resultsPEDAFunctionsUnitTest);

%% EPIC TS-46 - PEDA Outputs
resultsPEDAOutputsUnitTest = runtests('PEDAOutputsUnitTest');
resultsPEDAOutputsUnitTest = table(resultsPEDAOutputsUnitTest);

%% EPIC TS-48 - PEDA Masking
resultsPEDAMaskingUnitTest = runtests('PEDAMaskingUnitTest');
resultsPEDAMaskingUnitTest = table(resultsPEDAMaskingUnitTest);

%% EPIC TS-60 - PEDA Miscellaneous
resultsPEDAMiscUnitTest = runtests('PEDAMiscUnitTest');
resultsPEDAMiscUnitTest = table(resultsPEDAMiscUnitTest);

%% EPIC TS-66 - PEDA Isotherms
resultsPEDAIsothermUnitTest = runtests('PEDAIsothermUnitTest');
resultsPEDAIsothermUnitTest = table(resultsPEDAIsothermUnitTest);

%% EPIC TS-132 - PEDA reference ImageShift
UnitTestParameters.PEDAPath = fullfile(UnitTestParameters.ModifiedImageShiftDataSetPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
UnitTestParameters.SegmentPath = fullfile(UnitTestParameters.PEDAPath,'Segment 1');
resultsPEDAReferenceImageshiftUnitTest = runtests('PEDAReferenceImageshiftUnitTest');
resultsPEDAReferenceImageshiftUnitTest = table(resultsPEDAReferenceImageshiftUnitTest);

%% EPIC TS-112 - PEDA Combined segments/subsegments
UnitTestParameters.PEDAPath = fullfile(UnitTestParameters.ModifiedTwoSegmentDataSetPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
resultsPEDACombinedSegmentsUnitTest = runtests('PEDACombinedSegmentsUnitTest');

UnitTestParameters.PEDAPath = fullfile(UnitTestParameters.MultipleSSDataSetPath,['PEDA',PEDA_VERSION_UNDER_TEST]);
resultsPEDACombinedSubSegmentsUnitTest = runtests('PEDACombinedSubSegmentsUnitTest');

resultsPEDACombinedSegmentsSubSegmentsUnitTest = [table(resultsPEDACombinedSegmentsUnitTest);table(resultsPEDACombinedSubSegmentsUnitTest)];

%% Unit test summary
disp('============================================');
fprintf('UNIT TESTING OF PEDA %s FINISHED \n',PEDA_VERSION_UNDER_TEST);
overallUnitTestResultsFilename = sprintf('PEDA%s_OverallUnitTestResults.csv',PEDA_VERSION_UNDER_TEST);

if exist(fullfile(PATH_TO_UNIT_TEST_RESULTS,overallUnitTestResultsFilename))
    delete(fullfile(PATH_TO_UNIT_TEST_RESULTS,overallUnitTestResultsFilename));
end

overallUnitTestResults = [resultsPEDAFunctionsUnitTest;resultsPEDAOutputsUnitTest;resultsPEDAMaskingUnitTest;resultsPEDAMiscUnitTest;resultsPEDAIsothermUnitTest; resultsPEDAReferenceImageshiftUnitTest; resultsPEDACombinedSegmentsSubSegmentsUnitTest];
writetable(overallUnitTestResults,fullfile(PATH_TO_UNIT_TEST_RESULTS,overallUnitTestResultsFilename),'QuoteStrings',true)

fprintf('\tOutputs located in %s\n',PATH_TO_UNIT_TEST_RESULTS);
fprintf('\tOverall Unit Test results written to file %s\n',overallUnitTestResultsFilename);
disp('============================================');

% Revert to default values
set(0,'DefaultFigureVisible','on')