% Initialization
global UnitTestParameters

%% TS-75 - PEDA shall generate 1�-increment isotherms for either a sector or a complete revolution 
% Check for a sector
load(fullfile(UnitTestParameters.SegmentPath,'Isotherms.mat'))
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'))

assert(isequal(size(isothermRadius,1),numel(SxParameters.TreatedSector)),'Temperature isotherm does not cover the treated sector');
assert(isequal(size(isothermRadiusTDose,1),numel(SxParameters.TreatedSector)),'Dose isotherm does not cover the treated sector');

% TODO: check for a whole treatment
%% TS-76 - PEDA shall extend the isotherm boundary search to 7 radial mm greater than the prostate boundary
load(fullfile(UnitTestParameters.SegmentPath,'Isotherms.mat'))
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'))
tol = 0.0001;

isothermCondition = SxParameters.ProstateBoundaryMM(SxParameters.TreatedSector+1,SxParameters.isUAactive) - MaxProstateRadius(:,SxParameters.isUAactive) < tol;

assert(all(isothermCondition(:)),'Isotherm boundary does not search 7 mm greater than prostate boundary')

%% TS-285 - PEDA shall generate the 240 CEM43 isotherm for each active slice on its corresponding thermal dose images.
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'))
load(fullfile(UnitTestParameters.SegmentPath,'Isotherms.mat'))
% Segment 1
assert(isequal(exist('isothermRadiusTDose'),1),'isothermRadiusTDose matrix is empty or does not exist');

% Whole-treatment. Only if more than 2 segments
if size(SxParameters,2) > 1
   assert(isequal(exist('isothermRadiusTDose'),1),'isothermRadiusTDose matrix is empty or does not exist');
end

%% TS-286 - PEDA shall compute the 55�C isotherm for each active slice on its corresponding maximum temperature image
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'))
load(fullfile(UnitTestParameters.SegmentPath,'Isotherms.mat'))
% Segment 1
assert(isequal(exist('isothermRadius55'),1),'isothermRadius55 matrix is empty or does not exist');

% Whole-treatment. Only if more than 2 segments
if size(SxParameters,2) > 1
   assert(isequal(exist('isothermRadius55'),1),'isothermRadius55 matrix is empty or does not exist');
end


%% TS-290 - PEDA shall compute target temperature isotherms for each active slice on its corresponding maximum temperature images for each target temperature of the treatment controller.  A combined isotherm shall be made up of these isotherms (Control Isotherm).
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'))
% Segment 1
assert(logical(exist(fullfile(UnitTestParameters.SegmentPath,'Isotherms.mat'))),'Isotherm matrix does not exist in segment')
load(fullfile(UnitTestParameters.SegmentPath,'Isotherms.mat'))

assert(isequal(exist('isothermRadius'),1),'isothermRadius matrix is empty or does not exist');
assert(isequal(exist('isothermRadius63'),1),'isothermRadius63 matrix is empty or does not exist');
assert(isequal(exist('isothermRadius65'),1),'isothermRadius65 matrix is empty or does not exist');
assert(isequal(exist('isothermRadius_combined'),1),'isothermRadius_combined matrix is empty or does not exist');

% Whole-treatment. Only if more than 2 segments
if size(SxParameters,2) > 1
    assert(logical(exist(fullfile(UnitTestParameters.PEDAPath,'Isotherms.mat'))),'Isotherm matrix does not exist for whole treatment')
    load(fullfile(UnitTestParameters.PEDAPath,'Isotherms.mat'))

    assert(isequal(exist('isothermRadius'),1),'isothermRadius matrix is empty or does not exist');
    assert(isequal(exist('isothermRadius63'),1),'isothermRadius63 matrix is empty or does not exist');
    assert(isequal(exist('isothermRadius65'),1),'isothermRadius65 matrix is empty or does not exist');
    assert(isequal(exist('isothermRadius_combined'),1),'isothermRadius_combined matrix is empty or does not exist');
end
