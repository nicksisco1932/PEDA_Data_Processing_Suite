% Initialization
global UnitTestParameters
% Load SxParameters
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'));

%% TS-133 - PEDA shall store UA center X and Y coordinates for each slice and dyn in SxParameters
NumSlices = 12;
NumDyns = length(SxParameters.ImageNumber);

assert(all(size(SxParameters.ux) == [NumDyns, NumSlices]),'UA Center X has incorrect size. Expected: [%d %d], Actual: [%d %d]',NumDyns, NumSlices,size(SxParameters.ux,1),size(SxParameters.ux,2));
assert(all(size(SxParameters.uy) == [NumDyns, NumSlices]),'UA Center Y has incorrect size. Expected: [%d %d], Actual: [%d %d]',NumDyns, NumSlices,size(SxParameters.uy,1),size(SxParameters.uy,2));

%% TS-134 - PEDA shall save the ProstateMask for each dyn to account for ImageShift 
ProstateMask = cell2mat(struct2cell(load(fullfile(UnitTestParameters.SegmentPath,'\Masks\ProstateMask'))));
NumSlices = 12;
ImageNumberEnd = SxParameters.ImageNumber(end);

assert(all(size(ProstateMask) == [128,128, NumSlices, ImageNumberEnd]),'ProstateMask has incorrect size. Expected: [128 128 %d %d], Actual: [%d %d %d %d]',...
    NumSlices, ImageNumberEnd, size(ProstateMask,1), size(ProstateMask,2), size(ProstateMask,3), size(ProstateMask,4));

%% TS-135 - PEDA shall save the UAMask for each slice and dyn to account for ImageShift
UAMask = cell2mat(struct2cell(load(fullfile(UnitTestParameters.SegmentPath,'\Masks\UAMask'))));
NumSlices = 12;
ImageNumberEnd = SxParameters.ImageNumber(end);

assert(all(size(UAMask) == [128,128, NumSlices, ImageNumberEnd]),'UAMask has incorrect size. Expected: [128 128 %d %d], Actual: [%d %d %d %d]',...
    NumSlices, ImageNumberEnd, size(UAMask,1), size(UAMask,2), size(UAMask,3), size(UAMask,4));

%% TS-136 - PEDA shall create movies that are ImageShifted

%% TS-137 - PEDA shall output corrected TMax and TDose for reference ImageShift

%% TS-138 - PEDA shall use a combined mask in CountHotPixels for ImageShift
ControlMask = cell2mat(struct2cell(load(fullfile(UnitTestParameters.SegmentPath,'\Masks\ControlMask'))));
HotPixelMask = cell2mat(struct2cell(load(fullfile(UnitTestParameters.SegmentPath,'\Masks\HotPixelMask'))));
[X_MTR,Y_MTR] = pol2cart(SxParameters.ControlBoundaryTheta*(pi/180),SxParameters.MinimumTreatmentRadius);
for sliceIdx = 1:12
    for dynIdx = 1:size(SxParameters.ux,1)
        MTRMask(:,:,sliceIdx,dynIdx) = poly2mask(X_MTR + SxParameters.ux(dynIdx,sliceIdx),-Y_MTR + SxParameters.uy(dynIdx,sliceIdx), 128, 128);
    end
end

ExpectedMask = prod(ControlMask(:,:,:,SxParameters.ImageNumber(1):end),4) .* prod(~MTRMask,4);

assert(isequal(ExpectedMask,HotPixelMask),'HotPixelMask not equal to ExpectedMask')