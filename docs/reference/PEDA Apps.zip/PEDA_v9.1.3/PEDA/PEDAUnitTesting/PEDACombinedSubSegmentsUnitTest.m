% Initialization
global UnitTestParameters
tol = 10^-5;

%% TS-200: PEDA shall recalculate the prostate mask and cumulative mask when a subsegment is created
% Segment 2 has a nice boundary change
ProstateMask = importdata(fullfile(UnitTestParameters.PEDAPath,'Segment 2\Masks\ProstateMask.mat'));
Mask = importdata(fullfile(UnitTestParameters.PEDAPath,'Segment 2\Masks\Mask.mat'));
SxParameters = importdata(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'));
SxParameters = SxParameters(2);

% Prostate mask test
sliceOfInterest = 5;
for subSegmentIdx = 1:numel(SxParameters.SubSegmentImageNumber)-1
    dynamicInterval = max(SxParameters.ImageNumber(1),SxParameters.SubSegmentImageNumber(subSegmentIdx)):SxParameters.SubSegmentImageNumber(subSegmentIdx+1)-1;
    pixelOfInterest = [62 56];
    if subSegmentIdx == 1
        assert(all(ProstateMask(pixelOfInterest(1),pixelOfInterest(2),sliceOfInterest,dynamicInterval)),'Error: pixel (%d, %d) of prostate mask of subSegment %d of slice %d expected to be 1. Was 0 instead',pixelOfInterest(1),pixelOfInterest(2),subSegmentIdx, sliceOfInterest); 
    elseif subSegmentIdx == 2
        assert(all(~ProstateMask(pixelOfInterest(1),pixelOfInterest(2),sliceOfInterest,dynamicInterval)),'Error: pixel (%d, %d) of prostate mask of subSegment %d of slice %d expected to be 0. Was 1 instead',pixelOfInterest(1),pixelOfInterest(2),subSegmentIdx, sliceOfInterest); 
    end
end

% Cumulative mask test
% Anatomy data was altered on dyn 27 (ImageNumber 26). Pixels between radius 15 and 20 are set to zeros. 
% CurrentTemperature data was altered on dyns 25-26 (ImageNumber 24-25). Pixels between radius 15 and 20 are set to 30 (dyn 25) and then 50 (dyn 26)
% Let's test from radius 16 to 19 pixels
sliceOfInterest = 3;
[XSmallCircle,YSmallCircle] = pol2cart(SxParameters.ControlBoundaryTheta*(pi/180),16); 
[XBigCircle,YBigCircle] = pol2cart(SxParameters.ControlBoundaryTheta*(pi/180),19);
SmallCirclemask = poly2mask(XSmallCircle + SxParameters.ux(sliceOfInterest),-YSmallCircle + SxParameters.uy(sliceOfInterest), 128, 128);
BigCircleMask = poly2mask(XBigCircle + SxParameters.ux(sliceOfInterest),-YBigCircle + SxParameters.uy(sliceOfInterest), 128, 128);
CircleMask = BigCircleMask & ~SmallCirclemask;

for subSegmentIdx = 1:numel(SxParameters.SubSegmentImageNumber)-1
    % Masked pixels only appear at dynamic 26
    dynamicInterval = max(26,SxParameters.SubSegmentImageNumber(subSegmentIdx)):SxParameters.SubSegmentImageNumber(subSegmentIdx+1)-1;
    if subSegmentIdx == 1 % All zeros on subsegment 1
        maskUnderTest = squeeze(Mask(:,:,sliceOfInterest,dynamicInterval));
        assert(all(~(maskUnderTest(CircleMask))),'Error: cumulative mask of subSegment %d of slice %d expected to be all 0s',subSegmentIdx, sliceOfInterest);
    elseif subSegmentIdx == 2 % Back to one on subsegment 2
        maskUnderTest = squeeze(Mask(:,:,sliceOfInterest,dynamicInterval));
        assert(all(maskUnderTest(CircleMask)),'Error: cumulative mask of subSegment %d of slice %d expected to be all 1s',subSegmentIdx, sliceOfInterest);
    end
end

%% TS-204: PEDA shall combine SubSegment boundaries with UA centered at its ImageShifted location at end of segment
clear ThermalAngle SimulatedAngleData SimulatedRotationDirection TreatedSector ExpectedResult
load('private\SxParameters-CombineBoundaries.mat')
% SxParameters is 2 treatment segments
% - Segment 1 has 2 subsegments (TreatedSectors [0:199 358:359] and [181:358])
% - Segment 2 has 1 subsegment (TreatedSector [151:167])
% Changes:
% - On E7 (slice 8), Segment 1 last dyn, UA center x coordinate was changed from 64.5 to 66.5
% - On E1 (slice 2), Segment 2 last dyn, UA center x coordinate was changed from 64.5 to 58.5
% - On E5 (slice 6), Segment 1 last dyn, UA center x coordinate was changed from 64.075 to 63.8
% - On E3 (slice 4), Segment 1 last dyn, UA center y coordinate was changed from 64.075 to 71
% - On E5 (slice 6), Segment 1 Subsegment 1, changed Prostate Radius at angle 230 (not treated) from 26.63968658 to 40
% - On E1 (slice 2), Segment 1 Subsegment 1, changed Control  Radius at angle 138 (treated) from 7.338562236 to 25
% - On E4 (slice 5), Segment 1 Subsegment 2, changed Prostate Radius at angle 309 (treated) from 23.38665295 to 39
% - On E2 (slice 3), Segment 1 Subsegment 2, changed Control  Radius at angle 56  (not treated) from 14.57290985 to 27
% - On E6 (slice 7), Segment 2, changed Prostate Radius at angle 161 (treated) from 15.8962 to 40
% - On E7 (slice 8), Segment 2, changed Control  Radius at angle 264 (not treated) from 12.5493 to 15


[~, ~, ~, ~, CombinedUX, CombinedUY] = CombineBoundaries(SxParameters(1));

ExpectedResult = SxParameters(1).ux(end,:);
assert(all(abs(CombinedUX - ExpectedResult) < tol),'Combined subsegment UA center (x coordinate) with ImageShift on E3 failed')

ExpectedResult = SxParameters(1).uy(end,:);
assert(all(abs(CombinedUY - ExpectedResult) < tol),'Combined subsegment UA center (y coordinate) with ImageShift on E3 failed')


%% TS-203: PEDA shall combine Treatment Segment boundaries with UA centered at its ImageShifted location at end of Segment 1
clear SxParameters CombinedUX CombinedUY ExpectedResult
load('private\SxParameters-CombineBoundaries.mat')

[~, ~, ~, ~, CombinedUX, CombinedUY] = CombineBoundaries(SxParameters);

ExpectedResult = SxParameters(1).ux(end,:);
assert(all(abs(CombinedUX - ExpectedResult) < tol),'Combined treatment segment UA center (x coordinate) with ImageShift on E3 failed')

ExpectedResult = SxParameters(1).uy(end,:);
assert(all(abs(CombinedUY - ExpectedResult) < tol),'Combined treatment segment UA center (y coordinate) with ImageShift on E3 failed')

%% TS-202: PEDA shall combine SubSegment boundaries by taking the maximum radius at each 1�-increment for treated sectors only
clear SxParameters CombinedUX CombinedUY ExpectedResult
load('private\SxParameters-CombineBoundaries.mat')

[CombinedProstateBoundary, CombinedControlBoundary, ~, ~, ~, ~] = CombineBoundaries(SxParameters(1));
CombinedProstateBoundaryMM = CombinedProstateBoundary.*SxParameters(1).PixelSize(1);
CombinedControlBoundaryMM = CombinedControlBoundary.*SxParameters(1).PixelSize(1);

% Part of TreatedSector in Segment 1 Subsegment 2, not Subsegment 1
assert(CombinedProstateBoundaryMM(310,5) == 39,'Prostate boundary on slice 5 (E4), theta = 309 deg, does not have the expected value of 39 mm')
% Part of TreatedSector in Segment 1 Subsegment 1, not Subsegment 2
assert(CombinedControlBoundaryMM(139,2) == 25, 'Control boundary on slice 2 (E1), theta = 138 deg, does not have the expected value of 25 mm')
% Part of TreatedSector in Segment 1 Subsegment 2, not Subsegment 1
assert(CombinedProstateBoundaryMM(231,6) == SxParameters(1).ProstateBoundaryMM(231,6,2),'Prostate boundary on slice 6 (E5), theta = 230 deg, does not have the expected value of 25.01 mm')
% Part of TreatedSector in Segment 1 Subsegment 1, not Subsegment 2
assert(CombinedControlBoundaryMM(57,3) == SxParameters(1).ControlBoundaryMM(57,3,1),'Control boundary on slice 3 (E2), theta = 56 deg, does not have the expected value of 14.57 mm')

%% TS-205: PEDA shall use the combined SubSegment boundaries if they exist when combining Treatment segment boundaries
clear SxParameters CombinedProstateBoundary CombinedControlBoundary CombinedProstateBoundaryMM CombinedControlBoundaryMM
load('private\SxParameters-CombineBoundaries.mat')

[CombinedProstateBoundary, CombinedControlBoundary, ~, ~, ~, ~] = CombineBoundaries(SxParameters);
CombinedProstateBoundaryMM = CombinedProstateBoundary.*SxParameters(1).PixelSize(1);
CombinedControlBoundaryMM = CombinedControlBoundary.*SxParameters(1).PixelSize(1);

% Part of TreatedSector in Segment 1 Subsegment 2, not Subsegment 1
assert(CombinedProstateBoundaryMM(310,5) == 39,'Prostate boundary on slice 5 (E4), theta = 309 deg, does not have the expected value of 39 mm')
% Part of TreatedSector in Segment 1 Subsegment 1, not Subsegment 2
assert(CombinedControlBoundaryMM(139,2) == 25, 'Control boundary on slice 2 (E1), theta = 138 deg, does not have the expected value of 25 mm')
% Part of TreatedSector in Segment 1 Subsegment 2, not Subsegment 1
assert(CombinedProstateBoundaryMM(231,6) == SxParameters(1).Combined.ProstateBoundaryMM(231,6),'Prostate boundary on slice 6 (E5), theta = 230 deg, does not have the expected value of 25.01 mm')
% Part of TreatedSector in Segment 1 Subsegment 1, not Subsegment 2
assert(CombinedControlBoundaryMM(57,3) == SxParameters(1).Combined.ControlBoundaryMM(57,3),'Control boundary on slice 3 (E2), theta = 56 deg, does not have the expected value of 14.57 mm')
% Part of TreatedSector in Segment 2 and Segment 1 Subsegment 1
assert(CombinedProstateBoundaryMM(160,7) == SxParameters(2).ProstateBoundaryMM(160,7),'Prostate boundary on slice 7 (E6), theta = 161 deg, does not have the expected value of 40 mm')
% Part of TreatedSector in Segment 1 Subsegment 2, not Segment 2
assert(CombinedControlBoundaryMM(263,8) == SxParameters(1).Combined.ControlBoundaryMM(263,8),'Control boundary on slice 8 (E7), theta = 264 deg, does not have the expected value of 12.55 mm')
