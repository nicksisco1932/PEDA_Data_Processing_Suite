% Initialization
global UnitTestParameters

%% TS-61 - PEDA shall mask low SNRs pixels
% Test data has been created such that pixels (51,44),(90,82), and (52,73)
% have their intensity set to 0 on Magnitude images on dynamic 31, slice 5. These pixels should therefore
% be masked throughout the rest of the treatment

%Open Mask.mat and SxParameters
load(fullfile(UnitTestParameters.SegmentPath,'Masks','Mask.mat'));
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'));

for dynIdx = 31:SxParameters.ImageNumber(end)
    currentMaskSlice2 = Mask(:,:,5,dynIdx);
    assert(currentMaskSlice2(51,44) == 0,sprintf('Intensity masking failed on dyn %d',dynIdx)); %On the image, corresponds to pixel 44,51
    assert(currentMaskSlice2(90,82) == 0,sprintf('Intensity masking failed on dyn %d',dynIdx));
    assert(currentMaskSlice2(52,73) == 0,sprintf('Intensity masking failed on dyn %d',dynIdx));
end

%% TS-64 - PEDA shall offset any pixel greater than 48 mm from the UA Center and whose temperature is greater or equal to Tc-3 (54�C) to a temperature of Tc-4 (53�C) and to a dose of 200 (Distance masking)
% Test data has been created such that pixels (34,39),(92,44), and (75,95)
% are outside a 48-mm radius from the UA center and have a temperature of 64,57,56 respectively (above Tc-3)
% for dynamic 29, slice 6. 
% These pixels should be assigned a temperature of 53�C and a dose of 200 CEM43

%Open NoisyPixels - Slice 6
load(fullfile(UnitTestParameters.SegmentPath,'NoisyPixels.mat'));
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'));
load(fullfile(UnitTestParameters.SegmentPath,'TMaxMasked.mat'));
load(fullfile(UnitTestParameters.SegmentPath,'TDoseMasked.mat'));

%Make sure the matrix is not empty
assert(~isempty(NoisyPixels),'NoisyPixels matrix is empty')

%First, evaluate that pixels have been recognized as noisy
sliceIdx = 6;
assert(any(ismember(NoisyPixels,[34,39,6],'rows')),'Pixel (%d,%d) - Slice %d not present in NoisyPixels.mat (Distance Masking)',34,39,sliceIdx);
assert(any(ismember(NoisyPixels,[92,44,6],'rows')),'Pixel (%d,%d) - Slice %d not present in NoisyPixels.mat (Distance Masking)',92,44,sliceIdx);
assert(any(ismember(NoisyPixels,[75,95,6],'rows')),'Pixel (%d,%d) - Slice %d not present in NoisyPixels.mat (Distance Masking)',75,95,sliceIdx);

%Second, verify that their temperature has been offset to 53�C and to a dose of 200 CEM43 for isotherm generation
assert(isequal(TMaxMasked(34,39,sliceIdx),53),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TMaxMasked (Distance masking)',34,39,sliceIdx,(SxParameters.Tc - 4), TMaxMasked(34,39,sliceIdx));
assert(isequal(TMaxMasked(92,44,sliceIdx),53),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TMaxMasked (Distance masking)',92,44,sliceIdx,(SxParameters.Tc - 4), TMaxMasked(92,44,sliceIdx));
assert(isequal(TMaxMasked(75,95,sliceIdx),53),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TMaxMasked (Distance masking)',75,95,sliceIdx,(SxParameters.Tc - 4), TMaxMasked(75,95,sliceIdx));

assert(isequal(TDoseMasked(34,39,sliceIdx),200),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TDose (Distance masking)',34,39,sliceIdx,200,TDoseMasked(34,39,sliceIdx));
assert(isequal(TDoseMasked(92,44,sliceIdx),200),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TDose (Distance masking)',92,44,sliceIdx,200,TDoseMasked(92,44,sliceIdx));
assert(isequal(TDoseMasked(75,95,sliceIdx),200),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TDose (Distance masking)',75,95,sliceIdx,200,TDoseMasked(75,95,sliceIdx));

%% TS-65 - PEDA shall offset any pixel left after distance masking which is more than 40 degrees apart from the beam direction at its peak temperature to a temperature of Tc-4 (53�C) and to a dose of 200 (Beam Angle Masking)
% Test data has been created such that pixels (46,67),(80,55), and (58,49)
% are between a 48-mm radius and an extended control mask, and a 40� apart from the beam angle
% at their peak temperature on dynamic 29, slice 6. 
% These pixels should be assigned a temperature of 53�C and a dose of 200 CEM43

%Open NoisyPixels - Slice 6
load(fullfile(UnitTestParameters.SegmentPath,'NoisyPixels.mat'));
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'));
load(fullfile(UnitTestParameters.SegmentPath,'TMaxMasked.mat'));
load(fullfile(UnitTestParameters.SegmentPath,'TDoseMasked.mat'));

%First, evaluate pixels which have been recognized as noisy
sliceIdx = 6;
assert(any(ismember(NoisyPixels,[46,67,6],'rows')),'Pixel (%d,%d) - Slice %d not present in NoisyPixels.mat (Beam Masking)',46,67,sliceIdx);
assert(any(ismember(NoisyPixels,[80,55,6],'rows')),'Pixel (%d,%d) - Slice %d not present in NoisyPixels.mat (Beam Masking)',80,55,sliceIdx);
assert(any(ismember(NoisyPixels,[58,49,6],'rows')),'Pixel (%d,%d) - Slice %d not present in NoisyPixels.mat (Beam Masking)',58,49,sliceIdx);

%Second, verify that their temperature has been offset to 53�C and to a dose of 200 CEM43 for isotherm generation
assert(isequal(TMaxMasked(46,67,sliceIdx),53),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TMaxMasked (Beam masking)',46,67,sliceIdx,(SxParameters.Tc - 4),TMaxMasked(46,67,sliceIdx));
assert(isequal(TMaxMasked(80,55,sliceIdx),53),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TMaxMasked (Beam masking)',80,55,sliceIdx,(SxParameters.Tc - 4),TMaxMasked(80,55,sliceIdx));
assert(isequal(TMaxMasked(58,49,sliceIdx),53),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TMaxMasked (Beam masking)',58,49,sliceIdx,(SxParameters.Tc - 4),TMaxMasked(58,49,sliceIdx));

assert(isequal(TDoseMasked(46,67,sliceIdx),200),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TDose (Beam masking)',46,67,sliceIdx,200,TDoseMasked(46,67,sliceIdx));
assert(isequal(TDoseMasked(80,55,sliceIdx),200),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TDose (Beam masking)',80,55,sliceIdx,200,TDoseMasked(80,55,sliceIdx));
assert(isequal(TDoseMasked(58,49,sliceIdx),200),'Pixel (%d,%d) - Slice %d not offset (Expected: %d - Actual: %d) in TDose (Beam masking)',58,49,sliceIdx,200,TDoseMasked(58,49,sliceIdx));

%% TS-172 - PEDA shall never mask pixels contained within the prostate mask (excluding the UA center)

%% TS-182 - PEDA shall mask pixels whose temperature changes by more than 10�C between two dynamics
% Test data has been created such that pixels (51,44),(90,82), and (52,73)
% have a temperature jump of 11, 25, and 30�C respectively on dynamic 27, slice 2. 
% These pixels should therefore be masked throughout the rest of the treatment
%Open Mask.mat and SxParameters
load(fullfile(UnitTestParameters.SegmentPath,'Masks','Mask.mat'));
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters.mat'));

for dynIdx = 27:SxParameters.ImageNumber(end)
    currentMaskSlice2 = Mask(:,:,2,dynIdx);
    assert(currentMaskSlice2(51,44) == 0,sprintf('Temperature masking failed on dyn %d',dynIdx)); %On the image, corresponds to pixel 44,51
    assert(currentMaskSlice2(90,82) == 0,sprintf('Temperature masking failed on dyn %d',dynIdx));
    assert(currentMaskSlice2(52,73) == 0,sprintf('Temperature masking failed on dyn %d',dynIdx));
end

%% TS-289 - PEDA shall count the number of pixels >86degC and >100degC inside the control, excluding the MTR (Hot Pixel Masking)
load(fullfile(UnitTestParameters.PEDAPath,'PEDAOverallResults.mat'));
sliceIdx = 3;

expectedValue = 134;
actualValue = PEDAOverallResults.HotPixels.PixelsApproachingBoiling(3);
assert(isequal(actualValue,expectedValue),'Number of pixels approaching boiling on slice %d is incorrect (Expected: %d - Actual: %d)',sliceIdx, expectedValue, actualValue);

expectedValue = 0;
actualValue = PEDAOverallResults.HotPixels.PixelsAboveBoiling(3);
assert(isequal(actualValue,expectedValue),'Number of boiling pixels on slice %d is incorrect (Expected: %d - Actual: %d)',sliceIdx, expectedValue, actualValue);
