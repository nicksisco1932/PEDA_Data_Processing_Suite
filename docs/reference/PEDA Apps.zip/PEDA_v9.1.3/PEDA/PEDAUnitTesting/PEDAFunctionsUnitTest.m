tol = 10^-5;
% ==========================================================================
% ----- Function UnwindAngle  -----
% ==========================================================================
%%% DEFINITIONS
% CCW is increasing angle
% CW is decreasing angle
%% UnwindAngleUT : Angle unwrap going CCW
expectedUnwoundAngle = 0:0.5:1000;
SimulatedAngleData = wrapTo360(expectedUnwoundAngle);
UnwoundSimulatedAngleData = UnwindAngle(SimulatedAngleData);

assert(all(abs(expectedUnwoundAngle-UnwoundSimulatedAngleData) < tol),'Angle unwrap going CCW test failed')

%% UnwindAngleUT - Angle unwrap going CW
expectedUnwoundAngle = -(0:0.5:1000);
SimulatedAngleData = wrapTo360(expectedUnwoundAngle);
UnwoundSimulatedAngleData = UnwindAngle(SimulatedAngleData);

assert(all(abs(expectedUnwoundAngle-UnwoundSimulatedAngleData) < tol),'Angle unwrap going CW test failed')

%% UnwindAngleUT - Angle unwrap going CW then CCW
expectedUnwoundAngle = [20:0.5:750 repmat(750,1,20) 750:-0.5:420];

SimulatedAngleData = wrapTo360(expectedUnwoundAngle);
UnwoundSimulatedAngleData = UnwindAngle(SimulatedAngleData);

assert(all(abs(expectedUnwoundAngle-UnwoundSimulatedAngleData) < tol),'Angle unwrap going CW then CCW test failed')

%% UnwindAngleUT - Angle unwrap going CCW then CW
expectedUnwoundAngle = -[20:0.5:750 repmat(750,1,20) 750:-0.5:420] + 360;

SimulatedAngleData = wrapTo360(expectedUnwoundAngle);
UnwoundSimulatedAngleData = UnwindAngle(SimulatedAngleData);

assert(all(abs(expectedUnwoundAngle-UnwoundSimulatedAngleData) < tol),'Angle unwrap going CCW then CW test failed')

% ==========================================================================
% ----- Function GetTreatedSector  -----
% ==========================================================================
%% GetTreatedSectorUT - Sector CCW, no wrap
ThermalAngle = 20:0.1:300;
SimulatedAngleData = wrapTo360(ThermalAngle);
TreatedSector = GetTreatedSector(SimulatedAngleData);
ExpectedResult = (20:300);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector CCW, no wrap failed')

%% GetTreatedSectorUT - Sector CW, no wrap
ThermalAngle = 350:-0.1:200;
SimulatedAngleData = wrapTo360(ThermalAngle);
TreatedSector = GetTreatedSector(SimulatedAngleData);
ExpectedResult = (200:350);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector CW, no wrap failed')

%% GetTreatedSectorUT - Sector CCW, wrap
ThermalAngle = [300:0.1:360 0.5:0.2:100];
SimulatedAngleData = wrapTo360(ThermalAngle);
TreatedSector = GetTreatedSector(SimulatedAngleData);
ExpectedResult = ([300:359 0:100]);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector CCW, wrap failed')

%% GetTreatedSectorUT - Sector CW, wrap
ThermalAngle = [200:-0.2:0 360:-0.5:300];
SimulatedAngleData = wrapTo360(ThermalAngle);
TreatedSector = GetTreatedSector(SimulatedAngleData);
ExpectedResult = ([300:359 0:200]);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector CW, wrap failed')

%% GetTreatedSectorUT - Sector CW (greater) then sector CCW , no wrap
sectorCW = 350:-0.2:50;
sectorCCW = [51:1:90 91:0.2:115];
ThermalAngle = [sectorCW sectorCCW];
SimulatedAngleData = wrapTo360(ThermalAngle);
TreatedSector = GetTreatedSector(SimulatedAngleData);
ExpectedResult = (50:350);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector CW (greater) then sector CCW, no wrap failed')

%% GetTreatedSectorUT - Sector CW then sector CCW (greater), no wrap
sectorCW = 80:-0.2:50;
sectorCCW = [49:1:90 91:0.2:320];
ThermalAngle = [sectorCW sectorCCW];
SimulatedAngleData = wrapTo360(ThermalAngle);
TreatedSector = GetTreatedSector(SimulatedAngleData);

ExpectedResult = (49:320);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector CW then sector CCW (greater), no wrap failed')

%% GetTreatedSectorUT - Sector CW with wrap, then sector CCW (greater)
sectorCW = 10:-0.2:-10;
sectorCCW = [-10:0.2:20];
ThermalAngle = [sectorCW sectorCCW];
SimulatedAngleData = wrapTo360(ThermalAngle);
TreatedSector = GetTreatedSector(SimulatedAngleData);

ExpectedResult = ([350:359 0:20]);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector CW with wrap, then sector CCW (greater) failed')


%% GetTreatedSector - Patient 002-111 data
load('private\TxParameters-002-111.mat')
SimulatedAngleData = TxParameters.ThermAngle;
TreatedSector = GetTreatedSector(SimulatedAngleData);

ExpectedResult = TxParameters.TreatedSector;

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector patient 002-111 data failed')

%% GetTreatedSector - Patient 005-102-S2 data
load('private\SxParameters-005-102.mat')
SimulatedAngleData = SxParameters(2).ThermAngle;
TreatedSector = GetTreatedSector(SimulatedAngleData);

ExpectedResult = wrapTo360([165:359 0:46]);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector patient 005-102-S2 data failed')

%% GetTreatedSector - Patient 005-112-S1 data
load('private\SxParameters-005-112.mat')
SimulatedAngleData = SxParameters(1).ThermAngle;
TreatedSector = GetTreatedSector(SimulatedAngleData);

ExpectedResult = wrapTo360([339:359 0:220]);

assert(all(abs(TreatedSector - ExpectedResult) < tol),'Treated sector patient 005-112-S1 data failed')

%% CalculateSectorMask
% ==========================================================================
% ----- Function CalculateSectorMask  -----
% ==========================================================================
% Test created based on bug TS-194, where the function crashed if theta_i is exactly 0
ThermAngle = 1:150;
FanAngle = 15;
ux0 = repmat(64,1,12);
uy0 = repmat(64,1,12);
isUAactive = ones(12,1);
MTRmm = 8;
DilateFactorMM = 2;
ProstateBoundary = 10*ones(360,12);
PixelSize = 2;
NumSlices = 12;
NumRows = 128;
NumCols = 128;
TUVMask = ones(NumCols,NumRows,NumSlices);

errorCalculatingSectorMask = 0;

for dynIdx = 1:length(ThermAngle)
    try
    SectorMask = subCalculateSectorMask(ThermAngle(dynIdx), FanAngle, ux0, uy0, isUAactive, MTRmm, DilateFactorMM, ProstateBoundary, PixelSize, NumSlices, NumRows, NumCols, TUVMask);
    catch
        errorCalculatingSectorMask = 1;
    end
end

assert(errorCalculatingSectorMask == 0,'Error when testing sector mask generation');

%% TS-232 - PEDA shall calculate power errors during treatment.  It shall report a failure if the power error on any active element does not lie within the range of -30% to 50%, for 99% of the treatment time when requesting power
tol = 10^-5;
load('private\HardwareInfo-PowerDeviations.mat')

LOWERBOUND_PERCENT_POWER_DEVIATION = -30;
UPPERBOUND_PERCENT_POWER_DEVIATION = 50;
MINIMUM_NUMBER_SAMPLES = 100;
[~, ~, ~, ~, ~, NumberOfSamplesPerElement, PercentPowerWithinSpec] = AnalyzePowerDeviations(HardwareInfo,LOWERBOUND_PERCENT_POWER_DEVIATION,UPPERBOUND_PERCENT_POWER_DEVIATION);

MeetsMinimumNumberOfSamples = NumberOfSamplesPerElement > MINIMUM_NUMBER_SAMPLES;

ExpectedResult = [100 100 99 100 100];
assert(all(abs(PercentPowerWithinSpec(MeetsMinimumNumberOfSamples) - ExpectedResult(MeetsMinimumNumberOfSamples)) < tol),'Power deviation statistics has failed.  Expected E3 with 99% of measurements within -30% to +50%')

%% TS-233 - PEDA shall calculate the time between MRI acquisition and TULSA-PRO hardware states updated by the treatment controller.  It shall report a failure if it is not ≤8 seconds for 99% of the treatment time
tol = 10^-5;
load('private\TreatmentControllerData-MRIDelayStatistics.mat')

[~, maxTCD_AcquisitionStartToHWUpdateSEC_99]  = AnalyzeMRIDelayStatistics(TreatmentControllerData);

ExpectedResult = 8.5;
assert(all(abs(maxTCD_AcquisitionStartToHWUpdateSEC_99 - ExpectedResult) < tol),'MRI Delay Statistics has failed.  Expected worst delay of 8.5 sec')


%% TS-278a - PEDA shall calculate the area DSC
% Input the same isotherm and target boundary and the DSC output should be 1 (i.e. perfect match)
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = targetBoundary;
prostateBoundary = targetBoundary + 2;
margin = 0;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

ExpectedResult = 1;
for sliceIdx = 1:12
    if isUAactive(sliceIdx)
        assert(all(abs(errorStatistics.DSCarea(sliceIdx) - ExpectedResult) < tol),'DSC area has failed when target and isotherm were equal.  Expected DSC area = 1 on all slices.')
    end
end

%% TS-278b - PEDA shall calculate the area DSC
% Input a target boundary and zero matrix for isotherms and the DSC output should be 0 (i.e. no overlap)
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = zeros(360,12);
prostateBoundary = targetBoundary + 2;
margin = 0;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

ExpectedResult = 0;

for sliceIdx = 1:12
    if isUAactive(sliceIdx)
        assert(all(abs(errorStatistics.DSCarea(sliceIdx) - ExpectedResult) < tol),'DSC area has failed when there was no overlap between target and isotherm.  Expected DSC area = 0 on all slices.')
    end
end

%% TS-278c - PEDA shall calculate the area DSC
% Input a circular target boundary with radius 20 mm and circular isotherms with radius 19 mm and the DSC output should be 0.95 (i.e. undertreatment by 1 mm)
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = zeros(360,12);
isothermRadius(:,2:11) = 19; % isotherm reached 19 mm on all 10 boundaries
prostateBoundary = targetBoundary + 2;
margin = 0;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

ExpectedResult = 2*pi*19^2./(pi*19^2 + pi*20^2);

for sliceIdx = 1:12
    if isUAactive(sliceIdx)
        assert(all(abs(errorStatistics.DSCarea(sliceIdx) - ExpectedResult) < tol),sprintf('DSC area has failed when target boundary was circle (r = 20mm) and isotherm was circle (r = 19mm).  Expected DSC of %1.5f', ExpectedResult))
    end
end

%% TS-279a - PEDA shall calculate the volume DSC
% Input the same isotherm and target boundary and the DSC output should be 1 (i.e. perfect match)
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = targetBoundary;
prostateBoundary = targetBoundary + 2;
margin = 0;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

ExpectedResult = 1;

assert(all(abs(errorStatistics.DSCvol - ExpectedResult) < tol),'DSC volume has failed when target and isotherm were equal.  Expected DSC volume of 1.')


%% TS-279b - PEDA shall calculate the volume DSC
% Input a target boundary and zero matrix for isotherms and the DSC output should be 0 (i.e. no overlap)
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = zeros(360,12);
prostateBoundary = targetBoundary + 2;
margin = 0;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

ExpectedResult = 0;

assert(all(abs(errorStatistics.DSCvol - ExpectedResult) < tol),'DSC volume has failed when there was no overlap between target and isotherm. Expected DSC volume of 0.')


%% TS-279c - PEDA shall calculate the volume DSC
% Input a circular target boundary with radius 20 mm and circular isotherms with radius 19 mm and the DSC output should be 0.95 (i.e. undertreatment by 1 mm)
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = zeros(360,12);
isothermRadius(:,2:11) = 19; % isotherm reached 19 mm on all 10 boundaries
prostateBoundary = targetBoundary + 2;
margin = 0;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

ExpectedResult = 2*pi*19^2./(pi*19^2 + pi*20^2);

assert(all(abs(errorStatistics.DSCvol - ExpectedResult) < tol),sprintf('DSC area has failed when target boundary was circle (r = 20mm) and isotherm was circle (r = 19mm).  Expected DSC of %1.5f', ExpectedResult))

%% TS-280a - PEDA shall calculate overtreatment when isotherm is greater than margin of half pixel
% Input a circular target boundary with radius 20 mm and circular isotherms with radius 21 mm and the overshoot volume with a 1 mm margin should be 0%
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = zeros(360,12);
isothermRadius(:,2:11) = 21; % isotherm reached 21 mm on all 10 boundaries
prostateBoundary = targetBoundary + 2;
margin = 1;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

ExpectedResult = 0;

assert(all(abs(errorStatistics.OSVolumePercent - ExpectedResult) < tol),'Overshoot volume has failed when the isotherm was 1 mm greater than the target.  Expected Overshoot Volume Percent with a 1 mm margin of 0')

%% TS-280b - PEDA shall calculate overtreatment when isotherm is greater than margin of half pixel
% Input a circular target boundary with radius 20 mm and circular isotherms with radius 21.5 mm and the overshoot volume with a 1 mm margin should be 5.31250%
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = zeros(360,12);
isothermRadius(:,2:11) = 21.5; % isotherm reached 21.5 mm on all 10 boundaries
prostateBoundary = targetBoundary + 2;
margin = 1;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

% Target volume (r = 20mm) and Isotherm (r = 21.5mm) are cylinders. Target
% volume with 1 mm margin is a cylinder with r = 21 mm.  Overtreatment is
% therefore an annulus between r = 21 to 22mm.

OvertreatmentVolumeWith1mmMargin = (pi*21.5^2 - pi*21^2)*SliceThickness*sum(isUAactive);
ExpectedResult = OvertreatmentVolumeWith1mmMargin./(pi*20^2*SliceThickness*sum(isUAactive))*100;

assert(all(abs(errorStatistics.OSVolumePercent - ExpectedResult) < tol),sprintf('Overshoot volume has failed when the isotherm was 1.5 mm greater than the target.  Expected Overshoot Volume Percent with a 1 mm margin of %1.5f', ExpectedResult))

%% TS-281a - PEDA shall calculate undertreatment when isotherm is less than margin of half pixel
% Input a circular target boundary with radius 20 mm and circular isotherms with radius 19 mm and the overshoot volume with a 1 mm margin should be 0%
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = zeros(360,12);
isothermRadius(:,2:11) = 19; % isotherm reached 19 mm on all 10 boundaries
prostateBoundary = targetBoundary + 2;
margin = 1;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

ExpectedResult = 0;

assert(all(abs(errorStatistics.USVolumePercent - ExpectedResult) < tol),'Undershoot volume has failed when the isotherm was 1 mm less than the target.  Expected Undershoot Volume Percent with a 1 mm margin of 0')

%% TS-281b - PEDA shall calculate undertreatment when isotherm is less than margin of half pixel
targetBoundary = zeros(360,12);
targetBoundary(:,2:11) = 20; % 10 active boundaries with circle of radius 20 mm
isothermRadius = zeros(360,12);
isothermRadius(:,2:11) = 18.5; % isotherm reached 18.5 mm on all 10 boundaries
prostateBoundary = targetBoundary + 2;
margin = 1;
MinTR = 8;
MaxTR = 28;
SliceThickness = 5;
isUAactive = logical([0 1 1 1 1 1 1 1 1 1 1 0]);
treatedSector = 0:359;

errorStatistics = CalculateErrors(isothermRadius,targetBoundary,prostateBoundary,margin,MinTR,MaxTR,SliceThickness,isUAactive,treatedSector);

% Target volume (r = 20mm) and Isotherm (r = 18.5mm) are cylinders. Target
% volume with 1 mm margin is a cylinder with r = 19 mm.  Overtreatment is
% therefore an annulus between r = 18.5 to 19mm.

UndertreatmentVolumeWith1mmMargin = (pi*19^2 - pi*18.5^2)*SliceThickness*sum(isUAactive);
ExpectedResult = UndertreatmentVolumeWith1mmMargin./(pi*20^2*SliceThickness*sum(isUAactive))*100;

assert(all(abs(errorStatistics.USVolumePercent - ExpectedResult) < tol),sprintf('Undershoot volume has failed when the isotherm was 1.5 mm less than the target.  Expected Undershoot Volume Percent with a 1 mm margin of %1.5f', ExpectedResult))

%% TS-285 - PEDA shall generate the 240 CEM43 isotherm for each active slice on its corresponding thermal dose images
tol = 0.3;
load('private\MaskAnnulusRadius_21_to_27MM.mat')

TDose = zeros(128,128);
TDose(MaskAnnulusRadius_21_to_27MM) = 240;
ux = 64.5;
uy = 64.5;
PixelSize = 2;
ProstateBoundary = ones(360,1).*26/2;
ControlBoundary = ones(360,1).*24/2;
TreatedSector = 0:359;
AdditionalRadiusMM = 7;
UARadius = 2;

isothermRadius240CEM43 = CalculateIsotherm(TDose, ux, uy, PixelSize, ProstateBoundary, TreatedSector, 240, 3, ControlBoundary, AdditionalRadiusMM, UARadius);

ExpectedResult = ones(360,1).*24;
assert(all(abs(isothermRadius240CEM43 - ExpectedResult) < tol),'Isotherm calculation on TDose image of constant 240 CEM43 at r=24 has failed.  Expected 240 CEM43 isotherm of constant radius 24 mm')

%% TS-286 - PEDA shall compute the 55°C isotherm for each active slice on its corresponding maximum temperature image.
load('private\MaskAnnulusRadius_21_to_27MM.mat')
tol = 0.3;
TMax = zeros(128,128);
TMax(MaskAnnulusRadius_21_to_27MM) = 55;
ux = 64.5;
uy = 64.5;
PixelSize = 2;
ProstateBoundary = ones(360,1).*26/2;
ControlBoundary = ones(360,1).*24/2;
TreatedSector = 0:359;
AdditionalRadiusMM = 7;
UARadius = 2;

isothermRadius55degC = CalculateIsotherm(TMax, ux, uy, PixelSize, ProstateBoundary, TreatedSector, 55, 3, ControlBoundary, AdditionalRadiusMM, UARadius);

ExpectedResult = ones(360,1).*24;
assert(all(abs(isothermRadius55degC - ExpectedResult) < tol),'Overshoot volume has failed when target and isotherm were equal.  Expected Overshoot Volume Percent with a 1 mm margin of 0')