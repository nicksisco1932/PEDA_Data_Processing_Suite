% Initialization
global UnitTestParameters
%% TS-78 - PEDA folder shall contain PEDA version number 
strIndex = strfind(UnitTestParameters.PEDAPath,'PEDA');
PEDAVersionFolderName = UnitTestParameters.PEDAPath(strIndex(end)+length('PEDA'):end);
assert(~isempty(strfind(PEDAVersionFolderName,UnitTestParameters.PEDAVersion)),'PEDA version number not found in folder name');

%% TS-152 - PEDA shall only be run with 64-bit MATLAB version 2017a or above
assert(~isempty(strfind(computer,'64')))
assert(~verLessThan('matlab','9.2'))
