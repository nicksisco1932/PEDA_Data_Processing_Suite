% Initialization
global UnitTestParameters
tol = 10^-5;

%% TS-115 - PEDA shall generate combined mask from pixels that have been masked in all segments 
MaskS1 = cell2mat(struct2cell(load(fullfile(UnitTestParameters.PEDAPath,'Segment 1\Masks\Mask'))));
MaskS2 = cell2mat(struct2cell(load(fullfile(UnitTestParameters.PEDAPath,'Segment 2\Masks\Mask'))));
MaskCombined = cell2mat(struct2cell(load(fullfile(UnitTestParameters.PEDAPath,'Mask'))));

% We need to account for shift between segments. 
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters'))

maskedPixelsS1 = MaskS1(:,:,:,end-1);

% We map ux, uy to last dyn of segment 1
dux = SxParameters(2).ux(end,:) - SxParameters(1).ux(end,:);
duy = SxParameters(2).uy(end,:) - SxParameters(1).uy(end,:);
for sliceIdx = 1:12
    shiftedMaskS2(:,:,sliceIdx) = circshift(MaskS2(:,:,sliceIdx,end-1),[-duy(sliceIdx) -dux(sliceIdx)]);
end

conditionUnderTest = (maskedPixelsS1 | shiftedMaskS2) == MaskCombined;
assert(all(conditionUnderTest(:)),'Combined mask is not equal to the logical OR of each segmental mask');

%% TS-116 - PEDA shall combine TDose and TMax by taking the sum of each segment dose and the maximum of each segment temperature respectively 
% TMap - Specific pixels of TMap and TDose have been altered.
load(fullfile(UnitTestParameters.PEDAPath,'TMax'))
% Pixels modified in S1 - No need to account for shift
assert(TMax(60,60,4) == 110,'TMax at pixel 60,60 on slice 4 incorrect (expected: 110)');
assert(TMax(63,58,4) == 103,'TMax at pixel 63,58 on slice 4 incorrect (expected: 103)');

% Pixels modified in S2 - Need to account for shift
load(fullfile(UnitTestParameters.PEDAPath,'SxParameters'))
dux = SxParameters(2).ux(end,:) - SxParameters(1).ux(end,:);
duy = SxParameters(2).uy(end,:) - SxParameters(1).uy(end,:);
pixel1ToTest = [60,71] - [duy(4),dux(4)];
pixel2ToTest = [66,73] - [duy(4),dux(4)];

assert(TMax(pixel1ToTest(1),pixel1ToTest(2),4) == 150,'TMax at pixel 60,71 on slice 4 incorrect (expected: 150)');
assert(abs(TMax(pixel2ToTest(1),pixel2ToTest(2),4) - 120.2) < tol,'TMax at pixel 66,73 on slice 4 incorrect (expected: 120.2)');

% TDose
TDoseS1 = cell2mat(struct2cell(load(fullfile(UnitTestParameters.PEDAPath,'Segment 1\TDose'))));
TDoseS2 = cell2mat(struct2cell(load(fullfile(UnitTestParameters.PEDAPath,'Segment 2\TDose'))));
TDoseCombined = cell2mat(struct2cell(load(fullfile(UnitTestParameters.PEDAPath,'TDose'))));

for sliceIdx = 1:12
    shiftedTDoseS2(:,:,sliceIdx) = circshift(TDoseS2(:,:,sliceIdx),[-duy(sliceIdx) -dux(sliceIdx)]);
end

conditionUnderTest = (TDoseS1 + shiftedTDoseS2) == TDoseCombined;
assert(all(conditionUnderTest(:)),'Combined TDose is not equal to the sum of segment TDose');

%% TS-188 - PEDA shall combine segmental boundaries by taking the maximum radius at each 1�-increment for treated sectors only
% PROSTATE
% Segment 1 - Slice 5 - Theta = 0deg - Radius changed to 40
% Segment 1 - Slice 5 - Theta = 359deg - Radius changed to 5
% CONTROL
% Segment 1 - Slice 2 - Theta = 0deg - Radius changed to 39.1
% Segment 1 - Slice 5 - Theta = 237deg - Radius changed to 36

% PROSTATE
% Segment 2 - Slice 2 - Theta = 74deg - Radius changed to 37
% Segment 2 - Slice 6 - Theta = 271deg - Radius changed to 39
% CONTROL
% Segment 2 - Slice 1 - Theta = 301deg - Radius changed to 37
% Segment 2 - Slice 2 - Theta = 82deg - Radius changed fto 40

% TreatmentControllerData.txt values of ControlAngle were manually changed.
% Because PEDA detects angle jump (from 360 to 0) by looking at jumps > 349�, we have to make sure to switch from 359� to 0� in the
% text file (i.e. you can't simply write 338 and then 13, but rather have 338 - 359 - 0 - 13)
% SEGMENT 1 - TREATED SECTOR = 338� -> 13�
% SEGMENT 2 - TREATED SECTOR = 15� -> 46�

load(fullfile(UnitTestParameters.PEDAPath,'TxParameters'))

% Was treated
assert(TxParameters.ProstateBoundaryMM(1,6) == 40,'Prostate boundary on slice 5, theta = 0 deg, does not have the expected value of 40')
assert(TxParameters.ProstateBoundaryMM(360,6) == 5,'Prostate boundary on slice 6, theta = 360 deg, does not have the expected value of 5')
assert(TxParameters.ControlBoundaryMM(1,2) == 39.1,'Prostate boundary on slice 2, theta = 0 deg, does not have the expected value of 39.1')

% Was not treated thus collapsed to MTR
assert(TxParameters.ProstateBoundaryMM(75,3) == 7,'Prostate boundary on slice 2, theta = 74 deg, does not have the expected value of 7')
assert(TxParameters.ProstateBoundaryMM(272,7) == 7,'Prostate boundary on slice 7, theta = 271 deg, does not have the expected value of 7')
assert(TxParameters.ControlBoundaryMM(238,6) == 5,'Prostate boundary on slice 5, theta = 237 deg, does not have the expected value of 5')
assert(TxParameters.ControlBoundaryMM(302,2) == 5,'Prostate boundary on slice 9, theta = 301 deg, does not have the expected value of 5')
assert(TxParameters.ControlBoundaryMM(83,3) == 5,'Prostate boundary on slice 10, theta = 82 deg, does not have the expected value of 5')