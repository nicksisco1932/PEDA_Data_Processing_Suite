%==========================================================================
% ----- Variable initialization -----
%==========================================================================
clear all
clc
diary off
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Replace these strings before running the test
PEDA_VERSION_UNDER_TEST = 'v9.1.3';
PATH_TO_UNIT_TEST_DATA = 'C:\Users\BColes\Local_Temp\_CO\CO-07049 - PEDA\PEDAUnitTestCases_v9.1.3';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PATH_TO_PEDA_FILES = fileparts(fileparts(mfilename('fullpath')));
if isempty(PATH_TO_PEDA_FILES) || isempty(PATH_TO_UNIT_TEST_DATA)
    error('Make sure you properly set the fields PATH_TO_PEDA_FILES and PATH_TO_UNIT_TEST_DATA in performPEDATesting.m before starting')
end
PATH_TO_UNIT_TEST_RESULTS = fullfile(PATH_TO_UNIT_TEST_DATA,'PEDATestingResults');

addpath(PATH_TO_PEDA_FILES);

% Create output folder
if ~exist(PATH_TO_UNIT_TEST_RESULTS)
    mkdir(PATH_TO_UNIT_TEST_RESULTS);
else
    rmdir(PATH_TO_UNIT_TEST_RESULTS,'s')
    mkdir(PATH_TO_UNIT_TEST_RESULTS);
end

% UnitTests outputs are not very thorough so we will save the command window
CommandWindowFilename = sprintf('PEDA%s_CommandWindowTestResults.txt',PEDA_VERSION_UNDER_TEST);
diary(fullfile(PATH_TO_UNIT_TEST_RESULTS,CommandWindowFilename));

% For the future, try to understand how to pass arguments during unit testing
global UnitTestParameters
UnitTestParameters.UnitTestModifiedDataSetPath = PATH_TO_UNIT_TEST_DATA;
UnitTestParameters.ModifiedGelDataSetPath = fullfile(PATH_TO_UNIT_TEST_DATA,'\ModifiedDataSet\GelTest');
UnitTestParameters.ModifiedTwoSegmentDataSetPath = fullfile(PATH_TO_UNIT_TEST_DATA,'\ModifiedDataSet\TwoSegments');
UnitTestParameters.ModifiedImageShiftDataSetPath = fullfile(PATH_TO_UNIT_TEST_DATA,'\ModifiedDataSet\ImageShiftedData');
UnitTestParameters.MultipleSSDataSetPath = fullfile(PATH_TO_UNIT_TEST_DATA,'\ModifiedDataSet\MultiSubSegment');
UnitTestParameters.FirstElementNotE1PEDAPath = fullfile(PATH_TO_UNIT_TEST_DATA,'\ModifiedDataSet\FirstElementNotE1');
UnitTestParameters.OriginalDataSetPath = fullfile(PATH_TO_UNIT_TEST_DATA,'\OriginalDataSet');
UnitTestParameters.RawFolderAndThermalBoostPEDAPath = fullfile(PATH_TO_UNIT_TEST_DATA, '\ModifiedDataSet\RawFoldersAndThermalBoost');
UnitTestParameters.GEAndTDCv211PEDAPath = fullfile(PATH_TO_UNIT_TEST_DATA,'\ModifiedDataSet\GEAndTDCv2.11');
UnitTestParameters.TDCv212PEDAPath = fullfile(PATH_TO_UNIT_TEST_DATA,'\ModifiedDataSet\UApAndTDC2.12');
UnitTestParameters.PEDAVersion = PEDA_VERSION_UNDER_TEST;

% Make sure the version under test is correct
fid = fopen(fullfile(PATH_TO_PEDA_FILES,'MAIN_PEDA.m'),'r');
tempParse = textscan(fid,'%s','delimiter','\n');
tempParse = regexp(tempParse{1,1},'(?<=PEDA_VERSION = '')(.*)(?='';)','match');
currentPEDAversion = cell2mat(tempParse{find(~cellfun(@isempty,tempParse))});

assert(strcmp(currentPEDAversion,UnitTestParameters.PEDAVersion),'Incorrect PEDA version to test (Current: %s; Expected: %s)',currentPEDAversion,PEDA_VERSION_UNDER_TEST)

%==========================================================================
% ----- PEDA Unit Testing and Functional Testing -----
%==========================================================================
run('PEDAUnitTesting.m')

diary off