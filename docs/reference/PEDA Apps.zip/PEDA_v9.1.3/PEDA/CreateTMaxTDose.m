function [TMap, Anatomy, MaxTemperatureTime, Mask, TUV, TUVMag] = CreateTMaxTDose(TxParameters)
%======================================
% function createTMaxTDose
%
% Purpose:
% ========
% Load and create appropriate data for analysis
%==========================================================================

%==========================================================================
% Raw Data folder Parse - TDC 2.10 Updates
%==========================================================================
SWVersion = cell2mat(textscan(strrep(TxParameters.SoftwareVersion,'.',' '),'%d'));
if SWVersion(1) >= 2 && SWVersion(2) >= 10
    ParseRawDataFolder(fileparts(TxParameters.pathSessionFiles));
end 

%==========================================================================
% Load or generate appropriate matrices
%==========================================================================
TMap = LoadMatrix('TMap', TxParameters);
LoadMatrix('Magnitude & Phase', TxParameters);
TUV = LoadMatrix('TUV', TxParameters);
TUVMag = LoadMatrix('TUVMag', TxParameters);
Anatomy = LoadMatrix('Anatomy', TxParameters); 

%==========================================================================
% Generate masks
%==========================================================================
fprintf('Mask... ');
if exist(fullfile(TxParameters.pathData,'Masks','Mask.mat'))
    load(fullfile(TxParameters.pathData,'Masks','Mask.mat'));
else
    mkdir(fullfile(TxParameters.pathData,'Masks'));
    Mask = CalculateDynamicMasks(TxParameters, Anatomy, TMap);
end

%==========================================================================
% Variable initialization
%==========================================================================
[NRows, NCols, NSlices,~] = size(TMap);
TDose =       zeros(NRows,NCols,NSlices);
TDoseMasked = zeros(NRows,NCols,NSlices);
MaxTemperatureTime = TMap(:,:,:,1:TxParameters.NumRefImages);

% Pre-compute for image shift
shiftUX = round(TxParameters.ux - TxParameters.ux(1,:)); % Only apply whole pixel shift
shiftUY = round(TxParameters.uy - TxParameters.uy(1,:)); % Only apply whole pixel shift
diffNumPixelShiftsX = [shiftUX(1,:);diff(shiftUX)]; % Matrix with 1s on the first dyn of a shift. 0 all other dynamics
diffNumPixelShiftsY = [shiftUY(1,:);diff(shiftUY)]; % Matrix with 1s on the first dyn of a shift. 0 all other dynamics

% Pre-compute for TDose
deltaTime = [TxParameters.ImageTime(1);diff(TxParameters.ImageTime)]./60;

%==========================================================================
% Generate TDose, MaxTemperatureTime
%==========================================================================
fprintf('TDose...    ')
%%
for sliceIdx = 1:TxParameters.NumberSlices
    arrTDose = zeros(NRows, NCols);
    arrTDoseMasked = zeros(NRows, NCols);

    for dynIdx = 1:TxParameters.ImageNumber(end)
        offsetDynIdx        = dynIdx-TxParameters.ImageNumber(1)+1;
        currentTMap         = TMap(:,:,sliceIdx,dynIdx);
        currentTMapMasked   = currentTMap.*Mask(:,:,sliceIdx,dynIdx);
        
        %==========================================================================
        % MaxTemperatureTime
        %==========================================================================
        if dynIdx >= TxParameters.NumRefImages
            if dynIdx < TxParameters.ImageNumber(1)
                MaxTemperatureTime(:,:,sliceIdx,dynIdx) = max(MaxTemperatureTime(:,:,sliceIdx,dynIdx-1),currentTMap);
            else
                if diffNumPixelShiftsX(offsetDynIdx, sliceIdx) || diffNumPixelShiftsY(offsetDynIdx, sliceIdx)
                    % TS-208
                    singleShiftedDyn = circshift(circshift(MaxTemperatureTime(:,:,sliceIdx,dynIdx-1),diffNumPixelShiftsY(offsetDynIdx, sliceIdx),1),diffNumPixelShiftsX(offsetDynIdx, sliceIdx),2);
                    MaxTemperatureTime(:,:,sliceIdx,dynIdx) = max(singleShiftedDyn,currentTMap);
                else
                    MaxTemperatureTime(:,:,sliceIdx,dynIdx) = max(MaxTemperatureTime(:,:,sliceIdx,dynIdx-1),currentTMap);
                end
                
                %==========================================================================
                % TDose
                %==========================================================================
                ind_43 =            currentTMap >= TxParameters.ThermalDoseThreshold;
                ind_rest =          currentTMap < TxParameters.ThermalDoseThreshold;
                ind_43_masked =     currentTMapMasked >= TxParameters.ThermalDoseThreshold;
                ind_rest_masked =   currentTMapMasked < TxParameters.ThermalDoseThreshold;
                
                arrTDose(ind_43) =                  arrTDose(ind_43) + (0.5 .^(TxParameters.ThermalDoseThreshold - currentTMap(ind_43))) * deltaTime(offsetDynIdx);
                arrTDose(ind_rest) =                arrTDose(ind_rest) + (0.25 .^(TxParameters.ThermalDoseThreshold - currentTMap(ind_rest))) * deltaTime(offsetDynIdx);
                arrTDoseMasked(ind_43_masked) =     arrTDoseMasked(ind_43_masked) + (0.5 .^(TxParameters.ThermalDoseThreshold - currentTMapMasked(ind_43_masked))) * deltaTime(offsetDynIdx);
                arrTDoseMasked(ind_rest_masked) =   arrTDoseMasked(ind_rest_masked) + (0.25 .^(TxParameters.ThermalDoseThreshold - currentTMapMasked(ind_rest_masked))) * deltaTime(offsetDynIdx);
            end
        else
        end
    end
    TDose(:,:,sliceIdx) = arrTDose;
    TDoseMasked(:,:,sliceIdx) = arrTDoseMasked;
    
    % Update display
    progressPercentage = min(round(sliceIdx/12*100),100);
    backspaceChars = repmat('\b',1,length(num2str(progressPercentage))+1);
    fprintf([backspaceChars '%d%%'],progressPercentage);
end
%%
%==========================================================================
% Generate TMax & TMaxMasked
%==========================================================================
TMax       = MaxTemperatureTime(:,:,:,end);
TMaxMasked = MaxTemperatureTime(:,:,:,end).*Mask(:,:,:,end);

%==========================================================================
% Save everything
%==========================================================================
fprintf(backspaceChars);
fprintf(' Saving... ')
save(fullfile(TxParameters.pathData,filesep,'TMax.mat'),'TMax');
save(fullfile(TxParameters.pathData,filesep,'TMaxMasked.mat'),'TMaxMasked');
save(fullfile(TxParameters.pathData,filesep,'TDose.mat'),'TDose');
save(fullfile(TxParameters.pathData,filesep,'TDoseMasked.mat'),'TDoseMasked');
fprintf('\b\b\b\b\b\b\b\b\b\b');
fprintf('MaxTempTime... Saving...')
save(fullfile(TxParameters.pathData,filesep,'MaxTemperatureTime.mat'),'MaxTemperatureTime');
fprintf('\b\b\b\b\b\b\b\b\b\b\n');
end

%==========================================================================
% Nested function which loads data
%==========================================================================
function outputMatrix = LoadMatrix(type, TxParameters)
pathSegment = TxParameters.pathSessionFiles;
pathPEDASegment = TxParameters.pathData;

fprintf('%s... ',type);
if exist(fullfile(pathPEDASegment,[type '.mat']))
    fprintf('Loading...')
    outputMatrix = load(fullfile(pathPEDASegment,[type '.mat']));
    outputMatrix = outputMatrix.(type);
elseif strcmp(type,'Magnitude & Phase') && exist(fullfile(pathPEDASegment,'Magnitude.mat')) && exist(fullfile(pathPEDASegment,'Phase.mat'))
    return
else
    % Assign filters
    switch type
        case 'TMap'
            fileFilter = 'Thermometry\*Current*';
        case 'TUV'
            fileFilter = 'TUV\*Uncertainty*';
        case 'TUVMag'
            fileFilter = 'TUV\*Anatomy*';
        case 'Magnitude & Phase'
            fileFilter = 'Thermometry\*Raw*';
        case 'Anatomy'
            fileFilter = 'Thermometry\*Anatomy*';
    end
    

    if contains(TxParameters.Manufacturer,'GE')
        % If Magnitude and Phase are required, use the two outputs version of the function
        % Saving matrices //output RE/IM matrices for GE
       
        if strcmp(type,'Magnitude & Phase')
            [outputMatrix,Im] = ReadData(pathSegment,fileFilter,TxParameters.ImageNumber(end),'GE');

        elseif strcmp(type,'TUVMag') || strcmp(type,'TUV')
            outputMatrix = ReadData(pathSegment,fileFilter);
        else
            outputMatrix = ReadData(pathSegment,fileFilter,TxParameters.ImageNumber(end));
        end

        fprintf('Saving... ')
        
        if strcmp(type,'Magnitude & Phase')
            tmpStruct.Re = outputMatrix;
            save(fullfile(pathPEDASegment,'Re.mat'),'-struct','tmpStruct');
            tmpStruct = rmfield(tmpStruct,'Re');

            tmpStruct.Im = Im;
            save(fullfile(pathPEDASegment,'Im.mat'),'-struct','tmpStruct');

            Magnitude = abs(outputMatrix + Im * i);
            tmpStruct.Magnitude = Magnitude;
            save(fullfile(pathPEDASegment, 'Magnitude.mat'), 'Magnitude');

            Phase = atan2(Im, outputMatrix);
            tmpStruct.Phase = Phase;
            save(fullfile(pathPEDASegment, 'Phase.mat'), 'Phase');

        else
            % Trick to save matrix with the name type (e.g 'TMap.mat')
            tmpStruct.(type) = outputMatrix;
            save(fullfile(pathPEDASegment,[type '.mat']),'-struct','tmpStruct');
        end
    else    

        % If Magnitude and Phase are required, use the two outputs version of the function
        % Saving matrices // Siemens or Philips
        if strcmp(type,'Magnitude & Phase')
            [outputMatrix,Phase] = ReadData(pathSegment,fileFilter,TxParameters.ImageNumber(end),'SP');

        elseif strcmp(type,'TUVMag') || strcmp(type,'TUV')
            outputMatrix = ReadData(pathSegment,fileFilter);
        else
            outputMatrix = ReadData(pathSegment,fileFilter,TxParameters.ImageNumber(end));
        end

        fprintf('Saving... ')
        if strcmp(type,'Magnitude & Phase')
            tmpStruct.Magnitude = outputMatrix;
            save(fullfile(pathPEDASegment,'Magnitude.mat'),'-struct','tmpStruct');
            tmpStruct = rmfield(tmpStruct,'Magnitude');
            tmpStruct.Phase = Phase;
            save(fullfile(pathPEDASegment,'Phase.mat'),'-struct','tmpStruct');
        else
            % Trick to save matrix with the name type (e.g 'TMap.mat')
            tmpStruct.(type) = outputMatrix;
            save(fullfile(pathPEDASegment,[type '.mat']),'-struct','tmpStruct');
        end
    end
end
fprintf('\b\b\b\b\b\b\b\b\b\b') % Erase console output
end


